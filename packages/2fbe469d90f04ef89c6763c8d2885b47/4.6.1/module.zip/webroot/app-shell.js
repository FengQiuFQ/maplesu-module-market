(() => {
  'use strict';
  const handlers = new Map(), tasks = new Map(), flows = new Set();
  const valid = new Set(['terminal', 'files', 'automation']);
  let current = null, navigation = 0, started = false, taskExpiry = new Map();
  const ui = () => window.SKUiUtils;
  function renderIcons(root = document) {
    if (!window.SKIcons) return;
    for (const target of root.querySelectorAll('[data-icon]')) {
      if (target.querySelector('svg')) continue;
      target.insertAdjacentHTML('afterbegin', window.SKIcons.icon(target.dataset.icon, 19));
    }
  }
  function updateChrome() {
    for (const button of document.querySelectorAll('[data-nav-view]')) {
      const selected = button.dataset.navView === current;
      button.classList.toggle('active', selected);
      if (selected) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
    }
    document.body.dataset.activeView = current || 'terminal';
    document.body.classList.toggle('has-flow', flows.size > 0);
    renderTasks();
  }
  async function navigate(view, context = {}) {
    if (!valid.has(view)) throw new Error('Unknown view');
    const ticket = ++navigation, previous = current;
    if (previous !== view && previous && await handlers.get(previous)?.beforeLeave?.({ to: view, ...context }) === false) return false;
    if (ticket !== navigation) return false;
    if (previous !== view) {
      handlers.get(previous)?.deactivate?.({ to: view });
      for (const root of document.querySelectorAll('.app-view[data-view]')) {
        const visible = root.dataset.view === view;
        root.hidden = !visible; root.inert = !visible; root.classList.toggle("show", visible);
        root.setAttribute('aria-hidden', String(!visible));
      }
      current = view;
      updateChrome();
    }
    try { await handlers.get(view)?.activate?.({ from: previous, ...context }); }
    catch (error) { ui()?.showToast(error?.message || '页面加载失败', 2200); }
    if (ticket !== navigation) return false;
    renderIcons();
    document.dispatchEvent(new CustomEvent('sk:viewchange', { detail: { view, from: previous } }));
    return true;
  }
  function renderTasks() {
    const target = document.getElementById('appTasks');
    if (!target) return;
    target.replaceChildren();
    for (const [id, task] of tasks) {
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'app-task'; button.dataset.task = id;
      button.dataset.state = task.state || (task.active ? 'running' : 'completed');
      button.setAttribute('aria-label', [task.label, task.detail, '查看任务'].filter(Boolean).join('，'));
      const dot = document.createElement('span'); dot.className = 'task-dot';
      const label = document.createElement('span'); label.className = 'app-task-label'; label.textContent = task.label || '任务';
      const progress = document.createElement('span'); progress.className = 'app-task-progress';
      progress.textContent = task.active && Number.isFinite(task.progress) ? `${Math.round(task.progress)}%` : task.active ? '进行中' : task.state === 'failed' ? '失败' : '完成';
      button.append(dot, label, progress);
      button.onclick = async () => { if (await navigate(task.view || id)) await task.resume?.(); };
      target.append(button);
    }
    target.hidden = tasks.size === 0;
    document.body.classList.toggle('has-tasks', tasks.size > 0);
  }
  function setTask(id, task) {
    clearTimeout(taskExpiry.get(id));
    if (!task) { tasks.delete(id); renderTasks(); return; }
    const previous = tasks.get(id);
    if (!task.active && !task.state && !task.resume) { tasks.delete(id); renderTasks(); return; }
    tasks.set(id, { ...task });
    if (!task.active && !task.resume) taskExpiry.set(id, setTimeout(() => { tasks.delete(id); renderTasks(); }, 5000));
    // Announce completion once, without navigating away from the user's work.
    if (previous?.active && !task.active) ui()?.showToast(task.state === 'failed' ? task.label || '任务失败' : task.label || '任务完成', 1800);
    renderTasks();
  }
  function back() { return handlers.get(current)?.back?.() || false; }
  function start() {
    if (started) return; started = true;
    renderIcons();
    for (const button of document.querySelectorAll('[data-nav-view]')) button.addEventListener('click', () => navigate(button.dataset.navView));
    document.getElementById('terminalSettingsBtn')?.addEventListener('click', () => ui().showModal(document.getElementById('terminalSettingsModal')));
    document.getElementById('terminalSettingsClose')?.addEventListener('click', () => ui().hideModal(document.getElementById('terminalSettingsModal')));
    document.getElementById('terminalShortcutsBtn')?.addEventListener('click', event => {
      const panel = document.getElementById('terminalShortcuts'); panel.hidden = !panel.hidden;
      event.currentTarget.setAttribute('aria-expanded', String(!panel.hidden));
    });
    document.addEventListener('sk:overlaychange', event => document.body.classList.toggle('has-overlay', !!event.detail?.open));
    navigate('terminal');
  }
  window.SKAppShell = {
    register(view, callbacks) { if (!valid.has(view)) throw new Error('Unknown view'); handlers.set(view, callbacks); },
    navigate, start, back, setTask, renderIcons,
    setFlow(id, active) { if (active) flows.add(id); else flows.delete(id); updateChrome(); },
    get activeView() { return current; },
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true }); else queueMicrotask(start);
})();

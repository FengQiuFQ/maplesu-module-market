(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.SKAutomationModel = api;
})(typeof globalThis !== "undefined" ? globalThis : this, () => {
  const MAX_SCHEMES = 50;
  const MAX_FAVORITES = 6;
  const MAX_STEPS = 100;
  const MAX_INPUTS = 32;

  function makeId(prefix = "id") {
    const bytes = new Uint8Array(10);
    if (globalThis.crypto?.getRandomValues) globalThis.crypto.getRandomValues(bytes);
    else for (let index = 0; index < bytes.length; index += 1) bytes[index] = Math.floor(Math.random() * 256);
    return `${prefix}_${Array.from(bytes, value => value.toString(16).padStart(2, "0")).join("")}`;
  }

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function formatArgs(args = []) {
    return args.map(value => "'" + String(value).replace(/'/g, "'\\''") + "'").join(' ');
  }

  function parseArgsText(value) {
    const args = []; let current = '', quote = null, escape = false;
    for (const character of String(value || '').trim()) {
      if (escape) { current += character; escape = false; continue; }
      if (quote === '"') { if (character === '\\') escape = true; else if (character === '"') quote = null; else current += character; continue; }
      if (quote === "'") { if (character === "'") quote = null; else current += character; continue; }
      if (/\s/.test(character)) { if (current) { args.push(current); current = ''; } continue; }
      if (character === '"' || character === "'") quote = character;
      else if (character === '\\') escape = true;
      else current += character;
    }
    if (escape) current += '\\';
    if (quote) throw new Error('参数引号未闭合');
    if (current) args.push(current);
    return args;
  }

  function parseSecondsText(value, positive = false) {
    const text = String(value ?? '').trim();
    if (!/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(text)) throw new Error('请输入有效的十进制秒数');
    const seconds = Number(text), milliseconds = Math.round(seconds * 1000);
    if (!Number.isFinite(seconds) || seconds > 86400 || (positive && milliseconds <= 0)) throw new Error(positive ? '等待时间须大于 0 且不超过 86400 秒' : '延时须为 0 到 86400 秒');
    return milliseconds / 1000;
  }

  function normalizeInput(value = {}) {
    return {
      id: String(value.id || makeId("input")),
      afterSec: Math.min(86400, Math.max(0, Number(value.afterSec) || 0)),
      ...(Object.hasOwn(value, 'afterSecText') ? { afterSecText: String(value.afterSecText ?? '') } : {}),
      text: String(value.text || ""),
      appendEnter: value.appendEnter !== false,
    };
  }

  function normalizeStep(value = {}) {
    const type = ["script", "command", "wait"].includes(value.type) ? value.type : "command";
    const step = { id: String(value.id || makeId("step")), type };
    if (type === "script") {
      step.path = String(value.path || "");
      step.args = Array.isArray(value.args) ? value.args.map(item => String(item)) : [];
      if (Object.hasOwn(value, 'argsText')) step.argsText = String(value.argsText ?? '');
      step.inputs = (Array.isArray(value.inputs) ? value.inputs : []).slice(0, MAX_INPUTS).map(normalizeInput);
    } else if (type === "command") {
      step.command = String(value.command || "");
      step.inputs = (Array.isArray(value.inputs) ? value.inputs : []).slice(0, MAX_INPUTS).map(normalizeInput);
    } else {
      step.seconds = Math.min(86400, Math.max(0, Number(value.seconds) || 0));
      if (Object.hasOwn(value, 'secondsText')) step.secondsText = String(value.secondsText ?? '');
    }
    return step;
  }

  function normalizeDraft(value = {}) {
    return {
      schemeId: value.schemeId ? String(value.schemeId) : null,
      name: String(value.name || ""),
      failurePolicy: value.failurePolicy === "continue" ? "continue" : "stop",
      steps: (Array.isArray(value.steps) ? value.steps : []).slice(0, MAX_STEPS).map(normalizeStep),
    };
  }

  function normalizeScheme(value = {}) {
    const draft = normalizeDraft(value);
    return {
      id: String(value.id || makeId("scheme")),
      name: String(value.name || "").trim(),
      favorite: value.favorite === true,
      failurePolicy: draft.failurePolicy,
      createdAtMs: Number(value.createdAtMs) || Date.now(),
      updatedAtMs: Number(value.updatedAtMs) || Date.now(),
      steps: draft.steps,
    };
  }

  function normalizeConfig(value = {}) {
    return {
      revision: Math.max(0, Number(value.revision) || 0),
      draft: normalizeDraft(value.draft),
      schemes: (Array.isArray(value.schemes) ? value.schemes : []).slice(0, MAX_SCHEMES).map(normalizeScheme),
    };
  }

  function stepLabel(step, index = 0) {
    if (step.type === "script") return step.path.split("/").filter(Boolean).pop() || `脚本 ${index + 1}`;
    if (step.type === "wait") return `等待 ${step.seconds || 0} 秒`;
    const firstLine = String(step.command || "").trim().split("\n")[0];
    return firstLine || `命令 ${index + 1}`;
  }

  function validateStorage(config) {
    const names = new Set();
    for (const scheme of config.schemes) {
      if (!scheme.name.trim()) throw new Error('方案名称不能为空');
      if (names.has(scheme.name.trim())) throw new Error('方案名称已存在，请换一个名称');
      names.add(scheme.name.trim());
      if (new TextEncoder().encode(scheme.name).length > 256) throw new Error('方案名称过长');
      for (const step of scheme.steps) {
        for (const raw of [step.argsText, step.secondsText, ...(step.inputs || []).map(input => input.afterSecText)]) {
          if (raw !== undefined && new TextEncoder().encode(raw).length > 8192) throw new Error('输入内容超过保存长度限制');
        }
      }
    }
    return true;
  }

  function validateRunnable(scheme) {
    if (!scheme?.steps.length) throw new Error('请至少添加一个步骤');
    for (const [index, step] of scheme.steps.entries()) {
      try {
        if (step.type === 'command' && !String(step.command || '').trim()) throw new Error('命令为空');
        if (step.type === 'script') {
          if (!String(step.path || '').startsWith('/')) throw new Error('脚本需要绝对路径');
          if (step.argsText !== undefined) parseArgsText(step.argsText);
        }
        if (step.type === 'wait') parseSecondsText(step.secondsText ?? String(step.seconds), true);
        for (const input of step.inputs || []) parseSecondsText(input.afterSecText ?? String(input.afterSec));
      } catch (error) { throw new Error(`第 ${index + 1} 步：${error.message}`); }
    }
    return true;
  }

  class AutomationModel {
    constructor(config = {}) {
      this.config = normalizeConfig(config);
    }

    setConfig(config) { this.config = normalizeConfig(config); }
    snapshot() { return clone(this.config); }
    get draft() { return this.config.draft; }
    get schemes() { return this.config.schemes; }
    favorites() { return this.schemes.filter(item => item.favorite).slice(0, MAX_FAVORITES); }

    uniqueName(base = '未命名方案', excludeId = '') {
      let name = base, suffix = 2;
      while (this.schemes.some(item => item.id !== excludeId && item.name === name)) name = `${base} ${suffix++}`;
      return name;
    }

    createScheme() {
      if (this.schemes.length >= MAX_SCHEMES) throw new Error('最多保存 50 个方案');
      const scheme = normalizeScheme({ id: makeId('scheme'), name: this.uniqueName(), steps: [] });
      this.schemes.unshift(scheme);
      this.loadScheme(scheme.id);
      return scheme;
    }

    syncDraft() {
      let scheme = this.schemes.find(item => item.id === this.draft.schemeId);
      if (!scheme) {
        if (!this.draft.name && !this.draft.steps.length) return null;
        if (this.schemes.length >= MAX_SCHEMES) throw new Error('最多保存 50 个方案');
        scheme = normalizeScheme({ id: makeId('scheme'), name: this.uniqueName(), steps: [] });
        this.schemes.unshift(scheme);
        this.draft.schemeId = scheme.id;
      }
      scheme.name = this.draft.name.trim() || this.uniqueName('未命名方案', scheme.id);
      scheme.failurePolicy = this.draft.failurePolicy;
      scheme.steps = clone(this.draft.steps);
      scheme.updatedAtMs = Date.now();
      return scheme;
    }

    addStep(type, value = {}) {
      if (this.draft.steps.length >= MAX_STEPS) throw new Error("每个方案最多 100 个步骤");
      const step = normalizeStep({ ...value, id: makeId("step"), type });
      this.draft.steps.push(step);
      this.syncDraft();
      return step;
    }

    appendScript(path, args = []) {
      return this.addStep("script", { path, args, inputs: [] });
    }

    removeStep(index) {
      if (index < 0 || index >= this.draft.steps.length) return false;
      this.draft.steps.splice(index, 1);
      this.syncDraft();
      return true;
    }

    moveStep(from, to) {
      if (from < 0 || from >= this.draft.steps.length || to < 0 || to >= this.draft.steps.length || from === to) return false;
      const [step] = this.draft.steps.splice(from, 1);
      this.draft.steps.splice(to, 0, step);
      this.syncDraft();
      return true;
    }

    duplicateStep(index) {
      if (this.draft.steps.length >= MAX_STEPS) throw new Error("每个方案最多 100 个步骤");
      const source = this.draft.steps[index];
      if (!source) return null;
      const copy = normalizeStep({ ...clone(source), id: makeId("step") });
      copy.inputs = (copy.inputs || []).map(input => ({ ...input, id: makeId("input") }));
      this.draft.steps.splice(index + 1, 0, copy);
      this.syncDraft();
      return copy;
    }

    addInput(stepIndex) {
      const step = this.draft.steps[stepIndex];
      if (!step || step.type === "wait") return null;
      if (step.inputs.length >= MAX_INPUTS) throw new Error("每个步骤最多 32 条自动输入");
      const input = normalizeInput({ id: makeId("input") });
      step.inputs.push(input);
      this.syncDraft();
      return input;
    }

    removeInput(stepIndex, inputIndex) {
      const inputs = this.draft.steps[stepIndex]?.inputs;
      if (!inputs || inputIndex < 0 || inputIndex >= inputs.length) return false;
      inputs.splice(inputIndex, 1);
      this.syncDraft();
      return true;
    }

    loadScheme(id) {
      const scheme = this.schemes.find(item => item.id === id);
      if (!scheme) return false;
      this.config.draft = normalizeDraft({
        schemeId: scheme.id,
        name: scheme.name,
        failurePolicy: scheme.failurePolicy,
        steps: clone(scheme.steps),
      });
      return true;
    }

    saveDraft(name, copyMode = false) {
      const normalizedName = String(name || "").trim();
      if (!normalizedName) throw new Error("方案名称不能为空");
      const existingName = this.schemes.find(item => item.name === normalizedName && item.id !== this.draft.schemeId);
      if (existingName) throw new Error("方案名称已存在");
      const now = Date.now();
      let scheme = !copyMode && this.draft.schemeId ? this.schemes.find(item => item.id === this.draft.schemeId) : null;
      if (!scheme) {
        if (this.schemes.length >= MAX_SCHEMES) throw new Error("最多保存 50 个方案");
        scheme = normalizeScheme({ id: makeId("scheme"), name: normalizedName, createdAtMs: now, updatedAtMs: now });
        this.schemes.unshift(scheme);
      }
      scheme.name = normalizedName;
      scheme.failurePolicy = this.draft.failurePolicy;
      scheme.steps = clone(this.draft.steps).map(normalizeStep);
      scheme.updatedAtMs = now;
      this.draft.schemeId = scheme.id;
      this.draft.name = normalizedName;
      return scheme;
    }

    deleteScheme(id) {
      const index = this.schemes.findIndex(item => item.id === id);
      if (index < 0) return false;
      this.schemes.splice(index, 1);
      if (this.draft.schemeId === id) this.config.draft = normalizeDraft();
      return true;
    }

    restoreScheme(value, index = 0) {
      if (this.schemes.some(item => item.id === value.id)) throw new Error('方案已存在，未重复恢复');
      if (this.schemes.length >= MAX_SCHEMES) throw new Error('方案已达 50 个，无法恢复；请先移除一个方案');
      const restored = normalizeScheme(clone(value));
      if (this.schemes.some(item => item.name === restored.name)) {
        const base = Array.from(restored.name);
        do { restored.name = this.uniqueName(`${base.join('')} 恢复`); }
        while (new TextEncoder().encode(restored.name).length > 256 && base.pop() !== undefined);
      }
      if (restored.favorite && this.favorites().length >= MAX_FAVORITES) restored.favorite = false;
      restored.updatedAtMs = Date.now();
      this.schemes.splice(Math.max(0, Math.min(index, this.schemes.length)), 0, restored);
      return restored;
    }

    restoreStep(ownerId, value, index = 0) {
      const owner = this.schemes.find(item => item.id === ownerId);
      if (!owner) throw new Error('原方案已删除，无法恢复步骤');
      const steps = this.draft.schemeId === ownerId ? this.draft.steps : owner.steps;
      if (steps.some(item => item.id === value.id)) throw new Error('步骤已存在，未重复恢复');
      if (steps.length >= MAX_STEPS) throw new Error('步骤已达 100 个，无法恢复；请先移除一个步骤');
      const restored = normalizeStep(clone(value));
      steps.splice(Math.max(0, Math.min(index, steps.length)), 0, restored);
      if (this.draft.schemeId === ownerId) this.syncDraft();
      else owner.updatedAtMs = Date.now();
      return restored;
    }

    duplicateScheme(id) {
      const source = this.schemes.find(item => item.id === id);
      if (!source) return null;
      if (this.schemes.length >= MAX_SCHEMES) throw new Error("最多保存 50 个方案");
      let name = `${source.name} 副本`;
      let suffix = 2;
      while (this.schemes.some(item => item.name === name)) name = `${source.name} 副本 ${suffix++}`;
      const copy = normalizeScheme({ ...clone(source), id: makeId("scheme"), name, favorite: false, createdAtMs: Date.now(), updatedAtMs: Date.now() });
      this.schemes.unshift(copy);
      this.loadScheme(copy.id);
      return copy;
    }

    renameScheme(id, name) {
      const normalizedName = String(name || "").trim();
      if (!normalizedName) throw new Error("方案名称不能为空");
      if (this.schemes.some(item => item.id !== id && item.name === normalizedName)) throw new Error("方案名称已存在");
      const scheme = this.schemes.find(item => item.id === id);
      if (!scheme) return false;
      scheme.name = normalizedName;
      scheme.updatedAtMs = Date.now();
      if (this.draft.schemeId === id) this.draft.name = normalizedName;
      return true;
    }

    toggleFavorite(id) {
      const scheme = this.schemes.find(item => item.id === id);
      if (!scheme) return false;
      if (!scheme.favorite && this.favorites().length >= MAX_FAVORITES) throw new Error("最多收藏 6 个方案");
      scheme.favorite = !scheme.favorite;
      scheme.updatedAtMs = Date.now();
      return scheme.favorite;
    }
  }

  return {
    AutomationModel,
    normalizeConfig,
    normalizeDraft,
    normalizeStep,
    normalizeInput,
    stepLabel,
    makeId,
    formatArgs,
    parseArgsText,
    parseSecondsText,
    validateStorage,
    validateRunnable,
    MAX_SCHEMES,
    MAX_FAVORITES,
    MAX_STEPS,
    MAX_INPUTS,
  };
});

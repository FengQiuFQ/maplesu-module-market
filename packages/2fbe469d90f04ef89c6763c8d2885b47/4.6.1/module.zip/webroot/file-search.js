(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.SKFileSearch = api;
})(typeof window === 'object' ? window : globalThis, function () {
  'use strict';
  const MAX_RESULTS = 2000, PAGE_SIZE = 100;
  const active = state => state.starting || state.status === 'searching';

  function validateSearch(path, query) {
    path = String(path || '').trim(); query = String(query || '').trim();
    if (!path.startsWith('/') || path.includes('\0')) throw new Error('请输入完整的绝对目录路径');
    const parts = [];
    for (const part of path.split('/')) {
      if (!part || part === '.') continue;
      if (part === '..') parts.pop(); else parts.push(part);
    }
    path = '/' + parts.join('/');
    if (path === '/') throw new Error('请选择具体目录，不能从根目录 / 搜索');
    if (!query) throw new Error('请输入要搜索的文件名');
    if (query.includes('\0') || new TextEncoder().encode(query).length > 256) {
      throw new Error('文件名关键词不能超过 256 字节');
    }
    return { path, query };
  }

  // A delayed start reply must still be cancelled when its panel is closing.
  function createController({ api, render = () => {}, onNavigate = async () => {},
    setTimer = setTimeout, clearTimer = clearTimeout }) {
    let state = { opened: false, status: 'idle', starting: false, closing: false,
      cancelling: false, path: '', query: '', id: '', visited: 0, skipped: 0,
      totalMatches: 0, truncated: false, currentPath: '', items: [], nextOffset: 0,
      hasMore: false, error: '', context: null };
    let timer = null, epoch = 0, pollingEpoch = null, starting = null, closing = null;
    let cancelRequest = null;
    const publish = () => render(state);
    function stopTimer() { clearTimer(timer); timer = null; }
    function schedule(delay = 400) {
      stopTimer();
      if (state.opened && !state.closing && (state.status === 'searching' || state.hasMore)) {
        timer = setTimer(() => { timer = null; void poll(); }, delay);
      }
    }
    function summary(data) {
      state.status = data.state || state.status;
      for (const key of ['visited', 'skipped', 'totalMatches']) {
        if (Number.isFinite(Number(data[key]))) state[key] = Math.max(0, Number(data[key]));
      }
      state.truncated = !!data.truncated;
      state.currentPath = data.currentPath || '';
      if (data.error?.message) state.error = data.error.message;
      if (state.status !== 'searching') state.cancelling = false;
    }
    async function poll() {
      if (pollingEpoch === epoch || !state.opened || state.closing || !state.id) return;
      const ticket = epoch, id = state.id, offset = state.nextOffset;
      pollingEpoch = ticket;
      try {
        const data = await api.getFileSearch(id, offset, PAGE_SIZE);
        if (ticket !== epoch || !state.opened || state.closing) return;
        summary(data);
        const items = Array.isArray(data.items) ? data.items : [];
        const next = Number(data.nextOffset);
        if (!Number.isSafeInteger(next) || next < offset || next !== offset + items.length
            || next > MAX_RESULTS || data.hasMore && !items.length) {
          throw new Error('搜索分页结果异常，请重新搜索');
        }
        const known = new Set(state.items.map(item => item.path));
        for (const item of items) {
          if (item.type !== 'file' || typeof item.path !== 'string' || !item.path.startsWith('/')
              || typeof item.parent !== 'string' || !item.parent.startsWith('/')) continue;
          if (!known.has(item.path)) { known.add(item.path); state.items.push(item); }
        }
        state.nextOffset = next; state.hasMore = !!data.hasMore;
        state.error = data.error?.message || ''; publish();
        schedule(state.hasMore ? 30 : 400);
      } catch (error) {
        if (ticket !== epoch || !state.opened || state.closing) return;
        state.error = error?.message || '获取搜索进度失败'; publish();
        // Preserve controls after a transient failure so the user can stop it.
        schedule(1500);
      } finally { if (pollingEpoch === ticket) pollingEpoch = null; }
    }
    async function start(path, query) {
      if (active(state) || state.closing) return false;
      let input;
      try { input = validateSearch(path, query); }
      catch (error) { state.error = error.message; publish(); return false; }
      stopTimer(); const ticket = ++epoch;
      state = { ...state, ...input, starting: true, status: 'idle', id: '',
        cancelling: false, items: [], nextOffset: 0, hasMore: false, error: '',
        visited: 0, skipped: 0, totalMatches: 0, truncated: false, currentPath: '' };
      publish();
      starting = (async () => {
        try {
          const data = await api.startFileSearch(input.path, input.query);
          if (!data?.id) throw new Error('搜索任务未返回有效 ID');
          if (ticket !== epoch) {
            await api.cancelFileSearch(data.id, { keepalive: true }); return false;
          }
          state.id = data.id; summary(data);
          if (state.status === 'idle') state.status = 'searching';
          state.starting = false; state.hasMore = true; publish(); schedule(0); return true;
        } catch (error) {
          if (ticket === epoch) {
            state.status = 'failed'; state.starting = false;
            state.error = error?.message || '搜索启动失败'; publish();
          }
          return false;
        }
      })();
      try { return await starting; } finally { starting = null; }
    }
    async function cancel() {
      if (cancelRequest) return cancelRequest;
      if (!active(state)) return true;
      state.cancelling = true; stopTimer(); publish();
      cancelRequest = (async () => {
        if (starting) await starting;
        if (!state.id || state.status !== 'searching') return true;
        ++epoch;
        const id = state.id;
        try {
          const data = await api.cancelFileSearch(id, { keepalive: true });
          if (state.id === id) { summary(data); state.hasMore = true; state.error = ''; publish(); schedule(0); }
          return true;
        } catch (error) {
          state.cancelling = false; state.error = error?.message || '停止搜索失败，请重试';
          publish(); schedule(1500); return false;
        }
      })();
      try { return await cancelRequest; } finally { cancelRequest = null; }
    }
    async function close() {
      if (closing) return closing;
      if (!state.opened) return true;
      state.closing = true; stopTimer(); publish();
      closing = (async () => {
        if (!(await cancel())) { state.closing = false; publish(); schedule(400); return false; }
        stopTimer(); ++epoch;
        state.opened = false; state.closing = false; state.starting = false;
        publish(); return true;
      })();
      try { return await closing; } finally { closing = null; }
    }
    function open(path, context) {
      if (state.opened) return;
      state = { ...state, opened: true, status: 'idle', path, query: '', id: '',
        closing: false, cancelling: false, starting: false, visited: 0, skipped: 0,
        totalMatches: 0, truncated: false, currentPath: '', items: [], nextOffset: 0,
        hasMore: false, error: '', context };
      ++epoch; publish();
    }
    async function select(index) {
      const item = state.items[index], context = state.context;
      if (item && !state.closing && await close()) await onNavigate(item, context);
    }
    function leavePage() { stopTimer(); void close(); }
    return { open, start, poll, cancel, close, select, leavePage, get state() { return state; } };
  }

  function create({ api, onNavigate }) {
    const ui = window.SKUiUtils, icons = window.SKIcons;
    if (!document.getElementById('fileSearchStyles')) {
      const link = document.createElement('link');
      link.id = 'fileSearchStyles'; link.rel = 'stylesheet'; link.href = 'file-search.css';
      document.head.append(link);
    }
    const root = document.createElement('div');
    root.id = 'fileSearchModal'; root.className = 'modal-wrap fm-search-wrap';
    root.innerHTML = [
      '<section class="modal fm-search-panel" aria-labelledby="fileSearchTitle">',
      '<header class="modal-title"><span id="fileSearchTitle">搜索文件</span>',
      '<button id="fileSearchClose" class="icon-action" data-close-modal type="button" aria-label="关闭搜索"></button></header>',
      '<div class="modal-body fm-search-body"><form id="fileSearchForm" class="fm-search-form">',
      '<label for="fileSearchPath">搜索目录</label><input id="fileSearchPath" type="text" autocomplete="off" spellcheck="false" enterkeyhint="next" placeholder="例如 /sdcard/Download">',
      '<label for="fileSearchQuery">文件名包含</label><div class="fm-search-query-row">',
      '<input id="fileSearchQuery" type="text" autocomplete="off" spellcheck="false" maxlength="256" enterkeyhint="search" placeholder="输入部分文件名">',
      '<button id="fileSearchStart" class="m-btn m-exec" type="submit">搜索</button></div></form>',
      '<p class="fm-search-help">包含子目录，英文字母不区分大小写；不跟随符号链接、不跨文件系统。最多显示 2,000 项，不支持根目录 /。</p>',
      '<div id="fileSearchError" class="fm-search-error" role="alert" hidden></div>',
      '<div class="fm-search-progress"><div class="fm-search-summary" role="status" aria-live="polite"><strong id="fileSearchState">等待搜索</strong><span id="fileSearchCount"></span></div>',
      '<button id="fileSearchStop" class="m-btn" type="button" hidden>停止</button></div>',
      '<div id="fileSearchCurrent" class="fm-search-current" hidden></div>',
      '<div id="fileSearchLimit" class="fm-search-limit" hidden>已达到 2,000 项上限，请缩小目录范围或使用更具体的文件名。</div>',
      '<p class="fm-search-result-hint">点击结果，定位到所在目录</p>',
      '<div id="fileSearchResults" class="fm-search-results" role="list" aria-label="匹配文件"></div>',
      '<div id="fileSearchEmpty" class="fm-search-empty">输入文件名开始搜索</div>',
      '</div></section>'
    ].join('');
    document.body.append(root);
    const get = id => root.querySelector('#' + id);
    const el = { path: get('fileSearchPath'), query: get('fileSearchQuery'), start: get('fileSearchStart'),
      close: get('fileSearchClose'), stop: get('fileSearchStop'), form: get('fileSearchForm'),
      state: get('fileSearchState'), count: get('fileSearchCount'), error: get('fileSearchError'),
      current: get('fileSearchCurrent'), limit: get('fileSearchLimit'),
      results: get('fileSearchResults'), empty: get('fileSearchEmpty') };
    el.close.innerHTML = icons.icon('x', 20);
    let wasOpen = false, renderedId = '', renderedCount = 0;
    const controller = createController({ api, onNavigate, render(state) {
      if (state.opened) ui.showModal(root); else ui.hideModal(root);
      if (state.opened && !wasOpen) { el.path.value = state.path; el.query.value = state.query; }
      wasOpen = state.opened;
      const running = active(state);
      el.path.disabled = el.query.disabled = el.start.disabled = running || state.closing;
      el.close.disabled = state.closing;
      el.close.title = running ? '关闭并停止搜索' : '关闭搜索';
      el.start.textContent = state.starting ? '启动中…' : state.id ? '重新搜索' : '搜索';
      el.stop.hidden = !running; el.stop.disabled = state.cancelling || state.closing;
      el.stop.textContent = state.cancelling ? '正在停止…' : '停止';
      el.state.textContent = state.closing ? '正在停止并关闭…' : state.starting ? '正在启动…'
        : state.cancelling ? '正在停止…' : ({ idle: '等待搜索', searching: '正在搜索',
          completed: '搜索完成', cancelled: '搜索已停止', failed: '搜索失败' })[state.status] || '搜索中';
      el.count.textContent = state.id ? '已检查 ' + state.visited.toLocaleString() + ' 项 · 找到 '
        + state.totalMatches.toLocaleString() + ' 项 · 已显示 ' + state.items.length.toLocaleString()
        + ' 项' + (state.skipped ? ' · 跳过 ' + state.skipped.toLocaleString() + ' 项' : '') : '';
      el.error.hidden = !state.error; el.error.textContent = state.error;
      el.current.hidden = !state.currentPath || !running;
      el.current.textContent = state.currentPath; el.current.title = state.currentPath;
      el.limit.hidden = !state.truncated;
      if (renderedId !== state.id || renderedCount > state.items.length) {
        el.results.replaceChildren(); renderedId = state.id; renderedCount = 0;
      }
      const fragment = document.createDocumentFragment();
      for (; renderedCount < state.items.length; renderedCount++) {
        const item = state.items[renderedCount], row = document.createElement('button');
        row.type = 'button'; row.className = 'fm-search-result'; row.dataset.index = renderedCount;
        row.setAttribute('role', 'listitem'); row.title = item.path;
        row.setAttribute('aria-label', '定位到 ' + item.path);
        const icon = document.createElement('span'); icon.className = 'fm-search-result-icon';
        icon.innerHTML = icons.icon('file', 20);
        const info = document.createElement('span'); info.className = 'fm-search-result-info';
        const name = document.createElement('strong'); name.textContent = item.name || item.path.split('/').pop();
        const parent = document.createElement('span'); parent.textContent = item.parent;
        const size = document.createElement('span'); size.className = 'fm-search-result-size';
        size.textContent = ui.formatBytes(item.size);
        info.append(name, parent); row.append(icon, info, size); fragment.append(row);
      }
      el.results.append(fragment);
      el.results.hidden = !state.items.length; el.empty.hidden = !!state.items.length;
      el.empty.textContent = state.status === 'completed' ? '没有找到匹配文件'
        : state.status === 'cancelled' ? '搜索已停止，尚未找到匹配文件'
        : state.status === 'failed' ? '搜索未能完成，可重新搜索'
        : running ? '正在查找文件，可随时停止' : '输入文件名开始搜索';
    } });
    el.form.onsubmit = event => { event.preventDefault(); void controller.start(el.path.value, el.query.value); };
    el.close.onclick = () => { void controller.close(); };
    el.stop.onclick = () => { void controller.cancel(); };
    el.results.onclick = event => {
      const row = event.target.closest('.fm-search-result');
      if (row) void controller.select(Number(row.dataset.index)).catch(error => ui.showToast(error?.message || '目录定位失败', 2200));
    };
    root.onclick = event => { if (event.target === root) void controller.close(); };
    window.addEventListener('pagehide', controller.leavePage);
    return controller;
  }
  return { create, createController, validateSearch, MAX_RESULTS, PAGE_SIZE };
});

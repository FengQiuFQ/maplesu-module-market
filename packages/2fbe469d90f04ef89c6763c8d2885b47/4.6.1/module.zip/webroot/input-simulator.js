(() => {
  const app = window.SKRootApp;
  const ui = window.SKUiUtils;
  const modelApi = window.SKAutomationModel;
  if (!app || !ui || !modelApi) return;

  const { cmd, sendBtn, sheetOverlay, quickActions } = app.elements;
  const { AutomationModel, normalizeStep, parseArgsText, parseSecondsText, validateStorage, validateRunnable } = modelApi;
  const terminalCore = window.SKTerminalCore;
  const composer = document.querySelector(".composer");

  const elements = {
    sheet: document.getElementById("autoSheet"),
    close: document.getElementById("autoClose"),
    draftState: document.getElementById("automationDraftState"),
    libraryTab: document.getElementById("automationLibraryTab"),
    editorTab: document.getElementById("automationEditorTab"),
    libraryView: document.getElementById("automationLibraryView"),
    editorView: document.getElementById("automationEditorView"),
    newScheme: document.getElementById("automationNewScheme"),
    schemeList: document.getElementById("automationSchemeList"),
    draftName: document.getElementById("automationDraftName"),
    failurePolicy: document.getElementById("automationFailurePolicy"),
    stepList: document.getElementById("autoList"),
    editorScroll: document.querySelector('.automation-editor-scroll'),
    stepCount: document.getElementById('automationStepCount'),
    addZone: document.querySelector(".automation-add-zone"),
    addStep: document.getElementById("automationAddStepBtn"),
    addMenu: document.getElementById("automationAddMenu"),
    copy: document.getElementById("automationCopy"),
    more: document.getElementById("automationMore"),
    stepModal: document.getElementById("automationStepModal"),
    stepTitle: document.getElementById("automationStepTitle"),
    stepFields: document.getElementById("automationStepFields"),
    stepClose: document.getElementById("automationStepClose"),
    execute: document.getElementById("autoExecBtn"),
    quickSchemes: document.getElementById("automationQuickSchemes"),
    runBar: document.getElementById("automationRunBar"),
    runName: document.getElementById("automationRunName"),
    runState: document.getElementById("automationRunState"),
    runProgress: document.getElementById("automationRunProgress"),
    runDetail: document.getElementById("automationRunDetail"),
  };



  const schemeAction = {
    modal: document.getElementById("automationSchemeActionModal"),
    title: document.getElementById("automationSchemeActionTitle"),
    target: document.getElementById("automationSchemeActionTarget"),
    run: document.getElementById("automationSchemeRun"),
    edit: document.getElementById("automationSchemeEdit"),
    favorite: document.getElementById("automationSchemeFavorite"),
    duplicate: document.getElementById("automationSchemeDuplicate"),
    delete: document.getElementById("automationSchemeDelete"),
    cancel: document.getElementById("automationSchemeActionCancel"),
  };

  const model = new AutomationModel();
  let loaded = false;
  let loadingConfig = null;
  let activeView = "library";
  let expandedStepId = null;
  let stepReturnTarget = null;
  const expandedInputGroups = new Set();
  let saveTimer = null;
  let saveQueue = null;
  let localVersion = 0, confirmedVersion = 0, confirmedRevision = 0;
  let inFlight = null, pausedSave = null, flushRequested = false;
  let validationBlockedVersion = -1, recoveryRemote = null;
  let pendingRun = null;
  let runStarting = false;
  let activeRun = null;
  let runPollTimer = null;
  let schemeActionId = "";
  let dragIndex = -1;
  let pointerDrag = null;
  let scriptPicker = null;

  const runStateNames = {
    idle: "空闲",
    preparing: "准备中",
    running: "执行中",
    completed: "执行完成",
    failed: "执行失败",
  };

  function safeAttr(value) { return ui.safeHtml(String(value ?? "")); }

  function serializeArgs(args) {
    return (Array.isArray(args) ? args : []).map(value => terminalCore.shellQuote(value)).join(" ");
  }

  function setDraftState(text, type = "") {
    elements.draftState.title = text;
    elements.draftState.setAttribute('aria-label', text);
    elements.draftState.innerHTML = window.SKIcons?.icon(type === 'error' ? 'alert-circle' : type === 'saving' ? 'cloud-upload' : 'cloud-check', 18) || '';
    elements.draftState.classList.toggle("saving", type === "saving");
    elements.draftState.classList.toggle("error", type === "error");
  }

  function closeSaveMenu() {}

  function setView(view) {
    activeView = view === "editor" ? "editor" : "library";
    closeSaveMenu();
    closeAddMenu();
    closeStepMenus();
    const editing = activeView === "editor";
    elements.libraryTab.classList.toggle("active", !editing);
    elements.editorTab.classList.toggle("active", editing);
    elements.libraryTab.setAttribute("aria-selected", String(!editing));
    elements.editorTab.setAttribute("aria-selected", String(editing));
    elements.libraryView.hidden = editing;
    elements.editorView.hidden = !editing;
    elements.newScheme.hidden = editing;
    elements.execute.hidden = !editing;
    if (elements.copy) elements.copy.hidden = !editing;
    if (elements.more) elements.more.hidden = !editing;
  }

  function closeAddMenu() {
    if (!elements.addMenu) return;
    elements.addMenu.hidden = true;
    elements.addMenu.removeAttribute('style');
    elements.addStep?.setAttribute("aria-expanded", "false");
  }

  function closeStepMenus() {
    for (const menu of elements.stepList.querySelectorAll('.automation-step-menu')) {
      menu.hidden = true;
      menu.removeAttribute('style');
    }
    for (const button of elements.stepList.querySelectorAll('[data-step-action="menu"]')) button.setAttribute('aria-expanded', 'false');
  }

  function positionMenu(menu, button) {
    const viewport = window.visualViewport;
    const top = (viewport?.offsetTop || 0) + 8;
    let bottom = top + (viewport?.height || window.innerHeight) - 16;
    const dock = document.querySelector('.app-dock')?.getBoundingClientRect();
    if (dock?.height) bottom = Math.min(bottom, dock.top - 8);
    const trigger = button.getBoundingClientRect();
    menu.style.position = 'fixed';
    menu.style.right = 'auto';
    menu.style.bottom = 'auto';
    menu.style.maxHeight = `${Math.max(44, bottom - top)}px`;
    const width = menu.getBoundingClientRect().width;
    const below = Math.max(0, bottom - trigger.bottom - 5);
    const above = Math.max(0, trigger.top - top - 5);
    const upward = menu.scrollHeight > below && above > below;
    menu.style.maxHeight = `${Math.max(44, upward ? above : below)}px`;
    const height = menu.getBoundingClientRect().height;
    menu.style.top = `${Math.max(top, upward ? trigger.top - height - 5 : Math.min(trigger.bottom + 5, bottom - height))}px`;
    menu.style.left = `${Math.max(8, Math.min(trigger.right - width, window.innerWidth - width - 8))}px`;
  }

  function stepSummary(step) {
    if (step.type === "wait") return `等待 ${step.secondsText ?? step.seconds ?? 0} 秒`;
    if (step.type === "script") return step.path || "选择脚本或填写完整路径";
    return String(step.command || "").trim().split("\n")[0] || "输入要执行的命令";
  }

  function updateStepSummary(card, step) {
    const summary = card?.querySelector('.automation-step-summary-text');
    if (summary) { summary.textContent = stepSummary(step); summary.title = summary.textContent; }
  }

  function rememberInputGroups() {
    for (const details of elements.stepFields.querySelectorAll('.automation-inputs')) {
      const id = elements.stepFields.dataset.stepId;
      if (details.open) expandedInputGroups.add(id); else expandedInputGroups.delete(id);
    }
  }
  function renderStepEditor(openInputId = null) {
    rememberInputGroups();
    if (openInputId) expandedInputGroups.add(openInputId);
    const index = model.draft.steps.findIndex(step => step.id === expandedStepId);
    if (index < 0) return closeStepEditor();
    const step = model.draft.steps[index];
    elements.stepTitle.textContent = `步骤 ${index + 1} · ${step.type === 'wait' ? '等待' : step.type === 'script' ? '运行脚本' : '执行命令'}`;
    elements.stepFields.dataset.stepIndex = String(index);
    elements.stepFields.dataset.stepId = step.id;
    elements.stepFields.innerHTML = stepBody(step, index);
  }
  function expandStep(stepId) {
    stepReturnTarget = { ownerId: model.draft.schemeId, stepId, index: model.draft.steps.findIndex(step => step.id === stepId) };
    expandedStepId = stepId;
    renderStepEditor();
    ui.showModal(elements.stepModal);
  }
  function closeStepEditor() {
    const wasOpen = elements.stepModal.classList.contains('show');
    const target = stepReturnTarget;
    stepReturnTarget = null;
    rememberInputGroups();
    ui.hideModal(elements.stepModal);
    expandedStepId = null;
    if (!wasOpen || !target) return;
    requestAnimationFrame(() => {
      if (window.SKAppShell.activeView !== 'automation' || activeView !== 'editor' || model.draft.schemeId !== target.ownerId) return;
      const overlayOpen = [...document.querySelectorAll('.modal-wrap.show, .fm-places-sheet.show, .text-editor.show, .image-viewer, .page-exit-overlay.show')]
        .some(element => !element.hidden && element.getAttribute('aria-hidden') !== 'true' && element.getClientRects().length && getComputedStyle(element).visibility !== 'hidden');
      if (overlayOpen || elements.sheet.inert) return;
      const cards = [...elements.stepList.querySelectorAll('.automation-step-card')];
      const card = cards.find(element => element.dataset.stepId === target.stepId) || cards[Math.min(Math.max(0, target.index), cards.length - 1)];
      const button = card?.querySelector('[data-step-action="toggle"]') || elements.addStep;
      if (button && !button.closest('[hidden], [inert]')) button.focus({ preventScroll: true });
    });
  }

  function renderQuickSchemes() {
    const favorites = model.favorites();
    elements.quickSchemes.hidden = favorites.length === 0;
    elements.quickSchemes.innerHTML = favorites.map(scheme =>
      `<button class="automation-quick-card" type="button" data-scheme-id="${safeAttr(scheme.id)}" title="${safeAttr(scheme.name)}"><span>${ui.safeHtml(scheme.name)}</span></button>`
    ).join("");
  }

  function renderLibrary() {
    elements.schemeList.innerHTML = model.schemes.length ? model.schemes.map(scheme => {
      let ready = true; try { validateRunnable(scheme); } catch (_) { ready = false; }
      return `<article class="automation-scheme-card" data-scheme-id="${safeAttr(scheme.id)}">
        <button class="automation-scheme-main" type="button" data-scheme-action="edit"><strong>${ui.safeHtml(scheme.name)}</strong><small>${scheme.steps.length} 个步骤${ready ? '' : ' · 未完成'}</small></button>
        <button class="icon-action" type="button" data-scheme-action="run" aria-label="运行${safeAttr(scheme.name)}" title="运行" ${ready ? '' : 'disabled'}>${window.SKIcons?.icon('play', 17) || '▷'}</button>
        <button class="icon-action" type="button" data-scheme-action="copy" aria-label="复制${safeAttr(scheme.name)}" title="复制">${window.SKIcons?.icon('copy', 17) || '⧉'}</button>
        <button class="icon-action automation-scheme-more" type="button" data-scheme-action="menu" aria-label="${safeAttr(scheme.name)}的操作" title="更多">⋯</button>
      </article>`;
    }).join('') : '<div class="automation-empty"><strong>还没有方案</strong><span>点击右上角加号新建。</span></div>';
    renderQuickSchemes();
  }

  function inputRows(step, stepIndex) {
    if (!step.inputs?.length) return "";
    return step.inputs.map((input, inputIndex) => `<div class="automation-input-row" data-input-index="${inputIndex}">
      <div class="automation-input-row-head"><strong>输入 ${inputIndex + 1}</strong><button type="button" data-step-action="remove-input" data-step-index="${stepIndex}" aria-label="删除第 ${inputIndex + 1} 条自动输入">移除</button></div>
      <label class="automation-input-content"><span>发送内容</span><input type="text" maxlength="8192" value="${safeAttr(input.text)}" data-input-field="text" placeholder="输入要发送的文字" /></label>
      <div class="automation-input-options"><label class="automation-input-delay"><span>步骤启动后（秒）</span><input type="text" inputmode="decimal" maxlength="8192" value="${safeAttr(input.afterSecText ?? String(input.afterSec))}" data-input-field="afterSec" /></label><label class="automation-input-enter"><input type="checkbox" data-input-field="appendEnter" ${input.appendEnter ? "checked" : ""} /><span>附加回车</span></label></div>
    </div>`).join("");
  }

  function stepBody(step, index) {
    if (step.type === "wait") {
      return `<label class="automation-field"><span>等待秒数</span><input type="text" inputmode="decimal" maxlength="8192" value="${safeAttr(step.secondsText ?? String(step.seconds))}" data-step-field="seconds" /></label>`;
    }
    const common = step.type === "script"
      ? `<div class="automation-field"><label for="automationScriptPath">脚本或可执行文件</label><div class="automation-script-path"><input id="automationScriptPath" type="text" maxlength="4096" value="${safeAttr(step.path)}" data-step-field="path" placeholder="/absolute/path/script.sh" /><button class="icon-action" type="button" data-step-action="pick-script" aria-label="从文件管理选择脚本" title="从文件管理选择脚本">${window.SKIcons?.icon('folder', 19) || '↗'}</button></div></div>`
      : `<div class="automation-command-fields">
          <label class="automation-field automation-command-field"><span>命令</span><textarea maxlength="8192" data-step-field="command" placeholder="输入 Shell 命令">${ui.safeHtml(step.command)}</textarea></label>
        </div>`;
    const args = step.type === "script"
      ? `<label class="automation-field"><span>参数</span><input type="text" maxlength="8192" value="${safeAttr(step.argsText ?? serializeArgs(step.args))}" data-step-field="args" placeholder="多个参数支持引号" /></label>` : "";
    return `${common}${args}<details class="automation-inputs" ${expandedInputGroups.has(step.id) ? 'open' : ''}>
      <summary><span>自动输入</span><span class="automation-input-count">${step.inputs?.length || 0} 条</span></summary>
      <div class="automation-inputs-content"><p>按相对本步骤启动的时间发送内容。</p>${inputRows(step, index)}<button class="automation-add-input" type="button" data-step-action="add-input" data-step-index="${index}">添加自动输入</button></div>
    </details>`;
  }

  function renderEditor() {
    const draft = model.draft;
    elements.draftName.value = draft.name || '';
    elements.failurePolicy.value = draft.failurePolicy;
    elements.draftName.placeholder = model.schemes.find(item => item.id === draft.schemeId)?.name || '未命名方案';
    if (elements.stepCount) elements.stepCount.textContent = `${draft.steps.length} 个步骤`;
    elements.stepList.innerHTML = draft.steps.length ? draft.steps.map((step, index) => `<article class="automation-step-card" data-step-index="${index}" data-step-id="${safeAttr(step.id)}" draggable="true">
      <header class="automation-step-head"><button class="automation-drag-handle icon-action" type="button" aria-label="拖动步骤${index + 1}">⠿</button>
      <button class="automation-step-summary" type="button" data-step-action="toggle" aria-label="编辑步骤${index + 1}"><span class="automation-step-number">${index + 1}</span><span class="automation-step-summary-text">${ui.safeHtml(stepSummary(step))}</span></button>
      <div class="automation-step-menu-wrap"><button class="automation-step-tool icon-action" type="button" data-step-action="menu" aria-label="步骤${index + 1}的操作" aria-expanded="false">⋯</button><div class="automation-step-menu" hidden><button type="button" data-step-action="up" ${index ? '' : 'disabled'}>上移</button><button type="button" data-step-action="down" ${index === draft.steps.length - 1 ? 'disabled' : ''}>下移</button><button type="button" data-step-action="duplicate">复制步骤</button><button type="button" data-step-action="delete">删除步骤</button></div></div></header></article>`).join('') : '<div class="automation-empty"><span>点击加号添加步骤</span></div>';
    elements.execute.disabled = runStarting || activeRunState();
  }

  function renderAll() {
    renderLibrary();
    renderEditor();
    renderRun();
  }

  async function loadConfig(force = false) {
    if (loaded && !force) return model.config;
    if (loadingConfig) return loadingConfig;
    loadingConfig = (async () => {
      const config = await RequestApi.getAutomationConfig();
      model.setConfig(config);
      confirmedRevision = model.config.revision;
      const orphan = !model.draft.schemeId && (model.draft.name || model.draft.steps.length);
      const current = model.schemes.find(item => item.id === model.draft.schemeId);
      const changed = current && ((model.draft.name.trim() || current.name) !== current.name || model.draft.failurePolicy !== current.failurePolicy || JSON.stringify(model.draft.steps) !== JSON.stringify(current.steps));
      if (orphan || changed) { model.syncDraft(); ++localVersion; }
      loaded = true;
      renderAll();
      if (localVersion > confirmedVersion) scheduleSave();
      return model.config;
    })();
    try { return await loadingConfig; }
    finally { loadingConfig = null; }
  }

  function scheduleSave(immediate = false) {
    clearTimeout(saveTimer);
    if (pausedSave) { setDraftState(pausedSave.message, 'error'); return; }
    setDraftState('待同步', 'saving');
    saveTimer = setTimeout(() => drainSaves(false).catch(() => {}), immediate ? 0 : 400);
  }
  function equivalent(left, right) {
    const ordered = value => Array.isArray(value) ? value.map(ordered)
      : value && typeof value === 'object' ? Object.fromEntries(Object.keys(value).sort().map(key => [key, ordered(value[key])])) : value;
    const { revision: _leftRevision, ...a } = left;
    const { revision: _rightRevision, ...b } = right;
    return JSON.stringify(ordered(a)) === JSON.stringify(ordered(b));
  }
  async function reconcileSave() {
    if (!pausedSave) return;
    const recovery = document.getElementById('automationSyncModal');
    const detail = document.getElementById('automationSyncDetail');
    recoveryRemote = null;
    document.getElementById('automationUseLocal').disabled = true;
    document.getElementById('automationUseRemote').disabled = true;
    detail.textContent = '正在只读核对服务端配置…';
    ui.showModal(recovery);
    try {
      const remote = await RequestApi.getAutomationConfig();
      if (pausedSave.snapshot && equivalent(remote, pausedSave.snapshot)) {
        confirmedRevision = remote.revision; model.config.revision = remote.revision;
        confirmedVersion = pausedSave.version; pausedSave = null;
        if (localVersion > confirmedVersion) scheduleSave(); else setDraftState('已同步');
        ui.hideModal(recovery);
      } else {
        recoveryRemote = remote;
        detail.textContent = `已读取服务端版本 ${remote.revision}。本地修改仍保留，请选择使用哪份配置。`;
        document.getElementById('automationUseLocal').disabled = false;
        document.getElementById('automationUseRemote').disabled = false;
      }
    } catch (_) { detail.textContent = '暂时无法读取服务端状态。本地修改已保留，可稍后重新核对。'; }
  }
  function drainSaves(flush = false) {
    if (flush) flushRequested = true;
    if (saveQueue) return saveQueue;
    saveQueue = (async () => {
      do {
        if (pausedSave) throw new Error(pausedSave.message);
        if (confirmedVersion >= localVersion) return;
        const snapshot = model.snapshot(), version = localVersion;
        snapshot.revision = confirmedRevision;
        try { validateStorage(snapshot); } catch (error) { validationBlockedVersion = version; setDraftState(error.message, 'error'); throw error; }
        inFlight = { snapshot, version };
        setDraftState('同步中', 'saving');
        try {
          const saved = await RequestApi.setAutomationConfig(snapshot);
          if (!Number.isSafeInteger(saved?.revision) || saved.revision <= confirmedRevision) throw new Error('保存回执无效');
          confirmedRevision = saved.revision; model.config.revision = saved.revision;
          confirmedVersion = version;
        } catch (error) {
          if (error.code === 'INVALID_ARGUMENT') {
            validationBlockedVersion = version;
            setDraftState(error.message || '配置无效，请修正后自动同步', 'error');
            throw error;
          }
          pausedSave = { snapshot, version, message: error.code === 'CONFIG_CHANGED' ? '配置冲突，修改已保留' : '同步待确认，修改已保留' };
          setDraftState(pausedSave.message, 'error');
          throw error;
        } finally { inFlight = null; }
        if (confirmedVersion >= localVersion) setDraftState('已同步');
        else if (!flushRequested) { scheduleSave(); return; }
      } while (confirmedVersion < localVersion);
    })().finally(() => {
      saveQueue = null; flushRequested = false;
      if (!pausedSave && localVersion > confirmedVersion && localVersion > validationBlockedVersion) scheduleSave();
    });
    return saveQueue;
  }
  function persistConfig() { clearTimeout(saveTimer); return drainSaves(true); }
  function markChanged() {
    model.syncDraft(); ++localVersion; renderLibrary(); scheduleSave();
  }

  async function activate(context = {}) {
    try {
      await loadConfig();
      setView(context.subview || activeView);
    } catch (error) {
      setDraftState("加载失败", "error");
      alert(error?.message || "方案配置加载失败");
    }
  }

  function deactivate() {
    closeSaveMenu();
    closeAddMenu();
    closeStepMenus();
  }

  function openAutoSheet(view) {
    return window.SKAppShell.navigate("automation", view ? { subview: view } : {});
  }

  function closeAutoSheet() {
    return window.SKAppShell.navigate("terminal");
  }

  function back() {
    if (elements.addMenu && !elements.addMenu.hidden) { closeAddMenu(); return true; }
    if (elements.stepList.querySelector('.automation-step-menu:not([hidden])')) { closeStepMenus(); return true; }
    if (activeView === "editor") { setView("library"); return true; }
    return false;
  }

  function validateDraft() { return validateRunnable(model.draft); }

  function schemeById(id) { return model.schemes.find(item => item.id === id); }

  function openSchemeAction(id) {
    const scheme = schemeById(id);
    if (!scheme) return;
    schemeActionId = id;
    schemeAction.title.textContent = "方案操作";
    schemeAction.target.textContent = `${scheme.name}\n${scheme.steps.length} 个步骤`;
    schemeAction.favorite.textContent = scheme.favorite ? "取消收藏" : "收藏到终端";
    ui.showModal(schemeAction.modal);
  }

  function runCandidate(payload) {
    if (payload.schemeId) return schemeById(payload.schemeId);
    return { id: "", name: model.draft.name || "未保存草稿", failurePolicy: model.draft.failurePolicy, steps: model.draft.steps };
  }

  function openRunConfirm(payload) {
    const candidate = runCandidate(payload);
    if (!candidate) return;
    if (runStarting || (activeRun && ["preparing", "running"].includes(activeRun.state))) {
      ui.showToast("已有方案正在执行", 1500);
      return;
    }
    try { validateRunnable(candidate); } catch (error) { ui.showToast(error.message, 2400); return; }
    // A scheme is a deterministic input sequence. Start it immediately;
    // readiness/foreground checks are intentionally left to the user because
    // queued bytes may be meant for the currently running foreground program.
    pendingRun = { schemeId: payload.schemeId || model.draft.schemeId };
    startPendingRun();
  }

  async function startPendingRun() {
    if (!pendingRun || runStarting) return;
    const runPayload = pendingRun;
    runStarting = true;
    renderRun();
    try {
      await persistConfig();
      validateRunnable(runCandidate(runPayload));
      activeRun = await RequestApi.startAutomationRun(runPayload);
      if (pendingRun === runPayload) pendingRun = null;
      renderRun();
      pollRun();
    } catch (error) {
      alert(error?.message || "方案启动失败");
    } finally {
      runStarting = false;
      elements.execute.disabled = activeRunState();
      renderRun();
    }
  }

  function activeRunState() {
    return !!activeRun && ["preparing", "running"].includes(activeRun.state);
  }

  function renderRun() {
    const active = activeRunState();
    const visible = !!activeRun?.id;
    elements.runBar.hidden = !visible;
    composer?.classList.toggle("automation-locked", active);
    cmd.disabled = active;
    sendBtn.disabled = active;
    if (quickActions) quickActions.setAttribute("aria-disabled", active ? "true" : "false");
    elements.execute.disabled = active || runStarting;
    if (!visible) {
      window.SKAppShell?.setTask("automation", runStarting
        ? { active: true, label: "准备执行方案", detail: "正在保存并启动", progress: 0, view: "automation" }
        : null);
      return;
    }
    elements.runName.textContent = activeRun.name || "自动化方案";
    elements.runState.textContent = runStateNames[activeRun.state] || activeRun.state;
    const total = Number(activeRun.totalSteps) || 0;
    const done = Math.min(total, (Number(activeRun.successCount) || 0) + (Number(activeRun.failureCount) || 0));
    const percent = total > 0 ? Math.round((active ? Math.max(done, Number(activeRun.currentStep) || 0) : total) / total * 100) : 0;
    elements.runProgress.style.width = `${Math.min(100, percent)}%`;
    const step = activeRun.steps?.[Number(activeRun.currentStep) || 0];
    const stepText = step ? `第 ${(Number(activeRun.currentStep) || 0) + 1}/${total} 步 · ${step.type}` : `${done}/${total} 步`;
    elements.runDetail.textContent = `${stepText} · 成功 ${activeRun.successCount || 0} · 失败 ${activeRun.failureCount || 0}`;
    window.SKAppShell?.setTask("automation", {
      active, label: `${elements.runName.textContent} · ${elements.runState.textContent}`,
      detail: elements.runDetail.textContent, progress: percent, view: "automation", state: activeRun.state,
    });
  }

  async function pollRun() {
    clearTimeout(runPollTimer);
    if (!activeRun?.id) return;
    try {
      activeRun = await RequestApi.getAutomationRun(activeRun.id);
      renderRun();
      if (activeRunState()) {
        runPollTimer = setTimeout(pollRun, 500);
      } else {
        elements.execute.disabled = false;
        setTimeout(() => {
          if (!activeRunState()) {
            activeRun = null;
            renderRun();
          }
        }, 4500);
      }
    } catch (error) {
      console.warn("automation status failed", error);
      runPollTimer = setTimeout(pollRun, 1200);
    }
  }

  async function resumeRun() {
    try {
      const status = await RequestApi.getAutomationRun();
      if (status?.id) {
        activeRun = status;
        renderRun();
        if (activeRunState()) pollRun();
      }
    } catch (error) {
      console.warn("automation resume failed", error);
    }
  }

  function updateStepField(target) {
    const card = target.closest("[data-step-index]");
    if (!card) return;
    const index = Number(card.dataset.stepIndex);
    const step = model.draft.steps[index];
    if (!step) return;
    const field = target.dataset.stepField;
    if (field === "path" || field === "command") step[field] = target.value;
    else if (field === "seconds") { step.secondsText = target.value; try { step.seconds = parseSecondsText(target.value, true); } catch (_) {} }
    else if (field === "args") {
      step.argsText = target.value;
      try { step.args = parseArgsText(target.value); target.setCustomValidity(''); }
      catch (error) { target.setCustomValidity(error.message); }
    }
    markChanged();
    updateStepSummary(elements.stepList.querySelector(`[data-step-id="${step.id}"]`), step);
  }

  function updateInputField(target) {
    const card = target.closest("[data-step-index]");
    const row = target.closest(".automation-input-row");
    if (!card || !row) return;
    const step = model.draft.steps[Number(card.dataset.stepIndex)];
    const input = step?.inputs?.[Number(row.dataset.inputIndex)];
    if (!input) return;
    const field = target.dataset.inputField;
    if (field === "appendEnter") input.appendEnter = target.checked;
    else if (field === "afterSec") { input.afterSecText = target.value; try { input.afterSec = parseSecondsText(target.value); } catch (_) {} }
    else if (field === "text") input.text = target.value;
    markChanged();
  }

  async function pickScriptFile(step) {
    if (scriptPicker || step.type !== 'script') return;
    if (typeof window.SKFileManager?.pickFile !== 'function') {
      ui.showToast('文件选择暂不可用', 2200);
      return;
    }
    // Commit the visible editor first, including an autofilled value that has
    // not emitted an input event. Selecting a path does not depend on a save.
    if (elements.stepFields.dataset.stepId === step.id) {
      for (const field of elements.stepFields.querySelectorAll('[data-step-field]')) {
        const name = field.dataset.stepField;
        const displayed = name === 'args' ? step.argsText ?? serializeArgs(step.args)
          : name === 'seconds' ? step.secondsText ?? String(step.seconds) : step[name] ?? '';
        if (field.value !== displayed) updateStepField(field);
      }
      for (const field of elements.stepFields.querySelectorAll('[data-input-field]')) {
        const input = step.inputs?.[Number(field.closest('[data-input-index]')?.dataset.inputIndex)];
        if (!input) continue;
        const name = field.dataset.inputField;
        const displayed = name === 'afterSec' ? input.afterSecText ?? String(input.afterSec) : input[name];
        if ((name === 'appendEnter' ? field.checked : field.value) !== displayed) updateInputField(field);
      }
    }
    const session = { schemeId: model.draft.schemeId, stepId: step.id, draft: model.draft, step };
    scriptPicker = session;
    rememberInputGroups();
    ui.hideModal(elements.stepModal);
    expandedStepId = null;
    stepReturnTarget = null;
    let result;
    let failure = null;
    try {
      try {
        result = await window.SKFileManager.pickFile({ purpose: 'automation-script', initialPath: step.path });
      } catch (error) {
        failure = error;
      }
      if (scriptPicker !== session || result?.reason === 'navigation') return;
      // IDs locate a reordered step; object identity rejects a replaced draft
      // or a removed/restored step even when it has reused the same ID.
      const current = model.draft.steps.find(item => item.id === session.stepId);
      if (model.draft !== session.draft || model.draft.schemeId !== session.schemeId || current !== session.step || current.type !== 'script') return;
      if (!['automation', 'files'].includes(window.SKAppShell.activeView)) return;
      if (result && !result.cancelled && typeof result.path === 'string' && result.path) {
        current.path = result.path;
        renderEditor();
        markChanged();
      }
      const restored = await window.SKAppShell.navigate('automation', { subview: 'editor', scriptFileReturn: true });
      if (restored === false || scriptPicker !== session || window.SKAppShell.activeView !== 'automation' || model.draft !== session.draft || !model.draft.steps.includes(current)) return;
      expandStep(current.id);
      requestAnimationFrame(() => {
        if (expandedStepId === current.id && elements.stepModal.classList.contains('show')) elements.stepFields.querySelector('[data-step-field="path"]')?.focus({ preventScroll: true });
      });
      if (failure) ui.showToast(failure?.message || '无法打开文件选择', 2200);
    } finally {
      if (scriptPicker === session) scriptPicker = null;
    }
  }

  function handleStepAction(button) {
    const card = button.closest("[data-step-index]");
    const index = Number(button.dataset.stepIndex ?? card?.dataset.stepIndex);
    const action = button.dataset.stepAction;
    const step = model.draft.steps[index];
    if (!step || button.disabled) return;
    if (action === "toggle") { expandStep(step.id); return; }
    if (action === "pick-script") { void pickScriptFile(step); return; }
    if (action === "menu") {
      const menu = card.querySelector('.automation-step-menu');
      const shouldOpen = menu.hidden;
      closeStepMenus();
      menu.hidden = !shouldOpen;
      button.setAttribute('aria-expanded', String(shouldOpen));
      if (shouldOpen) positionMenu(menu, button);
      return;
    }
    try {
      if (action === "up") model.moveStep(index, index - 1);
      else if (action === "down") model.moveStep(index, index + 1);
      else if (action === "duplicate") expandedStepId = model.duplicateStep(index).id;
      else if (action === "delete") {
        const removed = JSON.parse(JSON.stringify(step)), ownerId = model.draft.schemeId;
        model.removeStep(index);
        if (expandedStepId === step.id) expandedStepId = model.draft.steps[Math.min(index, model.draft.steps.length - 1)]?.id || null;
        ui.showUndo('已删除步骤', () => {
          model.restoreStep(ownerId, removed, index);
          renderEditor(); markChanged();
        });
      }
      else if (action === "add-input") { model.addInput(index); expandedInputGroups.add(step.id); }
      else if (action === "remove-input") {
        const inputIndex = Number(button.closest(".automation-input-row")?.dataset.inputIndex);
        model.removeInput(index, inputIndex);
      } else return;
      renderEditor();
      if (elements.stepModal.classList.contains('show')) renderStepEditor(action === 'add-input' ? step.id : null);
      markChanged();
    } catch (error) {
      alert(error.message);
    }
  }

  function installDragHandlers() {
    elements.stepList.addEventListener("dragstart", event => {
      const card = event.target.closest(".automation-step-card");
      if (!card) return;
      dragIndex = Number(card.dataset.stepIndex);
      card.classList.add("dragging");
      event.dataTransfer.effectAllowed = "move";
    });
    elements.stepList.addEventListener("dragover", event => {
      const card = event.target.closest(".automation-step-card");
      if (!card || dragIndex < 0) return;
      event.preventDefault();
      elements.stepList.querySelectorAll(".drag-over").forEach(node => node.classList.remove("drag-over"));
      card.classList.add("drag-over");
    });
    elements.stepList.addEventListener("drop", event => {
      const card = event.target.closest(".automation-step-card");
      if (!card || dragIndex < 0) return;
      event.preventDefault();
      const target = Number(card.dataset.stepIndex);
      if (model.moveStep(dragIndex, target)) markChanged();
      dragIndex = -1;
      renderEditor();
    });
    elements.stepList.addEventListener("dragend", () => {
      dragIndex = -1;
      elements.stepList.querySelectorAll(".dragging,.drag-over").forEach(node => node.classList.remove("dragging", "drag-over"));
    });

    elements.stepList.addEventListener("pointerdown", event => {
      const handle = event.target.closest(".automation-drag-handle");
      const card = handle?.closest(".automation-step-card");
      if (!handle || !card || event.button > 0) return;
      pointerDrag = { pointerId: event.pointerId, from: Number(card.dataset.stepIndex), to: Number(card.dataset.stepIndex), moved: false };
      handle.setPointerCapture?.(event.pointerId);
    });
    elements.stepList.addEventListener("pointermove", event => {
      if (!pointerDrag || pointerDrag.pointerId !== event.pointerId) return;
      event.preventDefault();
      pointerDrag.moved = true;
      const node = document.elementFromPoint(event.clientX, event.clientY)?.closest(".automation-step-card");
      if (!node) return;
      pointerDrag.to = Number(node.dataset.stepIndex);
      elements.stepList.querySelectorAll(".drag-over").forEach(item => item.classList.remove("drag-over"));
      node.classList.add("drag-over");
    }, { passive: false });
    const finish = event => {
      if (!pointerDrag || pointerDrag.pointerId !== event.pointerId) return;
      const { from, to, moved } = pointerDrag;
      pointerDrag = null;
      if (moved && model.moveStep(from, to)) markChanged();
      renderEditor();
    };
    elements.stepList.addEventListener("pointerup", finish);
    elements.stepList.addEventListener("pointercancel", finish);
  }

  elements.close.onclick = closeAutoSheet;
  elements.libraryTab.onclick = () => setView("library");
  elements.editorTab.onclick = () => setView("editor");
  elements.newScheme.onclick = () => {
    try { model.createScheme(); } catch (error) { ui.showToast(error.message, 2200); return; }
    expandedStepId = null;
    expandedInputGroups.clear();
    renderEditor();
    setView("editor");
    markChanged();
  };
  elements.draftName.oninput = () => { model.draft.name = elements.draftName.value; markChanged(); };
  elements.failurePolicy.onchange = () => { model.draft.failurePolicy = elements.failurePolicy.value; markChanged(); };
  elements.addZone.onclick = event => {
    const type = event.target.closest("[data-add-step]")?.dataset.addStep;
    if (!type) return;
    try {
      const added = type === "script" ? model.addStep("script", { path: "", args: [], inputs: [] })
        : type === "wait" ? model.addStep("wait", { seconds: 1 })
        : model.addStep("command", { command: "", inputs: [] });
      expandedStepId = added.id;
      closeAddMenu();
      renderEditor();
      markChanged();
      expandStep(added.id);
    } catch (error) { alert(error.message); }
  };
  if (elements.addStep) elements.addStep.onclick = event => {
    event.stopPropagation();
    if (!elements.addMenu) return;
    const shouldOpen = elements.addMenu.hidden;
    closeSaveMenu();
    closeStepMenus();
    elements.addMenu.hidden = !shouldOpen;
    elements.addStep.setAttribute("aria-expanded", String(shouldOpen));
    if (shouldOpen) positionMenu(elements.addMenu, elements.addStep);
  };
  elements.stepList.addEventListener("input", event => {
    if (event.target.dataset.stepField) updateStepField(event.target);
    else if (event.target.dataset.inputField) updateInputField(event.target);
  });
  elements.stepList.addEventListener("change", event => {
    if (event.target.dataset.inputField) updateInputField(event.target);
  });
  elements.stepList.addEventListener("click", event => {
    const button = event.target.closest("[data-step-action]");
    if (button) handleStepAction(button);
  });
  installDragHandlers();
  elements.stepList.addEventListener('scroll', closeStepMenus, { passive: true });
  elements.editorScroll?.addEventListener('scroll', () => { closeStepMenus(); closeSaveMenu(); closeAddMenu(); }, { passive: true });
  const closeMenus = () => { closeStepMenus(); closeSaveMenu(); closeAddMenu(); };
  window.addEventListener('resize', closeMenus);
  window.visualViewport?.addEventListener('resize', closeMenus);

  function openScheme(id) {
    closeStepEditor();
    if (!model.loadScheme(id)) return;
    expandedInputGroups.clear(); renderEditor(); setView('editor'); markChanged();
  }
  function copyScheme(id) {
    try { model.syncDraft(); const copy = model.duplicateScheme(id); if (!copy) return; openScheme(copy.id); }
    catch (error) { ui.showToast(error.message, 2200); }
  }
  elements.copy?.addEventListener('click', () => copyScheme(model.draft.schemeId));
  elements.more?.addEventListener('click', () => openSchemeAction(model.draft.schemeId));
  elements.stepClose?.addEventListener('click', closeStepEditor);
  elements.stepFields?.addEventListener('input', event => {
    if (event.target.dataset.stepField) updateStepField(event.target);
    else if (event.target.dataset.inputField) updateInputField(event.target);
  });
  elements.stepFields?.addEventListener('change', event => { if (event.target.dataset.inputField) updateInputField(event.target); });
  elements.stepFields?.addEventListener('click', event => { const button = event.target.closest('[data-step-action]'); if (button) handleStepAction(button); });
  elements.draftState.addEventListener('click', reconcileSave);
  document.getElementById('automationSyncCheck').onclick = reconcileSave;
  document.getElementById('automationUseRemote').onclick = () => {
    if (!recoveryRemote || !window.confirm('采用服务端配置会放弃本页未同步修改，继续？')) return;
    model.setConfig(recoveryRemote); confirmedRevision = recoveryRemote.revision;
    confirmedVersion = localVersion; pausedSave = null; validationBlockedVersion = -1;
    renderAll(); setDraftState('已同步'); ui.hideModal(document.getElementById('automationSyncModal'));
  };
  document.getElementById('automationUseLocal').onclick = async () => {
    if (!recoveryRemote || !window.confirm('将以本地方案配置覆盖已读取的服务端版本，继续？')) return;
    confirmedRevision = recoveryRemote.revision; model.config.revision = recoveryRemote.revision;
    pausedSave = null; validationBlockedVersion = -1;
    ui.hideModal(document.getElementById('automationSyncModal'));
    try { await persistConfig(); } catch (_) {}
  };

  elements.execute.onclick = () => openRunConfirm({ source: "draft" });

  document.addEventListener("click", event => {
    if (!event.target.closest(".automation-save-wrap")) closeSaveMenu();
    if (!event.target.closest(".automation-add-zone")) closeAddMenu();
    if (!event.target.closest(".automation-step-menu-wrap")) closeStepMenus();
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") { closeSaveMenu(); closeAddMenu(); closeStepMenus(); }
  });

  elements.schemeList.addEventListener('click', event => {
    const card = event.target.closest('[data-scheme-id]'); if (!card) return;
    const action = event.target.closest('[data-scheme-action]')?.dataset.schemeAction;
    if (action === 'run') openRunConfirm({ schemeId: card.dataset.schemeId });
    else if (action === 'copy') copyScheme(card.dataset.schemeId);
    else if (action === 'menu') openSchemeAction(card.dataset.schemeId);
    else if (action === 'edit') openScheme(card.dataset.schemeId);
  });

  elements.quickSchemes.onclick = event => {
    const card = event.target.closest("[data-scheme-id]");
    if (card) openRunConfirm({ schemeId: card.dataset.schemeId });
  };

  schemeAction.cancel.onclick = () => { schemeActionId = ""; ui.hideModal(schemeAction.modal); };
  schemeAction.run.onclick = () => { const id = schemeActionId; ui.hideModal(schemeAction.modal); openRunConfirm({ schemeId: id }); };
  schemeAction.edit.onclick = () => { ui.hideModal(schemeAction.modal); openScheme(schemeActionId); };
  schemeAction.favorite.onclick = () => { try { model.toggleFavorite(schemeActionId); ui.hideModal(schemeAction.modal); markChanged(); } catch (error) { ui.showToast(error.message); } };
  schemeAction.duplicate.onclick = () => { ui.hideModal(schemeAction.modal); copyScheme(schemeActionId); };
  schemeAction.delete.onclick = () => {
    const id = schemeActionId, index = model.schemes.findIndex(item => item.id === id);
    if (index < 0) return;
    const removed = JSON.parse(JSON.stringify(model.schemes[index]));
    const wasCurrent = model.draft.schemeId === id;
    model.deleteScheme(id); ui.hideModal(schemeAction.modal); closeStepEditor(); renderEditor(); markChanged();
    ui.showUndo(`已删除“${removed.name}”`, () => {
      const restored = model.restoreScheme(removed, index);
      if (wasCurrent && !model.draft.schemeId) model.loadScheme(id);
      renderEditor(); markChanged();
      if (restored.name !== removed.name) ui.showToast(`已恢复为“${restored.name}”`, 2200);
      else if (removed.favorite && !restored.favorite) ui.showToast('方案已恢复，收藏名额已满', 2200);
    });
  };

  sheetOverlay.addEventListener("click", () => {
    if (typeof app.closeAllSheets === "function") app.closeAllSheets();
  });

  function legacyTasks() {
    let pendingDelay = 0;
    const result = [];
    for (const step of model.draft.steps) {
      if (step.type === "wait") { pendingDelay += Number(step.seconds) || 0; continue; }
      if (step.type === "command") result.push({ cmd: step.command, delay: String(pendingDelay || 0) });
      else if (step.type === "script") {
        const args = serializeArgs(step.args);
        result.push({ cmd: terminalCore.buildShCommand(step.path, args), delay: String(pendingDelay || 0) });
      }
      pendingDelay = 0;
    }
    return result;
  }

  function replaceLegacyTasks(tasks) {
    const steps = [];
    (Array.isArray(tasks) ? tasks : []).forEach((task, index) => {
      const delay = Number(task?.delay) || 0;
      if (delay > 0) steps.push(normalizeStep({ type: "wait", seconds: delay }));
      if (String(task?.cmd || "").trim()) steps.push(normalizeStep({ type: "command", command: String(task.cmd) }));
    });
    model.config.draft = { schemeId: null, name: "", failurePolicy: "stop", steps };
    expandedStepId = null;
    expandedInputGroups.clear();
    renderEditor();
    markChanged();
  }

  async function appendScript(path, args = []) {
    await loadConfig();
    model.appendScript(path, args);
    expandedStepId = null;
    renderEditor();
    markChanged();
    await persistConfig();
    await openAutoSheet("editor");
  }

  window.SKInputSimulator = {
    open: openAutoSheet,
    close: closeAutoSheet,
    getTasks: legacyTasks,
    replaceTasks: replaceLegacyTasks,
    renderTasks: renderEditor,
    appendScript,
    getConfig: () => model.snapshot(),
    model,
    flush: persistConfig,
    get saveState() { return { localVersion, confirmedVersion, inFlight: !!inFlight, paused: !!pausedSave }; },
  };
  app.openAutoSheet = openAutoSheet;
  window.SKAppShell?.register("automation", { activate, deactivate, back });

  const previousCloseAllSheets = app.closeAllSheets;
  app.closeAllSheets = () => {
    if (typeof previousCloseAllSheets === "function") previousCloseAllSheets();
    deactivate();
  };

  loadConfig().catch(error => console.warn("automation config load failed", error));
  resumeRun();
})();

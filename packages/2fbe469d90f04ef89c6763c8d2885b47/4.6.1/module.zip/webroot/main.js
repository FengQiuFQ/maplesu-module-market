(() => {
  const out = document.getElementById("out");
  const cmd = document.getElementById("cmd");
  const sendBtn = document.getElementById("sendBtn");
  const connDot = document.getElementById("connDot");
  const connText = document.getElementById("connText");
  const quickActions = document.getElementById("quickActions");
  const fileBtn = document.getElementById("fileBtn");
  const autoBtn = document.getElementById("autoBtn");
  const sheetOverlay = document.getElementById("sheetOverlay");
  const pageExitOverlay = document.getElementById("pageExitOverlay");
  const terminalKeepSwitch = document.getElementById("terminalKeepSwitch");
  const terminalResidentSwitch = document.getElementById("terminalResidentSwitch");
  const terminalResidentState = document.getElementById("terminalResidentState");
  const terminalTransportSelect = document.getElementById("terminalTransportSelect");
  const terminalTransportState = document.getElementById("terminalTransportState");
  const terminalEndButton = document.getElementById("terminalEndButton");

  const terminalCore = window.SKTerminalCore?.createTerminalCore({
    out,
    connDot,
    connText,
  });

  if (!terminalCore) {
    console.error("SKTerminalCore not loaded");
    return;
  }

  async function refreshHistory() {
    let history = await RequestApi.getQuickActions();
    if (!history || !Array.isArray(history) || history.length === 0) history = [];
    quickActions.replaceChildren(...history.reverse().map(cmdStr => {
      const displayStr = cmdStr.length > 17 ? cmdStr.substring(0, 17) + '...' : cmdStr;
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "action-chip";
      chip.dataset.cmd = cmdStr;
      chip.title = cmdStr;
      chip.textContent = displayStr;
      return chip;
    }));
  }

  async function sendCommand() {
    const raw = cmd.value || "";
    const v = raw.trim();
    cmd.value = "";
    cmd.focus();
    sendBtn.disabled = true;
    try {
      await RequestApi.sendCommand(v);
      setTimeout(refreshHistory, 300);
    } catch (e) {
      terminalCore.appendLine("ERR: 发送失败 - " + (e && e.message ? e.message : String(e)));
    } finally {
      sendBtn.disabled = false;
      terminalCore.scrollBottom(true);
    }
  }
  
  const app = {
    elements: {
      out,
      cmd,
      sendBtn,
      connDot,
      connText,
      quickActions,
      fileBtn,
      autoBtn,
      sheetOverlay,
      pageExitOverlay,
    },
    refreshHistory,
    sendCommand,
    appendLine: terminalCore.appendLine,
    setConn: terminalCore.setConn,
    scrollBottom: () => terminalCore.scrollBottom(true),
    formatOutputText: terminalCore.formatOutputText,
    consumeChunk: terminalCore.consumeChunk,
    closeAllSheets: null,
    openAutoSheet: null,
    effectiveTerminalKeepMode: false,
    savedTerminalKeepMode: false,
    effectiveTerminalResidentMode: false,
    savedTerminalResidentMode: false,
    effectiveTerminalTransportMode: "pty",
    savedTerminalTransportMode: "pty",
  };
  let terminalSettingsLoading = true;
  let residentSavePending = false;
  let pageHiddenPending = false;

  function applyResidentState(state) {
    app.effectiveTerminalResidentMode = state.effective;
    app.savedTerminalResidentMode = state.saved;
    if (terminalResidentSwitch) terminalResidentSwitch.checked = state.saved;
    if (terminalResidentState) {
      terminalResidentState.textContent = `当前生效：${state.effective ? '开启' : '关闭'}；已保存：${state.saved ? '开启' : '关闭'}（立即生效）`;
    }
  }

  async function initTerminalSettings() {
    try {
      const [keepResult, transportResult, residentResult] = await Promise.allSettled([
        RequestApi.getTerminalKeepMode(),
        RequestApi.getTerminalTransportMode(),
        RequestApi.getTerminalResidentMode(),
      ]);
      if (keepResult.status === 'fulfilled') {
        app.effectiveTerminalKeepMode = keepResult.value == "1";
        app.savedTerminalKeepMode = app.effectiveTerminalKeepMode;
      } else console.warn("load terminal compatibility setting failed:", keepResult.reason);
      if (transportResult.status === 'fulfilled') {
        app.effectiveTerminalTransportMode = transportResult.value.effective;
        app.savedTerminalTransportMode = transportResult.value.saved;
      } else console.warn("load terminal transport setting failed:", transportResult.reason);
      if (residentResult.status === 'fulfilled') {
        applyResidentState(residentResult.value);
        if (terminalResidentSwitch) terminalResidentSwitch.disabled = false;
      } else {
        if (terminalResidentState) terminalResidentState.textContent = '常驻状态读取失败，请重新打开 WebUI';
        console.warn("load terminal resident setting failed:", residentResult.reason);
      }
      terminalCore.setTransportMode(app.effectiveTerminalTransportMode);
      if (terminalKeepSwitch) terminalKeepSwitch.checked = app.effectiveTerminalKeepMode;
      if (terminalTransportSelect) terminalTransportSelect.value = app.savedTerminalTransportMode;
      renderTransportState();
    } catch (e) {
      console.warn("load terminal settings failed:", e);
    } finally {
      terminalSettingsLoading = false;
      if (pageHiddenPending || document.visibilityState === 'hidden') onPageHidden();
    }

    if (terminalResidentSwitch) terminalResidentSwitch.addEventListener("change", async () => {
      const nextValue = terminalResidentSwitch.checked;
      terminalResidentSwitch.disabled = true;
      residentSavePending = true;
      try {
        applyResidentState(await RequestApi.saveTerminalResidentMode(nextValue));
        window.SKUiUtils?.showToast?.("后台常驻设置已保存并立即生效", 1800);
      } catch (e) {
        // A lost response may follow a successful save; reconcile before
        // deciding how a pending page hide should be handled.
        try { applyResidentState(await RequestApi.getTerminalResidentMode()); }
        catch (_) { terminalResidentSwitch.checked = app.savedTerminalResidentMode; }
        window.SKUiUtils?.showToast?.("常驻设置保存失败，请检查当前生效状态", 2200);
        console.warn("save terminal resident setting failed:", e);
      } finally {
        residentSavePending = false;
        terminalResidentSwitch.disabled = false;
        if (pageHiddenPending || document.visibilityState === 'hidden') onPageHidden();
      }
    });

    if (terminalKeepSwitch) terminalKeepSwitch.addEventListener("change", async () => {
      const nextValue = terminalKeepSwitch.checked;
      terminalKeepSwitch.disabled = true;
      try {
        await RequestApi.saveTerminalKeepMode(nextValue);
        app.savedTerminalKeepMode = nextValue;
        window.SKUiUtils?.showToast?.("设置已保存，下次打开 WebUI 生效", 1800);
      } catch (e) {
        terminalKeepSwitch.checked = app.savedTerminalKeepMode;
        window.SKUiUtils?.showToast?.("设置保存失败，请稍后重试", 1800);
        console.warn("save terminal settings failed:", e);
      } finally {
        terminalKeepSwitch.disabled = false;
      }
    });

    if (terminalTransportSelect) terminalTransportSelect.addEventListener("change", async () => {
      const nextValue = terminalTransportSelect.value;
      terminalTransportSelect.disabled = true;
      try {
        await RequestApi.saveTerminalTransportMode(nextValue);
        app.savedTerminalTransportMode = nextValue;
        renderTransportState();
        window.SKUiUtils?.showToast?.("传输模式已保存，下次打开 WebUI 生效", 2200);
      } catch (e) {
        terminalTransportSelect.value = app.savedTerminalTransportMode;
        window.SKUiUtils?.showToast?.("传输模式保存失败，请稍后重试", 1800);
        console.warn("save terminal transport settings failed:", e);
      } finally {
        terminalTransportSelect.disabled = false;
      }
    });
  }

  function transportLabel(mode) {
    return mode === "pipe" ? "匿名管道" : "PTY";
  }

  function renderTransportState() {
    if (!terminalTransportState) return;
    const effective = transportLabel(app.effectiveTerminalTransportMode);
    const saved = transportLabel(app.savedTerminalTransportMode);
    const next = effective === saved ? `当前生效：${effective}` : `当前生效：${effective}；下次启动：${saved}`;
    const compatibilityWarning = app.effectiveTerminalKeepMode
      && app.effectiveTerminalTransportMode === "pty"
      ? "；兼容模式关闭页面后保留 PTY，请用“结束整个终端”回收"
      : "";
    terminalTransportState.textContent = next + compatibilityWarning;
  }

  window.SKRootApp = app;

  quickActions.addEventListener("click", (e) => {
    const chip = e.target.closest(".action-chip");
    if (chip && chip.dataset.cmd) {
      cmd.value = chip.dataset.cmd;
      cmd.focus();
    }
  });

  cmd.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") {
      ev.preventDefault();
      sendCommand();
    }
  });

  sendBtn.addEventListener("click", sendCommand);
  terminalCore.setConn(null, "连接中");
  initTerminalSettings();
  refreshHistory();
  let savedScroll = 0, following = true;
  window.SKAppShell?.register('terminal', {
    activate() { requestAnimationFrame(() => { if (following) terminalCore.scrollBottom(true); else out.scrollTop = savedScroll; }); },
    deactivate() { savedScroll = out.scrollTop; following = out.scrollHeight - out.clientHeight - out.scrollTop < 24; },
    back() {
      const shortcuts = document.getElementById('terminalShortcuts');
      if (shortcuts && !shortcuts.hidden) { shortcuts.hidden = true; document.getElementById('terminalShortcutsBtn').setAttribute('aria-expanded', 'false'); return true; }
      return false;
    },
  });
  setInterval(terminalCore.tick, 1000);


  let pageExited = false;

  function requestTerminalExit(automatic = false) {
    if (pageExited) return;
    pageExited = true;
    showPageExitOverlay();
    terminalCore.setConn(false, "已退出");
    cmd.disabled = true;
    sendBtn.disabled = true;
    try {
      if (typeof app.closeAllSheets === "function") app.closeAllSheets();
    } catch (e) {
      console.warn("close sheets failed:", e);
    }
    try {
      RequestApi.exitWebui(automatic);
    } catch (e) {
      console.warn("exitWebui failed:", e);
    }
  }

  if (terminalEndButton) terminalEndButton.addEventListener("click", () => {
    if (window.confirm("结束整个终端？当前 Shell 和正在运行的方案都会停止。")) requestTerminalExit();
  });

  function showPageExitOverlay() {
    if (!pageExitOverlay) return;
    pageExitOverlay.classList.add("show");
    pageExitOverlay.setAttribute("aria-hidden", "false");
  }

  function onPageHidden() {
    if (pageExited) return;
    pageHiddenPending = true;
    if (terminalSettingsLoading || residentSavePending) return;
    pageHiddenPending = false;
    if (app.effectiveTerminalResidentMode) return;

    // 兼容后台模式在本次 WebUI 创建时就已生效；页面隐藏时不主动释放终端。
    // 开关修改只影响下次打开，所以这里不要读取 savedTerminalKeepMode。
    if (app.effectiveTerminalKeepMode) return;

    requestTerminalExit(true);
  }

  document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") onPageHidden();
  });

  window.addEventListener("pagehide", onPageHidden);

})();

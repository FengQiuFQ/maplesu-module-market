(() => {
  function createTerminalCore(elements) {
    const { out, connDot, connText } = elements;

    // Both transports can carry ANSI output from shells and CLI tools. Keep a
    // small stateful renderer instead of treating carriage returns and SGR
    // sequences as literal text. This covers common CLI styling without
    // attempting to emulate a full-screen TUI terminal.
    let transportMode = "pty";
    let ptyEscape = "";
    let ptyOsc = false;
    let ptyStyle = {};
    let ptyCursor = 0;
    let ptyLine = [];
    let ptyPartialRow = null;
    let ptyBatch = false;

    const ansiColors = [
      "#000000", "#b91c1c", "#15803d", "#a16207", "#1d4ed8", "#7e22ce", "#0f766e", "#e2e8f0",
      "#475569", "#ef4444", "#22c55e", "#eab308", "#3b82f6", "#a855f7", "#14b8a6", "#f8fafc",
    ];

    function ansi256Color(index) {
      index = Math.max(0, Math.min(255, Number(index) || 0));
      if (index < 16) return ansiColors[index];
      if (index >= 232) {
        const gray = 8 + (index - 232) * 10;
        return `rgb(${gray},${gray},${gray})`;
      }
      const n = index - 16;
      const r = Math.floor(n / 36), g = Math.floor((n % 36) / 6), b = n % 6;
      const channel = value => value === 0 ? 0 : 55 + value * 40;
      return `rgb(${channel(r)},${channel(g)},${channel(b)})`;
    }

    function resetPtyStyle() { ptyStyle = {}; }

    function styleForCell(cell) {
      const style = { ...cell.style };
      if (style.inverse) {
        const fg = style.color || "#1e293b";
        style.color = style.background || "#1e293b";
        style.background = fg;
      }
      delete style.inverse;
      return style;
    }

    function renderPtyLine() {
      if (!ptyPartialRow) {
        ptyPartialRow = document.createElement("div");
        ptyPartialRow.className = "line ansi-line";
        out.appendChild(ptyPartialRow);
      }
      ptyPartialRow.replaceChildren();
      let run = null;
      for (let index = 0; index < ptyLine.length; index++) {
        const cell = ptyLine[index] || { ch: " ", style: {} };
        const style = styleForCell(cell);
        const key = JSON.stringify(style);
        if (!run || run.key !== key) {
          run = { key, node: document.createElement("span") };
          Object.assign(run.node.style, style);
          ptyPartialRow.appendChild(run.node);
        }
        run.node.textContent += cell.ch;
      }
      if (ptyLine.length === 0) ptyPartialRow.textContent = "";
      scrollBottom();
    }

    function requestPtyRender() {
      if (!ptyBatch && (ptyLine.length || ptyPartialRow)) renderPtyLine();
    }

    function finishPtyLine() {
      if (!ptyPartialRow) renderPtyLine();
      ptyPartialRow = null;
      ptyLine = [];
      ptyCursor = 0;
    }

    function erasePtyLine(mode) {
      if (mode === 0) ptyLine.splice(ptyCursor);
      else if (mode === 1) ptyLine.splice(0, ptyCursor + 1);
      else if (mode === 2) ptyLine = [];
      requestPtyRender();
    }

    function applySgr(params) {
      if (!params.length) params = [0];
      for (let index = 0; index < params.length; index++) {
        const raw = params[index];
        const n = raw === "" ? 0 : Number(raw);
        if (n === 0) resetPtyStyle();
        else if (n === 1) ptyStyle.fontWeight = "700";
        else if (n === 2) ptyStyle.opacity = "0.72";
        else if (n === 22) { delete ptyStyle.fontWeight; delete ptyStyle.opacity; }
        else if (n === 4) ptyStyle.textDecoration = "underline";
        else if (n === 24) delete ptyStyle.textDecoration;
        else if (n === 3) ptyStyle.fontStyle = "italic";
        else if (n === 23) delete ptyStyle.fontStyle;
        else if (n === 9) ptyStyle.textDecoration = "line-through";
        else if (n === 29) delete ptyStyle.textDecoration;
        else if (n === 7) ptyStyle.inverse = true;
        else if (n === 27) delete ptyStyle.inverse;
        else if (n === 39) delete ptyStyle.color;
        else if (n === 49) delete ptyStyle.background;
        else if (n >= 30 && n <= 37) ptyStyle.color = ansiColors[n - 30];
        else if (n >= 90 && n <= 97) ptyStyle.color = ansiColors[n - 90 + 8];
        else if (n >= 40 && n <= 47) ptyStyle.background = ansiColors[n - 40];
        else if (n >= 100 && n <= 107) ptyStyle.background = ansiColors[n - 100 + 8];
        else if (n === 38 || n === 48) {
          const target = n === 38 ? "color" : "background";
          const kind = Number(params[++index]);
          if (kind === 5) ptyStyle[target] = ansi256Color(params[++index]);
          else if (kind === 2) {
            const r = Number(params[++index] || 0), g = Number(params[++index] || 0), b = Number(params[++index] || 0);
            ptyStyle[target] = `rgb(${r},${g},${b})`;
          }
        }
      }
    }

    function applyPtyCsi(finalChar, body) {
      const privateMode = body.startsWith("?");
      const clean = privateMode ? body.slice(1) : body;
      const params = clean ? clean.split(";") : [];
      const values = params.map(v => Number(v || 0));
      if (finalChar === "m") return applySgr(params);
      if (privateMode) return; // cursor visibility and other TUI modes are ignored.
      const amount = Math.max(1, values[0] || 1);
      if (finalChar === "G" || finalChar === "`") ptyCursor = Math.max(0, amount - 1);
      else if (finalChar === "C" || finalChar === "a") ptyCursor += amount;
      else if (finalChar === "D") ptyCursor = Math.max(0, ptyCursor - amount);
      else if (finalChar === "K") erasePtyLine(values[0] || 0);
      else if (finalChar === "J" && (values[0] || 0) === 2) { ptyLine = []; requestPtyRender(); }
      else if (finalChar === "H" || finalChar === "f") ptyCursor = Math.max(0, (values[1] || 1) - 1);
    }

    function writePtyChar(ch) {
      if (ch === "\n") return finishPtyLine();
      if (ch === "\r") { ptyCursor = 0; return requestPtyRender(); }
      if (ch === "\b") { ptyCursor = Math.max(0, ptyCursor - 1); return requestPtyRender(); }
      if (ch === "\t") { const next = ptyCursor + (8 - (ptyCursor % 8)); while (ptyLine.length < next) ptyLine.push({ ch: " ", style: {} }); ptyCursor = next; return requestPtyRender(); }
      if (ch < " ") return;
      ptyLine[ptyCursor] = { ch, style: { ...ptyStyle } };
      ptyCursor++;
      requestPtyRender();
    }

    function consumePtyChunk(chunk) {
      ptyBatch = true;
      try { for (const ch of String(chunk ?? "")) {
        if (ptyOsc) {
          if (ch === "\x07") ptyOsc = false;
          else if (ptyEscape === "\x1b") {
            if (ch === "\\") { ptyOsc = false; ptyEscape = ""; }
            else ptyEscape = ch === "\x1b" ? "\x1b" : "";
          } else if (ch === "\x1b") ptyEscape = "\x1b";
          continue;
        }
        if (ptyEscape) {
          ptyEscape += ch;
          if (ptyEscape === "\x1b]") { ptyOsc = true; ptyEscape = ""; continue; }
          if (ptyEscape.startsWith("\x1b[")) {
            // The introducer '[' is itself in the final-byte range; wait for
            // at least one byte after ESC[ before completing a CSI sequence.
            if (ptyEscape.length > 2 && /[\x40-\x7e]/.test(ch)) {
              applyPtyCsi(ch, ptyEscape.slice(2, -1));
              ptyEscape = "";
            }
            continue;
          }
          if (ptyEscape.length >= 2) { ptyEscape = ""; }
          continue;
        }
        if (ch === "\x1b") { ptyEscape = "\x1b"; continue; }
        writePtyChar(ch);
      } } finally { ptyBatch = false; requestPtyRender(); }
    }

    let failCount = 0;
    let pending = "";
    let partialRow = null;

    function formatOutputText(text) {
      if (!text) return "";
      let html = text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
      if (/(成功|OK|DONE)/.test(html)) return `<span class="hl-root">${html}</span>`;
      const errPattern = /(发送失败|ERR:|FAILED|Error|error|失败|HTTP [45]\d{2})/g;
      return html.replace(errPattern, (match) => `<span class="hl-err">${match}</span>`);
    }

    let followOutput = true;
    out.addEventListener?.('scroll', () => {
      if (out.clientHeight > 0) followOutput = out.scrollHeight - out.clientHeight - out.scrollTop < 24;
    }, { passive: true });
    function scrollBottom(force = false) {
      if (!force && !followOutput) return;
      requestAnimationFrame(() => {
        if (!out.clientHeight) return;
        out.scrollTop = out.scrollHeight;
        followOutput = true;
      });
    }

    function appendLine(text) {
      const row = document.createElement("div");
      row.className = "line";
      const txt = document.createElement("div");
      txt.className = "txt";
      txt.innerHTML = formatOutputText(text);
      row.appendChild(txt);
      out.appendChild(row);
      scrollBottom();
    }

    function setPartialText(text) {
      if (!text) {
        if (partialRow) {
          partialRow.remove();
          partialRow = null;
        }
        return;
      }
      if (!partialRow) {
        partialRow = document.createElement("div");
        partialRow.className = "line";
        partialRow.innerHTML = '<div class="txt"></div>';
        out.appendChild(partialRow);
      }
      partialRow.firstChild.innerHTML = formatOutputText(text);
      scrollBottom();
    }

    function normalizePtyOutput(s) {
      return String(s ?? "")
        .replace(/\r\n/g, "\n")
        .replace(/\r/g, "");
    }

    function consumeChunk(chunk) {
      if (!chunk) return;
      // ANSI is an output format, independent of whether the bytes arrived
      // through a PTY or anonymous pipe.  Pipe mode lacks TTY semantics, but
      // CLI programs can still emit colors and carriage-return progress.
      consumePtyChunk(chunk);
    }

    function setConn(ok, text) {
      connDot.classList.remove("ok", "bad", "connecting");
      if (ok === true) connDot.classList.add("ok");
      else if (ok === false) connDot.classList.add("bad");
      else connDot.classList.add("connecting");
      connText.textContent = text;
    }

	let hasConnectedOnce = false;
	let exitOverlayShown = false;

	function showPageExitOverlay() {
	  if (exitOverlayShown) return;
	  exitOverlayShown = true;
	  const overlay = document.getElementById("pageExitOverlay");
	  if (overlay) overlay.classList.add("show");
	}

	async function tick() {
	  try {
		const chunk = await RequestApi.getNewOutput();
		if (chunk) consumeChunk(chunk);
		failCount = 0;
		hasConnectedOnce = true;
		setConn(true, "在线");
	  } catch (e) {
		failCount++;
		if (!hasConnectedOnce) {
		  setConn(false, "异常");
		  return;
		}
		if (failCount >= 2) {
		  setConn(false, "已退出");
		  showPageExitOverlay();
		  return;
		}
		setConn(null, "连接中");
	  }
	}

    return {
      formatOutputText,
      scrollBottom,
      appendLine,
      consumeChunk,
      setTransportMode(mode) {
        transportMode = mode === "pipe" ? "pipe" : "pty";
      },
      setConn,
      tick,
    };
  }

  function shellQuote(s) {
    s = String(s ?? "");
    return "'" + s.replace(/'/g, `'\\''`) + "'";
  }

  function splitShellArgs(input) {
    input = String(input ?? "").trim();
    if (!input) return [];
    const args = [];
    let cur = "";
    let quote = null; // "'" or '"'
    let escape = false;
    for (let i = 0; i < input.length; i++) {
      const ch = input[i];
      if (escape) {
        cur += ch;
        escape = false;
        continue;
      }
      if (quote === '"') {
        if (ch === "\\") escape = true;
        else if (ch === '"') quote = null;
        else cur += ch;
        continue;
      }
      if (quote === "'") {
        if (ch === "'") quote = null;
        else cur += ch;
        continue;
      }
      // 不在引号内
      if (/\s/.test(ch)) {
        if (cur) { args.push(cur); cur = ""; }
        continue;
      }
      if (ch === '"' || ch === "'") { quote = ch; continue; }
      if (ch === "\\") { escape = true; continue; }
      cur += ch;
    }
    if (escape) cur += "\\";
    if (quote) throw new Error("参数引号未闭合");
    if (cur) args.push(cur);
    return args;
  }

  function getPathDir(filePath) {
    const p = String(filePath ?? "");
    const idx = p.lastIndexOf("/");
    if (idx < 0) return ".";
    if (idx === 0) return "/";
    return p.slice(0, idx);
  }

  function buildShCommand(filePath, rawArgs) {
    filePath = String(filePath ?? "");
    const dir = getPathDir(filePath);
    const argv = splitShellArgs(rawArgs).map(shellQuote);
    const cmd = ["(cd", shellQuote(dir), "&&", "sh", shellQuote(filePath), ...argv,].join(" ");
    return cmd + ")";
  }

  function buildExecCommand(filePath, rawArgs) {
    filePath = String(filePath ?? "");
    const dir = getPathDir(filePath);
    const argv = splitShellArgs(rawArgs).map(shellQuote);
    const quotedFile = shellQuote(filePath);
    const cmd = ["(cd", shellQuote(dir), "&&", "chmod", "777", quotedFile, "&&", quotedFile, ...argv].join(" ");
    return cmd + ")";
  }

  window.SKTerminalCore = {
    createTerminalCore,
    shellQuote,
    splitShellArgs,
    buildShCommand,
    buildExecCommand,
    getPathDir,
  };
})();

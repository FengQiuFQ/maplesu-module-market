async function refresh() {
  const status = document.getElementById('status');
  const log = document.getElementById('log');
  try {
    const state = await fetch('api/status', { cache: 'no-store' }).then(r => r.json());
    const stateLabel = state.running ? 'running' : 'stopped';
    const staleLabel = state.pid_file_stale ? ' stale-pid' : '';
    status.textContent = stateLabel + staleLabel + ' pid=' + state.pid +
      ' alive=' + state.pid_alive + ' abi=' + state.abiList;
    log.textContent = await fetch('api/log', { cache: 'no-store' }).then(r => r.text());
    if (state.last_exit_status) {
      log.textContent += '\n[status]\n' + state.last_exit_status;
    }
  } catch (error) {
    status.textContent = 'error: ' + error;
  }
}
refresh();
setInterval(refresh, 3000);

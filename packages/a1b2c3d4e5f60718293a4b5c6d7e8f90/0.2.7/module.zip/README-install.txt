OhMyKeymint → SKRoot Pro 移植模块（模块包）

安装方式：
  1) 用 SKRoot 模块安装器安装本 zip（模块 ID: a1b2c3d4e5f60718293a4b5c6d7e8f90）
  2) 重启手机；模块会自动：
     - 安装内核 avc_denied 钩子（只对 keymint/kwrk 进程放行）
     - 写入原模块默认的隐藏标记属性（BL 状态等）
     - 启动 keymint / inject 守护、注入 keystore2
     - 启动 Shizuku（若已安装）
  3) 首次使用需要自备 keybox：在模块 WebUI「更换Keybox」里导入你自己的 keybox.xml

默认配置（与原模块一致）：
  开：keybox/KeyMint 接管、隐藏标记属性、目标应用 5 个
  关：PIF 指纹伪装、自动添加应用

隐藏项（本版新增）：
  - 进程名：keymint/inject → kwrkmint/kwrkinj
  - 模块入口 comm：kwrkmod
  - 属性：原模块全部 BL/调试隐藏 + bootmode recovery→unknown、
    persist.logd.size* 清空、ro.kernel.qemu 清空，
    并覆盖 TEESimulator hide_bootloader.sh 的全部分区/厂商标记：
    partition.*.verified=0、ro.oem_unlock_supported=0、ro.boot.asusverifiedstate=PASS
    （通过 kwrk_rp + avc 放行 + resetprop -n 强制写入，SKRoot 原生 resetprop 对这些无效）
  - 开机立即写属性一遍，20 秒后再补一遍
  - OMK 日志级别降为 error；WebUI 端口 10 分钟无请求自动退出
  - bin/inject 启动时改为指向 bin/kwrkinj 的软链，keymint 的
    auto-targets watcher 正常工作

已知限制（均为真实状态，不做假显示）：
  - 设备为 HIDL keymint@4.0 / keymint3，OMK 探测 AIDL 接口，
    因此 WebUI 中 TEE / StrongBox 的「硬件支持」会显示不支持
  - Soter（微信支付指纹）与腾讯 Soter Server 功能已移除
  - RKP 签发需要系统 RemoteProvisioner APK + 兼容 AIDL + Google RKP 服务（本机均不满足）
  - 修复 RKP 会先检测厂商修复通道，检测到支持才允许执行
  - 对抗「证书链替换」的专用检测器（如 echo-trap / StrongBox 标记校验）无法真实通过，
    这是软件接管证书链的固有限制，与原模块一致

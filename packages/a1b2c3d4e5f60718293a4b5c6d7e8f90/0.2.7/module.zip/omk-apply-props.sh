#!/system/bin/sh
# OMK 属性伪装：把 PIF 指纹与"已上锁"引导状态写入系统属性（SKRoot resetprop）
PRIV="$1"
[ -z "$PRIV" ] && exit 1
RP="$PRIV/resetprop"
[ -x "$RP" ] || RP=/data/adb/magisk/resetprop
[ -x "$RP" ] || exit 2
OMK="$PRIV/omk"
# 模块加载器会把模块目录递归标成 system_file，keystore2 读不了 omk 数据；
# 这里重新打回 keystore_data_file（注入初始化依赖可读的 injector.toml/keybox）
chcon -R u:object_r:keystore_data_file:s0 "$PRIV/omk" 2>/dev/null

# vendor./sys. 命名空间属性用 vendor_init 域 setprop 写入（resetprop 对这两个命名空间静默无效）
vset() {
  ( echo u:r:vendor_init:s0 > /proc/self/attr/current 2>/dev/null; /system/bin/setprop "$1" "$2" ) 2>/dev/null
}
PROFILE="$OMK/data/pif_fingerprint.json"

# 隐藏标记属性（原模块 service.sh 默认行为）
$RP ro.boot.vbmeta.invalidate_on_error yes
$RP ro.boot.vbmeta.avb_version 1.2
$RP ro.boot.vbmeta.hash_alg sha256
$RP ro.boot.vbmeta.size 19968
$RP ro.boot.vbmeta.device_state locked
$RP ro.boot.verifiedbootstate green
$RP ro.boot.flash.locked 1
$RP ro.boot.veritymode enforcing
$RP ro.boot.warranty_bit 0
$RP ro.warranty_bit 0
$RP ro.debuggable 0
$RP ro.force.debuggable 0
$RP ro.secure 1
$RP ro.adb.secure 1
$RP ro.build.type user
$RP ro.build.tags release-keys
$RP ro.vendor.boot.warranty_bit 0
$RP ro.vendor.warranty_bit 0
vset vendor.boot.vbmeta.device_state locked
vset vendor.boot.verifiedbootstate green
vset sys.oem_unlock_allowed 0
$RP ro.secureboot.lockstate locked
$RP ro.boot.realmebootstate green
$RP ro.boot.realme.lockstate 1
$RP ro.crypto.state encrypted
vset sys.usb.adb.disabled " "

# PIF 指纹（仅当用户启用时）
if [ -f "$PRIV/pif_enabled" ] && [ -f "$PROFILE" ]; then
  val() { sed -n 's/.*"'"$1"'":[[:space:]]*"\([^"]*\)".*/\1/p' "$PROFILE" | head -1; }
  enabled=$(sed -n 's/.*"enabled":[[:space:]]*\(true\|false\).*/\1/p' "$PROFILE" | head -1)
  model=$(val model); brand=$(val brand); manu=$(val manufacturer)
  dev=$(val device); prod=$(val product); fp=$(val fingerprint)
  patch=$(val security_patch); bid=$(val id); rel=$(val release)
  inc=$(val incremental); btype=$(val build_type); tags=$(val tags)
  [ -n "$model" ] && $RP ro.product.model "$model"
  [ -n "$brand" ] && $RP ro.product.brand "$brand"
  [ -n "$manu" ]  && $RP ro.product.manufacturer "$manu"
  [ -n "$dev" ]   && $RP ro.product.device "$dev"
  [ -n "$prod" ]  && $RP ro.product.name "$prod"
  if [ -n "$fp" ]; then
    $RP ro.build.fingerprint "$fp"
    $RP ro.system.build.fingerprint "$fp"
    $RP ro.vendor.build.fingerprint "$fp"
    $RP ro.product.build.fingerprint "$fp"
    $RP ro.bootimage.build.fingerprint "$fp"
    $RP ro.odm.build.fingerprint "$fp"
    $RP ro.system_ext.build.fingerprint "$fp"
  fi
  [ -n "$patch" ] && $RP ro.build.version.security_patch "$patch"
  [ -n "$bid" ]   && $RP ro.build.id "$bid"
  [ -n "$rel" ]   && $RP ro.build.version.release "$rel"
  [ -n "$inc" ]   && $RP ro.build.version.incremental "$inc"
  [ -n "$btype" ] && $RP ro.build.type "$btype"
  [ -n "$tags" ]  && $RP ro.build.tags "$tags"
fi
echo "omk props applied"

# 恢复模式痕迹
for bp in ro.bootmode ro.boot.bootmode vendor.boot.bootmode; do
  case "$(getprop $bp)" in
    *recovery*) $RP $bp unknown ;;
  esac
done

# LSPosed/框架 logd 痕迹
setprop persist.logd.size "" 2>/dev/null
setprop persist.logd.size.crash "" 2>/dev/null
setprop persist.logd.size.system "" 2>/dev/null
setprop persist.logd.size.main "" 2>/dev/null

# 云手机/模拟器痕迹
[ -n "$($RP ro.kernel.qemu)" ] && $RP ro.kernel.qemu ""

# 降低 OMK 日志输出（减少 logcat 痕迹）
[ -f "$PRIV/omk/config.toml" ] && sed -i 's/^log_level *=.*/log_level = "error"/' "$PRIV/omk/config.toml" 2>/dev/null
[ -f "$PRIV/omk/injector.toml" ] && sed -i 's/^log_level *=.*/log_level = "error"/' "$PRIV/omk/injector.toml" 2>/dev/null

# 分区校验 / 厂商解锁标记（对齐 TEESimulator hide_bootloader.sh）
# SKRoot 自带 resetprop 对 partition.* / ro.oem_unlock_supported / 新增 ro.boot.* 会静默失败；
# 用 kwrk_rp（resetprop 副本 + argc0=resetprop + comm=kwrk 触发 avc 放行）配合 -n 强制写入。
RPW="$PRIV/bin/kwrk_rp"
if [ -x "$RPW" ]; then
  for pp in partition.system.verified partition.vendor.verified partition.product.verified \
            partition.system_ext.verified partition.odm.verified; do
    $RPW -n "$pp" 0 2>/dev/null
  done
  $RPW -n ro.oem_unlock_supported 0 2>/dev/null
  $RPW -n ro.boot.asusverifiedstate PASS 2>/dev/null
fi

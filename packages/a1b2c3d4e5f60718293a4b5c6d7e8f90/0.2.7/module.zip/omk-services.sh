#!/system/bin/sh
D="$1"
while :; do
  [ -z "$(pidof kwrkmint)" ] && (setsid "$D/bin/kwrkmint" >/dev/null 2>&1 &)
  if [ -z "$(pidof kwrkinj)" ]; then
    (setsid "$D/bin/kwrkinj" --auto-targets-watch >/dev/null 2>&1 &)
  fi
  sleep 3
done

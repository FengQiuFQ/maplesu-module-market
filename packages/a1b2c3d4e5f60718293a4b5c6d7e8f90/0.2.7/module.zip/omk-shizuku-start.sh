#!/system/bin/sh
# 保持 Shizuku server 在线（root 方式启动）
APK=$(/system/bin/pm path moe.shizuku.privileged.api 2>/dev/null | sed 's/package://')
[ -z "$APK" ] && APK=$(ls /data/app/*/moe.shizuku*/base.apk 2>/dev/null | head -1)
[ -z "$APK" ] && exit 0
LIB="${APK%/*}/lib/arm64/libshizuku.so"
[ -x "$LIB" ] || exit 0
[ -n "$(pidof shizuku_server)" ] && exit 0
setsid "$LIB" --apk="$APK" >/dev/null 2>&1 &

# 兜底看门狗：C supervisor 异常退出时，由 shell 循环保证 keymint/inject 继续运行
D=$(dirname "$0")
if [ -z "$(pidof kwrkmint)" ] || [ -z "$(pidof kwrkinj)" ]; then
  if ! ps -A -o ARGS 2>/dev/null | grep -q "[o]mk-services.sh"; then
    setsid "$D/omk-services.sh" "$D" >/dev/null 2>&1 &
  fi
fi

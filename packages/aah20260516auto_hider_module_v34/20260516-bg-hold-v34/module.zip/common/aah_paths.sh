#!/system/bin/sh

AAH_DATA_DIR=${AAH_DATA_DIR:-/data/local/tmp/app_auto_hider}
AAH_RULES_DIR=${AAH_RULES_DIR:-$AAH_DATA_DIR/rules}
AAH_PRESETS_FILE=${AAH_PRESETS_FILE:-$AAH_DATA_DIR/presets.json}
AAH_FREE_LEASE=${AAH_FREE_LEASE:-$AAH_DATA_DIR/free_online_ok}
AAH_LEGACY_RULES_DIR=${AAH_LEGACY_RULES_DIR:-$MODPATH/rules}
AAH_LEGACY_PRESETS_FILE=${AAH_LEGACY_PRESETS_FILE:-$MODPATH/presets.json}

aah_paths_prepare() {
    mkdir -p "$AAH_DATA_DIR" "$AAH_RULES_DIR" 2>/dev/null || true
    chmod 0777 "$AAH_DATA_DIR" "$AAH_RULES_DIR" 2>/dev/null || true
    if command -v chown >/dev/null 2>&1; then
        chown shell:shell "$AAH_DATA_DIR" "$AAH_RULES_DIR" 2>/dev/null || true
    fi
    if [ -x /system/bin/toybox ]; then
        /system/bin/toybox chcon -R u:object_r:shell_data_file:s0 "$AAH_DATA_DIR" 2>/dev/null || true
    else
        chcon -R u:object_r:shell_data_file:s0 "$AAH_DATA_DIR" 2>/dev/null || true
    fi
}

aah_paths_migrate_legacy() {
    aah_paths_prepare
    if [ -d "$AAH_LEGACY_RULES_DIR" ]; then
        for _aah_old_rule in "$AAH_LEGACY_RULES_DIR"/*.conf; do
            [ -f "$_aah_old_rule" ] || continue
            _aah_new_rule="$AAH_RULES_DIR/$(basename "$_aah_old_rule")"
            [ -f "$_aah_new_rule" ] || cp -p "$_aah_old_rule" "$_aah_new_rule" 2>/dev/null || true
        done
    fi
    if [ -f "$AAH_LEGACY_PRESETS_FILE" ] && [ ! -f "$AAH_PRESETS_FILE" ]; then
        cp -p "$AAH_LEGACY_PRESETS_FILE" "$AAH_PRESETS_FILE" 2>/dev/null || true
    fi
    chmod 0666 "$AAH_RULES_DIR"/*.conf "$AAH_PRESETS_FILE" 2>/dev/null || true
    unset _aah_old_rule _aah_new_rule
}

aah_restore_managed_apps() {
    MODPATH=${MODPATH:-/data/adb/skroot/modules/app_auto_hider}
    AAH_DATA_DIR=${AAH_DATA_DIR:-/data/local/tmp/app_auto_hider}
    AAH_RULES_DIR=${AAH_RULES_DIR:-$AAH_DATA_DIR/rules}
    _aah_users=$(
        {
            am get-current-user 2>/dev/null
            cmd user list 2>/dev/null | sed -n 's/.*UserInfo{\([0-9][0-9]*\):.*/\1/p'
            echo 0
        } | sed '/^[[:space:]]*$/d' | sort -nu | tr '\n' ' '
    )
    [ -n "$_aah_users" ] || _aah_users=0
    _aah_pkgs=$(
        {
            cat "$AAH_DATA_DIR/aah.state" 2>/dev/null
            for _aah_rule in "$AAH_RULES_DIR"/*.conf "$MODPATH/rules"/*.conf; do
                [ -f "$_aah_rule" ] && sed -e 's/\r$//' -e '/^[[:space:]]*#/d' -e '/^[[:space:]]*$/d' "$_aah_rule" 2>/dev/null
            done
        } | sort -u | grep -v '^$'
    )
    for _aah_pkg in $_aah_pkgs; do
        for _aah_user in $_aah_users; do
            pm unhide --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || cmd package unhide --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || true
            pm unsuspend --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || cmd package unsuspend --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || true
            pm enable --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || true
        done
    done
    [ -n "$_aah_pkgs" ] && echo "[$(date '+%H:%M:%S.%3N' 2>/dev/null)] restore-managed pkgs=$(printf '%s' "$_aah_pkgs" | tr '\n' ',')" >> "$AAH_DATA_DIR/aah.log" 2>/dev/null
    rm -f "$AAH_DATA_DIR/aah.state" "$AAH_DATA_DIR/aah.games" "$AAH_DATA_DIR"/aah.bgsince.* 2>/dev/null || true
    unset _aah_users _aah_pkgs _aah_rule _aah_pkg _aah_user
}

#!/system/bin/sh
# 模块卸载时执行：恢复所有被隐藏的应用，清理数据目录
MODDIR=${0%/*}
AAH_DATA_DIR="/data/local/tmp/app_auto_hider"
AAH_RULES_DIR="$AAH_DATA_DIR/rules"
AAH_STATE="$AAH_DATA_DIR/aah.state"

# 停止守护进程
if [ -f "$AAH_DATA_DIR/aah.pid" ]; then
    _pid=$(cat "$AAH_DATA_DIR/aah.pid" 2>/dev/null | tr -d ' \r\n')
    [ -n "$_pid" ] && kill -9 "$_pid" 2>/dev/null
fi
rm -f "$AAH_DATA_DIR/aah.pid" "$AAH_DATA_DIR/aah.lock/pid" 2>/dev/null
rmdir "$AAH_DATA_DIR/aah.lock" 2>/dev/null

# 获取所有用户
AAH_USERS=$(
    {
        am get-current-user 2>/dev/null
        cmd user list 2>/dev/null | sed -n 's/.*UserInfo{\([0-9][0-9]*\):.*/\1/p'
        echo 0
    } | sed '/^[[:space:]]*$/d' | sort -nu | tr '\n' ' '
)
[ -n "$AAH_USERS" ] || AAH_USERS=0

# 收集所有被管理的包名
AAH_PKGS=$(
    {
        cat "$AAH_STATE" 2>/dev/null
        for _r in "$AAH_RULES_DIR"/*.conf "$MODDIR/rules"/*.conf; do
            [ -f "$_r" ] && sed -e 's/\r$//' -e '/^[[:space:]]*#/d' -e '/^[[:space:]]*$/d' "$_r" 2>/dev/null
        done
    } | sort -u | grep -v '^$'
)

# 恢复所有应用
for _pkg in $AAH_PKGS; do
    for _u in $AAH_USERS; do
        pm unhide --user "$_u" "$_pkg" >/dev/null 2>&1
        cmd package unhide --user "$_u" "$_pkg" >/dev/null 2>&1
        pm unsuspend --user "$_u" "$_pkg" >/dev/null 2>&1
        pm enable --user "$_u" "$_pkg" >/dev/null 2>&1
    done
done

# 清理数据目录
rm -rf "$AAH_DATA_DIR" 2>/dev/null

echo "[AAH] uninstall done: restored $(echo "$AAH_PKGS" | wc -l) apps"

// main.js — 应用自动隐藏 WebUI
// 通过 SKRoot 官方 REST API 与 so 通信

let allApps = [];
let filteredApps = [];
let selectedApps = new Set();
let allGames = [];
let filteredGames = [];
let selectedGame = '';
let currentRules = [];

// ============ API ============
async function apiGet(path) {
  try {
    const resp = await fetch(new URL(path, window.location.href), { method: 'GET' });
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    return await resp.text();
  } catch (e) { console.error('GET', path, e); return null; }
}

async function apiPost(path, body = '') {
  try {
    const resp = await fetch(new URL(path, window.location.href), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body
    });
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    return await resp.text();
  } catch (e) { console.error('POST', path, e); return null; }
}

// ============ 状态轮询 ============
async function fetchStatus() {
  const raw = await apiGet('/api/status');
  if (!raw) return;
  try {
    const s = JSON.parse(raw);
    const dot = document.getElementById('statusDot');
    const text = document.getElementById('statusText');
    if (s.running) { dot.classList.add('online'); text.textContent = '运行中'; }
    else { dot.classList.remove('online'); text.textContent = '已停止'; }
    document.getElementById('daemonStatus').textContent = s.running ? '运行中' : '已停止';
    document.getElementById('daemonPid').textContent = s.pid || '--';
    document.getElementById('fgApp').textContent = s.foreground || '--';
    document.getElementById('hiddenCount').textContent = (s.hidden || []).length + ' 个';
  } catch (e) {}
}

async function fetchConfig() {
  const raw = await apiGet('/api/config');
  if (!raw) return;
  try {
    const c = JSON.parse(raw);
    document.getElementById('cfgDisabled').checked = c.disabled;
    document.getElementById('cfgFgOnly').checked = c.foreground_only;
    document.getElementById('cfgKeepBg').checked = c.keep_background;
  } catch (e) {}
}

async function saveConfig() {
  const body = JSON.stringify({
    disabled: document.getElementById('cfgDisabled').checked,
    foreground_only: document.getElementById('cfgFgOnly').checked,
    keep_background: document.getElementById('cfgKeepBg').checked
  });
  await apiPost('/api/config', body);
  showToast('配置已保存');
}

// ============ 规则 ============
async function fetchRules() {
  const raw = await apiGet('/api/rules');
  if (!raw) return;
  try {
    const data = JSON.parse(raw);
    currentRules = data.games || [];
    renderRules();
  } catch (e) {}
}

function renderRules() {
  const list = document.getElementById('ruleList');
  if (!currentRules.length) {
    list.innerHTML = '<div class="empty-hint">暂无规则，点击右上角添加</div>';
    return;
  }
  let html = '';
  currentRules.forEach(r => {
    html += '<div class="rule-card">';
    html += '<div class="rule-game">' + esc(r.pkg) + '</div>';
    html += '<div class="rule-apps">';
    (r.apps || []).forEach(a => {
      html += '<span class="rule-app-tag">' + esc(a) + '</span>';
    });
    if (!r.apps || !r.apps.length) html += '<span class="rule-empty">未配置隐藏应用</span>';
    html += '</div>';
    html += '<div class="rule-actions">';
    html += '<button class="btn-sm btn-danger" onclick="deleteRule(\'' + esc(r.pkg) + '\')">删除</button>';
    html += '</div></div>';
  });
  list.innerHTML = html;
}

async function deleteRule(pkg) {
  if (!confirm('确定删除规则：' + pkg + '？')) return;
  await apiPost('/api/rules/delete', JSON.stringify({ game: pkg }));
  showToast('已删除');
  fetchRules();
}

// ============ 添加规则 ============
async function openAddDialog() {
  selectedApps.clear();
  selectedGame = '';
  document.getElementById('appSearch').value = '';
  const gs = document.getElementById('gameSearch');
  if (gs) gs.value = '';
  document.getElementById('addModal').classList.add('show');
  // 加载触发应用列表（手机内全部第三方应用）
  const gamesRaw = await apiGet('/api/games');
  try {
    const g = JSON.parse(gamesRaw);
    allGames = g.games || [];
    filteredGames = allGames;
    renderGameList();
  } catch (e) {
    document.getElementById('gameList').innerHTML = '<div class="loading">加载失败</div>';
  }
  // 加载应用列表
  const appsRaw = await apiGet('/api/apps');
  try {
    const a = JSON.parse(appsRaw);
    allApps = a.apps || [];
    filteredApps = allApps;
    renderAppList();
  } catch (e) {
    document.getElementById('appList').innerHTML = '<div class="loading">加载失败</div>';
  }
}

function closeAddDialog() {
  document.getElementById('addModal').classList.remove('show');
}

function filterGames() {
  const kw = document.getElementById('gameSearch').value.toLowerCase();
  filteredGames = kw ? allGames.filter(a => a.pkg.toLowerCase().includes(kw) || (a.label || '').toLowerCase().includes(kw)) : allGames;
  renderGameList();
}
function renderGameList() {
  const list = document.getElementById('gameList');
  if (!filteredGames.length) { list.innerHTML = '<div class="empty-hint">无匹配应用</div>'; return; }
  let html = '';
  filteredGames.forEach(a => {
    const on = selectedGame === a.pkg ? 'selected' : '';
    html += '<div class="app-item app-item-single ' + on + '" onclick="selectGame(\'' + esc(a.pkg).replace(/'/g, "\\'") + '\')">';
    html += '<span class="radio-dot ' + on + '"></span>';
    html += '<div class="app-info"><span class="app-label">' + esc(a.label || a.pkg) + '</span>';
    html += '<span class="app-pkg">' + esc(a.pkg) + '</span></div></div>';
  });
  list.innerHTML = html;
}
function selectGame(pkg) {
  selectedGame = (selectedGame === pkg) ? '' : pkg;
  renderGameList();
}
function filterApps() {
  const kw = document.getElementById('appSearch').value.toLowerCase();
  filteredApps = kw ? allApps.filter(a => a.pkg.toLowerCase().includes(kw) || (a.label || '').toLowerCase().includes(kw)) : allApps;
  renderAppList();
}

function renderAppList() {
  const list = document.getElementById('appList');
  if (!filteredApps.length) { list.innerHTML = '<div class="empty-hint">无匹配应用</div>'; return; }
  let html = '';
  filteredApps.forEach(a => {
    const checked = selectedApps.has(a.pkg) ? 'checked' : '';
    html += '<label class="app-item">';
    html += '<input type="checkbox" value="' + esc(a.pkg) + '" ' + checked + ' onchange="toggleApp(this)">';
    html += '<div class="app-info"><span class="app-label">' + esc(a.label || a.pkg) + '</span>';
    html += '<span class="app-pkg">' + esc(a.pkg) + '</span></div></label>';
  });
  list.innerHTML = html;
}

function toggleApp(cb) {
  if (cb.checked) selectedApps.add(cb.value);
  else selectedApps.delete(cb.value);
}

async function saveRule() {
  const game = selectedGame;
  if (!game) { showToast('请选择触发应用'); return; }
  if (!selectedApps.size) { showToast('请选择要隐藏的应用'); return; }
  const body = JSON.stringify({ game, apps: Array.from(selectedApps) });
  const res = await apiPost('/api/rules', body);
  if (res) {
    showToast('规则已保存');
    closeAddDialog();
    fetchRules();
  } else {
    showToast('保存失败');
  }
}

// ============ 守护进程控制 ============
async function daemonAction(action) {
  await apiPost('/api/daemon', action);
  showToast(action === 'start' ? '已启动' : action === 'stop' ? '已停止' : '已重启');
  setTimeout(fetchStatus, 500);
}

// ============ 工具 ============
function esc(s) {
  return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

function showToast(msg, duration = 2000) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), duration);
}

// ============ 初始化 ============
let statusTimer = null;
function startPolling() {
  if (statusTimer) return;
  fetchStatus();
  statusTimer = setInterval(fetchStatus, 5000);
}
function stopPolling() {
  if (statusTimer) { clearInterval(statusTimer); statusTimer = null; }
}
function init() {
  fetchStatus();
  fetchConfig();
  fetchRules();
  // 页面可见时轮询，切到后台时暂停以省电（移动端友好）
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stopPolling();
    else startPolling();
  });
  startPolling();
}
init();

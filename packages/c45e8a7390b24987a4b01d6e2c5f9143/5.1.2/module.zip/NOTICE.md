# 来源与许可证

本目录中的 MapleSU 适配代码按 AGPL-3.0-or-later 提供，完整文本见包内 `COPYING`。
保留以下上游的作者、许可证及声明。此开发包未修改 SDK 的内核实现。

| 组件 | 固定提交 | 来源 |
| --- | --- | --- |
| ReZygisk | `2c1d0df3b0d6e40d064927523c4dd1116cb8e832` | https://github.com/PerformanC/ReZygisk |
| CSOLoader | `0d29278cf60a3c38850dde3eaf07b0ffc3241f03` | ReZygisk 固定子模块，AGPL-3.0-or-later |
| PLTI | `ffbffaa9177bbb8ceede5bb120239a7ce0041c04` | ReZygisk 固定子模块，BSD-3-Clause |

ReZygisk 的原 `NOTICE` 声明 AGPL-3.0-or-later，其原 `LICENSE` 文件内容为 GPLv3。
两者按原样保留于 `LICENSES/ReZygisk-*`，未擅自替换上游声明。

策略工具复用 MapleSU 已有的 `module-policy`，来源、固定提交与文件摘要见其
`upstream/sources.json`。Magisk 派生代码与 GPL 文本、libsepol 源码与 LGPL 文本
随对应源码一起提供；改造未引入全局 permissive。

MapleSU_Ultra SDK 的头文件和 `libkernel_module_kit_static.a` 属于既有的外部
构建依赖；SDK 本身不包含在源码下载中。构建身份记录实际链接静态库的摘要。

两个用户提供的参考 ZIP 仅用于比较模块布局与 SDK 调用约定，未将其私有 daemon
改名打包，也未沿用联网时间门。HMA-OSS 发布库只用于兼容性测试，不在宿主包内。

LSPosed v1.9.2 与 Vector v2.2 官方发布文件也仅用于隔离兼容性测试，不在宿主包
中分发。测试依据分别固定为 f8927757e8704d96611e1f3d75f702e3f0ce061f 与
88f8e1faa8b4e7ce20aefabe9c295cd746ea038e；不把原版 LSPosed、Vector 和来源不同
的同名第三方包当成同一实现。

WebUI 为本项目独立实现，使用用户提供的 MapleSU Ultra 品牌横幅和现有管理器插画。
Zygisk Next 1.5.2 的发布前端仅参考状态信息组织；未复制其 JS/CSS 或附带其私有
二进制。宿主只展示自身已接通的能力，不将上游独有设置作为空开关提供。

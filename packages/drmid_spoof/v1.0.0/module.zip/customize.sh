#!/system/bin/sh
# customize.sh — install-time setup.
SKIPUNZIP=0
ui_print "- 伪装DrmID: installing"

case "$ARCH" in
  arm64) ;;
  *) ui_print "! arm64 only (ARCH=$ARCH)"; abort "! aborting";;
esac

mkdir -p /data/adb/drmid_spoof
chmod 0700 /data/adb/drmid_spoof

set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
set_perm "$MODPATH/drmid.sh" 0 0 0755

ui_print "- Installed. After reboot, open the module WebUI:"
ui_print "    设置 -> 模式(关闭/全局/单独) + 伪装值(随机/指定)"

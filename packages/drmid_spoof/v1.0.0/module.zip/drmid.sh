#!/system/bin/sh
# drmid.sh — WebUI backend. One-line JSON / "OK:"/"ERR:" output.
#   status                 -> JSON {daemon,target,mode,value,apps,active}
#   mode <off|global|app>  -> set spoof mode
#   setval <64hex>         -> set spoof value
#   random                 -> random spoof value
#   apps <pkg> [pkg...]    -> set per-app targets (resolves package -> uid)
#   applist                -> list installed third-party packages (one per line)
#   labels <pkg>...        -> "<pkg>\t<label>" lines (label resolved from the APK)
#   webui                  -> emit the embedded WebUI HTML (served from the daemon)
#   info                   -> JSON {name,version,author,description} from module.prop
# The value lives in drmid.hex (64 hex chars, parsed by the C daemon); mode in
# `mode`; targets in `apps` (packages, for display) + `uids` (resolved, for hook).
D=/data/adb/drmid_spoof
HEX="$D/drmid.hex"; MODEF="$D/mode"; APPSF="$D/apps"; UIDSF="$D/uids"
PIDF="$D/daemon.pid"
mkdir -p "$D"

_hup() { [ -f "$PIDF" ] && kill -HUP "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null; }
_daemon() { [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null && echo running || echo stopped; }
_val() { [ -s "$HEX" ] && tr -d ' \r\n' < "$HEX"; }
_mode() { [ -s "$MODEF" ] && tr -d ' \r\n' < "$MODEF" || echo off; }
_is_hex64() { case "$1" in *[!0-9a-fA-F]*) return 1;; esac; [ "${#1}" -eq 64 ]; }
# emit apps file as a JSON array
_apps_json() {
  printf '['
  if [ -s "$APPSF" ]; then
    first=1
    while IFS= read -r p; do
      [ -z "$p" ] && continue
      [ $first -eq 1 ] && first=0 || printf ','
      printf '"%s"' "$p"
    done < "$APPSF"
  fi
  printf ']'
}
# resolve a package name to its app uid (user 0)
_uid_of() {
  u=$(stat -c %u "/data/data/$1" 2>/dev/null)
  case "$u" in ''|*[!0-9]*) u=$(dumpsys package "$1" 2>/dev/null | grep -m1 'userId=' | sed 's/.*userId=\([0-9]*\).*/\1/');; esac
  case "$u" in ''|*[!0-9]*) return 1;; esac
  echo "$u"
}

case "$1" in
  status)
    m=$(_mode); v=$(_val)
    act=false
    if [ "$m" != off ] && [ -n "$v" ]; then
      if [ "$m" = global ]; then act=true
      elif [ "$m" = app ] && [ -s "$UIDSF" ]; then act=true; fi
    fi
    printf '{"daemon":"%s","target":"%s","mode":"%s","value":"%s","apps":%s,"active":%s}\n' \
      "$(_daemon)" "$(cat "$D/injected_target" 2>/dev/null)" "$m" "$v" "$(_apps_json)" "$act"
    ;;
  setval)
    _is_hex64 "$2" || { echo "ERR:need 64 hex chars"; exit 2; }
    printf '%s' "$2" | tr 'A-F' 'a-f' > "$HEX"; chmod 0600 "$HEX"; _hup
    echo "OK:$(_val)"
    ;;
  random)
    H=$(od -An -N32 -tx1 /dev/urandom | tr -d ' \n')
    printf '%s' "$H" > "$HEX"; chmod 0600 "$HEX"; _hup; echo "OK:$H"
    ;;
  mode)
    case "$2" in off|global|app) printf '%s' "$2" > "$MODEF"; _hup; echo "OK:$2";;
      *) echo "ERR:bad_mode"; exit 2;; esac
    ;;
  apps)
    shift
    : > "$APPSF"; : > "$UIDSF"
    # accept space- or comma-separated package names
    for p in $(printf '%s' "$*" | tr ',' ' '); do
      [ -z "$p" ] && continue
      echo "$p" >> "$APPSF"
      u=$(_uid_of "$p") && echo "$u" >> "$UIDSF"
    done
    chmod 0600 "$APPSF" "$UIDSF" 2>/dev/null
    _hup
    echo "OK:$(tr '\n' ' ' < "$UIDSF")"
    ;;
  applist)
    pm list packages -3 2>/dev/null | sed 's/^package://' | sort
    ;;
  labels)
    # resolve display labels for the given packages: apk path via pm, label via
    # the daemon's APK parser. One "<pkg>\t<label>" line each (label may be empty).
    shift
    BIN="${0%/*}/bin/drmid_daemon"
    for p in "$@"; do
      [ -z "$p" ] && continue
      lbl=""
      if [ -x "$BIN" ]; then
        ap=$(pm path "$p" 2>/dev/null | sed -n 's/^package://p' | head -n1)
        [ -n "$ap" ] && lbl=$("$BIN" label "$ap" 2>/dev/null | tr -d '\r\n\t')
      fi
      printf '%s\t%s\n' "$p" "$lbl"
    done
    ;;
  webui)
    # Emit the embedded WebUI (or a tamper page) straight from the daemon binary.
    # The HTML/CSS/JS is compiled into the binary, not shipped as loose files,
    # so it can't be casually edited; the binary also validates module.prop.
    BIN="${0%/*}/bin/drmid_daemon"
    [ -x "$BIN" ] || { echo "ERR:no daemon binary"; exit 1; }
    exec "$BIN" webui
    ;;
  info)
    P="${0%/*}/module.prop"
    # values are from our own (validated) module.prop; strip the few chars that
    # would break the one-line JSON rather than hand-roll escaping in toybox sed.
    _field() { sed -n "s/^$1=//p" "$P" 2>/dev/null | head -n1 | tr -d '\\"\r'; }
    printf '{"name":"%s","version":"%s","author":"%s","description":"%s"}\n' \
      "$(_field name)" "$(_field version)" "$(_field author)" "$(_field description)"
    ;;
  *) echo "ERR:unknown_cmd"; exit 1;;
esac

#!/system/bin/sh
# post-fs-data.sh — stage the hook .so and start the injector daemon.
MODDIR=${0%/*}
D=/data/adb/drmid_spoof
mkdir -p "$D"

cp -f "$MODDIR/bin/libdrmid_hook.so" "$D/libdrmid_hook.so" 2>/dev/null
chmod 0644 "$D/libdrmid_hook.so" 2>/dev/null

if [ -x "$MODDIR/bin/drmid_daemon" ]; then
  nohup "$MODDIR/bin/drmid_daemon" --hook "$D/libdrmid_hook.so" >>"$D/daemon.log" 2>&1 &
  echo "$!" > "$D/daemon.pid"
fi

#!/system/bin/sh
# service.sh — after boot, nudge the daemon to re-apply config once the HAL is up.
# (The daemon auto-applies drmid.bin right after it injects, so this is a safety
#  net for a persisted spoof value across reboots — no id capture is needed.)
MODDIR=${0%/*}
D=/data/adb/drmid_spoof

while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
sleep 6
[ -f "$D/daemon.pid" ] && kill -HUP "$(cat "$D/daemon.pid" 2>/dev/null)" 2>/dev/null

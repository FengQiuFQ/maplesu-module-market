#!/system/bin/sh
# uninstall.sh — clean up on module removal.
DATADIR=/data/adb/drmid_spoof

# Stop daemon (hook is auto-removed when target restarts / on reboot)
if [ -f "$DATADIR/daemon.pid" ]; then
  kill "$(cat "$DATADIR/daemon.pid" 2>/dev/null)" 2>/dev/null
fi

# Keep user config? Remove everything for a clean uninstall.
rm -rf "$DATADIR"

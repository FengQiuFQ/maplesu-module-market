#!/system/bin/sh
# 注：msg 用 printf "%b" 输出且不带换行，必须用 echo 补换行，
# 直接调用 msg 会导致输出粘连，故整文件关闭 SC2005（shellcheck 误报）
# shellcheck disable=SC2005

MODDIR="${0%/*}"
[ "$MODDIR" = "." ] && MODDIR="$(pwd)"
if [ ! -f "$MODDIR/inject_cosa.sh" ] && [ -f "/data/adb/modules/cosa_injector/inject_cosa.sh" ]; then
  MODDIR="/data/adb/modules/cosa_injector"
fi

# 加载 i18n（缺失时用兜底实现，避免 msg 未定义导致脚本崩溃）
if [ -f "$MODDIR/i18n.sh" ]; then
  . "$MODDIR/i18n.sh"
else
  msg() { printf "%s" "$1"; }
fi

# 注：msg 用 printf "%b" 输出且不带换行，此处必须用 echo 补换行，
# 直接调用 msg 会导致输出粘连（shellcheck SC2005 为误报）
echo "$(msg action_running)"
echo "$(msg action_moddir "$MODDIR")"
echo "$(msg action_injecting)"

if [ ! -f "$MODDIR/inject_cosa.sh" ]; then
  echo "$(msg action_notfound)"
  exit 1
fi

chmod 0755 "$MODDIR/inject_cosa.sh" 2>/dev/null || true
"$MODDIR/inject_cosa.sh"
RC=$?

echo "$(msg action_rc2 "$RC")"
exit "$RC"

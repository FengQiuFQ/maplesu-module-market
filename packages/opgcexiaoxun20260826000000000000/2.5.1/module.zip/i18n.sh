#!/system/bin/sh
# i18n.sh — COSA Injector 多语言支持库
# 支持: zh (中文), en (英文), fr (法语), ru (俄语)
# 用法: . "$MODDIR/i18n.sh"  然后用 msg <key> [arg1 arg2 ...] 输出本地化字符串
# 目标 shell 为 Android mksh，支持 local 关键字（SC3043 仅针对严格 POSIX）
# shellcheck disable=SC3043

_detect_lang() {
  local locale=""
  locale="$(getprop persist.sys.locale 2>/dev/null)"
  [ -z "$locale" ] && locale="$(getprop ro.product.locale 2>/dev/null)"
  [ -z "$locale" ] && locale="$(getprop persist.sys.language 2>/dev/null)"
  case "$locale" in
    zh*) echo "zh" ;;
    fr*) echo "fr" ;;
    ru*) echo "ru" ;;
    *)   echo "en" ;;
  esac
}

COSA_LANG="$(_detect_lang)"

# msg <key> [args...]
# 输出对应语言的字符串，%1 %2 ... 为位置参数占位符
msg() {
  local key="$1"; shift
  local str=""

  case "$COSA_LANG" in

    zh)
      case "$key" in
        install_start)        str="开始执行自定义安装逻辑..." ;;
        soc_detected)         str="设备 SoC 识别为: %1" ;;
        device_model)         str="设备型号: %1" ;;
        module_version)       str="当前模块版本为：%1" ;;
        whitelist_hit)        str="白名单命中: %1 -> %2" ;;
        platform_mapped)      str="平台映射: %1 -> %2" ;;
        soc_raw_dir)          str="使用原始 SoC 策略目录: %1" ;;
        whitelist_strategy)   str="使用白名单专属策略: %1" ;;
        base_strategy_lay)    str="铺底通用策略: %1" ;;
        whitelist_override)   str="覆盖白名单专属策略: %1" ;;
        proprietary_found)    str="检测到专有配置: %1，铺底通用策略: %2" ;;
        proprietary_override) str="覆盖专有配置: %1 -> %2" ;;
        strategy_deploy)      str="发现策略目录: %1，正在部署..." ;;
        strategy_notfound)    str="警告: 未找到匹配的策略文件夹 (SoC=%1, 解析=%2)" ;;
        mt_slc_detected)      str="检测到MT平台SLC调度配置: %1" ;;
        slc_version_synced)   str="已同步version为: %1" ;;
        slc_postfs_done)      str="已生成 post-fs-data.sh 和修改 service.sh 用于挂载SLC调度配置" ;;
        cleanup_start)        str="正在清理冗余策略..." ;;
        action_exec)          str="正在执行 action.sh..." ;;
        action_rc)            str="action.sh 执行返回码: %1" ;;
        action_notfound)      str="警告: 未找到 action.sh" ;;
        powercfg_gen)         str="正在生成 powercfg.json..." ;;
        powercfg_deploy)      str="正在部署 powercfg 文件到 /data/..." ;;
        powercfg_deployed)    str="已部署: %1" ;;
        node_init)            str="正在初始化服务节点..." ;;
        node_done)            str="节点初始化完成。" ;;
        install_done)         str="自定义安装步骤完成。" ;;
        notice_title)         str="【重要提示 / IMPORTANT】" ;;
        notice_body)          str="使用此模块必须关闭系统设置中的\"用户体验计划\"！\n路径：设置 -> 关于本机 -> 体验改进计划\n请务必照做！" ;;
        install_complete)     str="安装完成！" ;;
        inject_already_run)   str="提示：已有注入任务在执行，跳过本次运行" ;;
        db_notfound)          str="错误：数据库不存在（已尝试 /data 和 /data_ce）" ;;
        bind_id_fail)         str="错误：无法计算本机设备绑定 ID" ;;
        strategy_merged)      str="使用已合并策略目录: %1" ;;
        strategy_dir)         str="使用加密策略目录: %1" ;;
        inject_bin_notfound)  str="错误：未找到 inject_core 二进制文件，请确保已部署到模块目录" ;;
        inject_bin_using)     str="使用二进制注入器: %1" ;;
        prj_name)             str="机型代号: %1" ;;
        update_time)          str="更新时间: %1" ;;
        inject_done)          str="注入完成 (rc=%1)" ;;
        inject_fail)          str="错误：注入失败 (rc=%1)" ;;
        feedback_disabling)   str="正在关闭用户体验计划" ;;
        feedback_disabled)    str="成功：已关闭用户体验计划" ;;
        feedback_fail)        str="错误：未关闭用户体验计划" ;;
        boot_timeout)         str="错误：等待开机完成超时，终止注入" ;;
        db_not_ready)         str="提示：数据库尚未创建，跳过本次注入（已尝试 /data 和 /data_ce）" ;;
        inject_start)         str="开始执行策略注入" ;;
        inject_end)           str="策略注入流程结束" ;;
        action_running)       str="== OPGCE 运行中 ==" ;;
        action_moddir)        str="模块目录: %1" ;;
        action_injecting)     str="开始执行注入..." ;;
        action_rc2)           str="执行返回码: %1" ;;
        # debug
        dbg_model_start)      str="[DEBUG] hydro_model() 开始" ;;
        dbg_soc)              str="[DEBUG] SoC=%1" ;;
        dbg_jq_found)         str="[DEBUG] jq=%1" ;;
        dbg_whitelist_check)  str="[DEBUG] 白名单查询: key=%1" ;;
        dbg_mapped_soc)       str="[DEBUG] 映射结果: %1 -> %2" ;;
        dbg_resolved)         str="[DEBUG] 最终解析SoC: %1" ;;
        dbg_chip_subdir)      str="[DEBUG] chip_subdir=%1" ;;
        dbg_wl_path)          str="[DEBUG] 白名单路径=%1" ;;
        *)                    str="[zh:$key]" ;;
      esac
      ;;

    fr)
      case "$key" in
        install_start)        str="Démarrage de la logique d'installation personnalisée..." ;;
        soc_detected)         str="SoC détecté: %1" ;;
        device_model)         str="Modèle de l'appareil: %1" ;;
        module_version)       str="Version du module: %1" ;;
        whitelist_hit)        str="Correspondance liste blanche: %1 -> %2" ;;
        platform_mapped)      str="Correspondance plateforme: %1 -> %2" ;;
        soc_raw_dir)          str="Utilisation du répertoire SoC brut: %1" ;;
        whitelist_strategy)   str="Utilisation de la stratégie liste blanche: %1" ;;
        base_strategy_lay)    str="Déploiement stratégie de base: %1" ;;
        whitelist_override)   str="Remplacement par stratégie liste blanche: %1" ;;
        proprietary_found)    str="Config propriétaire détectée: %1, base: %2" ;;
        proprietary_override) str="Remplacement config propriétaire: %1 -> %2" ;;
        strategy_deploy)      str="Répertoire de stratégie trouvé: %1, déploiement..." ;;
        strategy_notfound)    str="Avertissement: aucun répertoire de stratégie (SoC=%1, résolu=%2)" ;;
        mt_slc_detected)      str="Config SLC plateforme MT détectée: %1" ;;
        slc_version_synced)   str="Version synchronisée: %1" ;;
        slc_postfs_done)      str="post-fs-data.sh généré et service.sh modifié pour le montage SLC" ;;
        cleanup_start)        str="Nettoyage des stratégies redondantes..." ;;
        action_exec)          str="Exécution de action.sh..." ;;
        action_rc)            str="Code retour action.sh: %1" ;;
        action_notfound)      str="Avertissement: action.sh introuvable" ;;
        powercfg_gen)         str="Génération de powercfg.json..." ;;
        powercfg_deploy)      str="Déploiement des fichiers powercfg vers /data/..." ;;
        powercfg_deployed)    str="Déployé: %1" ;;
        node_init)            str="Initialisation du nœud de service..." ;;
        node_done)            str="Nœud initialisé." ;;
        install_done)         str="Installation personnalisée terminée." ;;
        notice_title)         str="[IMPORTANT]" ;;
        notice_body)          str="Vous devez désactiver le \"Programme d'amélioration\" dans les paramètres système!\nChemin: Paramètres -> À propos -> Programme d'amélioration\nVeuillez le faire!" ;;
        install_complete)     str="Installation terminée!" ;;
        inject_already_run)   str="Info: une injection est déjà en cours, ignoré" ;;
        db_notfound)          str="Erreur: base de données introuvable (essayé /data et /data_ce)" ;;
        bind_id_fail)         str="Erreur: impossible de calculer l'ID de liaison de l'appareil" ;;
        strategy_merged)      str="Utilisation du répertoire de stratégie fusionné: %1" ;;
        strategy_dir)         str="Répertoire de stratégie chiffré: %1" ;;
        inject_bin_notfound)  str="Erreur: binaire inject_core introuvable, vérifiez le déploiement" ;;
        inject_bin_using)     str="Injecteur binaire: %1" ;;
        prj_name)             str="Code appareil: %1" ;;
        update_time)          str="Heure de mise à jour: %1" ;;
        inject_done)          str="Injection terminée (rc=%1)" ;;
        inject_fail)          str="Erreur: injection échouée (rc=%1)" ;;
        feedback_disabling)   str="Désactivation du programme d'amélioration..." ;;
        feedback_disabled)    str="Succès: programme d'amélioration désactivé" ;;
        feedback_fail)        str="Erreur: programme d'amélioration non désactivé" ;;
        boot_timeout)         str="Erreur: délai d'attente démarrage dépassé, injection annulée" ;;
        db_not_ready)         str="Info: base de données non créée, injection ignorée (/data et /data_ce)" ;;
        inject_start)         str="Démarrage de l'injection de stratégie" ;;
        inject_end)           str="Fin du processus d'injection" ;;
        action_running)       str="== OPGCE en cours ==" ;;
        action_moddir)        str="Répertoire du module: %1" ;;
        action_injecting)     str="Démarrage de l'injection..." ;;
        action_rc2)           str="Code retour: %1" ;;
        dbg_model_start)      str="[DEBUG] hydro_model() début" ;;
        dbg_soc)              str="[DEBUG] SoC=%1" ;;
        dbg_jq_found)         str="[DEBUG] jq=%1" ;;
        dbg_whitelist_check)  str="[DEBUG] Vérification liste blanche: clé=%1" ;;
        dbg_mapped_soc)       str="[DEBUG] Résultat mapping: %1 -> %2" ;;
        dbg_resolved)         str="[DEBUG] SoC résolu final: %1" ;;
        dbg_chip_subdir)      str="[DEBUG] chip_subdir=%1" ;;
        dbg_wl_path)          str="[DEBUG] chemin liste blanche=%1" ;;
        *)                    str="[fr:$key]" ;;
      esac
      ;;

    ru)
      case "$key" in
        install_start)        str="Запуск пользовательской логики установки..." ;;
        soc_detected)         str="Обнаружен SoC: %1" ;;
        device_model)         str="Модель устройства: %1" ;;
        module_version)       str="Версия модуля: %1" ;;
        whitelist_hit)        str="Совпадение в белом списке: %1 -> %2" ;;
        platform_mapped)      str="Сопоставление платформы: %1 -> %2" ;;
        soc_raw_dir)          str="Используется исходный каталог SoC: %1" ;;
        whitelist_strategy)   str="Используется стратегия из белого списка: %1" ;;
        base_strategy_lay)    str="Развёртывание базовой стратегии: %1" ;;
        whitelist_override)   str="Перекрытие стратегией из белого списка: %1" ;;
        proprietary_found)    str="Обнаружена проприетарная конфигурация: %1, база: %2" ;;
        proprietary_override) str="Перекрытие проприетарной конфигурацией: %1 -> %2" ;;
        strategy_deploy)      str="Найден каталог стратегий: %1, развёртывание..." ;;
        strategy_notfound)    str="Предупреждение: каталог стратегий не найден (SoC=%1, разрешено=%2)" ;;
        mt_slc_detected)      str="Обнаружена конфигурация SLC платформы MT: %1" ;;
        slc_version_synced)   str="Версия синхронизирована: %1" ;;
        slc_postfs_done)      str="post-fs-data.sh создан, service.sh изменён для монтирования SLC" ;;
        cleanup_start)        str="Очистка избыточных стратегий..." ;;
        action_exec)          str="Выполнение action.sh..." ;;
        action_rc)            str="Код возврата action.sh: %1" ;;
        action_notfound)      str="Предупреждение: action.sh не найден" ;;
        powercfg_gen)         str="Генерация powercfg.json..." ;;
        powercfg_deploy)      str="Развёртывание файлов powercfg в /data/..." ;;
        powercfg_deployed)    str="Развёрнуто: %1" ;;
        node_init)            str="Инициализация узла службы..." ;;
        node_done)            str="Узел инициализирован." ;;
        install_done)         str="Пользовательская установка завершена." ;;
        notice_title)         str="[ВАЖНО]" ;;
        notice_body)          str="Необходимо отключить \"Программу улучшения\" в настройках системы!\nПуть: Настройки -> Об устройстве -> Программа улучшения\nОбязательно выполните это!" ;;
        install_complete)     str="Установка завершена!" ;;
        inject_already_run)   str="Инфо: задача инъекции уже выполняется, пропуск" ;;
        db_notfound)          str="Ошибка: база данных не найдена (проверены /data и /data_ce)" ;;
        bind_id_fail)         str="Ошибка: не удалось вычислить ID привязки устройства" ;;
        strategy_merged)      str="Используется объединённый каталог стратегий: %1" ;;
        strategy_dir)         str="Каталог зашифрованных стратегий: %1" ;;
        inject_bin_notfound)  str="Ошибка: бинарный файл inject_core не найден, проверьте развёртывание" ;;
        inject_bin_using)     str="Используется инжектор: %1" ;;
        prj_name)             str="Код устройства: %1" ;;
        update_time)          str="Время обновления: %1" ;;
        inject_done)          str="Инъекция завершена (rc=%1)" ;;
        inject_fail)          str="Ошибка: инъекция не удалась (rc=%1)" ;;
        feedback_disabling)   str="Отключение программы улучшения..." ;;
        feedback_disabled)    str="Успех: программа улучшения отключена" ;;
        feedback_fail)        str="Ошибка: программа улучшения не отключена" ;;
        boot_timeout)         str="Ошибка: превышено время ожидания загрузки, инъекция отменена" ;;
        db_not_ready)         str="Инфо: база данных ещё не создана, инъекция пропущена (/data и /data_ce)" ;;
        inject_start)         str="Начало инъекции стратегий" ;;
        inject_end)           str="Процесс инъекции завершён" ;;
        action_running)       str="== OPGCE запущен ==" ;;
        action_moddir)        str="Каталог модуля: %1" ;;
        action_injecting)     str="Запуск инъекции..." ;;
        action_rc2)           str="Код возврата: %1" ;;
        dbg_model_start)      str="[DEBUG] hydro_model() начало" ;;
        dbg_soc)              str="[DEBUG] SoC=%1" ;;
        dbg_jq_found)         str="[DEBUG] jq=%1" ;;
        dbg_whitelist_check)  str="[DEBUG] Проверка белого списка: ключ=%1" ;;
        dbg_mapped_soc)       str="[DEBUG] Результат маппинга: %1 -> %2" ;;
        dbg_resolved)         str="[DEBUG] Итоговый SoC: %1" ;;
        dbg_chip_subdir)      str="[DEBUG] chip_subdir=%1" ;;
        dbg_wl_path)          str="[DEBUG] путь белого списка=%1" ;;
        *)                    str="[ru:$key]" ;;
      esac
      ;;

    *)  # en (default)
      case "$key" in
        install_start)        str="Starting custom installation logic..." ;;
        soc_detected)         str="Device SoC detected: %1" ;;
        device_model)         str="Device model: %1" ;;
        module_version)       str="Module version: %1" ;;
        whitelist_hit)        str="Whitelist match: %1 -> %2" ;;
        platform_mapped)      str="Platform mapped: %1 -> %2" ;;
        soc_raw_dir)          str="Using raw SoC strategy directory: %1" ;;
        whitelist_strategy)   str="Using whitelist-specific strategy: %1" ;;
        base_strategy_lay)    str="Laying base strategy: %1" ;;
        whitelist_override)   str="Overriding with whitelist strategy: %1" ;;
        proprietary_found)    str="Proprietary config detected: %1, base: %2" ;;
        proprietary_override) str="Overriding with proprietary config: %1 -> %2" ;;
        strategy_deploy)      str="Strategy directory found: %1, deploying..." ;;
        strategy_notfound)    str="Warning: no matching strategy directory (SoC=%1, resolved=%2)" ;;
        mt_slc_detected)      str="MT platform SLC dispatch config detected: %1" ;;
        slc_version_synced)   str="Version synced to: %1" ;;
        slc_postfs_done)      str="post-fs-data.sh generated and service.sh patched for SLC mount" ;;
        cleanup_start)        str="Cleaning up redundant strategies..." ;;
        action_exec)          str="Executing action.sh..." ;;
        action_rc)            str="action.sh return code: %1" ;;
        action_notfound)      str="Warning: action.sh not found" ;;
        powercfg_gen)         str="Generating powercfg.json..." ;;
        powercfg_deploy)      str="Deploying powercfg files to /data/..." ;;
        powercfg_deployed)    str="Deployed: %1" ;;
        node_init)            str="Initializing service node..." ;;
        node_done)            str="Node initialized." ;;
        install_done)         str="Custom installation steps complete." ;;
        notice_title)         str="[IMPORTANT]" ;;
        notice_body)          str="You must disable the \"User Experience Program\" in system settings!\nPath: Settings -> About -> Experience Improvement Program\nPlease do so!" ;;
        install_complete)     str="Installation complete!" ;;
        inject_already_run)   str="Info: injection task already running, skipping" ;;
        db_notfound)          str="Error: database not found (tried /data and /data_ce)" ;;
        bind_id_fail)         str="Error: failed to compute device bind ID" ;;
        strategy_merged)      str="Using merged strategy directory: %1" ;;
        strategy_dir)         str="Using encrypted strategy directory: %1" ;;
        inject_bin_notfound)  str="Error: inject_core binary not found, ensure module is deployed" ;;
        inject_bin_using)     str="Using injector binary: %1" ;;
        prj_name)             str="Device codename: %1" ;;
        update_time)          str="Update time: %1" ;;
        inject_done)          str="Injection complete (rc=%1)" ;;
        inject_fail)          str="Error: injection failed (rc=%1)" ;;
        feedback_disabling)   str="Disabling user experience program..." ;;
        feedback_disabled)    str="Success: user experience program disabled" ;;
        feedback_fail)        str="Error: user experience program not disabled" ;;
        boot_timeout)         str="Error: boot completion timeout, injection aborted" ;;
        db_not_ready)         str="Info: database not yet created, injection skipped (/data and /data_ce)" ;;
        inject_start)         str="Starting strategy injection" ;;
        inject_end)           str="Strategy injection process ended" ;;
        action_running)       str="== OPGCE Running ==" ;;
        action_moddir)        str="Module directory: %1" ;;
        action_injecting)     str="Starting injection..." ;;
        action_rc2)           str="Return code: %1" ;;
        dbg_model_start)      str="[DEBUG] hydro_model() start" ;;
        dbg_soc)              str="[DEBUG] SoC=%1" ;;
        dbg_jq_found)         str="[DEBUG] jq=%1" ;;
        dbg_whitelist_check)  str="[DEBUG] Whitelist lookup: key=%1" ;;
        dbg_mapped_soc)       str="[DEBUG] Mapping result: %1 -> %2" ;;
        dbg_resolved)         str="[DEBUG] Final resolved SoC: %1" ;;
        dbg_chip_subdir)      str="[DEBUG] chip_subdir=%1" ;;
        dbg_wl_path)          str="[DEBUG] whitelist path=%1" ;;
        *)                    str="[en:$key]" ;;
      esac
      ;;
  esac

  # 替换位置参数 %1 %2 ...
  # 优化：纯 shell 前缀/后缀剥离实现，零 fork。
  # 旧版每个参数 fork 一次 sed；直接 ${var//} 写法在 bash 5.2 下
  # 替换内容含 & 时会被当作"已匹配文本"展开，此处一并规避
  local i=1
  for arg in "$@"; do
    _mi_in="$str"; _mi_pat="%$i"; _mi_out=""
    while :; do
      case "$_mi_in" in
        *"$_mi_pat"*)
          _mi_out="${_mi_out}${_mi_in%%"$_mi_pat"*}${arg}"
          _mi_in="${_mi_in#*"$_mi_pat"}"
          ;;
        *) break ;;
      esac
    done
    str="${_mi_out}${_mi_in}"
    i=$((i + 1))
  done

  printf "%b" "$str"
}

#!/system/bin/sh
MODDIR="${0%/*}"
[ "$MODDIR" = "." ] && MODDIR="$(pwd)"

ENC_STRATEGY_DIR="$MODDIR/encrypted_strategy"
DB_PATH=""
# 数据库候选路径（与 service.sh 保持一致）
for p in "/data/data/com.oplus.cosa/databases/db_game_database" \
         "/data/user_de/0/com.oplus.cosa/databases/db_game_database"; do
  [ -f "$p" ] && { DB_PATH="$p"; break; }
done
LOG_FILE="$MODDIR/inject.log"
LOCK_DIR="$MODDIR/.inject_lock"
DEVICE_CONFIG="$MODDIR/device_config.json"
LOG_MAX_KB=1024

# ── helpers ───────────────────────────────────────────────────────────────

# 日志轮转：超过 LOG_MAX_KB 时只保留尾部一半，避免日志无限增长
rotate_log() {
  [ -f "$LOG_FILE" ] || return 0
  size="$(stat -c %s "$LOG_FILE" 2>/dev/null)" || return 0
  case "$size" in
    ''|*[!0-9]*) return 0 ;;
  esac
  if [ "$size" -gt $((LOG_MAX_KB * 1024)) ]; then
    if tail -c $((LOG_MAX_KB * 512)) "$LOG_FILE" > "$LOG_FILE.tmp" 2>/dev/null; then
      mv -f "$LOG_FILE.tmp" "$LOG_FILE" || rm -f "$LOG_FILE.tmp" 2>/dev/null
    else
      rm -f "$LOG_FILE.tmp" 2>/dev/null
    fi
  fi
}

is_number() {
  case "$1" in
    ''|*[!0-9]*) return 1 ;;
    *) return 0 ;;
  esac
}

log_msg() {
  ts="$(date '+%Y-%m-%d %H:%M:%S')"
  echo "[$ts] $*" >> "$LOG_FILE"
  echo "[$ts] $*"
  log -t cosa_injector "$*" 2>/dev/null || true
}

# shellcheck disable=SC2317  # 由 trap EXIT 间接调用，非不可达
cleanup() {
  rmdir "$LOCK_DIR" >/dev/null 2>&1
}

# 在候选路径列表中找到第一个可执行文件
find_bin() {
  for candidate in "$@"; do
    [ -z "$candidate" ] && continue
    [ -f "$candidate" ] || continue
    [ -x "$candidate" ] || chmod 0755 "$candidate" >/dev/null 2>&1
    [ -x "$candidate" ] && { printf "%s" "$candidate"; return 0; }
  done
  return 1
}

calc_local_bind_id() {
  printf "a4dbd57451750c196914468bab7b89c59e424767b804a6ff7e07c7df7afa2efe"
}

disable_feedback() {
  log_msg "$(msg feedback_disabling)"
  settings put system oplus_customize_cta_user_experience 0 >/dev/null 2>&1
  if [ "$(settings get system oplus_customize_cta_user_experience 2>/dev/null)" = "0" ]; then
    log_msg "$(msg feedback_disabled)"
  else
    log_msg "$(msg feedback_fail)"
  fi
}

# ── lock ──────────────────────────────────────────────────────────────────
if ! mkdir "$LOCK_DIR" >/dev/null 2>&1; then
  log_msg "$(msg inject_already_run)"
  exit 0
fi
trap cleanup EXIT

rotate_log

# ── preflight checks ──────────────────────────────────────────────────────
if [ ! -f "$DB_PATH" ]; then
  log_msg "$(msg db_notfound)"
  exit 1
fi

LOCAL_BIND_ID="$(calc_local_bind_id)"
if [ -z "$LOCAL_BIND_ID" ] || [ "${#LOCAL_BIND_ID}" -ne 64 ]; then
  log_msg "$(msg bind_id_fail)"
  exit 1
fi

# ── detect chip subdir ────────────────────────────────────────────────────
# 注：customize.sh 安装时已将正确策略合并到 ENC_STRATEGY_DIR 根目录
# 此处检测逻辑：优先使用根目录（已合并），回退到子目录扫描
CHIP_SUBDIR=""

# 检查根目录是否已有 .enc 文件（customize.sh 合并后的结果）
if ls "$ENC_STRATEGY_DIR"/*.enc >/dev/null 2>&1; then
  ACTIVE_ENC_DIR="$ENC_STRATEGY_DIR"
  log_msg "$(msg strategy_merged "$ACTIVE_ENC_DIR")"
else
  # 回退：尝试 SoC 子目录匹配（兼容未经 customize.sh 安装的情况）
  SOC="$(getprop ro.soc.model 2>/dev/null)"
  [ -z "$SOC" ] && SOC="$(getprop ro.board.platform 2>/dev/null)"
  [ -z "$SOC" ] && SOC="$(getprop ro.hardware 2>/dev/null)"
  SOC_UPPER="$(echo "$SOC" | tr -cd '[:alnum:]' | tr '[:lower:]' '[:upper:]')"

  JQ_BIN=""
  for candidate in "$MODDIR/jq" "$MODDIR/jq-linux-arm64"; do
    [ -f "$candidate" ] || continue
    [ -x "$candidate" ] || chmod 0755 "$candidate" >/dev/null 2>&1
    [ -x "$candidate" ] && { JQ_BIN="$candidate"; break; }
  done

  # 白名单检查
  DEVICE_MODEL="$(getprop ro.product.vendor.model 2>/dev/null)"
  PRJ_NAME_INJ="$(getprop ro.boot.prjname 2>/dev/null)"
  for lookup_key in "$DEVICE_MODEL" "$PRJ_NAME_INJ"; do
    [ -z "$lookup_key" ] && continue
    if [ -n "$JQ_BIN" ] && [ -f "$DEVICE_CONFIG" ]; then
      # shellcheck disable=SC2016  # jq 程序本体，单引号是有意的
      wl_path="$($JQ_BIN -r --arg k "$lookup_key" '
        .devices | to_entries[] |
        select((.value.models | if type=="array" then index($k) != null else . == $k end)) |
        .value.strategy_path
      ' "$DEVICE_CONFIG" 2>/dev/null | head -1)"
    elif [ -f "$DEVICE_CONFIG" ]; then
      wl_name="$(awk -v k="\"$lookup_key\"" '
        /^[[:space:]]*"[^"]+"[[:space:]]*:/ { devname = $0; gsub(/^[[:space:]]*"|".*/, "", devname) }
        $0 ~ k { print devname; exit }
      ' "$DEVICE_CONFIG")"
      [ -n "$wl_name" ] && wl_path="$(sed -n "/\"$wl_name\"/,/}/s/.*\"strategy_path\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p" "$DEVICE_CONFIG" | head -1)"
    fi
    if [ -n "$wl_path" ] && [ -d "$ENC_STRATEGY_DIR/$wl_path" ]; then
      CHIP_SUBDIR="$wl_path"
      log_msg "$(msg whitelist_hit "$lookup_key" "$CHIP_SUBDIR")"
      break
    fi
  done

  # 平台映射检查
  if [ -z "$CHIP_SUBDIR" ]; then
    if [ -n "$SOC_UPPER" ] && [ -d "$ENC_STRATEGY_DIR/$SOC_UPPER" ]; then
      CHIP_SUBDIR="$SOC_UPPER"
    elif [ -n "$JQ_BIN" ] && [ -f "$DEVICE_CONFIG" ]; then
      MAPPED="$($JQ_BIN -r ".platforms.\"$SOC_UPPER\" // empty" "$DEVICE_CONFIG" 2>/dev/null)"
      [ -n "$MAPPED" ] && [ -d "$ENC_STRATEGY_DIR/$MAPPED" ] && CHIP_SUBDIR="$MAPPED"
    elif [ -f "$DEVICE_CONFIG" ]; then
      MAPPED="$(sed -n "/\"platforms\"/,/^  }/s/.*\"$SOC_UPPER\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p" "$DEVICE_CONFIG" | head -1)"
      [ -n "$MAPPED" ] && [ -d "$ENC_STRATEGY_DIR/$MAPPED" ] && CHIP_SUBDIR="$MAPPED"
    fi
  fi

  # 最终回退：扫描第一个含 .enc 的子目录
  if [ -z "$CHIP_SUBDIR" ]; then
    for d in "$ENC_STRATEGY_DIR"/*/; do
      [ -d "$d" ] || continue
      ls "$d"*.enc >/dev/null 2>&1 && { CHIP_SUBDIR="${d%/}"; CHIP_SUBDIR="${CHIP_SUBDIR##*/}"; break; }
    done
  fi

  if [ -n "$CHIP_SUBDIR" ]; then
    ACTIVE_ENC_DIR="$ENC_STRATEGY_DIR/$CHIP_SUBDIR"
  else
    ACTIVE_ENC_DIR="$ENC_STRATEGY_DIR"
  fi
fi

log_msg "$(msg strategy_dir "$ACTIVE_ENC_DIR")"

# ── inject_core binary ────────────────────────────────────────────────────
INJECT_BIN="$(find_bin \
    "$MODDIR/inject_core" \
    "/data/adb/modules/cosa_injector/inject_core")"

if [ -z "$INJECT_BIN" ]; then
  log_msg "$(msg inject_bin_notfound)"
  exit 1
fi

log_msg "$(msg inject_bin_using "$INJECT_BIN")"

MAP_ARG=""
[ -f "$DEVICE_CONFIG" ] && MAP_ARG="$DEVICE_CONFIG"

# 线程数：修复旧版 A||B&&C 优先级写法，nproc 为空/非数字时兜底为 4
THREADS="$(nproc 2>/dev/null)"
is_number "$THREADS" || THREADS=4
[ "$THREADS" -lt 1 ] && THREADS=4
[ "$THREADS" -gt 16 ] && THREADS=16

# ── 获取运行时参数 ────────────────────────────────────────────────────────
COSA_VER=""
COSA_VER="$(dumpsys package com.oplus.cosa 2>/dev/null | grep versionName | head -1 | sed 's/.*versionName=//' | tr -d ' ')"
[ -z "$COSA_VER" ] && COSA_VER="$(pm dump com.oplus.cosa 2>/dev/null | grep versionName | head -1 | sed 's/.*versionName=//' | tr -d ' ')"

PRJ_NAME="$(getprop ro.boot.prjname 2>/dev/null)"
OTHER_VAL=""
if [ -n "$PRJ_NAME" ]; then
  OTHER_VAL="${PRJ_NAME}_false&"
  log_msg "$(msg prj_name "$PRJ_NAME")"
fi

# 生成当前时间戳（设备本地时区）
MONTHS="Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec"
_mon="$(date '+%m' | sed 's/^0//')"
_mon_name="$(echo "$MONTHS" | awk -v m="$_mon" '{print $m}')"
_day="$(date '+%d' | sed 's/^0//')"
_year="$(date '+%Y')"
_time="$(date '+%H:%M:%S')"
UPDATE_TIME="${_mon_name} ${_day}, ${_year} ${_time}"
log_msg "$(msg update_time "$UPDATE_TIME")"

# 使用临时文件传递退出码（mksh 不支持 PIPESTATUS）
BIN_RC_FILE="$MODDIR/.inject_rc"
( "$INJECT_BIN" "$LOCAL_BIND_ID" "$ACTIVE_ENC_DIR" "$DB_PATH" "$THREADS" "$MAP_ARG" "$COSA_VER" "$OTHER_VAL" "$UPDATE_TIME" 2>&1; echo $? > "$BIN_RC_FILE" ) | tee -a "$LOG_FILE"
BIN_RC="$(cat "$BIN_RC_FILE" 2>/dev/null)"
rm -f "$BIN_RC_FILE"
# 修复：rc 文件缺失或内容非数字时兜底为失败，避免 -eq 语法错误
is_number "$BIN_RC" || BIN_RC=1

if [ "$BIN_RC" -eq 0 ] || [ "$BIN_RC" -eq 2 ]; then
  log_msg "$(msg inject_done "$BIN_RC")"
else
  log_msg "$(msg inject_fail "$BIN_RC")"
  exit 1
fi

# ── post-inject tasks ─────────────────────────────────────────────────────
disable_feedback
# 清理由 trap EXIT 统一处理，不再重复调用
exit 0

#!/system/bin/sh

MODDIR="${0%/*}"
[ "$MODDIR" = "." ] && MODDIR="$(pwd)"
if [ ! -f "$MODDIR/inject_cosa.sh" ] && [ -f "/data/adb/modules/cosa_injector/inject_cosa.sh" ]; then
  MODDIR="/data/adb/modules/cosa_injector"
fi
LOG_FILE="$MODDIR/inject.log"
TARGET_PKG="com.oplus.cosa"

# 数据库候选路径（与 inject_cosa.sh 保持一致）
# 修复：旧版使用 /data_ce/data/... ，该路径不存在，回退分支永远不会命中
DB_PATH=""
DB_CANDIDATE_1="/data/data/com.oplus.cosa/databases/db_game_database"
DB_CANDIDATE_2="/data/user_de/0/com.oplus.cosa/databases/db_game_database"

# 加载 i18n
. "$MODDIR/i18n.sh"

log_msg() {
  ts="$(date '+%Y-%m-%d %H:%M:%S')"
  echo "[$ts] $*" >> "$LOG_FILE"
  log -t cosa_injector "$*" 2>/dev/null || true
}

find_db() {
  if [ -f "$DB_CANDIDATE_1" ]; then
    DB_PATH="$DB_CANDIDATE_1"
    return 0
  fi
  if [ -f "$DB_CANDIDATE_2" ]; then
    DB_PATH="$DB_CANDIDATE_2"
    return 0
  fi
  return 1
}

wait_boot_completed() {
  i=0
  while [ "$i" -lt 180 ]; do
    if [ "$(getprop sys.boot_completed)" = "1" ]; then
      return 0
    fi
    i=$((i + 1))
    sleep 2
  done
  return 1
}

wait_db_ready() {
  i=0
  while [ "$i" -lt 90 ]; do
    find_db && return 0
    i=$((i + 1))
    sleep 2
  done
  return 1
}

# scene node init（与 vtools/powercfg.sh 逻辑保持一致）
NODE_DIR="/dev/opgce"
NODE_FILE="${NODE_DIR}/mode"

if [ ! -d "$NODE_DIR" ]; then
    mkdir -p "$NODE_DIR"
    chmod 0777 "$NODE_DIR"
    chcon u:object_r:device:s0 "$NODE_DIR" >/dev/null 2>&1 || true
fi

if [ ! -f "$NODE_FILE" ]; then
    touch "$NODE_FILE"
    chmod 0666 "$NODE_FILE"
    chcon u:object_r:device:s0 "$NODE_FILE" >/dev/null 2>&1 || true
fi

for bin in i18n.sh inject_cosa.sh jq jq-linux-arm64 sqlite3 sqlite3-linux-arm64; do
  [ -f "$MODDIR/$bin" ] && chmod 0755 "$MODDIR/$bin" >/dev/null 2>&1
done

if ! wait_boot_completed; then
  log_msg "$(msg boot_timeout)"
  exit 0
fi

if ! wait_db_ready; then
  log_msg "$(msg db_not_ready)"
  exit 0
fi

# 记录实际命中的数据库路径，便于排查
log_msg "数据库路径: $DB_PATH"

am force-stop "$TARGET_PKG" >/dev/null 2>&1
sleep 1

log_msg "$(msg inject_start)"
"$MODDIR/inject_cosa.sh"
log_msg "$(msg inject_end)"

# 关闭用户体验计划（inject_cosa.sh 内部也会执行；此处为注入提前失败时的兜底，幂等）
# 修复：旧版用 -eq 数值比较，settings get 返回 null/空串时会报语法错误
log_msg "$(msg feedback_disabling)"
settings put system oplus_customize_cta_user_experience 0 >/dev/null 2>&1
if [ "$(settings get system oplus_customize_cta_user_experience 2>/dev/null)" = "0" ]; then
  log_msg "$(msg feedback_disabled)"
else
  log_msg "$(msg feedback_fail)"
fi

#!/system/bin/sh

SCRIPT_DIR="${0%/*}"
[ "$SCRIPT_DIR" = "." ] && SCRIPT_DIR="$(pwd)"

if [ -f "$SCRIPT_DIR/../module.prop" ]; then
  propFile="$SCRIPT_DIR/../module.prop"
elif [ -f "/data/adb/modules/cosa_injector/module.prop" ]; then
  propFile="/data/adb/modules/cosa_injector/module.prop"
elif [ -f "/data/adb/modules_update/cosa_injector/module.prop" ]; then
  propFile="/data/adb/modules_update/cosa_injector/module.prop"
else
  propFile=""
fi

version="unknown"
versionCode="0"

if [ -n "$propFile" ] && [ -f "$propFile" ]; then
  version=$(grep "version=" "$propFile" | cut -d "=" -f2)
  versionCode=$(grep "versionCode=" "$propFile" | cut -d "=" -f2)
fi

cat > powercfg.json <<EOF
{
    "name": "OPGCE 风驰内核增强",
    "author": "anonymous",
    "version": "${version}",
    "versionCode": ${versionCode},
    "features": {
        "strict": false,
        "pedestal": false
    },
    "module": "cosa_injector",
    "state": "/dev/opgce/mode",
    "entry": "/data/powercfg.sh",
    "projectUrl": ""
}
EOF

if [ -f "powercfg.json" ]; then
    echo "成功生成: $(pwd)/powercfg.json"
else
    echo "错误: 生成失败"
    exit 1
fi

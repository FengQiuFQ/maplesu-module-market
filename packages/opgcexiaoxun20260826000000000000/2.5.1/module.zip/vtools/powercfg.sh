#!/system/bin/sh

mode_dir="/dev/opgce"
mode_file="${mode_dir}/mode"

if [ ! -f "$mode_file" ]; then
    if [ ! -d "$mode_dir" ]; then
        mkdir -p "$mode_dir"
        chmod 0777 "$mode_dir"
        # 与 service.sh 的节点初始化保持一致：尝试修正 SELinux 上下文
        chcon u:object_r:device:s0 "$mode_dir" >/dev/null 2>&1 || true
    fi

    touch "$mode_file"
    chmod 0666 "$mode_file"
    chcon u:object_r:device:s0 "$mode_file" >/dev/null 2>&1 || true
fi

case "$1" in
"init" | "fast" | "pedestal")
    echo "fast" > "$mode_file"
    ;;
"powersave" | "standby")
    echo "powersave" > "$mode_file"
    ;;
"balance")
    echo "balance" > "$mode_file"
    ;;
"performance")
    echo "performance" > "$mode_file"
    ;;
esac

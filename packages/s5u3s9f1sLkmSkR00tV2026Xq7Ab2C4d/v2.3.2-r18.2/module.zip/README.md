# SUSFS Guard (LKM) SKRoot 版

[susfs4ksu-lkm](https://github.com/inforcqb/susfs4ksu-lkm)（SUSFS 内核可加载模块方案）的 SKRoot 原生模块移植版。开机自动按设备内核版本匹配并加载对应的 `susfs_guard_lkm .ko`（无需重编内核），加载后自动重放已保存的 susfs 规则，并提供 WebUI 管理界面。

## 功能

- **自动加载**：覆盖 8 个 arm64 KMI（android12-5.10 / android13-5.10 / android13-5.15 / android14-5.15 / android14-6.1 / android15-6.6 / android16-6.12 / android17-6.18）；内核不匹配的机型安装时即拒绝；已存在 susfs（内建或先前已加载）时不叠加。
- **规则持久化 + 开机重放**：内核里的 susfs 规则都是内存态，重启即清零。本模块把规则保存在 SKRoot 磁盘存储里，每次开机加载 .ko 成功后自动重放。
- **WebUI 管理**（规则改动即时写入内核，无需重启）：
  - sus_path 路径隐藏（对 app ENOENT）
  - SKRoot 模块扫描 + 按模块 sus_path 隐藏（一键全部隐藏/显示，root 与管理器不受影响）
  - sus_kstat stat()/maps 结果伪装
  - open_redirect open() 重定向（uid_scheme 0..4）
  - 隐藏内核模块（/proc/modules、/sys/module、/proc/kallsyms）
  - 隐藏挂载前缀
  - susfs 日志开关、AVC 审计伪装开关
  - 一键 SKRoot 预设（sus_path 隐藏 /data/adb + AVC 伪装）
  - 内核状态查看（KMI、节点、内核侧规则计数）、加载日志查看、立即重放
- SKRoot 开机在 zygote 之前加载本模块，天然早于 post-fs-data 阶段（原版 `early_load` 默认生效）。

## 与原版（KernelSU 模块）的差异

- 原版的 `post-fs-data.sh` / `load.sh` / `kmi.sh` 脚本逻辑移植进 `libsusfs_guard_lkm.so`；捆绑的 8 个 `.ko`、`bin/susfs_insmod` 加载器与 `kmis` 清单与官方构建（main-52f3d9d）完全一致（sha256 见 `provenance.json`）
- 原版"仅加载器，不写规则"——本版新增规则管理与持久化重放；不预设任何隐藏规则（除内核自身默认），需要什么在 WebUI 里自行添加
- 不再安装 `/data/adb/post-fs-data.d/00-susfs-guard-lkm.sh` 早期分发脚本

## 说明

- 模块私有目录下创建 `disable` 文件可跳过开机加载（等价原版 disable 标记）
- 加载日志写入模块私有目录 `load.log`，也可在 WebUI 里查看
- `susfs_insmod` 依赖 `/proc/kallsyms` 读到真实符号地址；个别 `kptr_restrict` 很严的机型加载会失败，日志有体现
- 卸载：在 SKRoot 管理器中卸载并重启即可。已加载的 .ko 保留到下次重启（主动 rmmod 正在使用的 susfs 有风险，不做自动卸载）

## 版权

内核模块与加载工具版权归上游所有，GPL-2.0-only（见 LICENSE）。

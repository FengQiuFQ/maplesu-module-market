'use strict';

class SusfsApp {
    constructor() {
        this.rules = { paths: [], kstat: [], redirect: [], hide_modules: [], hide_mounts: [], sus_map: [] };
        this.localModules = [];
        this.localMounts = [];
        this.skModules = [];
        this.skRoot = '';
        this.closing = false;
        this.becameVisible = false;
        this.initTheme();
        this.bindEvents();
        this.initLifecycle();
        this.refresh();
    }

    /* ---------- 主题(跟随系统) ---------- */
    initTheme() {
        const dark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    }

    /* ---------- SKRoot 端点层(fetch POST) ---------- */
    async post(path, bodyObj) {
        const opts = { method: 'POST', headers: { 'Content-Type': 'application/json; charset=utf-8' } };
        if (bodyObj !== undefined) opts.body = JSON.stringify(bodyObj);
        const resp = await fetch(new URL(path, window.location.href), opts);
        const text = await resp.text();
        let json = null;
        try { json = JSON.parse(text); } catch (e) { /* ignore */ }
        if (!resp.ok) throw new Error(json && json.error ? json.error : ('HTTP ' + resp.status));
        if (!json || json.ok !== true) throw new Error(json && json.error ? json.error : '响应格式错误');
        return json;
    }

    /* ---------- 生命周期: 进入加载遮罩 / 退出自动结束 WebUI 进程 ---------- */
    initLifecycle() {
        const overlay = document.getElementById('startupOverlay');
        overlay.setAttribute('aria-hidden', 'false');
        // 12s 超时兜底, 防止状态接口卡死遮罩
        this.startupTimer = setTimeout(() => this.dismissStartup(), 12000);

        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') this.becameVisible = true;
            else if (document.visibilityState === 'hidden' && this.becameVisible) this.exitWebuiProgram();
        });
        window.addEventListener('pagehide', () => {
            if (this.becameVisible) this.exitWebuiProgram();
        });
    }

    dismissStartup() {
        clearTimeout(this.startupTimer);
        document.getElementById('startupOverlay').setAttribute('aria-hidden', 'true');
    }

    exitWebuiProgram() {
        if (this.closing) return;
        this.closing = true;
        const overlay = document.getElementById('closingOverlay');
        overlay.setAttribute('aria-hidden', 'false');
        try {
            fetch(new URL('/exitWebui', window.location.href), {
                method: 'POST', headers: { 'Content-Type': 'application/json; charset=utf-8' },
                body: '{}', keepalive: true,
            });
        } catch (e) { /* ignore */ }
    }

    /* ---------- 事件 ---------- */
    bindEvents() {
        const $ = id => document.getElementById(id);
        $('btnApply').onclick = () => this.action(() => this.post('/applyNow'), '规则已重放');
        $('btnPreset').onclick = () => this.action(() => this.post('/preset'), '预设已应用');
        $('btnLog').onclick = () => this.showLog();
        $('btnLogClose').onclick = () => $('logModal').classList.add('hidden');

        $('btnAddPath').onclick = () => this.addFromInput('inPath', p => this.post('/addPath', { path: p }), '路径不能为空', () => this.refresh());
        $('inPath').addEventListener('keydown', e => { if (e.key === 'Enter') $('btnAddPath').click(); });
        $('btnClearPath').onclick = () => this.confirmThen('确定清空全部 sus_path 规则？', () => this.post('/clearPath').then(() => this.refresh()));

        $('btnAddKstat').onclick = () => this.addFromInput('inKstat', p => this.post('/addKstat', { path: p }), '路径不能为空', () => this.refresh());
        $('inKstat').addEventListener('keydown', e => { if (e.key === 'Enter') $('btnAddKstat').click(); });
        $('btnClearKstat').onclick = () => this.confirmThen('确定清空全部 sus_kstat 规则？', () => this.post('/clearKstat').then(() => this.refresh()));

        $('btnAddRd').onclick = async () => {
            const t = $('inRdTarget').value.trim();
            const r = $('inRdRedirect').value.trim();
            const s = parseInt($('inRdScheme').value, 10);
            if (!t || !r) return this.toast('目标与重定向路径都要填写');
            try {
                const res = await this.post('/addRedirect', { target: t, redirect: r, scheme: s });
                $('inRdTarget').value = ''; $('inRdRedirect').value = '';
                this.reportErrors(res); this.refresh();
            } catch (e) { this.toast(e.message); }
        };
        $('btnClearRd').onclick = () => this.confirmThen('确定清空全部 open_redirect 规则？', () => this.post('/clearRedirect').then(() => this.refresh()));

        $('btnSaveUname').onclick = () => {
            const rel = $('inUnameRel').value.trim();
            const ver = $('inUnameVer').value.trim();
            this.action(() => this.post('/setUname', { enabled: true, release: rel, version: ver }), 'uname 伪装已启用');
        };
        $('btnOffUname').onclick = () => this.action(() => this.post('/setUname', { enabled: false, release: '', version: '' }), 'uname 伪装已关闭');

        $('btnOnBoot').onclick = () => {
            const fake = $('inBootFake').value;
            if (!fake.trim()) return this.toast('伪装内容不能为空');
            this.action(() => this.post('/setBootconfig', { enabled: true, fake }), 'bootconfig 伪装已启用');
        };
        $('btnOffBoot').onclick = () => this.confirmThen('恢复真实 /proc/bootconfig 内容？', async () => {
            await this.post('/setBootconfig', { enabled: false, fake: '' });
            this.toast('已恢复真实内容', true);
        });
        $('btnViewBoot').onclick = async () => {
            try {
                const res = await this.post('/getBootconfig');
                const box = $('bootView');
                box.classList.remove('hidden');
                box.textContent = '【当前内核】\n' + (res.current || '(空)') +
                    (res.stored ? '\n\n【已保存伪装】\n' + (res.stored.fake || '(未设置)') : '\n\n【已保存伪装】(未设置)');
            } catch (e) { this.toast(e.message); }
        };

        $('btnAddMap').onclick = () => this.addFromInput('inSusMap', p => this.post('/addSusMap', { path: p }), '路径不能为空', () => this.refresh());
        $('inSusMap').addEventListener('keydown', e => { if (e.key === 'Enter') $('btnAddMap').click(); });
        $('btnClearMap').onclick = () => this.confirmThen('确定清空 sus_map 保存列表？（内核侧需重启后清空）', () => this.post('/clearSusMap').then(() => this.refresh()));

        $('tgHideMnts').onchange = e => this.action(() => this.post('/setHideMnts', { enabled: e.target.checked }), null);

        $('btnRescanSk').onclick = () => this.scanSkModules();
        $('btnHideAllSk').onclick = () => this.setAllSkModules(true);
        $('btnShowAllSk').onclick = () => this.setAllSkModules(false);

        $('btnAddModule').onclick = () => {
            const v = $('inModule').value.trim();
            if (!v) return;
            if (this.localModules.includes(v)) return this.toast('已存在');
            this.localModules.push(v);
            $('inModule').value = '';
            this.renderChips();
        };
        $('btnSaveModules').onclick = () => this.action(() => this.post('/setHideModules', { list: this.localModules }), '内核模块隐藏列表已应用');

        $('btnAddMount').onclick = () => {
            let v = $('inMount').value.trim();
            if (!v) return;
            if (!v.endsWith('/')) v += '/';
            if (this.localMounts.includes(v)) return this.toast('已存在');
            this.localMounts.push(v);
            $('inMount').value = '';
            this.renderChips();
        };
        $('btnSaveMounts').onclick = () => this.action(() => this.post('/setHideMounts', { list: this.localMounts }), '挂载隐藏前缀已应用');
        $('btnResetMounts').onclick = () => this.confirmThen('恢复内核默认前缀（/data/adb/ /data/local/tmp/），且开机不再覆盖？', async () => {
            await this.post('/resetHideMounts');
            this.toast('已恢复内核默认', true);
            this.refresh();
        });

        $('tgLog').onchange = e => this.action(() => this.post('/setToggle', { key: 'log', value: e.target.checked ? 1 : 0 }), null, () => this.refresh());
        $('tgAvc').onchange = e => this.action(() => this.post('/setToggle', { key: 'avc', value: e.target.checked ? 1 : 0 }), null, () => this.refresh());

        $('btnExit').onclick = () => this.exitWebuiProgram();
    }

    addFromInput(inputId, fn, emptyMsg, after) {
        const el = document.getElementById(inputId);
        const v = el.value.trim();
        if (!v) return this.toast(emptyMsg);
        this.action(() => fn(v), null, () => { el.value = ''; if (after) after(); });
    }

    confirmThen(msg, fn) {
        if (window.confirm(msg)) fn().catch(e => this.toast(e.message));
    }

    async action(fn, okMsg, after) {
        try {
            const res = await fn();
            this.reportErrors(res);
            if (okMsg) this.toast(okMsg, true);
        } catch (e) {
            this.toast(e.message);
        }
        if (after) after();
    }

    reportErrors(res) {
        const box = document.getElementById('applyMsg');
        if (res && res.errors && res.errors.length) {
            box.textContent = '部分写入失败：\n' + res.errors.join('\n');
            box.classList.remove('hidden', 'ok');
        } else {
            box.classList.add('hidden');
        }
    }

    showLog() {
        this.post('/getLog').then(res => {
            document.getElementById('logView').textContent = res.log || '(空)';
            document.getElementById('logModal').classList.remove('hidden');
        }).catch(e => this.toast(e.message));
    }

    /* ---------- 渲染 ---------- */
    async refresh() {
        try {
            const [st, rules, info] = await Promise.all([this.post('/getStatus'), this.post('/listRules'), this.post('/getSusfsInfo')]);
            if (info.version) st.susfsVersion = info.version;
            if (info.variant) st.susfsVariant = info.variant;
            if (typeof info.features === 'string') st.susfsFeatures = info.features;
            if (info.errors && info.errors.length) st.errors = info.errors;
            this.rules = {
                paths: rules.paths || [],
                kstat: rules.kstat || [],
                redirect: rules.redirect || [],
                hide_modules: rules.hide_modules || [],
                hide_mounts: rules.hide_mounts || [],
                sus_map: rules.sus_map || [],
            };
            if (st.loaded) {
                document.getElementById('stSusfsVer').textContent =
                    (st.susfsVersion || '?') + (st.susfsVariant ? ' · ' + st.susfsVariant : '');
            }
            this.renderSusfsInfo(st);
            this.renderUname(rules);
            this.renderBoot(rules);
            document.getElementById('tgHideMnts').checked = rules.hide_mnts === 1;
            this.localModules = this.rules.hide_modules.slice();
            this.localMounts = this.rules.hide_mounts.slice();
            this.renderStatus(st);
            this.renderLists();
            this.renderChips();
            this.dismissStartup();
        } catch (e) {
            this.toast('加载失败: ' + e.message);
            this.dismissStartup();
        }
        this.scanSkModules();
    }

    /* ---------- SKRoot 模块扫描与按模块隐藏 ---------- */
    async scanSkModules() {
        const box = document.getElementById('listSkMods');
        try {
            const res = await this.post('/scanSkModules');
            this.skModules = res.modules || [];
            this.skRoots = res.roots || [];
            this.skDiag = res.scanErrors || [];
            this.skPrivateDir = res.privateDir || '';
            this.skBootDir = res.bootDir || '';
            this.renderSkModules();
        } catch (e) {
            const msg = String(e.message).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            box.innerHTML = '<div class="empty-tip">扫描失败: ' + msg + '</div>';
        }
    }

    renderSkModules() {
        const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        const box = document.getElementById('listSkMods');
        document.getElementById('skRootPath').textContent =
            (this.skRoots && this.skRoots.length) ? this.skRoots.join(' | ') : '-';
        box.innerHTML = '';
        if (!this.skModules.length) {
            let diag = '<div class="empty-tip">未发现模块。诊断：</div>';
            if (this.skPrivateDir) diag += '<div class="empty-tip mono" style="word-break:break-all">WebUI私有目录: ' + esc(this.skPrivateDir) + '</div>';
            if (this.skBootDir) diag += '<div class="empty-tip mono" style="word-break:break-all">开机记录目录: ' + esc(this.skBootDir) + '</div>';
            (this.skDiag || []).forEach(d => {
                const line = (typeof d === 'string') ? d
                    : (d.root + '（子目录 ' + d.subdirs + ' 个，均未识别为模块）');
                diag += '<div class="empty-tip mono" style="word-break:break-all">' + esc(line) + '</div>';
            });
            box.innerHTML = diag;
            return;
        }
        this.skModules.forEach(m => {
            const name = m.so ? m.so.replace(/^lib/, '').replace(/\.so$/, '') : m.dir;
            const desc = m.so ? (m.so + ' · ' + m.dir) : m.dir;
            box.insertAdjacentHTML('beforeend',
                '<div class="toggle-item">' +
                  '<div style="min-width:0">' +
                    '<div class="t-name">' + esc(name) + (m.self ? ' <span class="tag">本模块</span>' : '') + '</div>' +
                    '<div class="t-desc mono" style="word-break:break-all">' + esc(desc) + '</div>' +
                  '</div>' +
                  '<label class="switch"><input type="checkbox" data-path="' + esc(m.path) + '"' + (m.hidden ? ' checked' : '') + '><span class="slider"></span></label>' +
                '</div>');
        });
        box.querySelectorAll('input[data-path]').forEach(cb => {
            cb.onchange = () => {
                this.action(() => this.post('/setSkModuleHidden', { path: cb.dataset.path, hidden: cb.checked }));
            };
        });
    }

    async setAllSkModules(hidden) {
        if (!this.skModules.length) return;
        let fails = 0;
        for (const m of this.skModules) {
            if (!!m.hidden === hidden) continue;
            try { await this.post('/setSkModuleHidden', { path: m.path, hidden }); }
            catch (e) { fails++; }
        }
        this.toast(fails ? '完成，' + fails + ' 个失败' : (hidden ? '已全部隐藏' : '已全部显示'), !fails);
        this.scanSkModules();
    }

    renderStatus(st) {
        const chip = document.getElementById('loadChip');
        const txt = document.getElementById('loadChipText');
        if (st.loaded) { chip.className = 'chip chip-on'; txt.textContent = 'SUSFS 已加载'; }
        else { chip.className = 'chip chip-off'; txt.textContent = '未加载(待重启)'; }

        document.getElementById('stKernel').textContent = st.kernel || '-';
        document.getElementById('stKmi').textContent = st.kmi || (st.loaded ? '非本模块加载' : '-');
        document.getElementById('stSys').textContent = st.sysModule ? '存在' : '不存在';
        document.getElementById('stKstatCnt').textContent = st.loaded ? String(st.kernelKstatCount) : '-';
        document.getElementById('nodePath').textContent = st.nodes && st.nodes.path ? '正常' : '不存在';
        document.getElementById('nodeKstat').textContent = st.nodes && st.nodes.kstat ? '正常' : '不存在';

        if (st.loaded) {
            if (typeof st.logValue === 'string' && st.logValue.length) {
                document.getElementById('tgLog').checked = st.logValue[0] === '1';
            }
            if (typeof st.avcValue === 'string' && st.avcValue.length) {
                document.getElementById('tgAvc').checked = st.avcValue[0] === '1';
            }
        }
    }

    renderLists() {
        const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        const render = (arr, ulId, row) => {
            const ul = document.getElementById(ulId);
            ul.innerHTML = '';
            if (!arr.length) { ul.innerHTML = '<li class="empty-tip">暂无规则</li>'; return; }
            arr.forEach(item => { ul.insertAdjacentHTML('beforeend', row(item)); });
        };

        render(this.rules.paths, 'listPath', p =>
            `<li><span class="path">${esc(p)}</span><button class="del" data-path="${esc(p)}">删除</button></li>`);
        document.querySelectorAll('#listPath .del').forEach(b => b.onclick = () =>
            this.action(() => this.post('/delPath', { path: b.dataset.path }), null, () => this.refresh()));

        render(this.rules.kstat, 'listKstat', p =>
            `<li><span class="path">${esc(p)}</span><button class="del" data-path="${esc(p)}">删除</button></li>`);
        document.querySelectorAll('#listKstat .del').forEach(b => b.onclick = () =>
            this.action(() => this.post('/delKstat', { path: b.dataset.path }), null, () => this.refresh()));

        render(this.rules.redirect, 'listRd', r =>
            `<li><span class="path">${esc(r.t)} → ${esc(r.r)}</span><span class="scheme">scheme ${esc(r.s)}</span><button class="del" data-path="${esc(r.t)}">删除</button></li>`);
        document.querySelectorAll('#listRd .del').forEach(b => b.onclick = () =>
            this.action(() => this.post('/delRedirect', { target: b.dataset.path }), null, () => this.refresh()));

        render(this.rules.sus_map, 'listMap', p =>
            `<li><span class="path">${esc(p)}</span><button class="del" data-path="${esc(p)}">删除</button></li>`);
        document.querySelectorAll('#listMap .del').forEach(b => b.onclick = () =>
            this.action(() => this.post('/delSusMap', { path: b.dataset.path }), '已移出保存列表(内核侧重启后清除)', () => this.refresh()));
    }

    renderSusfsInfo(st) {
        const view = document.getElementById('featView');
        const feats = st.susfsFeatures;
        if (typeof feats === 'string' && feats.length) {
            view.textContent = feats.trim();
        } else {
            view.textContent = (st.errors && st.errors.length) ? st.errors.join('\n') : '暂无数据';
        }
    }

    renderUname(rules) {
        const un = rules.uname || {};
        document.getElementById('inUnameRel').value = un.release && un.release !== 'default' ? un.release : '';
        document.getElementById('inUnameVer').value = un.version && un.version !== 'default' ? un.version : '';
    }

    renderBoot(rules) {
        const bc = rules.bootconfig || {};
        document.getElementById('inBootFake').value = bc.fake || '';
    }

    renderChips() {
        const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        const chips = (arr, id, kind) => {
            const box = document.getElementById(id);
            box.innerHTML = '';
            if (!arr.length) { box.innerHTML = '<div class="empty-tip">暂无（保存后生效）</div>'; return; }
            arr.forEach((v, i) => {
                box.insertAdjacentHTML('beforeend',
                    `<span class="chip-tag">${esc(v)}<button data-kind="${kind}" data-i="${i}">×</button></span>`);
            });
        };
        chips(this.localModules, 'chipsModules', 'm');
        chips(this.localMounts, 'chipsMounts', 'd');
        document.querySelectorAll('#chipsModules button').forEach(b => b.onclick = () => {
            this.localModules.splice(parseInt(b.dataset.i, 10), 1); this.renderChips();
        });
        document.querySelectorAll('#chipsMounts button').forEach(b => b.onclick = () => {
            this.localMounts.splice(parseInt(b.dataset.i, 10), 1); this.renderChips();
        });
    }

    /* ---------- 轻提示 ---------- */
    toast(msg, ok) {
        let el = document.getElementById('__toast');
        if (!el) {
            el = document.createElement('div');
            el.id = '__toast';
            el.style.cssText = 'position:fixed;left:50%;bottom:40px;transform:translateX(-50%);' +
                'padding:9px 16px;border-radius:10px;font-size:13px;font-weight:600;z-index:120;' +
                'max-width:86%;word-break:break-all;box-shadow:0 4px 14px rgba(0,0,0,.25);transition:opacity .2s;';
            document.body.appendChild(el);
        }
        el.style.background = ok ? 'var(--ok)' : 'var(--danger)';
        el.style.color = '#fff';
        el.textContent = msg;
        el.style.opacity = '1';
        clearTimeout(this._toastTimer);
        this._toastTimer = setTimeout(() => { el.style.opacity = '0'; }, 2600);
    }
}

new SusfsApp();

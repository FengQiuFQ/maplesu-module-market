(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const body = document.body;

  let confLines = [];
  let lineKeys = {};
  let gameLineIdx = [];
  let gameRows = [];
  let lastSig = '';

  function setReady() { body.classList.add('screen-ready'); }
  function setStatus(state, text) {
    $('refreshBtn').setAttribute('data-state', state);
    $('statusText').textContent = text;
  }
  async function post(path, bodyText) {
    const r = await fetch(path, { method: 'POST', body: bodyText || '' });
    return r;
  }

  function tempCls(t) { return t >= 55 ? 't-err' : (t >= 40 ? 't-warn' : 't-ok'); }
  function maxOf(arr) { return arr && arr.length ? Math.max(...arr.map(i => i.temp)) : 0; }
  function setText(id, s) { const el = $(id); if (el && el.textContent !== s) el.textContent = s; }

  // 1s: temps + cpu clusters
  async function refreshFast() {
    let j; try { j = await (await post('/getStatus')).json(); } catch (e) { return; }
    const cpuMax = maxOf(j.temps.cpu);
    setText('cpuTemp', cpuMax ? cpuMax.toFixed(1) : '--');
    const el = $('cpuTemp');
    if (el) el.className = tempCls(cpuMax);
    setText('gpuTemp', maxOf(j.temps.gpu) ? maxOf(j.temps.gpu).toFixed(1) + '℃' : '--');
    setText('batTemp', maxOf(j.temps.battery) ? maxOf(j.temps.battery).toFixed(1) + '℃' : '--');
    setText('boardTemp', maxOf(j.temps.board) ? maxOf(j.temps.board).toFixed(1) + '℃' : '--');

    const sig = (j.cpus.clusters || []).map(c => c.cluster + ':' + c.cpus.length).join('|');
    const box = $('cpuClusters');
    if (sig !== lastSig) {
      lastSig = sig;
      let html = '';
      (j.cpus.clusters || []).forEach((cl, ci) => {
        html += `<div class="cluster">
          <div class="cluster-head">
            <span class="cluster-name">${cl.cluster} · ${cl.cpus.length}核</span>
            <span><span class="cluster-freq" id="cf_${ci}">--</span>
                  <span class="cluster-meta"> / ${(cl.max_khz/1000).toFixed(0)} MHz</span></span>
          </div>
          <div class="bar"><div class="bar-fill" id="bar_${ci}" style="width:0%"></div></div>
        </div>`;
      });
      box.innerHTML = html || '<div class="hero-sub">无数据</div>';
    }
    (j.cpus.clusters || []).forEach((cl, ci) => {
      const avg = cl.cpus.reduce((s, c) => s + c.cur_khz, 0) / (cl.cpus.length || 1);
      setText('cf_' + ci, (avg / 1000).toFixed(0));
      const bar = $('bar_' + ci);
      if (bar) {
        const pct = cl.max_khz ? Math.min(100, avg / cl.max_khz * 100) : 0;
        bar.style.width = pct.toFixed(0) + '%';
      }
    });
  }

  // 2s: status + mode + fg + game
  async function refreshSlow() {
    let j; try { j = await (await post('/getStatus')).json(); } catch (e) {
      setStatus('bad', '连接失败'); return;
    }
    setStatus(j.running ? 'ok' : 'bad', j.running ? '运行中' : '未运行');
    const mb = $('modeBadge');
    if (j.current_mode === 'game') { mb.textContent = '游戏模式'; mb.className = 'mode-badge game'; }
    else { mb.textContent = '日常模式'; mb.className = 'mode-badge'; }
    // 只显示配置过的游戏, 非游戏模式不暴露任何前台包名
    setText('fgPkg', j.current_mode === 'game' ? j.current_game : '日常模式');
    setText('gamePkg', j.current_mode === 'game' ? j.current_game : '未检测到游戏');
    const gb = $('gameBadge');
    const gd = $('gameDetail');
    if (j.current_mode === 'game') {
      gb.textContent = '游戏模式已激活'; gb.className = 'game-badge on';
      gd.hidden = false;
      const row = gameRows.find(g => g.pkg === j.current_game);
      if (row) gd.innerHTML = `当前游戏 <b>${row.pkg}</b><br>线程模式 <b>${row.mode}</b> · loads <b>${row.loads}</b> · 帧率 <b>${row.fps}</b>`;
      else gd.innerHTML = `当前游戏 <b>${j.current_game}</b>`;
    } else {
      gb.textContent = '日常模式'; gb.className = 'game-badge';
      gd.hidden = true; gd.innerHTML = '';
    }
  }

  function getKey(key) {
    if (lineKeys[key] === undefined) return '';
    return confLines[lineKeys[key]].split('=').slice(1).join('=').trim();
  }
  function setKey(key, val) {
    if (lineKeys[key] === undefined) {
      confLines.push(key + '=' + val); lineKeys[key] = confLines.length - 1;
    } else confLines[lineKeys[key]] = key + '=' + val;
  }

  async function loadConf() {
    const text = await (await post('/getConf')).text();
    confLines = text.split(/\r?\n/);
    lineKeys = {}; gameLineIdx = []; gameRows = [];
    confLines.forEach((line, idx) => {
      if (!line || line[0] === '#') return;
      const eq = line.indexOf('=');
      if (eq > 0) { lineKeys[line.slice(0, eq).trim()] = idx; return; }
      const p = line.trim().split(/\s+/);
      if (p.length >= 4 && p[0].includes('.') && /^\d+$/.test(p[1]) && /^-?\d+$/.test(p[2]) && /^\d+$/.test(p[3])) {
        gameLineIdx.push(idx);
        gameRows.push({ pkg: p[0], mode: p[1], loads: p[2], fps: p[3] });
      }
    });
    $('kBefore').value = getKey('45度之前') || 0;
    $('kAfter').value = getKey('45度之后') || 0;
    updateSliderLabels();
    renderGameList();
    inferMode();
  }

  function updateSliderLabels() {
    setText('vBefore', ((+$('kBefore').value) / 1000000).toFixed(1) + ' W');
    setText('vAfter', ((+$('kAfter').value) / 1000000).toFixed(1) + ' W');
  }

  function inferMode() {
    const loads = +getKey('日常小核');
    const bigoff = getKey('关闭CPU大核');
    let m = '';
    if (bigoff === '1') m = 'save';
    else if (loads === 80) m = 'game';
    else if (loads === 50) m = 'perf';
    else if (loads === -50) m = 'save';
    else if (loads === 0) m = 'balanced';
    document.querySelectorAll('.mode-btn').forEach(b =>
      b.classList.toggle('active', b.dataset.mode === m));
  }

  const PRESETS = {
    perf:     { bigoff: 0, freq: 3000000, loads: 50 },
    balanced: { bigoff: 0, freq: 2000000, loads: 0 },
    save:     { bigoff: 1, freq: 1500000, loads: -50 },
    game:     { bigoff: 0, freq: 3000000, loads: 80 },
  };

  async function applyMode(mode) {
    const p = PRESETS[mode]; if (!p) return;
    setKey('关闭CPU大核', p.bigoff);
    setKey('CPU小核频率', p.freq);
    setKey('CPU中核频率', p.freq);
    setKey('CPU大核频率', p.freq);
    setKey('日常小核', p.loads);
    setKey('日常中核', p.loads);
    setKey('日常大核', p.loads);
    await saveConf();
    document.querySelectorAll('.mode-btn').forEach(b =>
      b.classList.toggle('active', b.dataset.mode === mode));
  }

  function renderGameList() {
    setText('gameCount', String(gameRows.length));
    const box = $('gameList');
    box.innerHTML = '';
    gameRows.forEach((g, i) => {
      const row = document.createElement('div');
      row.className = 'game-row';
      row.innerHTML = `<span class="g-pkg">${g.pkg}<span class="g-meta">模式${g.mode} · loads${g.loads} · 帧${g.fps}</span></span>
        <button class="g-del" data-i="${i}">✕</button>`;
      box.appendChild(row);
    });
    box.querySelectorAll('.g-del').forEach(btn => {
      btn.onclick = () => { gameRows.splice(+btn.dataset.i, 1); saveConf(); renderGameList(); };
    });
  }

  async function saveConf() {
    setKey('45度之前', $('kBefore').value);
    setKey('45度之后', $('kAfter').value);
    gameLineIdx.forEach(i => { confLines[i] = ''; });
    let out = confLines.join('\n');
    if (gameRows.length) out += (out.endsWith('\n') ? '' : '\n') +
      gameRows.map(g => `${g.pkg} ${g.mode} ${g.loads} ${g.fps}`).join('\n') + '\n';
    await post('/saveConf', out);
  }

  document.querySelectorAll('.mode-btn').forEach(b =>
    b.addEventListener('click', () => applyMode(b.dataset.mode)));
  $('kBefore').addEventListener('input', updateSliderLabels);
  $('kAfter').addEventListener('input', updateSliderLabels);
  $('kBefore').addEventListener('change', saveConf);
  $('kAfter').addEventListener('change', saveConf);
  $('refreshBtn').addEventListener('click', () => { refreshFast(); refreshSlow(); });
  $('restartBtn').addEventListener('click', async () => {
    $('restartBtn').textContent = '重启中…';
    await post('/restartCaishuai');
    setTimeout(() => { $('restartBtn').textContent = '重启 caishuai'; refreshSlow(); }, 2000);
  });
  $('addGameBtn').addEventListener('click', async () => {
    const pkg = $('newPkg').value.trim();
    if (!pkg) return;
    gameRows.push({ pkg, mode: '1', loads: '0', fps: '0' });
    $('newPkg').value = '';
    renderGameList();
    await saveConf();
  });

  (async () => {
    await loadConf();
    await refreshFast();
    await refreshSlow();
    setReady();
    setInterval(refreshFast, 1000);
    setInterval(refreshSlow, 2000);
  })();
})();

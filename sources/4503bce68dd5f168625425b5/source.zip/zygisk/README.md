# MapleSU Zygisk · Ultra

可选的 MapleSU_Ultra 原生宿主，版本 `5.1.0`。使用固定版本 ReZygisk 的
Zygisk API 1–5 实现和独立的 MapleSU 适配层。Normal 继续使用自己的 KSU 模块链。

## 安装顺序

1. 在 Ultra 环境中把 `MapleSU-Zygisk-5.1.0-Ultra.zip` 作为原生模块安装。
2. 将 HMA-OSS Zygisk ZIP 作为普通模块安装。
3. 重启，在宿主 WebUI 查看监控、daemon 和注入状态，再在 HMA 中检查服务。

宿主通过 SDK 的 Zygote64 启动前入口启动；普通 Zygisk 模块的完整目录存于
设备加密存储，标准发现路径为 `/data/adb/modules/<id>`。宿主对应
`/data/adb/modules/maplesu_zygisk/bin/zygiskd64`，供 HMA 官方安装器检测。
安装/更新/停用后重启完整生效。扫描、早期脚本和 WebUI 只接受管理器发布到 Ultra
DE revision 的模块；共享目录中的 Normal 模块不进入列表或加载。
更新时旧 Zygisk revision 保留至下一次启动，
使当前 daemon 的目录 FD、动态库、dex 和资源保持一致。

Root provider 只读 Ultra SDK 的 `su_allowlist.txt`，按各用户包目录生成准确 UID；
已有 Root 的 owner 不再为每次授权刷新派生 SDK 提权子进程。读取失败清空授权快照，
撤权仍在下一次刷新生效。Root Key 只保留在 SDK/管理器内存，不放入参数、环境变量、状态接口或模块文件。
运行目录和授权快照为 Root 私有。Release 关闭例行 logcat 输出，保留错误诊断。
策略加载使用随包携带的现有 `maplesu-policy`，仅加载模块自己的规则。
SDK96 的默认 SELinux 通知开关会阻止实际策略加载通知。宿主在首次策略事务前，
按本次启动生成的两处通知包装器确认其共享开关，并恢复原函数路径。SDK 归档、
状态页和访问查询结果保持原有数据；未知包装器保留原行为并记录诊断。

## 构建

依赖：Python 3.11+、Git、PowerShell、Android SDK 的 NDK `26.1.10909125`、
CMake `3.22.1`/Ninja，以及现有 `runtime/upstream-pro` SDK 头文件与 ARM64 静态库。
SDK 是外部预编译依赖，对应摘要记录于 `BUILD-IDENTITY.json`；源码包不包含 SDK。

```powershell
./zygisk/build.ps1 -SdkDirectory D:/Maple_Env/Android/Sdk -Python C:/Python314/python.exe
```

输出位于 `dist-release/`。ARM64 宿主携带 ARM64/ARM32 的注入核心和 daemon；
只在系统实际启动对应 ABI 的 zygote 时使用。ELF 采用静态 libc++、16 KB 页对齐、
移除调试符号与主机源路径。ZIP 顺序和时间戳固定。

开发 checkout 的 `patch_upstream.py` 从固定提交生成 `zygisk/build/upstream`，
不覆盖 vendor 工作树。对应源码 ZIP 已包含经过校验的端口和 libsepol 源码，
取得同一 SDK 后可运行相同构建脚本；它按源码清单校验，不再依赖 Git 元数据。
WebUI 的“源码与许可证”提供与本包一致的 `source.zip`。

## WebUI

内置离线 WebUI，参考 Zygisk-Next 的状态与设置布局，保留 MapleSU 配色。
支持系统浅色与深色主题，使用简短文案和紧凑卡片。状态页分别显示 init 监控、各系统支持 ABI 的 daemon 和 Zygote 注入状态；只有
监控、daemon、注入三者就绪才显示运行中。模块列表区分磁盘安装状态与 daemon
发现快照，提供名称/ID 搜索和 ABI 筛选；实际模块功能仍以模块本身验收为准。

设置提供宿主启停确认、自动刷新偏好、复制诊断、导出诊断和对应源码。启停先
取得真实写入回执，再回读状态；失败不显示保存成功。前后台自动刷新互斥，
请求有超时，读取失败时标明状态未确认。兼容直连 SDK 和管理器隐藏代理路径。

原生模块页面使用的管理器 WebView 没有下载桥，导出由宿主直接写入手机
`/sdcard/Download/MapleSU-Zygisk-diagnostic.json` 或 `MapleSU-Zygisk-source.zip`，
完成后显示实际路径，而非依赖浏览器 blob 下载。诊断仅包含宿主状态和模块元数据，
不导出 SDK Key、授权 UID、访问链接或原始日志。源码也可通过静态 `source.zip` 获取。
模块安装、更新和删除仍在管理器中执行，WebUI 不维护第二套模块启停状态。

验证脚本：`tests/webui_api_smoke.py --serial <serial>`（只用任务专属临时目录）、
`tests/webui_browser.cjs`（Playwright，默认使用已配置的工作区依赖；其他环境可设置
`CODEX_NODE_MODULES` 和 `PLAYWRIGHT_CHROMIUM_EXECUTABLE`）。浏览器测试使用原生
接口生成的快照与明确的异常 fixture，预览截图标注测试数据；这不替代 Ultra 启动验收。

## 当前验证范围

- ARM64 和 ARM32 Release 编译。
- Normal 真机隔离进程：模块软链、禁用/删除/失效 revision、ABI 和模块 ID 扫描。
- 官方 HMA `oss-173` ARM64 库：CSOLoader 加载、API4 注册、目录 FD、空包目录下
  的 system_server pre/post 回调及卸载请求。
- 子进程超时回收与父进程退出清理；生产归档检测；HMA 官方安装器发现规则。
- 真机策略 `check`；首次 Ultra 故障启动的自有策略 `apply` 回执成功。

2026-11-05 曾在 OnePlus Ace 6 / Android 16 的 Ultra 真机通过一次宿主单独启用重启：
SDK Running、系统启动完成、monitor/daemon64 正常、Zygote64 已注入，SELinux
Enforcing，红外 HAL 正常。用户确认 WebUI 正常。随后 HMA oss-173 启用重启，
管理器显示模块激活、系统服务运行；普通测试应用的直接包查询与列表查询均按
HMA 配置隐藏指定测试包，同时保留自身可见。此结果不代表全部模块兼容通过。
模块来源修复后，真实 WebUI API 和两个 ABI 的扫描均只有 Ultra 安装的 HMA，
共享目录中的旧 Normal 模块被排除。临时扩展诊断已回滚。
随后持续 WebUI 测试复现断连及内核 panic，稳定性验收已重新打开；上述单次启动
通过不代表持续运行通过。WebUI 短 creator 配合 KeepRunning 已在停用注入的基线
验证持续响应，宿主授权刷新已移除重复内核提权；启用宿主后真实 HTTP 连续
181 秒及管理器退出测试通过，但后续仍有独立内核故障，稳定性尚未闭环。

此前启动故障还涉及被追踪 init 子服务的 SELinux 域转换：普通 shell tracer
导致红外 HAL exec 返回 EPERM。monitor 子进程使用现有 init 域，按模块策略
授予 ptrace；SDK owner 身份保持原样。Socket inode 使用现有 system_data_file，
宿主策略不再创建专用类型。实际 init→HAL 域转换
在自有子进程中完成红绿复现，测试停在内核 EXEC 事件，未执行 HAL 用户态代码。
生产 helper 加 exec 连续三次通过，未保留临时 shell 授权。

启动复核修正三处问题：在追踪 init 前先恢复 SIGCHLD 默认行为并注册 signalfd，
避免首次 fork 通知丢失后停住 init；SDK 入口沿自身父进程链找到已创建但尚未
执行原 app_process 的 Zygote bootstrap，显式捕获其后续 exec；保留 bootstrap
等待模块子进程产生的信号交付，避免 SIGCHLD 提前解除追踪。普通管理器或
dev-run 不接管现存 ART，也不通过强制重启 Zygote 补注入。注入算法仍使用上游。

隔离 Linux 容器回归：`tests/monitor_startup_smoke.py`。它将实际 monitor 的
PID 1 操作映射到测试自己的子进程，覆盖启动 fork、继承 SIGCHLD 忽略状态、
预先存在的 bootstrap exec 和 bootstrap 等待装载子进程；旧实现可复现漏追踪，
修复版四组各连续五次通过。容器需
`SYS_PTRACE`，工作区只读挂载到 `/workspace`，该测试不在手机或宿主机直接运行。

## 维护边界

Zygote 的通信 socket 位于 Root 私有的 `/data/misc/maplesu_zygisk`（0700），
不需要遍历 `/data/adb`。模块目录与库仍由 daemon 通过 FD 传递，不授予 Zygote
对 `adb_data_file` 的访问。HMA 的 ART Hook 在 system_server 专门化后使用可执行
内存，启动授权独立存于 `startup-policy.rule`。先记录当前启动中已有的权限，
保持早期脚本异步；仅当单独加载 HMA、系统启动完成且本次 system_server 的 HMA
报告初始化成功后，等待 10 秒撤回宿主临时授权，再按顺序重放启用模块声明的规则。
旧的状态文件不作为新服务就绪的依据。初始化超过 180 秒、状态不明或事务失败时保留
原行为。已有权限和模块声明的权限不撤回；其他模块仍保留动态 Hook 所需的常驻授权。
因此此优化针对已验证的 HMA 生命周期，不宣称任意模块均可撤回 execmem。

system_server fork 前通过有超时的 daemon 回执同步重新开放启动窗口，避免仅观察
新 PID 时已经错过模块初始化。窗口状态与策略事务串行；不切换全局 Permissive，
不修改 SDK 状态页，也不伪造策略查询。`tests/startup_policy_probe.c` 覆盖实际策略
加载、旧状态、原有权限、模块规则优先级、失败回退和准备/收紧并发。
这条 pre-fork 请求使用独立的非阻塞 socket 和 6 秒总时限，不复用会持续重试
EAGAIN 的通用读取函数。`tests/startup_rpc_probe.c` 覆盖延迟回执、信号打断、
服务缺席和 backlog 满载，测试进程不追踪或重启系统服务。

上游固定版本见 `NOTICE.md` 和 `BUILD-IDENTITY.json`。Android/ART 注入行为留在
上游核心；MapleSU 的 SDK 生命周期、授权和模块发现适配集中在 `native/`。
升级上游时先调整有上下文校验的端口脚本，再重复隔离测试和 Ultra 启动验收。
不引入联网启动、远端时间检查或截止日期门。

## HMA / LSPosed 兼容进度（2026-11-05）

HMA-OSS 固定测试版本为官方 `oss-173`。在进程私有挂载命名空间中执行原版
`customize.sh` 和全部子脚本：23 项 SHA256、API/ABI、安装器分支、宿主发现、
新安装/多用户更新、ABI 筛选和启动状态 hook 全部通过。损坏资源和停用宿主仍按
官方规则退出。测试中的 pm 为记录器，未安装应用；原版资源和检查脚本未改。
管理器安装器已修正 errexit 语义，保留模块显式 abort/exit。

官方 LSPosed `v1.9.2-7024`（API2）和 Vector `v2.2-3080`（API4）的 ARM64 库
已通过 CSOLoader/onLoad 注册。LSPosed 真实 companion 的启动、FD 协议及关闭
控制 socket 后退出已通过；本测试进程没有 ART，收到的缓存 FD 不代表 ART
符号解析已成功。注册测试保留模块要求的库生命周期，不提前强制 dlclose。

Vector 原版安装器 16 项资源校验已通过；新策略类型的 chcon 使用测试记录器，
未在 Normal 上加载规则。原版 service.sh 经真实 BusyBox/unshare 启动的目标为
记录器，已验证工作目录、参数和私有命名空间。管理器生命周期脚本使用已有
BusyBox standalone shell，兼容 toybox 缺少的 unshare --propagation 选项。
自解压框架生成 zygisk/ 后，完整目录也会迁入 DE，避免只识别 ZIP 内 zygisk/。

LSPosed/Vector 的早期框架 daemon 调度已接通：从 SDK 启动入口派生独立进程，
先加载已启用 Zygisk 模块自身的 sepolicy.rule，再依次运行 post-fs-data、post-mount、
service；包括只含 ARM32 库的模块。宿主在已有启动预算内最多等 500ms，模块脚本
在后台各限时 8 秒，避免卡住 init。框架 daemon 可继续等待 zygote socket/Binder。
早期入口与管理器使用同一启动脚本和每个 revision 的 boot 回执，后台 daemon
不继承回执锁；同次启动不重复执行，切到 Normal 后旧 Ultra boot 标记失效。

原版 LSPosed/Vector 脚本已在私有挂载 namespace 中通过完整早期调度测试，daemon
和策略加载器为记录器；另已验证失败返回、停用/删除、跨 boot、超时和后台进程回收。
回收兼容没有 /proc/PID/task/PID/children 的 Android 内核，只处理自身未回收子进程。
这补上了已知启动时序缺口，尚不等于 ART hook、框架 Binder 或 Xposed 模块功能验收。
HMA oss-173 自身通过 ZygoteLoader 进入 system_server，不依赖 LSPosed daemon；
其 Java/Binder、配置保存与实际包查询过滤已在 Ultra 真机通过，证据见
`evidence/maplesu-zygisk-compat-20261105/hma-filtering.json`。Vector 2.2 原版包已通过
管理器真实安装和策略加载。后续修复安装器覆盖执行位及 Vector 的 serial 服务注册权限后，
Vector 2.2 的真实 ART Hook 和 HMA 共存在 Ultra 真机通过，详见下方验收记录。
自解压模块生成 Root 所有目录时，DE 副本发布在同一个已有 Root 作业中完成，
避免应用 UID 移动 Root 所有目录而安装回滚。Zygote 接收宿主目录/库 FD 所需的
`allow zygote init fd use` 已加入自有策略。

移除旧策略类型需要更新宿主后重新启动；已加载的旧类型仍会保留到本次启动结束。
此修改减少固定类型特征，不承诺通用策略权限、管理器包名或其他模块的新增类型不可见。

LSPosed v1.9.2 是旧版框架，Android/ART 支持范围由框架自身决定。Vector v2.2 的
框架升级入口只识别 Magisk/KSU/APatch；Ultra 上通过 MapleSU 更新 ZIP，本宿主
保留真实 Root 身份。加载接口兼容不代表这些框架自己的管理器升级入口已支持 Ultra。

显式 FORCE_DENYLIST_UNMOUNT 使用 MapleSU 当前 boot 的投影账本和 init 挂载
身份匹配，适配 namespace 克隆后变化的 mount ID；保护其他来源的上层和子挂载。
只读选择测试已覆盖，真实卸载投影仍待 Ultra 验收。Ultra 默认无 denylist。

复现脚本：`tests/device_smoke.py`、`tests/installer_smoke.py`、
`tests/framework_smoke.py`、`tests/early_smoke.py`（均需 --serial）、`tests/host_checks.py` 和
`tests/source_rebuild.py`。真机隔离测试只操作任务专属 /data/local/tmp 目录，
这些隔离脚本本身不安装宿主、追踪 init、修改系统策略或重启。`early_smoke.py`
新增 `--sdk-probe` 可通过已安装的签名测试 instrumentation 使用 Ultra Root；其
DE fixture 只覆盖测试进程的私有挂载命名空间，更新后的脚本待设备重连后复验。
完整管理器源码中的配套改动也应
同时构建使用；仅替换宿主 ZIP 不包含管理器的新脚本与 DE 存储逻辑。

2026-11-05 最新功能验收：Vector 2.2 / HMA oss-173 在两个不同 boot 中共同加载。
普通应用每次重新启动后，方法标记、参数及返回值 Hook、直接包查询隐藏、列表查询隐藏、
自身包可见均通过；Vector 经 serial 的 system_server Binder 握手也已成功。
证据位于 `evidence/maplesu-zygisk-integration-20261105/`。这证明本次组合的实际功能，
不扩展为原版 LSPosed 1.9.2 或全部 Xposed 模块在 Android 16 上均通过。

安装重试期间仍复现 SDK 内核执行器 NX 故障，完整管理器重装未取得成功回执；
本次仅恢复了经官方安装脚本及原版框架文件摘要验证的 Vector 安装回执。
管理器的宿主可用性识别修改已通过单元测试和 Release Kotlin 编译，尚未部署新 APK。
后续通用 API 核对修正了 API 4/5 `exemptFd()` 的 bool 返回值：成功和无需处理时返回
true；无上下文、缺少 FD-ignore 参数或达到保留容量时返回 false，不再让模块读取未定义返回值。
`tests/api_contract_smoke.py` 在普通隔离进程中覆盖 API 1–5 的真实注册表、版本参数布局、
pre/post 回调及参数修改、选项、标志位和生产 FD 清理路径；JNI 数组操作为 fixture。
ARM64/ARM32 均编译，当前仅 ARM64 系统可运行该设备测试。此测试不代表 ART 注入验收。
`tests/framework_smoke.py --sdk-probe` 已在 Ultra 复验官方 LSPosed 的 companion、FD
协议及退出清理，Vector 官方安装器权限和服务启动测试也通过。
更新包仅重编译两个不链接 SDK 的注入核心，保留所选基础包其余六个 ELF 及其 SDK 摘要。
持续运行稳定性仍待内核问题闭环。

2026-11-05 Next/KSU 契约核对又复现并修复了两个旧 API 差异：API 1–3 的
正则 PLT Hook 提交前未登记目标 ELF，普通库的 Hook 会失败；排除规则的空字符串
应与 NULL 一样表示全部符号。端口脚本只修正这两个分支，不更换注入机制。
`tests/api_contract_smoke.py --fixture <libmaplesu-zygisk-plt-fixture.so>` 使用真实
dlopen 库和生产 Hook 实现，覆盖 API 1–5 的导入调用替换、原函数回调、按符号/
全部符号排除与恢复；ARM64 真机通过，ARM32 完成编译。
这些测试属于标准 Zygisk 契约，不代表 Next 专用 init/HyperOS 扩展或所有模块均已验收。

2026-11-06 策略收敛候选：模块脚本恢复 umask 022，宿主保持 0077。
LSPosed 共享数据适配器只在 daemon 中设置真实 stock media_rw_data_file 标签；保留 UID、mode 与 MLS categories。
早期调度器按当前 boot 和模块 inode 登记兼容契约；策略工具只略过该 revision 被替代的四条共享标签声明／宽权限。
其他模块、Normal、其他 boot 和未登记 revision 使用原规则。未知共享标签语法不提交，没有扩展 stock 类型权限。
HMA 初始化后，仅在 LSPosed 没有启用 Android/system_server 作用域模块时撤回宿主临时 execmem；
启用该作用域、未知配置及其他 Zygisk 模块保留动态 Hook 契约；框架重建前同步恢复权限。
真实策略计算18项、真机启动窗口夹具及普通应用共享配置／Hook／HMA已通过；整机 Duck 验收待执行。

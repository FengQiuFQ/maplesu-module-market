/* SPDX-License-Identifier: AGPL-3.0-or-later */
"use strict";
const $ = (id) => document.getElementById(id);
const model = {status: null, modules: null, statusError: false, modulesError: false, changing: false, abi: "all", updated: null};
let refreshTask = null, timer = null, toastTimer = null, requestedEnable = null;
let automatic = true;
try { automatic = localStorage.getItem("maplesu-zygisk-auto") !== "false"; } catch (_) { /* WebView storage is optional. */ }
function text(id, value) { $(id).textContent = value; }
function node(tag, className, content) {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (content !== undefined) el.textContent = content;
  return el;
}
function icon(name) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", "#i-" + name); svg.append(use); svg.setAttribute("aria-hidden", "true");
  return svg;
}
function toast(message) {
  clearTimeout(toastTimer); text("toast", message); $("toast").hidden = false;
  toastTimer = setTimeout(() => { $("toast").hidden = true; }, 4000);
}
async function request(path, method = "GET") {
  const abort = new AbortController();
  const timeout = setTimeout(() => abort.abort(), 8000);
  try {
    // Preserve the manager's module-proxy prefix as well as direct SDK URLs.
    const response = await fetch(path.replace(/^\//, ""), {method, signal: abort.signal, cache: "no-store", credentials: "same-origin", headers: {Accept: "application/json"}});
    if (!response.ok) throw new Error("HTTP " + response.status);
    return await response.json();
  } finally { clearTimeout(timeout); }
}
function validateStatus(s) {
  if (!s || typeof s.enabled !== "boolean" || typeof s.running !== "boolean" || !Number.isInteger(s.api) || typeof s.version !== "string" || typeof s.monitorAlive !== "boolean" || !Array.isArray(s.supportedAbis)) throw new Error("invalid_status");
  if (s.state !== null) {
    if (!s.state || !s.state.monitor || !["0", "1", "2", "3"].includes(String(s.state.monitor.state))) throw new Error("invalid_monitor");
    for (const daemon of Object.values(s.state.rezygiskd || {})) {
      if (!daemon || ![0, 1].includes(daemon.state) || !Array.isArray(daemon.modules) || daemon.modules.some(id => typeof id !== "string")) throw new Error("invalid_daemon");
    }
  }
  return s;
}
function validateModules(s) {
  if (!s || !Array.isArray(s.modules) || s.modules.some(m => !m || typeof m.id !== "string" || typeof m.name !== "string" || typeof m.version !== "string" || typeof m.author !== "string" || typeof m.enabled !== "boolean" || !Array.isArray(m.abis) || m.abis.some(a => !["32", "64"].includes(a)))) throw new Error("invalid_modules");
  return s.modules;
}
function monitorActive(s = model.status) { return !!(!model.statusError && s && s.running && s.state && String(s.state.monitor.state) === "0"); }
function daemonIds(abi) {
  const s = model.status, d = s?.state?.rezygiskd?.[abi];
  return monitorActive(s) && d?.state === 1 ? d.modules : [];
}
function discovered() { return new Set([...daemonIds("64"), ...daemonIds("32")]); }
function tag(el, value, tone = "") { el.className = "tag " + tone; el.textContent = value; }
function renderStatus() {
  const s = model.status;
  $("connection-error").hidden = !model.statusError;
  $("host-switch").disabled = !s || model.statusError || model.changing || !!s.removed;
  $("host-switch").setAttribute("aria-checked", String(s?.enabled ?? false));
  if (!s || model.statusError) {
    text("runtime-title", model.statusError ? "连接暂时中断" : "正在连接…");
    text("runtime-detail", model.statusError ? "请刷新重试" : "正在读取状态");
    $("hero").dataset.tone = "bad";
    $("status-badge").lastElementChild.textContent = model.statusError ? "未连接" : "读取中";
    text("monitor-state", "未确认"); text("monitor-detail", "等待响应"); text("module-count", "—");
    $("abi-status").replaceChildren(node("p", "muted inset", "等待架构状态"));
    text("updated-at", model.updated ? "上次 " + model.updated.toLocaleTimeString([], {hour: "2-digit", minute: "2-digit", second: "2-digit"}) : "等待更新");
    return;
  }
  let title, detail, badge, tone;
  const state = s.state, active = monitorActive(s);
  const abis = [...new Set([...s.supportedAbis, ...Object.keys(state?.rezygiskd || {})])].filter(a => ["64", "32"].includes(a)).sort().reverse();
  const allReady = abis.length > 0 && abis.every(a => state?.rezygiskd?.[a]?.state === 1 && state?.zygote?.[a] > 0);
  if (s.removed) { title = "等待移除"; detail = "重启后移除"; badge = "待重启"; tone = "off"; }
  else if (!s.enabled) { title = "Zygisk 已停用"; detail = "重启后停止加载"; badge = "已停用"; tone = "off"; }
  else if (active && allReady) { title = "Zygisk 正在运行"; detail = "Zygote 已注入"; badge = "运行中"; tone = "good"; }
  else if (active) { title = "等待 Zygote 就绪"; detail = "监视器运行中"; badge = "等待中"; tone = "pending"; }
  else if (s.monitorAlive && state && String(state.monitor.state) !== "0") { title = "Zygote 监视器已停止"; detail = state.monitor.reason || "请重启设备"; badge = "已停止"; tone = "bad"; }
  else { title = "等待 Zygisk 启动"; detail = "重启后加载 Zygisk"; badge = "待启动"; tone = "pending"; }
  text("runtime-title", title); text("runtime-detail", detail); $("hero").dataset.tone = tone;
  $("status-badge").lastElementChild.textContent = badge;
  text("version", s.version || "未报告"); text("api-version", "1–" + s.api);
  text("about-version", (s.version || "版本未报告") + " · Zygisk API 1–" + s.api);
  text("module-count", discovered().size);
  tag($("monitor-state"), active ? "运行中" : s.monitorAlive ? "已停止" : "未启动", active ? "good" : "warn");
  text("monitor-detail", active ? "监视器运行正常" : state?.monitor?.reason || "重启后加载");
  text("updated-at", model.updated ? model.updated.toLocaleTimeString([], {hour: "2-digit", minute: "2-digit", second: "2-digit"}) + " 更新" : "等待更新");
  const rows = abis.map(abi => {
    const d = state?.rezygiskd?.[abi], injected = state?.zygote?.[abi] > 0;
    const row = node("div", "info-row abi-row");
    row.append(node("span", "row-icon abi-icon", abi));
    const body = node("div", "row-body"); body.append(node("strong", "", abi + " 位 Zygote"));
    let line = "等待启动", label = "待启动", color = "";
    if (active && d?.state === 1 && injected) { line = "注入完成"; label = "已注入"; color = "good"; }
    else if (active && d?.state === 1) { line = "等待注入"; label = "等待中"; color = "warn"; }
    else if (d?.reason) { line = d.reason; label = "异常"; color = "bad"; }
    else if (active) { line = "等待服务启动"; label = "等待中"; color = "warn"; }
    else if (!s.enabled) { line = "下次启动不加载"; label = "已停用"; }
    body.append(node("small", "", line)); const stateTag = node("span"); tag(stateTag, label, color);
    row.append(body, stateTag); return row;
  });
  $("abi-status").replaceChildren(...(rows.length ? rows : [node("p", "muted inset", "暂无架构信息")]));
}
function renderModules() {
  $("module-error").hidden = !model.modulesError;
  if (!model.modules || model.modulesError) {
    $("module-list").replaceChildren(node("div", "card empty-state", model.modulesError ? "读取失败，请刷新重试" : "正在读取模块"));
    text("list-count", "—"); return;
  }
  const query = $("search").value.trim().toLocaleLowerCase();
  const modules = model.modules.filter(m => (model.abi === "all" || m.abis.includes(model.abi)) && (m.name + " " + m.id).toLocaleLowerCase().includes(query));
  text("list-count", modules.length + " 个模块");
  const cards = modules.map(m => {
    const card = node("article", "card module-card"); card.dataset.module = m.id;
    const top = node("div", "module-top"), symbol = node("span", "module-symbol"); symbol.append(icon("grid"));
    const body = node("div", "row-body"); body.append(node("h2", "module-name", m.name || m.id), node("span", "module-id", m.id)); top.append(symbol, body);
    const meta = node("div", "module-meta"); meta.append(node("span", "", m.version || "未标注版本"), node("span", "", "· " + (m.author || "未标注作者")));
    for (const abi of m.abis) meta.append(node("span", "tag", abi + " 位"));
    const loaded = m.abis.filter(abi => daemonIds(abi).includes(m.id));
    let label = m.removed ? "待移除" : !m.enabled ? "已停用" : m.update ? "待更新" : "已启用";
    let description = loaded.length ? loaded.join(" / ") + " 位已识别" : "等待重启加载";
    if (model.statusError) description = "状态待确认";
    else if (m.removed || !m.enabled) description = loaded.length ? "重启后停用" : "下次启动不加载";
    else if (m.update) description = "重启后加载新版本";
    else if (model.status?.supportedAbis.length && m.abis.every(a => !model.status.supportedAbis.includes(a))) description = "架构不匹配";
    else if (!model.status?.enabled) description = "Zygisk 已停用";
    const runtime = node("div", "module-runtime"); runtime.append(node("span", "", description), node("span", m.enabled && !m.update && loaded.length ? "good" : "", label));
    card.append(top, meta, runtime); return card;
  });
  $("module-list").replaceChildren(...(cards.length ? cards : [node("div", "card empty-state", model.modules.length ? "没有匹配的模块" : "尚未安装 Zygisk 模块")]));
}
function schedule() {
  clearTimeout(timer);
  if (automatic && !document.hidden) timer = setTimeout(async () => {
    if (!model.changing && !$("confirm-dialog").open) await refresh();
    schedule();
  }, 5000);
}
function refresh() {
  if (refreshTask) return refreshTask;
  $("refresh").classList.add("busy"); $("refresh").disabled = true;
  refreshTask = (async () => {
    const [status, modules] = await Promise.allSettled([
      request("/api/status").then(validateStatus), request("/api/modules").then(validateModules)
    ]);
    model.statusError = status.status !== "fulfilled";
    if (!model.statusError) { model.status = status.value; model.updated = new Date(); }
    model.modulesError = modules.status !== "fulfilled";
    if (!model.modulesError) model.modules = modules.value;
    renderStatus(); renderModules();
  })().finally(() => {
    refreshTask = null; $("refresh").classList.remove("busy"); $("refresh").disabled = false; schedule();
  });
  return refreshTask;
}
function navigate(page, updateHash = true) {
  if (!["overview", "modules", "settings"].includes(page)) page = "overview";
  for (const section of document.querySelectorAll(".page")) section.hidden = section.id !== page;
  for (const button of document.querySelectorAll(".nav-item")) {
    const active = button.dataset.page === page; button.classList.toggle("active", active);
    if (active) button.setAttribute("aria-current", "page"); else button.removeAttribute("aria-current");
  }
  text("page-title", {overview: "状态", modules: "模块", settings: "设置"}[page]);
  if (updateHash) history.replaceState(null, "", "#" + page);
  window.scrollTo(0, 0);
}
async function setEnabled(enable) {
  model.changing = true; renderStatus();
  $("refresh").disabled = true;
  try {
    if (refreshTask) await refreshTask;
    const result = await request(enable ? "/api/enable" : "/api/disable", "POST");
    if (result.ok !== true || result.enabled !== enable || result.rebootRequired !== true) throw new Error("invalid_receipt");
    $("reboot-notice").hidden = false;
    toast(enable ? "已启用，重启后生效" : "已停用，重启后生效");
  } catch (_) { toast("操作未确认，请刷新后重试"); }
  finally { model.changing = false; await refresh(); }
}
async function diagnostic() {
  if (model.changing) { toast("请等待设置保存完成"); return null; }
  await refresh();
  if (model.statusError || model.modulesError) { toast("读取失败，请重试"); return null; }
  // Deliberately omit URL, SDK key, UID grants, device identifiers and raw logs.
  return JSON.stringify({product: "MapleSU Zygisk", capturedAt: new Date().toISOString(), status: model.status, modules: model.modules}, null, 2);
}
async function copyDiagnostic() {
  const data = await diagnostic(); if (!data) return;
  try {
    let copied = false;
    if (navigator.clipboard?.writeText) {
      try { await navigator.clipboard.writeText(data); copied = true; } catch (_) { /* Android WebView may deny the asynchronous API. */ }
    }
    if (!copied) {
      const textarea = node("textarea", "clipboard-fallback"); textarea.value = data; textarea.readOnly = true; document.body.append(textarea);
      try { textarea.select(); if (!document.execCommand("copy")) throw new Error("clipboard"); } finally { textarea.remove(); }
    }
    toast("诊断信息已复制");
  } catch (_) { toast("复制失败，请导出诊断信息"); }
}
async function exportFile(source) {
  const button = $(source ? "export-source" : "download-diagnostic");
  button.disabled = true;
  try {
    // The manager's native-module WebView has no download bridge. Export on the
    // host instead of claiming a blob/download click saved a file.
    const result = await request(source ? "/api/export-source" : "/api/export", "POST");
    if (result.ok !== true || typeof result.path !== "string") throw new Error("invalid_export_receipt");
    toast("已保存至 " + result.path);
  } catch (_) { toast("导出未完成，请重试"); }
  finally { button.disabled = false; }
}
$("refresh").addEventListener("click", () => { if (!model.changing) refresh(); });
for (const button of document.querySelectorAll(".nav-item")) button.addEventListener("click", () => navigate(button.dataset.page));
$("show-modules").addEventListener("click", () => navigate("modules"));
$("search").addEventListener("input", renderModules);
for (const button of document.querySelectorAll(".filter")) button.addEventListener("click", () => {
  model.abi = button.dataset.abi;
  for (const filter of document.querySelectorAll(".filter")) { filter.classList.toggle("active", filter === button); filter.setAttribute("aria-pressed", String(filter === button)); }
  renderModules();
});
$("host-switch").addEventListener("click", () => {
  if (!model.status || model.statusError || model.changing) return;
  requestedEnable = !model.status.enabled;
  text("dialog-title", requestedEnable ? "启用 Zygisk？" : "停用 Zygisk？");
  text("dialog-detail", requestedEnable ? "重启后加载 Zygisk 及已启用的模块。" : "重启后停止加载 Zygisk 模块。");
  text("confirm-toggle", requestedEnable ? "启用" : "停用");
  $("confirm-dialog").returnValue = "cancel"; $("confirm-dialog").showModal();
});
$("confirm-dialog").addEventListener("close", () => {
  if ($("confirm-dialog").returnValue === "confirm" && requestedEnable !== null) setEnabled(requestedEnable);
  requestedEnable = null;
});
$("auto-switch").setAttribute("aria-checked", String(automatic));
$("auto-switch").addEventListener("click", () => {
  automatic = !automatic; $("auto-switch").setAttribute("aria-checked", String(automatic));
  try { localStorage.setItem("maplesu-zygisk-auto", String(automatic)); } catch (_) { /* Continue without persistence. */ }
  schedule();
});
$("copy-diagnostic").addEventListener("click", copyDiagnostic);
$("download-diagnostic").addEventListener("click", () => exportFile(false));
$("export-source").addEventListener("click", () => exportFile(true));
document.addEventListener("visibilitychange", () => { if (!document.hidden && automatic) refresh(); schedule(); });
window.addEventListener("hashchange", () => navigate(location.hash.slice(1), false));
navigate(location.hash.slice(1), false); refresh();

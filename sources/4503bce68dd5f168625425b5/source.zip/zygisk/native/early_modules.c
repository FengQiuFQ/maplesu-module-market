// SPDX-License-Identifier: AGPL-3.0-or-later
// Executed separately from the SDK owner: no credential is passed to scripts.
#include "module_scan.h"
#include "../../module-policy/src/shared_file_contract.h"
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static volatile sig_atomic_t stopping;
static void stop(int signal) { (void)signal; stopping = 1; }
static long long millis(void) {
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    return now.tv_sec * 1000LL + now.tv_nsec / 1000000;
}
static void kill_owned(void) {
    // Some Android kernels omit /proc/PID/task/PID/children. Enumerate PPid
    // instead; only this supervisor reaps these direct children, so their PIDs
    // stay reserved until the following waitpid loop.
    DIR *processes = opendir("/proc");
    if (!processes) return;
    struct dirent *entry;
    while ((entry = readdir(processes))) {
        if (entry->d_name[0] < '1' || entry->d_name[0] > '9') continue;
        char path[128], line[4096];
        snprintf(path, sizeof(path), "/proc/%s/stat", entry->d_name);
        FILE *file = fopen(path, "r");
        if (!file) continue;
        char *record = fgets(line, sizeof(line), file);
        fclose(file);
        char *end = record ? strrchr(line, ')') : NULL;
        int parent;
        if (end && sscanf(end + 1, " %*c %d", &parent) == 1 && parent == getpid())
            kill(atoi(entry->d_name), SIGKILL);
    }
    closedir(processes);
}

static void run_child(char *const argv[], const char *module, const char *stage) {
    pid_t leader = fork();
    if (leader < 0) return;
    if (leader == 0) {
        signal(SIGTERM, SIG_DFL);
        signal(SIGINT, SIG_DFL);
        if (setsid() < 0) _exit(125);
        close(198);
        execv(argv[0], argv);
        _exit(127);
    }
    int status = 0;
    long long until = millis() + 8000;
    pid_t result;
    do {
        result = waitpid(leader, &status, WNOHANG);
        if (result < 0 && errno == EINTR) continue;
        if (result != 0 || stopping || millis() >= until) break;
        usleep(10000);
    } while (1);
    if (result == 0 || (result < 0 && errno == EINTR)) {
        // A stalled module never holds init's Zygote startup. The actual child
        // is still unreaped, so signalling its process group cannot hit a reused PID.
        kill(-leader, SIGKILL);
        kill(leader, SIGKILL);
        while (waitpid(leader, &status, 0) < 0 && errno == EINTR) {}
    }
    fprintf(stderr, "early stage=%s module=%s status=%d\n", stage, module, status);
}

static void prepare_shared_context(const char *helper, const struct maple_module *module, const char *boot) {
    if (strcmp(module->name, "zygisk_lsposed")) return;
    int fd = openat(module->dir_fd, "sepolicy.rule", O_RDONLY | O_CLOEXEC);
    FILE *file = fd < 0 ? NULL : fdopen(fd, "r");
    if (!file) { if (fd >= 0) close(fd); return; }
    char line[4096];
    int known = 0, unsupported = 0;
    while (fgets(line, sizeof(line), file)) {
        int rule = maple_shared_file_rule(line);
        known += rule > 0;
        unsupported |= rule < 0;
    }
    fclose(file);
    if (unsupported || known != 4) return;
    const char *slash = strrchr(helper, '/');
    char library[4096];
    if (!slash || snprintf(library, sizeof(library), "%.*s/../lib64/liblsp-shared.so",
        (int)(slash - helper), helper) >= (int)sizeof(library) || access(library, R_OK)) return;
    struct stat directory;
    if (fstat(module->dir_fd, &directory)) return;
    fd = open(MAPLE_SHARED_CONTEXT_STATE, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC | O_NOFOLLOW, 0600);
    file = fd < 0 ? NULL : fdopen(fd, "w");
    if (!file) { if (fd >= 0) close(fd); return; }
    fprintf(file, "%s %llu %llu %s\n", boot, (unsigned long long)directory.st_dev,
        (unsigned long long)directory.st_ino, library);
    fclose(file);
}

int maple_run_early_modules(const char *helper) {
    signal(SIGTERM, stop);
    signal(SIGINT, stop);
    signal(SIGPIPE, SIG_IGN);
    if (prctl(PR_SET_CHILD_SUBREAPER, 1) != 0) return 1;
    FILE *boot = fopen("/proc/sys/kernel/random/boot_id", "r");
    char epoch[80];
    if (!boot) return 1;
    int ok = fscanf(boot, "%79s", epoch);
    fclose(boot);
    if (ok != 1) return 1;
    FILE *stamp = fopen("/data/adb/maplesu_zygisk/early.boot", "w");
    if (!stamp) return 1;
    fprintf(stamp, "%s\n", epoch);
    fclose(stamp);

    struct maple_module *modules = NULL;
    size_t count = 0;
    if (maple_scan_modules("/data/adb/modules", NULL, &modules, &count) != 0) return 1;
    // Module policies are loaded before framework daemons, just as in the
    // normal module contract. An individual failure does not stop the host.
    unlink(MAPLE_SHARED_CONTEXT_STATE);
    char policy[4096], rules[4096];
    const char *slash = strrchr(helper, '/');
    if (!slash) { maple_free_modules(modules, count); return 1; }
    snprintf(policy, sizeof(policy), "%.*s/maplesu-policy", (int)(slash - helper), helper);
    for (size_t i = 0; i < count && !stopping; ++i) {
        prepare_shared_context(helper, &modules[i], epoch);
        if (faccessat(modules[i].dir_fd, "sepolicy.rule", F_OK, 0) != 0) continue;
        snprintf(rules, sizeof(rules), "%s/sepolicy.rule", modules[i].path);
        char *argv[] = {policy, "apply", "--rules", rules, NULL};
        run_child(argv, modules[i].name, "policy");
    }
    const char *stages[] = {"post-fs-data", "post-mount", "service"};
    for (size_t s = 0; s < sizeof(stages) / sizeof(*stages) && !stopping; ++s) {
        for (size_t i = 0; i < count && !stopping; ++i) {
            int directory = modules[i].dir_fd;
            char script[64];
            snprintf(script, sizeof(script), "%s.sh", stages[s]);
            if (faccessat(directory, "disable", F_OK, 0) == 0 ||
                faccessat(directory, "remove", F_OK, 0) == 0 ||
                faccessat(directory, script, F_OK, 0) != 0) continue;
            char *argv[] = {"/data/adb/maplesu/bin/busybox", "sh", (char *)helper,
                modules[i].path, (char *)stages[s], NULL};
            run_child(argv, modules[i].name, stages[s]);
        }
    }
    maple_free_modules(modules, count);
    if (fcntl(198, F_GETFD) >= 0) { (void)write(198, "1", 1); close(198); }
    // Retain daemon descendants and reap them. On owner shutdown, stop our own
    // children only; no persisted PID, Android service or unrelated process is used.
    for (;;) {
        if (stopping) kill_owned();
        int status;
        pid_t child;
        while ((child = waitpid(-1, &status, WNOHANG)) > 0) {}
        if (child < 0 && errno == ECHILD) break;
        usleep(10000);
    }
    return 0;
}

// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <stddef.h>
#include <stdint.h>

namespace maple {
// SDK96's notifier wrappers share one byte controlling whether the real kernel
// functions run. Decode its generated instructions rather than retaining an
// address across boots. An unfamiliar wrapper leaves the SDK state untouched.
template<class Read> uint64_t notification_switch(uint64_t address, Read read) {
    uint32_t entry = 0;
    if (!read(address, &entry, sizeof(entry))) return 0;
    if (entry == 0xd503233f || entry == 0xd503245f) { // PACIASP / BTI c
        address += 4;
        if (!read(address, &entry, sizeof(entry))) return 0;
    }
    if ((entry & 0xfc000000) != 0x14000000) return 0;
    int64_t offset = (int64_t(int32_t(entry << 6)) >> 6) * 4;
    uint32_t wrapper[8] = {};
    if (!read(address + offset, wrapper, sizeof(wrapper))) return 0;
    if (wrapper[0] != 0xd10143ff || wrapper[1] != 0xa9bf7bfd || wrapper[2] != 0xa9bf7ffc ||
        (wrapper[3] & 0xff80001f) != 0xd280001c) return 0;
    uint64_t callback = uint64_t((wrapper[3] >> 5) & 0xffff) << (((wrapper[3] >> 21) & 3) * 16);
    size_t i = 4;
    // Zero halfwords are omitted by the SDK assembler after address relocation.
    for (; i < 8 && (wrapper[i] & 0xff80001f) == 0xf280001c; ++i) {
        unsigned shift = ((wrapper[i] >> 21) & 3) * 16;
        callback = (callback & ~(uint64_t(0xffff) << shift)) | (uint64_t((wrapper[i] >> 5) & 0xffff) << shift);
    }
    if (i == 8 || wrapper[i] != 0xd63f0380) return 0;
    if (callback < 0xffff000000000000ULL) return 0;
    uint32_t code[128] = {};
    if (!read(callback, code, sizeof(code))) return 0;
    uint64_t result = 0, candidate = 0;
    bool started = false;
    for (size_t i = 0; i + 1 < 128; ++i) {
        uint32_t word = code[i];
        if ((word & 0xff80001f) == 0xd280000a) {
            candidate = uint64_t((word >> 5) & 0xffff) << (((word >> 21) & 3) * 16);
            started = true;
        } else if (started && (word & 0xff80001f) == 0xf280000a) {
            unsigned shift = ((word >> 21) & 3) * 16;
            candidate = (candidate & ~(uint64_t(0xffff) << shift)) | (uint64_t((word >> 5) & 0xffff) << shift);
        } else if (started && word == 0x3940014a && (code[i + 1] & 0xff00001f) == 0x3400000a) {
            if (result || candidate < 0xffff000000000000ULL) return 0;
            result = candidate;
            started = false;
        } else started = false;
    }
    return result;
}
}

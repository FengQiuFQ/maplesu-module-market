// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include "notification_switch.h"

namespace maple {
inline bool restore_policy_notifications(bool* changed = nullptr) {
    if (changed) *changed = false;
    uint64_t switches[2] = {};
    const char* names[] = {"selinux_status_update_policyload", "selinux_status_update_setenforce"};
    auto read = [](uint64_t address, void* data, uint32_t size) {
        return !is_failed(kernel_module::read_kernel_mem(address, data, size));
    };
    for (int i = 0; i < 2; ++i) {
        uint64_t address = 0;
        if (is_failed(kernel_module::kallsyms_lookup_name(names[i], address)) || !address) return false;
        switches[i] = notification_switch(address, read);
    }
    if (!switches[0] || switches[0] != switches[1]) return false;
    uint8_t value = 255;
    if (!read(switches[0], &value, 1) || value > 1) return false;
    if (value == 0) return true;
    uint8_t normal = 0;
    bool restored = !is_failed(kernel_module::write_kernel_mem(switches[0], &normal, 1)) &&
        read(switches[0], &value, 1) && value == 0;
    if (changed) *changed = restored;
    return restored;
}
}

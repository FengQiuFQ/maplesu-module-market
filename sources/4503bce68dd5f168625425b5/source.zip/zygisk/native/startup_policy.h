// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif
// Keep module initialization privileges separate from steady-state policy.
// All callers serialize through one root-private, per-boot state file.
void maple_startup_policy_init(void);
bool maple_startup_policy_prepare(const char *host);
void maple_startup_policy_finish(const char *host, bool scripts_ready);
#ifdef __cplusplus
}
#endif

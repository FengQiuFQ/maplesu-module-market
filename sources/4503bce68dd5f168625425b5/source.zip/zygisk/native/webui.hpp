// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include "module_scope.h"
#include <algorithm>
#include <cerrno>
#include <csignal>
#include <ctime>
#include <dirent.h>
#include <fcntl.h>
#include <fstream>
#include <mutex>
#include <sstream>
#include <string>
#include <sys/stat.h>
#include <sys/system_properties.h>
#include <unistd.h>
#include <vector>

namespace maple::webui {
struct Reply { int status; std::string body; };
inline bool exists(const std::string &p) { return access(p.c_str(), F_OK) == 0; }
inline std::string read(const std::string &p) {
    std::ifstream f(p);
    return {std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>()};
}
inline std::string quote(const std::string &text) {
    std::string out = "\"";
    for (unsigned char c : text) {
        if (c == '"' || c == '\\') { out += '\\'; out += c; }
        else if (c < 0x20) {
            constexpr char hex[] = "0123456789abcdef";
            out += "\\u00"; out += hex[c >> 4]; out += hex[c & 15];
        } else out += c;
    }
    return out + '"';
}
inline std::string prop(const std::string &text, const std::string &key) {
    std::istringstream lines(text);
    std::string line;
    while (std::getline(lines, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.starts_with(key + "=")) return line.substr(key.size() + 1);
    }
    return "";
}
inline bool marker(const std::string &path, bool value) {
    if (!value) return unlink(path.c_str()) == 0 || errno == ENOENT;
    std::string temp = path + ".webui.tmp";
    int fd = open(temp.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC | O_NOFOLLOW, 0600);
    if (fd < 0) return false;
    bool ok = ::write(fd, "1", 1) == 1;
    close(fd);
    if (ok) ok = rename(temp.c_str(), path.c_str()) == 0;
    if (!ok) unlink(temp.c_str());
    return ok;
}
inline bool valid_id(const std::string &id) {
    return !id.empty() && id.front() != '.' && id != "maplesu_zygisk" &&
        id.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-") == std::string::npos;
}

// Only these paths enter the API; neither shell execution nor SDK credentials do.
// Injectable roots let the exact production handlers run in an isolated fixture.
class Api {
    std::string dir, runtime, modules, init_status, exports, revisions;
    std::mutex change_lock;
public:
    Api(std::string directory, std::string state_root = "/data/adb/maplesu_zygisk",
        std::string module_root = "/data/adb/modules", std::string init = "/proc/1/status",
        std::string export_root = "/sdcard/Download", std::string revision_root = MAPLE_ZYGISK_REVISIONS)
        : dir(std::move(directory)), runtime(std::move(state_root)),
          modules(std::move(module_root)), init_status(std::move(init)), exports(std::move(export_root)),
          revisions(std::move(revision_root)) {}

    Reply status() const {
        std::istringstream process(read(runtime + "/monitor.pid"));
        int pid = 0; process >> pid;
        bool alive = pid > 0 && kill(pid, 0) == 0;
        std::string init = read(init_status);
        int tracer = 0;
        if (auto at = init.find("TracerPid:"); at != std::string::npos) {
            std::istringstream field(init.substr(at + 10)); field >> tracer;
        }
        bool tracing = alive && tracer == pid;
        std::string state = alive ? read(runtime + "/state.json") : "";
        if (state.empty()) state = "null";
        bool removed = exists(dir + "/remove");
        bool enabled = !removed && !exists(dir + "/disable") && !exists(dir + "/data/disabled");
        std::string metadata = read(dir + "/payload/module.prop");
        char abi64[PROP_VALUE_MAX]{}, abi32[PROP_VALUE_MAX]{};
        __system_property_get("ro.product.cpu.abilist64", abi64);
        __system_property_get("ro.product.cpu.abilist32", abi32);
        std::string abis = *abi64 ? "\"64\"" : "";
        if (*abi32) abis += (abis.empty() ? "" : ",") + std::string("\"32\"");
        return {200, "{\"enabled\":" + std::string(enabled ? "true" : "false") +
            ",\"removed\":" + (removed ? "true" : "false") +
            ",\"running\":" + (tracing ? "true" : "false") +
            ",\"monitorAlive\":" + (alive ? "true" : "false") +
            ",\"api\":5,\"supportedAbis\":[" + abis + "],\"version\":" + quote(prop(metadata, "version")) + ",\"state\":" + state + "}"};
    }

    Reply list() const {
        DIR *root = opendir(modules.c_str());
        if (!root) return {500, "{\"error\":\"modules_unreadable\"}"};
        std::vector<std::pair<std::string, std::string>> items;
        while (dirent *entry = readdir(root)) {
            std::string id(entry->d_name);
            if (!valid_id(id)) continue;
            std::string path = modules + "/" + id;
            char resolved[PATH_MAX];
            if (!realpath(path.c_str(), resolved) || !maple_ultra_module(resolved, modules.c_str(), revisions.c_str())) continue;
            // Accept owned real directories and the legacy revision links.
            struct stat st{};
            if (stat(path.c_str(), &st) != 0 || !S_ISDIR(st.st_mode)) continue;
            std::string metadata = read(path + "/module.prop");
            if (prop(metadata, "id") != id) continue;
            auto library = [&](const char *abi) {
                return stat((path + "/zygisk/" + abi + ".so").c_str(), &st) == 0 && S_ISREG(st.st_mode);
            };
            bool arm64 = library("arm64-v8a"), arm32 = library("armeabi-v7a");
            if (!arm64 && !arm32) continue;
            bool removed = exists(path + "/remove"), disabled = exists(path + "/disable");
            std::string abis = arm64 ? "\"64\"" : "";
            if (arm32) abis += (abis.empty() ? "" : ",") + std::string("\"32\"");
            items.emplace_back(id, "{\"id\":" + quote(id) + ",\"name\":" + quote(prop(metadata, "name")) +
                ",\"version\":" + quote(prop(metadata, "version")) + ",\"author\":" + quote(prop(metadata, "author")) +
                ",\"enabled\":" + (!disabled && !removed ? "true" : "false") +
                ",\"removed\":" + (removed ? "true" : "false") +
                ",\"update\":" + (exists(path + "/update") ? "true" : "false") + ",\"abis\":[" + abis + "]}");
        }
        closedir(root);
        std::sort(items.begin(), items.end());
        std::string json = "{\"modules\":[";
        for (const auto &item : items) { if (json.back() != '[') json += ','; json += item.second; }
        return {200, json + "]}"};
    }

    Reply toggle(bool enable) {
        std::lock_guard<std::mutex> guard(change_lock);
        if (exists(dir + "/remove")) return {409, "{\"ok\":false,\"error\":\"pending_removal\"}"};
        std::string internal = dir + "/data/disabled", standard = dir + "/disable";
        bool before_internal = exists(internal), before_standard = exists(standard);
        bool ok = marker(internal, !enable) && marker(standard, !enable);
        if (!ok) {
            // Restore the prior request if the second marker failed; always report reality.
            bool restored_internal = marker(internal, before_internal);
            bool restored = marker(standard, before_standard) && restored_internal;
            return {500, "{\"ok\":false,\"error\":\"state_write_failed\",\"restored\":" +
                std::string(restored ? "true" : "false") + "}"};
        }
        return {200, "{\"ok\":true,\"enabled\":" + std::string(enable ? "true" : "false") + ",\"rebootRequired\":true}"};
    }

    Reply export_file(bool source) {
        std::lock_guard<std::mutex> guard(change_lock);
        std::string data;
        if (source) data = read(dir + "/webroot/source.zip");
        else {
            auto module_list = list();
            if (module_list.status != 200) return module_list;
            data = "{\"product\":\"MapleSU Zygisk\",\"capturedAtEpoch\":" + std::to_string(std::time(nullptr)) +
                ",\"status\":" + status().body + ",\"catalog\":" + module_list.body + "}\n";
        }
        if (data.empty()) return {500, "{\"ok\":false,\"error\":\"source_unreadable\"}"};
        mkdir(exports.c_str(), 0755);
        std::string path = exports + (source ? "/MapleSU-Zygisk-source.zip" : "/MapleSU-Zygisk-diagnostic.json");
        std::string temporary = path + ".tmp";
        int fd = open(temporary.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC | O_NOFOLLOW, 0644);
        bool ok = fd >= 0;
        size_t offset = 0;
        while (ok && offset < data.size()) {
            ssize_t written = ::write(fd, data.data() + offset, data.size() - offset);
            if (written < 0 && errno == EINTR) continue;
            if (written <= 0) ok = false;
            else offset += written;
        }
        if (fd >= 0 && close(fd) != 0) ok = false;
        if (ok) ok = rename(temporary.c_str(), path.c_str()) == 0;
        if (!ok) { unlink(temporary.c_str()); return {500, "{\"ok\":false,\"error\":\"export_failed\"}"}; }
        return {200, "{\"ok\":true,\"path\":" + quote(path) + "}"};
    }

    Reply dispatch(const std::string &method, const std::string &path) {
        if (method == "GET" && path == "/api/status") return status();
        if (method == "GET" && path == "/api/modules") return list();
        if (method == "POST" && path == "/api/enable") return toggle(true);
        if (method == "POST" && path == "/api/disable") return toggle(false);
        if (method == "POST" && path == "/api/export") return export_file(false);
        if (method == "POST" && path == "/api/export-source") return export_file(true);
        return {404, "{\"error\":\"not_found\"}"};
    }
};
}

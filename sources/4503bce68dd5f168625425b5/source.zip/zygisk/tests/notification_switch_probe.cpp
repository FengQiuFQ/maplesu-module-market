// Offline instruction fixtures: never read or write live kernel memory.
#include "../native/notification_switch.h"
#include <assert.h>
#include <initializer_list>
#include <stdio.h>
#include <string.h>

static constexpr uint64_t function = 0xffff000000001000ULL;
static constexpr uint64_t wrapper_address = function + 0x100;
static constexpr uint64_t callback = 0xffffd193991a0000ULL;
static constexpr uint64_t control = 0xffffd193991a6000ULL;
static uint32_t entry[2], wrapper[8], code[128];
static unsigned reads;
static bool fail_read;
static bool read(uint64_t address, void* output, size_t size) {
    ++reads;
    if (fail_read) return false;
    const void* input = nullptr;
    if (address >= function && address + size <= function + sizeof(entry)) input = (char*)entry + address - function;
    if (address == wrapper_address && size == sizeof(wrapper)) input = wrapper;
    if (address == callback && size == sizeof(code)) input = code;
    if (!input) return false;
    memcpy(output, input, size);
    return true;
}
static void constant(uint32_t* output, uint64_t value, unsigned reg) {
    for (unsigned i = 0; i < 4; ++i)
        output[i] = (i ? 0xf2800000 : 0xd2800000) | (i << 21) | (((value >> (16 * i)) & 0xffff) << 5) | reg;
}
static void fixture(uint32_t prefix) {
    memset(entry, 0, sizeof(entry)); memset(wrapper, 0, sizeof(wrapper)); memset(code, 0, sizeof(code));
    entry[0] = prefix;
    size_t at = prefix ? 1 : 0;
    entry[at] = 0x14000000 | ((wrapper_address - (function + at * 4)) / 4);
    wrapper[0] = 0xd10143ff; wrapper[1] = 0xa9bf7bfd; wrapper[2] = 0xa9bf7ffc;
    constant(wrapper + 3, callback, 28); wrapper[7] = 0xd63f0380;
    constant(code + 12, control, 10); code[16] = 0x3940014a; code[17] = 0x3400010a;
    reads = 0; fail_read = false;
}
int main() {
    for (uint32_t prefix : {uint32_t{0}, uint32_t{0xd503233f}, uint32_t{0xd503245f}}) {
        fixture(prefix); assert(maple::notification_switch(function, read) == control); assert(reads <= 4);
    }
    // The real next-boot setenforce wrapper omits its zero low halfword.
    fixture(0);
    wrapper[3] = 0xd2a0001c | (((callback >> 16) & 0xffff) << 5);
    wrapper[4] = 0xf2c0001c | (((callback >> 32) & 0xffff) << 5);
    wrapper[5] = 0xf2e0001c | (((callback >> 48) & 0xffff) << 5);
    wrapper[6] = 0xd63f0380; wrapper[7] = 0xa8c17bfd;
    if (maple::notification_switch(function, read) != control) {
        puts("FAIL: aligned SDK callback uses three constant instructions");
        return 1;
    }
    fixture(0); entry[0] = 0x17ffffc0; assert(maple::notification_switch(function, read) == 0);
    fixture(0); fail_read = true; assert(maple::notification_switch(function, read) == 0);
    fixture(0); wrapper[7] = 0xd63f0360; assert(maple::notification_switch(function, read) == 0);
    fixture(0); code[16] = 0x3940054a; assert(maple::notification_switch(function, read) == 0);
    fixture(0); code[13] = 0xd503201f; assert(maple::notification_switch(function, read) == 0);
    fixture(0); constant(code + 50, control, 10); code[54] = code[16]; code[55] = code[17];
    assert(maple::notification_switch(function, read) == 0);
    fixture(0); constant(code + 12, 0x1000, 10); assert(maple::notification_switch(function, read) == 0);
    puts("PASS: notifier wrapper, PAC/BTI, read failures, unfamiliar encodings and ambiguous pointers");
}

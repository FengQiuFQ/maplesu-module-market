/* Offline browser tests against real API snapshots + explicit edge-case fixtures. */
const fs = require("node:fs");
const path = require("node:path");
const http = require("node:http");
const os = require("node:os");
const assert = require("node:assert/strict");
const {createRequire} = require("node:module");
const requireRuntime = createRequire(path.join(process.env.CODEX_NODE_MODULES || path.join(os.homedir(), ".cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules"), "entry.cjs"));
const {chromium} = requireRuntime("playwright");
const root = path.resolve(__dirname, "../..");
const evidence = path.join(root, "evidence/zygisk-5.1.0-finalize-20261106");
const webroot = path.join(root, "zygisk/module/webroot");
const snapshots = JSON.parse(fs.readFileSync(path.join(evidence, "api-fixtures.json"), "utf8"));
const clone = obj => JSON.parse(JSON.stringify(obj));
let status = clone(snapshots.running), modules = clone(snapshots.modules), failStatus = false, malformed = false, failModules = false, failPost = false, failExport = false, delay = 0;
let statusCount = 0, posts = [];
const checks = [], errors = [];
function record(name) { checks.push({case: name, passed: true}); }
const server = http.createServer(async (req, res) => {
  let pathname = new URL(req.url, "http://localhost").pathname;
  const proxyPrefix = "/x7k9f/fixture-token/modweb/c45e8a7390b24987a4b01d6e2c5f9143/";
  if (pathname.startsWith(proxyPrefix)) pathname = "/" + pathname.slice(proxyPrefix.length);
  res.setHeader("Cache-Control", "no-store");
  if (pathname.startsWith("/api/")) {
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    if (pathname === "/api/status") {
      statusCount++; const snapshot = clone(status);
      if (delay) await new Promise(r => setTimeout(r, delay));
      if (failStatus) { res.writeHead(500); return res.end("{}"); }
      if (malformed) return res.end('{"enabled":true,');
      return res.end(JSON.stringify(snapshot));
    }
    if (pathname === "/api/modules") { if (failModules) { res.writeHead(500); return res.end("{}"); } return res.end(JSON.stringify(modules)); }
    if (req.method === "POST" && ["/api/export", "/api/export-source"].includes(pathname)) {
      if (failExport) { res.writeHead(500); return res.end('{"ok":false}'); }
      const source = pathname === "/api/export-source";
      const name = source ? "MapleSU-Zygisk-source.zip" : "MapleSU-Zygisk-diagnostic.json";
      fs.writeFileSync(path.join(evidence, "browser-export-" + name), source ? fs.readFileSync(path.join(evidence, "source-download.zip")) : JSON.stringify({status, catalog: modules}));
      return res.end(JSON.stringify({ok: true, path: "/sdcard/Download/" + name}));
    }
    if (req.method === "POST" && ["/api/enable", "/api/disable"].includes(pathname)) {
      posts.push(pathname);
      if (failPost) { res.writeHead(500); return res.end('{"ok":false}'); }
      status.enabled = pathname === "/api/enable";
      return res.end(JSON.stringify({ok: true, enabled: status.enabled, rebootRequired: true}));
    }
    res.writeHead(404); return res.end("{}");
  }
  if (pathname === "/source.zip") {
    res.setHeader("Content-Type", "application/zip"); return res.end(fs.readFileSync(path.join(evidence, "source-download.zip")));
  }
  const files = {"/": "index.html", "/index.html": "index.html", "/style.css": "style.css", "/app.js": "app.js", "/brand.png": "brand.png", "/cover.jpg": "cover.jpg"};
  if (!files[pathname]) { res.writeHead(404); return res.end(); }
  const type = {".html": "text/html", ".css": "text/css", ".js": "text/javascript", ".png": "image/png", ".jpg": "image/jpeg"}[path.extname(files[pathname])];
  res.setHeader("Content-Type", type + (type.startsWith("text/") ? "; charset=utf-8" : ""));
  res.end(fs.readFileSync(path.join(webroot, files[pathname])));
});
(async () => {
  await new Promise(resolve => server.listen(0, "127.0.0.1", resolve));
  const origin = "http://127.0.0.1:" + server.address().port;
  let browser;
  try {
    browser = await chromium.launch({headless: true, executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath()});
    const context = await browser.newContext({viewport: {width: 390, height: 844}, deviceScaleFactor: 2, colorScheme: "dark", reducedMotion: "reduce", permissions: ["clipboard-read", "clipboard-write"]});
    const page = await context.newPage();
    const {expect} = requireRuntime("playwright/test");
    page.on("pageerror", error => errors.push(error.message));
    page.on("console", msg => { if (msg.type() === "error" && !msg.text().includes("500")) errors.push(msg.text()); });
    const external = [];
    page.on("request", req => { if (!req.url().startsWith(origin) && !req.url().startsWith("blob:") && !req.url().startsWith("data:")) external.push(req.url()); });
    delay = 350;
    await page.goto(origin + "/?TOKEN=never-export-this");
    await expect(page.locator("#host-switch")).toBeDisabled(); record("loading-actions-disabled");
    await expect(page.locator("#runtime-title")).toHaveText("Zygisk 正在运行"); delay = 0;
    await expect(page.locator("#module-count")).toHaveText("3");
    await expect(page.locator(".abi-row")).toHaveCount(1);
    await expect(page.locator("#version")).toHaveText("5.1.0"); record("live-status-64bit-only-api-and-version");
    const refresh = async () => { await page.locator("#refresh").click(); await expect(page.locator("#refresh")).toBeEnabled(); };
    const nav = async target => { await page.locator('.nav-item[data-page="' + target + '"]').click(); };
    await page.locator("#show-modules").click();
    await expect(page.locator("#modules")).toBeVisible(); await expect(page.locator(".module-card")).toHaveCount(6);
    assert.equal(await page.locator("#module-list img").count(), 0); assert.equal(await page.locator("#module-list script").count(), 0);
    await expect(page.locator('[data-module="hma_oss"]')).toContainText("<img src=x onerror=alert(1)>"); record("module-list-metadata-text-only");
    await expect(page.locator('[data-module="disabled"]')).toContainText("重启后停用");
    await expect(page.locator('[data-module="update"]')).toContainText("重启后加载新版本"); record("disabled-update-runtime-distinguished");
    await expect(page.locator('[data-module="only32"]')).toContainText("架构不匹配"); record("unsupported-abi-not-promised-on-reboot");
    await page.locator("#search").fill("HMA_OSS"); await expect(page.locator(".module-card")).toHaveCount(1);
    await page.locator("#search").fill("nothing"); await expect(page.locator("#module-list")).toHaveText("没有匹配的模块");
    await page.locator("#search").fill(""); await page.locator('[data-abi="32"]').click(); await expect(page.locator(".module-card")).toHaveCount(2);
    await page.locator('[data-abi="all"]').click(); record("search-abi-filter-and-empty-state");
    await nav("settings"); await page.locator("#host-switch").click(); await expect(page.locator("#confirm-dialog")).toBeVisible();
    await page.getByRole("button", {name: "取消", exact: true}).click(); assert.equal(posts.length, 0);
    await expect(page.locator("#host-switch")).toHaveAttribute("aria-checked", "true"); record("cancel-preserves-state-no-request");
    await page.locator("#host-switch").focus(); await page.keyboard.press("Space"); await expect(page.locator("#confirm-dialog")).toBeVisible();
    await page.keyboard.press("Escape"); await expect(page.locator("#confirm-dialog")).toBeHidden(); assert.equal(posts.length, 0); record("keyboard-switch-and-escape-cancel");
    await page.locator("#host-switch").click(); await page.locator("#confirm-toggle").click();
    await expect(page.locator("#host-switch")).toHaveAttribute("aria-checked", "false"); await expect(page.locator("#host-switch")).toBeEnabled();
    await expect(page.locator("#reboot-notice")).toBeVisible(); assert.equal(posts.at(-1), "/api/disable"); record("disable-confirm-receipt-and-reboot-notice");
    await page.locator("#host-switch").click(); await expect(page.locator("#dialog-title")).toHaveText("启用 Zygisk？"); await page.locator("#confirm-toggle").click();
    await expect(page.locator("#host-switch")).toHaveAttribute("aria-checked", "true"); await expect(page.locator("#host-switch")).toBeEnabled(); assert.equal(posts.at(-1), "/api/enable"); record("enable-confirm-and-real-receipt");
    failPost = true; await page.locator("#host-switch").click(); await page.locator("#confirm-toggle").click(); await expect(page.locator("#toast")).toContainText("操作未确认");
    await expect(page.locator("#host-switch")).toBeEnabled(); await expect(page.locator("#host-switch")).toHaveAttribute("aria-checked", "true"); failPost = false; record("failed-toggle-refreshes-original-state");
    // In-flight status must finish before changing the requested host state.
    delay = 400; await page.locator("#refresh").click(); await page.locator("#host-switch").click(); await page.locator("#confirm-toggle").click();
    await expect(page.locator("#host-switch")).toHaveAttribute("aria-checked", "false"); await expect(page.locator("#host-switch")).toBeEnabled(); delay = 0; record("refresh-toggle-race-final-state");
    status = clone(snapshots.running); await refresh();
    await page.locator("#copy-diagnostic").click(); await expect(page.locator("#toast")).toHaveText("诊断信息已复制");
    const clip = await page.evaluate(() => navigator.clipboard.readText()); const diagnostic = JSON.parse(clip); assert.equal(diagnostic.status.version, "5.1.0"); assert.equal(diagnostic.modules.length, 6); assert.ok(!clip.includes("never-export-this")); record("clipboard-real-json-no-url-or-token");
    await page.locator("#download-diagnostic").click(); await expect(page.locator("#toast")).toContainText("已保存至 /sdcard/Download/MapleSU-Zygisk-diagnostic.json");
    assert.equal(JSON.parse(fs.readFileSync(path.join(evidence, "browser-export-MapleSU-Zygisk-diagnostic.json"))).catalog.modules.length, 6); record("diagnostic-export-receipt-no-blob-dependency");
    await page.locator("#export-source").click(); await expect(page.locator("#toast")).toContainText("已保存至 /sdcard/Download/MapleSU-Zygisk-source.zip");
    assert.equal(fs.readFileSync(path.join(evidence, "browser-export-MapleSU-Zygisk-source.zip")).subarray(0, 2).toString(), "PK"); record("corresponding-source-export-receipt");
    failExport = true; await page.locator("#download-diagnostic").click(); await expect(page.locator("#toast")).toContainText("导出未完成"); await expect(page.locator("#download-diagnostic")).toBeEnabled(); failExport = false; record("export-error-retry-not-false-success");
    failModules = true; await refresh(); await nav("modules"); await expect(page.locator("#module-error")).toBeVisible(); await expect(page.locator(".module-card")).toHaveCount(0); failModules = false; await refresh(); record("modules-read-error-not-stale-success");
    failStatus = true; await refresh(); await expect(page.locator("#connection-error")).toBeVisible(); await expect(page.locator("#host-switch")).toBeDisabled(); await expect(page.locator("#module-count")).toHaveText("—"); failStatus = false;
    malformed = true; await refresh(); await expect(page.locator("#connection-error")).toBeVisible(); malformed = false; await refresh(); await expect(page.locator("#connection-error")).toBeHidden(); record("http-and-malformed-json-recovery");
    status = clone(snapshots.waiting); await refresh(); await expect(page.locator("#runtime-title")).toHaveText("等待 Zygisk 启动"); record("waiting-state-not-claimed-running");
    status = clone(snapshots.disabled); await refresh(); await expect(page.locator("#runtime-title")).toHaveText("Zygisk 已停用"); record("disabled-state");
    status = clone(snapshots.running); status.state.zygote["64"] = 0; await refresh(); await expect(page.locator("#runtime-title")).toHaveText("等待 Zygote 就绪"); await expect(page.locator(".abi-row .tag")).toHaveText("等待中"); record("monitor-is-not-injection-success");
    status = clone(snapshots.running); status.supportedAbis.push("32"); status.state.rezygiskd["32"] = {state: 0, reason: 'dlopen "fixture" failed', modules: []};
    await refresh(); await expect(page.locator(".abi-row")).toHaveCount(2); await expect(page.locator("#abi-status")).toContainText('dlopen "fixture" failed'); record("dual-abi-daemon-failure-visible");
    status = clone(snapshots.running); status.running = false; status.state.monitor = {state: "2", reason: "fixture monitor stopped"}; await refresh();
    await expect(page.locator("#runtime-title")).toHaveText("Zygote 监视器已停止"); await expect(page.locator("#runtime-detail")).toHaveText("fixture monitor stopped"); record("stopped-monitor-reason");
    status = clone(snapshots.running); status.removed = true; status.enabled = false; await refresh(); await expect(page.locator("#host-switch")).toBeDisabled(); record("pending-removal-no-enable-action");
    status = clone(snapshots.running); modules = {modules: []}; await refresh(); await expect(page.locator("#module-list")).toHaveText("尚未安装 Zygisk 模块"); record("no-installed-modules"); modules = clone(snapshots.modules);
    await nav("settings"); await page.locator("#auto-switch").click(); await expect(page.locator("#auto-switch")).toHaveAttribute("aria-checked", "false");
    await page.reload(); await expect(page.locator("#auto-switch")).toHaveAttribute("aria-checked", "false"); await expect(page.locator("#refresh")).toBeEnabled(); const before = statusCount;
    await page.clock.install(); await page.clock.runFor(6000); assert.equal(statusCount, before); record("auto-refresh-preference-persisted-off");
    await page.locator("#auto-switch").click(); const autoBefore = statusCount; await page.clock.runFor(5100); await expect.poll(() => statusCount).toBeGreaterThan(autoBefore); record("automatic-refresh-functional");
    // Use the same visibility events delivered by Android WebView.
    await page.evaluate(() => { Object.defineProperty(document, "hidden", {configurable: true, get: () => true}); document.dispatchEvent(new Event("visibilitychange")); });
    await expect(page.locator("#refresh")).toBeEnabled(); const hiddenBefore = statusCount; await page.clock.runFor(11000); assert.equal(statusCount, hiddenBefore);
    await page.evaluate(() => { Object.defineProperty(document, "hidden", {configurable: true, get: () => false}); document.dispatchEvent(new Event("visibilitychange")); });
    await expect.poll(() => statusCount).toBeGreaterThan(hiddenBefore); record("background-polling-pauses-resumes");
    await page.clock.resume();
    const webviewCopy = await context.newPage();
    await webviewCopy.addInitScript(() => Object.defineProperty(navigator, "clipboard", {configurable: true, value: undefined}));
    await webviewCopy.goto(origin + "/#settings"); await expect(webviewCopy.locator("#host-switch")).toBeEnabled();
    await webviewCopy.locator("#copy-diagnostic").click(); await expect(webviewCopy.locator("#toast")).toHaveText("诊断信息已复制");
    await webviewCopy.close(); record("real-execCommand-copy-without-clipboard-api");
    // Download/clipboard failure is an explicit message, never a success toast.
    await page.evaluate(() => { Object.defineProperty(navigator, "clipboard", {configurable: true, value: {writeText: () => Promise.reject(Error("denied"))}}); document.execCommand = () => false; });
    await page.locator("#copy-diagnostic").click(); await expect(page.locator("#toast")).toContainText("复制失败"); record("clipboard-api-and-fallback-denial-feedback");
    await page.evaluate(() => { document.execCommand = cmd => { window.fixtureCopyCommand = cmd; return true; }; });
    await page.locator("#copy-diagnostic").click(); await expect(page.locator("#toast")).toHaveText("诊断信息已复制"); record("clipboard-denied-api-uses-webview-copy-fallback");
    // A minimal standalone copy fallback supports WebViews without Clipboard API.
    await page.evaluate(() => { Object.defineProperty(navigator, "clipboard", {configurable: true, value: undefined}); document.execCommand = cmd => { window.fixtureCopyCommand = cmd; return true; }; });
    await page.locator("#copy-diagnostic").click(); await expect(page.locator("#toast")).toHaveText("诊断信息已复制"); assert.equal(await page.evaluate(() => window.fixtureCopyCommand), "copy"); assert.equal(await page.locator(".clipboard-fallback").count(), 0); record("clipboard-webview-fallback-cleans-up");
    // No unbounded overlapping refreshes; an 8-second timeout re-enables controls.
    delay = 12000; await page.locator("#refresh").click(); await page.clock.runFor(8100);
    await expect(page.locator("#connection-error")).toBeVisible(); await expect(page.locator("#refresh")).toBeEnabled(); delay = 0;
    await page.clock.resume(); await refresh(); record("request-timeout-recovery");
    // Clean preview names only; the UI itself never ships fixture data.
    modules = {modules: clone(snapshots.modules.modules).filter(m => ["hma_oss", "linked"].includes(m.id))};
    modules.modules[0].name = "HMA-OSS"; modules.modules[0].author = "frknkrc44"; modules.modules[0].version = "oss-173";
    modules.modules[1].name = "LSPosed"; modules.modules[1].author = "LSPosed Developers"; modules.modules[1].version = "1.9.2";
    status = clone(snapshots.running); status.state.rezygiskd["64"].modules = ["hma_oss", "linked"];
    await refresh(); await nav("overview"); await page.evaluate(() => { document.querySelector(".edition").textContent = "测试数据"; document.getElementById("reboot-notice").hidden = true; document.getElementById("toast").hidden = true; });
    await page.screenshot({path: path.join(evidence, "webui-overview.png"), fullPage: true});
    await nav("modules"); await page.screenshot({path: path.join(evidence, "webui-modules.png"), fullPage: true});
    await nav("settings"); await page.screenshot({path: path.join(evidence, "webui-settings.png"), fullPage: true});
    for (const width of [320, 360, 390, 768, 1280]) {
      await page.setViewportSize({width, height: 900});
      for (const tab of ["overview", "modules", "settings"]) {
        await nav(tab);
        assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), "horizontal overflow " + width + " " + tab);
        const bounds = await page.locator(".bottom-nav").boundingBox(); assert.ok(bounds.x >= 0 && bounds.x + bounds.width <= width);
      }
    }
    record("responsive-320-360-390-768-1280-no-overflow");
    await page.setViewportSize({width: 390, height: 844}); await page.emulateMedia({colorScheme: "light"});
    assert.equal(await page.evaluate(() => getComputedStyle(document.body).backgroundColor), "rgb(245, 245, 247)");
    for (const tab of ["overview", "modules", "settings"]) {
      await nav(tab);
      assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), "light theme overflow " + tab);
      await page.screenshot({path: path.join(evidence, "webui-" + tab + "-light.png"), fullPage: true});
    }
    await page.emulateMedia({colorScheme: "dark"});
    assert.equal(await page.evaluate(() => getComputedStyle(document.body).backgroundColor), "rgb(16, 16, 20)");
    record("system-light-and-dark-themes");
    await page.setViewportSize({width: 1280, height: 900}); await nav("overview"); await page.screenshot({path: path.join(evidence, "webui-desktop.png"), fullPage: true});
    const proxyPage = await context.newPage();
    const proxyPrefix = "/x7k9f/fixture-token/modweb/c45e8a7390b24987a4b01d6e2c5f9143/";
    const proxyRequests = [];
    proxyPage.on("request", r => { if (new URL(r.url()).pathname.includes("/api/")) proxyRequests.push(new URL(r.url()).pathname); });
    await proxyPage.goto(origin + proxyPrefix);
    await expect(proxyPage.locator("#runtime-title")).toHaveText("Zygisk 正在运行");
    await proxyPage.locator('.nav-item[data-page="settings"]').click();
    await proxyPage.locator("#host-switch").click(); await proxyPage.locator("#confirm-toggle").click();
    await expect(proxyPage.locator("#host-switch")).toHaveAttribute("aria-checked", "false");
    assert.ok(proxyRequests.length >= 5 && proxyRequests.every(p => p.startsWith(proxyPrefix)));
    await proxyPage.close(); record("manager-hidden-proxy-prefix-get-and-post");
    assert.deepEqual(external, []); record("offline-no-external-network"); assert.deepEqual(errors, []); record("no-browser-runtime-or-csp-errors");
    await context.close();
    fs.writeFileSync(path.join(evidence, "browser-tests.json"), JSON.stringify({passed: true, scope: "Chromium rendered WebUI; production native API snapshots plus explicit failure fixtures", tests: checks}, null, 2));
    console.log("WEBUI_BROWSER_OK " + checks.length + " checks");
  } finally {
    if (browser) await browser.close();
    await new Promise(resolve => server.close(resolve));
  }
})().catch(error => { console.error(error); process.exitCode = 1; });

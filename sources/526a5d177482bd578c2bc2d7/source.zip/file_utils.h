﻿#pragma once
#include <string>
#include <vector>
#include <cstdint>
#include <cstring>
#include <errno.h>
#include <fstream>
#include <fcntl.h>
#include <unistd.h>
#include <filesystem>
#include <random>
#include <sys/stat.h>
#include <sys/xattr.h>

namespace file_utils {
    
static bool file_exists(const std::filesystem::path& p) {
    std::error_code ec;
    return std::filesystem::exists(p, ec);
}

static bool read_file_bytes(const char* path, std::vector<uint8_t>& out) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;

    f.seekg(0, std::ios::end);
    std::streamsize n = f.tellg();
    if (n < 0) return false;

    f.seekg(0, std::ios::beg);
    out.resize(static_cast<size_t>(n));
    return static_cast<bool>(f.read(reinterpret_cast<char*>(out.data()), n));
}

static bool write_file_bytes(const char* path, const void* data, size_t size) {
    if (!path) return false;
    std::ofstream f(path, std::ios::binary | std::ios::out | std::ios::trunc);
    if (!f) return false;
    if (data && size > 0) {
        f.write(static_cast<const char*>(data), static_cast<std::streamsize>(size));
    }
    return f.good();
}

static bool read_text_file(const char* target_path, std::string& text) {
    std::vector<uint8_t> buf;
	if(!read_file_bytes(target_path, buf)) return false;
	text.assign(buf.begin(), buf.end());
    return true;
}

static bool write_text_file(const char* target_path, std::string_view text) {
    if (!target_path) return false;
    std::ofstream file(target_path, std::ios::out | std::ios::trunc);
    if (!file.is_open()) return false;
    file << text;
    return file.good();
}

static inline bool create_empty_file(const char* target_path) {
    std::ofstream file(target_path, std::ios::binary | std::ios::out | std::ios::trunc);
    if (!file.is_open()) return false;
    file.close();
    return true;
}

static bool is_file(const std::filesystem::path& p) {
    std::error_code ec;
    return std::filesystem::is_regular_file(p, ec);
}

static bool is_dir(const std::filesystem::path& p) {
    std::error_code ec;
    return std::filesystem::is_directory(p, ec);
}

static bool make_dirs(const std::filesystem::path& p) {
    std::error_code ec;
    return std::filesystem::create_directories(p, ec);
}

static bool create_directory_if_not_exists(const char* dir_path) {
    if (!file_exists(dir_path)) {
        make_dirs(dir_path);
    }
    return file_exists(dir_path);
}

static bool delete_path(const std::filesystem::path& dir_path) {
    std::error_code ec;
    std::filesystem::remove_all(dir_path, ec);
    return !file_exists(dir_path);
}

static void clear_directory_contents(const std::string& path) {
    std::error_code ec;
    // 检查路径是否存在且为目录
    if (std::filesystem::exists(path, ec) && std::filesystem::is_directory(path, ec)) {
        // 遍历目录内的所有子项目
        for (const auto& entry : std::filesystem::directory_iterator(path, ec)) {
            std::error_code temp_ec;
            // 对内部的每个子项执行 remove_all
            std::filesystem::remove_all(entry.path(), temp_ec);
            if (temp_ec) {
                printf("clear failed at %s : %s\n", entry.path().c_str(), temp_ec.message().c_str());
            }
        }
    } else {
        if (ec) {
            printf("access failed: %s , %s\n", path.c_str(), ec.message().c_str());
        }
    }
}

static inline bool get_file_selinux_label(const char* file_full_path, std::string& out_label) {
    out_label.clear();
    if (!file_full_path) return false;
    ssize_t n = ::getxattr(file_full_path, XATTR_NAME_SELINUX, nullptr, 0);
    if (n <= 0) return false;
    std::vector<char> buf(static_cast<size_t>(n));
    n = ::getxattr(file_full_path, XATTR_NAME_SELINUX, buf.data(), buf.size());
    if (n < 0) return false;
    out_label.assign(buf.data(), static_cast<size_t>(n));
    if (!out_label.empty() && out_label.back() == '\0') out_label.pop_back();
    return true;
}

} // namespace file_utils

cmake_minimum_required(VERSION 3.22)
project(maplesu_zygisk LANGUAGES C CXX)
set(CMAKE_C_STANDARD 23)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)
set(UPSTREAM "${CMAKE_CURRENT_SOURCE_DIR}/build/upstream")
set(VENDOR "${CMAKE_CURRENT_SOURCE_DIR}/../third_party/rezygisk")
set(SDK "${CMAKE_CURRENT_SOURCE_DIR}/../runtime/upstream-pro")
get_filename_component(WORKSPACE_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/.." ABSOLUTE)
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${CMAKE_CURRENT_SOURCE_DIR}/module/module.prop")
file(STRINGS "${CMAKE_CURRENT_SOURCE_DIR}/module/module.prop" MAPLE_VERSION_LINE REGEX "^version=")
string(REPLACE "version=" "" MAPLESU_ZYGISK_VERSION "${MAPLE_VERSION_LINE}")
add_compile_definitions(_GNU_SOURCE ANDROID ZKSU_VERSION="MapleSU-Zygisk-${MAPLESU_ZYGISK_VERSION}"
    MAPLESU_ZYGISK_VERSION="${MAPLESU_ZYGISK_VERSION}")
add_compile_options(-ffunction-sections -fdata-sections -fvisibility=hidden
    -ffile-prefix-map=${WORKSPACE_ROOT}=.
    -fmacro-prefix-map=${WORKSPACE_ROOT}=.
    -Wall -Wextra -Wno-unused-parameter)
add_link_options(-Wl,--gc-sections -Wl,-z,relro,-z,now -Wl,-z,max-page-size=16384)

add_library(plti STATIC ${VENDOR}/loader/src/external/plti/src/plti.c
    ${VENDOR}/loader/src/external/plti/src/elf_util.c)
target_include_directories(plti PUBLIC ${VENDOR}/loader/src/external/plti/src)
set(CSO ${VENDOR}/loader/src/external/csoloader)
add_library(csoloader STATIC ${CSO}/src/backtrace-support.c ${CSO}/src/carray.c
    ${CSO}/src/csoloader.c ${CSO}/src/elf_util.c ${CSO}/src/linker.c ${CSO}/src/sleb128.c)
target_include_directories(csoloader PUBLIC ${CSO}/include)
target_compile_options(csoloader PRIVATE -Wno-int-conversion)

set(LOADER ${UPSTREAM}/loader/src)
add_library(module-scan STATIC native/module_scan.c)
target_include_directories(module-scan PUBLIC native)
add_library(module-policy-state STATIC native/module_policy_mode.cpp
    ../runtime/pro/policy/module_policy_config.cpp)
target_include_directories(module-policy-state PUBLIC native)
add_library(startup-policy STATIC native/startup_policy.c)
target_link_libraries(startup-policy PUBLIC module-scan module-policy-state dl)

add_library(common STATIC ${LOADER}/common/daemon.c ${LOADER}/common/elf_util.c
    ${LOADER}/common/misc.c ${LOADER}/common/socket_utils.c)
target_include_directories(common PUBLIC ${LOADER}/include)
target_link_libraries(common PUBLIC log)
add_library(zygisk SHARED ${LOADER}/injector/cpp_strings.c ${LOADER}/injector/entry.c
    ${LOADER}/injector/hook.c ${LOADER}/injector/ptrace_clear.c)
target_compile_options(zygisk PRIVATE -fno-stack-protector -fomit-frame-pointer)
target_link_options(zygisk PRIVATE -nostartfiles -Wl,--no-undefined)
target_link_libraries(zygisk PRIVATE common plti csoloader log m dl)
add_executable(zygisk-ptrace ${LOADER}/ptracer/main.c ${LOADER}/ptracer/monitor.c
    ${LOADER}/ptracer/ptracer.c ${LOADER}/ptracer/remote_csoloader.c ${LOADER}/ptracer/utils.c native/early_modules.c)
target_link_libraries(zygisk-ptrace PRIVATE common module-scan module-policy-state log m)

set(DAEMON ${UPSTREAM}/zygiskd/src)
add_executable(zygiskd ${DAEMON}/main.c ${DAEMON}/zygiskd.c ${DAEMON}/companion.c
    ${DAEMON}/utils.c native/root_maplesu.c)
target_include_directories(zygiskd PRIVATE ${DAEMON} ${DAEMON}/root_impl)
target_link_libraries(zygiskd PRIVATE module-scan startup-policy log dl)
add_executable(maplesu-zygisk-scan native/scan_main.c)
target_link_libraries(maplesu-zygisk-scan PRIVATE module-scan)
add_executable(maplesu-zygisk-abi-probe tests/abi_probe.c)
target_include_directories(maplesu-zygisk-abi-probe PRIVATE ${LOADER}/injector)
target_link_libraries(maplesu-zygisk-abi-probe PRIVATE common csoloader log dl m)

if(ANDROID_ABI STREQUAL "arm64-v8a")
    add_library(lsp-shared SHARED native/lsposed_shared_context.c)
    target_link_libraries(lsp-shared PRIVATE dl)
    add_subdirectory(../module-policy policy EXCLUDE_FROM_ALL)
    target_compile_definitions(maplesu_sepol PRIVATE HAVE_REALLOCARRAY)
    add_custom_target(ultra-policy ALL DEPENDS maplesu-policy)
    add_library(module_maplesu_zygisk SHARED native/host.cpp)
    target_include_directories(module_maplesu_zygisk PRIVATE ${SDK}/include)
    set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS ${SDK}/lib/arm64-v8a/libkernel_module_kit_static.a)
    file(SHA256 ${SDK}/lib/arm64-v8a/libkernel_module_kit_static.a MAPLE_SDK_ARCHIVE_SHA256)
    target_compile_definitions(module_maplesu_zygisk PRIVATE MAPLE_SDK_ARCHIVE_SHA256="${MAPLE_SDK_ARCHIVE_SHA256}")
    target_compile_options(module_maplesu_zygisk PRIVATE -fno-rtti)
    target_link_libraries(module_maplesu_zygisk PRIVATE
        ${SDK}/lib/arm64-v8a/libkernel_module_kit_static.a startup-policy z log dl)
    target_link_options(module_maplesu_zygisk PRIVATE -Wl,--no-undefined)
    target_link_options(module_maplesu_zygisk PRIVATE $<$<CONFIG:Release>:-Wl,--strip-debug>)
    add_executable(maplesu-zygisk-process-probe tests/process_probe.cpp)
    target_include_directories(maplesu-zygisk-process-probe PRIVATE native)
    add_executable(maplesu-zygisk-auth-probe tests/auth_snapshot_probe.cpp)
    target_include_directories(maplesu-zygisk-auth-probe PRIVATE native)
    add_executable(maplesu-zygisk-tracer-context-probe tests/tracer_context_probe.c)
    target_include_directories(maplesu-zygisk-tracer-context-probe PRIVATE native)
    add_executable(maplesu-zygisk-webui-probe tests/webui_probe.cpp)
    target_include_directories(maplesu-zygisk-webui-probe PRIVATE native)
    add_executable(maplesu-zygisk-json-probe tests/monitor_json_probe.c)
    target_include_directories(maplesu-zygisk-json-probe PRIVATE ${LOADER}/ptracer)
    target_link_libraries(maplesu-zygisk-json-probe PRIVATE common log m)
    add_executable(maplesu-zygisk-startup-policy-probe tests/startup_policy_probe.c)
    target_link_libraries(maplesu-zygisk-startup-policy-probe PRIVATE module-scan module-policy-state)
    target_compile_options(maplesu-zygisk-startup-policy-probe PRIVATE -UNDEBUG)
    add_executable(maplesu-zygisk-startup-rpc-probe tests/startup_rpc_probe.c ${LOADER}/common/daemon.c)
    target_compile_definitions(maplesu-zygisk-startup-rpc-probe PRIVATE MAPLE_SERVER_PREPARE_TIMEOUT_MS=100)
    target_compile_options(maplesu-zygisk-startup-rpc-probe PRIVATE -UNDEBUG)
    target_link_options(maplesu-zygisk-startup-rpc-probe PRIVATE -Wl,--wrap=connect -Wl,--wrap=setsockopt)
    target_link_libraries(maplesu-zygisk-startup-rpc-probe PRIVATE common)
endif()

add_executable(maplesu-zygisk-installer-probe tests/installer_namespace.c)
add_executable(maplesu-zygisk-notification-probe tests/notification_switch_probe.cpp)
target_compile_options(maplesu-zygisk-notification-probe PRIVATE -UNDEBUG)

add_executable(maplesu-zygisk-module-probe tests/module_registration.c)
target_include_directories(maplesu-zygisk-module-probe PRIVATE ${LOADER}/injector)
target_link_libraries(maplesu-zygisk-module-probe PRIVATE common csoloader log dl m)

add_executable(maplesu-zygisk-mount-probe tests/mount_probe.c)
target_include_directories(maplesu-zygisk-mount-probe PRIVATE native ${DAEMON})
target_link_libraries(maplesu-zygisk-mount-probe PRIVATE log)
target_compile_options(maplesu-zygisk-mount-probe PRIVATE -UNDEBUG)

add_executable(maplesu-zygisk-companion-probe tests/companion_probe.c
    ${DAEMON}/utils.c native/root_maplesu.c)
target_include_directories(maplesu-zygisk-companion-probe PRIVATE ${DAEMON})
target_link_libraries(maplesu-zygisk-companion-probe PRIVATE module-scan log dl)
target_compile_options(maplesu-zygisk-companion-probe PRIVATE -UNDEBUG)

add_executable(maplesu-zygisk-policy-transport-probe tests/policy_transport_probe.c
    ${DAEMON}/utils.c native/root_maplesu.c)
target_include_directories(maplesu-zygisk-policy-transport-probe PRIVATE native ${DAEMON})
target_link_libraries(maplesu-zygisk-policy-transport-probe PRIVATE module-scan log dl)
target_compile_options(maplesu-zygisk-policy-transport-probe PRIVATE -UNDEBUG)

add_executable(maplesu-zygisk-api-probe tests/api_contract_probe.c ${LOADER}/injector/cpp_strings.c)
target_include_directories(maplesu-zygisk-api-probe PRIVATE ${LOADER}/injector)
target_link_libraries(maplesu-zygisk-api-probe PRIVATE common plti csoloader log dl m)
target_compile_options(maplesu-zygisk-api-probe PRIVATE -UNDEBUG)

add_executable(maplesu-zygisk-directory-probe tests/module_directory_probe.c)
target_link_libraries(maplesu-zygisk-directory-probe PRIVATE common)

add_library(maplesu-zygisk-plt-fixture SHARED tests/plt_fixture.c)

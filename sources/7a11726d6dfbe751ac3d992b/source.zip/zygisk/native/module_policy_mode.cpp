// SPDX-License-Identifier: AGPL-3.0-or-later
#include "module_policy_mode.h"
#include "../../runtime/pro/policy/module_policy_config.h"

bool maple_module_policy_allowed(void) {
    using namespace maplesu::module_policy;
    try {
        const auto state = Store::open(false).read(current_boot_id());
        return state.effective && state.effective->mode != Mode::Block;
    } catch (...) {
        return false;
    }
}

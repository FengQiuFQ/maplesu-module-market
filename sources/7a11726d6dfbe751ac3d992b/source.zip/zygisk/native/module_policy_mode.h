// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif
// Submit rules only with a prepared, current-boot Load or Hide backend.
// Missing or stale state never falls back to legacy loads. Only Hide isolates views.
bool maple_module_policy_allowed(void);
#ifdef __cplusplus
}
#endif

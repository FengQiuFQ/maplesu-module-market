// Uses the pinned daemon's mountinfo parser. Receipts identify MapleSU projections
// in init's namespace; compare their identities after namespace cloning changes IDs.
static bool maple_same_mount(const struct mountinfo *a, const struct mountinfo *b) {
  return a->device == b->device && strcmp(a->root, b->root) == 0 &&
    strcmp(a->target, b->target) == 0 && strcmp(a->type, b->type) == 0 &&
    strcmp(a->source, b->source) == 0 && strcmp(a->fs_option, b->fs_option) == 0;
}

static bool maple_select_mounts(const struct mountinfos *origin,
                               const struct mountinfos *current, FILE *ledger, bool *selected) {
  char line[PATH_MAX + 32], target[PATH_MAX];
  unsigned int id;
  while (fgets(line, sizeof(line), ledger)) {
    if (sscanf(line, "%u %4095s", &id, target) != 2) continue;
    for (size_t i = 0; i < origin->length; i++) {
      const struct mountinfo *mount = &origin->mounts[i];
      if (mount->id != id || strcmp(mount->target, target) != 0) continue;
      for (size_t j = 0; j < current->length; j++) {
        if (maple_same_mount(mount, &current->mounts[j])) selected[j] = true;
      }
    }
  }
  return !ferror(ledger);
}

static bool maple_mount_covered(const struct mountinfos *mounts, const bool *detached, size_t index) {
  const char *target = mounts->mounts[index].target;
  size_t length = strlen(target);
  for (size_t j = 0; j < mounts->length; j++) {
    if (j == index || detached[j]) continue;
    const char *other = mounts->mounts[j].target;
    if ((j > index && strcmp(other, target) == 0) ||
        (strncmp(other, target, length) == 0 && other[length] == '/')) return true;
  }
  return false;
}

static bool maple_unmount_root(const struct mountinfos *current) {
  const char *state = "/data/adb/maplesu/module-mounts";
  char path[PATH_MAX], expected[80] = {0}, actual[80] = {0};
  snprintf(path, sizeof(path), "%s/ledger", state);
  FILE *ledger = fopen(path, "r");
  if (!ledger) return errno == ENOENT;
  snprintf(path, sizeof(path), "%s/boot", state);
  FILE *stamp = fopen(path, "r");
  FILE *boot = fopen("/proc/sys/kernel/random/boot_id", "r");
  if (stamp) { fscanf(stamp, "%79s", expected); fclose(stamp); }
  if (boot) { fscanf(boot, "%79s", actual); fclose(boot); }
  if (!*expected || !*actual || strcmp(expected, actual) != 0) {
    fclose(ledger);
    return true;  // Stale receipts never identify mounts in a new boot.
  }
  struct mountinfos origin = {0};
  if (!parse_mountinfo("1", &origin)) { fclose(ledger); return false; }
  bool *selected = calloc(current->length ? current->length : 1, sizeof(bool));
  bool *detached = calloc(current->length ? current->length : 1, sizeof(bool));
  bool ok = selected && detached && maple_select_mounts(&origin, current, ledger, selected);
  fclose(ledger);
  free_mounts(&origin);
  if (ok) {
    for (size_t i = current->length; i > 0; i--) {
      size_t index = i - 1;
      if (!selected[index]) continue;
      // Preserve foreign upper layers and child mounts. Never detach their subtree.
      if (maple_mount_covered(current, detached, index) ||
          umount2(current->mounts[index].target, MNT_DETACH) != 0) {
        ok = false;
      } else {
        detached[index] = true;
      }
    }
  }
  free(selected);
  free(detached);
  return ok;
}

"""Deterministic, stripped Ultra-native archive, with corresponding port sources."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import re
import subprocess
import tarfile
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def pinned_tree(folder):
    if (folder / ".git").exists():
        data = subprocess.check_output(["git", "-C", str(folder), "archive", "HEAD"])
        with tarfile.open(fileobj=io.BytesIO(data)) as archive:
            return {entry.name: archive.extractfile(entry).read() for entry in archive if entry.isfile()}
    return {path.relative_to(folder).as_posix(): path.read_bytes()
            for path in folder.rglob("*") if path.is_file() and ".git" not in path.parts}


def zipped(files):
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            item = zipfile.ZipInfo(name, (2026, 11, 4, 0, 0, 0))
            item.compress_type = zipfile.ZIP_DEFLATED
            item.create_system = 3
            item.external_attr = 0o100644 << 16
            archive.writestr(item, data)
    return output.getvalue()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ndk", required=True)
    parser.add_argument("--build-dir", type=Path, default=HERE / "build")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    props = dict(line.split("=", 1) for line in (HERE / "module/module.prop").read_text(encoding="utf-8").splitlines()
                 if "=" in line and not line.startswith("#"))
    version = props["version"]
    archive_hash = hashlib.sha256((ROOT / "runtime/upstream-pro/lib/arm64-v8a/libkernel_module_kit_static.a").read_bytes()).hexdigest()
    linked_host = (args.build_dir / "arm64-v8a/libmodule_maplesu_zygisk.so").read_bytes()
    linked_hashes = re.findall(rb"MAPLESU_SDK_ARCHIVE_SHA256=([0-9a-f]{64})", linked_host)
    if linked_hashes != [archive_hash.encode()]:
        raise RuntimeError("ZYGisk host must be relinked with the current SDK before packaging")
    sdk_identity = json.loads((ROOT / "runtime/upstream-pro/SDK-RELEASE.json").read_text(encoding="utf-8"))
    if sdk_identity["archive"]["sha256"] != archive_hash:
        raise RuntimeError("SDK release identity does not match the link input")
    tool = Path(args.ndk) / "toolchains/llvm/prebuilt/windows-x86_64/bin"
    files = {}
    manifest = {"version": version, "target": "MapleSU_Ultra", "zygiskApi": [1, 2, 3, 4, 5],
                "deviceAcceptance": "Per-build device acceptance is recorded separately; complete reboot stability acceptance is pending.", "binaries": {}, "upstream": {}}
    upstream = ROOT / "third_party/rezygisk"
    pinned = {"ReZygisk": upstream,
                         "CSOLoader": upstream / "loader/src/external/csoloader",
                         "PLTI": upstream / "loader/src/external/plti"}
    if (upstream / ".git").exists():
        for name, folder in pinned.items():
            manifest["upstream"][name] = subprocess.check_output(["git", "-C", str(folder), "rev-parse", "HEAD"], text=True).strip()
    else:
        manifest["upstream"] = json.loads((upstream / "MAPLESU-PORT.json").read_text())["upstream"]
    manifest["sdkArchiveSha256"] = archive_hash
    manifest["sdkBuildId"] = sdk_identity["sdkBuildId"]
    manifest["runnerSha256"] = hashlib.sha256((ROOT / "manager/src/main/assets/maplesu/modules/run.sh").read_bytes()).hexdigest()
    manifest["policySource"] = json.loads((ROOT / "module-policy/upstream/sources.json").read_text())
    with tempfile.TemporaryDirectory(prefix="maplesu-zygisk-package-") as temp:
        for abi, suffix in (("arm64-v8a", "64"), ("armeabi-v7a", "32")):
            for source, target in (("libzygisk.so", f"lib{'64' if suffix == '64' else ''}/libzygisk.so"),
                                   ("zygiskd", f"bin/zygiskd{suffix}"),
                                   ("zygisk-ptrace", f"bin/zygisk-ptrace{suffix}")):
                binary = Path(temp) / (abi + "-" + source)
                binary.write_bytes((args.build_dir / abi / source).read_bytes())
                subprocess.run([str(tool / "llvm-strip.exe"), "--strip-all", str(binary)], check=True)
                files[target] = binary.read_bytes()
            if suffix == "64":
                binary = Path(temp) / "host.so"
                binary.write_bytes((args.build_dir / abi / "libmodule_maplesu_zygisk.so").read_bytes())
                subprocess.run([str(tool / "llvm-strip.exe"), "--strip-all", str(binary)], check=True)
                files["libmodule_maplesu_zygisk.so"] = binary.read_bytes()
                binary = Path(temp) / "policy"
                binary.write_bytes((args.build_dir / "arm64-v8a/policy/maplesu-policy").read_bytes())
                subprocess.run([str(tool / "llvm-strip.exe"), "--strip-all", str(binary)], check=True)
                files["bin/maplesu-policy"] = binary.read_bytes()
    with tempfile.TemporaryDirectory(prefix="maplesu-shared-package-") as extra:
        binary = Path(extra) / "liblsp-shared.so"
        binary.write_bytes((args.build_dir / "arm64-v8a/liblsp-shared.so").read_bytes())
        subprocess.run([str(tool / "llvm-strip.exe"), "--strip-all", str(binary)], check=True)
        files["lib64/liblsp-shared.so"] = binary.read_bytes()
    for path in (HERE / "module").rglob("*"):
        if path.is_file():
            name = path.relative_to(HERE / "module").as_posix()
            files["payload/module.prop" if name == "module.prop" else name] = path.read_bytes()
    files["bin/run-module.sh"] = (ROOT / "manager/src/main/assets/maplesu/modules/run.sh").read_bytes()
    # A top-level module.prop would make MapleSU's archive detector see two module types.
    assert "module.prop" not in files
    files["COPYING"] = (upstream / "loader/src/external/csoloader/LICENSE").read_bytes()
    for source, target in {
        upstream / "LICENSE": "ReZygisk-LICENSE",
        upstream / "NOTICE": "ReZygisk-NOTICE",
        upstream / "loader/src/external/plti/LICENSE": "PLTI-LICENSE",
        ROOT / "module-policy/upstream/magisk/LICENSE": "Policy-Magisk-LICENSE",
        ROOT / "module-policy/upstream/libsepol-LICENSE": "Policy-libsepol-LICENSE",
        ROOT / "third_party/kernelsu/applied/LICENSE": "Policy-KernelSU-LICENSE",
    }.items():
        files["LICENSES/" + target] = source.read_bytes()
    files["README.md"] = (HERE / "README.md").read_bytes()
    files["CHANGELOG.md"] = (HERE / "CHANGELOG.md").read_bytes()
    files["NOTICE.md"] = (HERE / "NOTICE.md").read_bytes()
    for name, data in files.items():
        if data[:4] == b"\x7fELF":
            assert b"D:\\Maple_Workflow" not in data and b"D:/Maple_Workflow" not in data
            assert b"C:\\Users\\" not in data and b"C:/Users/" not in data
            manifest["binaries"][name] = {"size": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    sources = {}
    for folder in (HERE, ROOT / "module-policy"):
        for path in folder.rglob("*"):
            if not path.is_file() or any(p in (".git", "build", "__pycache__") for p in path.relative_to(folder).parts):
                continue
            sources[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    sources["manager/src/main/assets/maplesu/modules/run.sh"] = files["bin/run-module.sh"]
    for name in ("module_policy_config.h", "module_policy_config.cpp", "kernel_layout.h", "kernel_layout.cpp",
                 "jailbreak_status_layout.h", "jailbreak_status_layout.cpp"):
        path = ROOT / "runtime/pro/policy" / name
        sources[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    for name in ("boot_sdk_abi.h", "selinux_hide_abi.h"):
        path = ROOT / "jailbreak-providers/root-loader" / name
        sources[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    for name in ("LICENSE", "uapi/supercall.h", "uapi/app_profile.h"):
        path = ROOT / "third_party/kernelsu/applied" / name
        sources[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    # Start from immutable upstream bytes; local vendor edits never enter a release.
    port_sources = {}
    for folder in pinned.values():
        for name, data in pinned_tree(folder).items():
            if name == "MAPLESU-PORT.json":
                continue
            port_sources[(folder / name).relative_to(upstream).as_posix()] = data
    for path in (HERE / "build/upstream").rglob("*"):
        if path.is_file():
            port_sources[path.relative_to(HERE / "build/upstream").as_posix()] = path.read_bytes()
    port_manifest = {"upstream": manifest["upstream"], "files": {
        name: hashlib.sha256(data).hexdigest() for name, data in port_sources.items()}}
    port_sources["MAPLESU-PORT.json"] = json.dumps(port_manifest, indent=2, sort_keys=True).encode()
    sources.update({"third_party/rezygisk/" + name: data for name, data in port_sources.items()})
    policy_dependency = ROOT / ".deps/selinux"
    for name, data in pinned_tree(policy_dependency).items():
        if name.startswith("libsepol/"):
            sources[".deps/selinux/" + name] = data
    sources["tools/build_module_policy.py"] = (ROOT / "tools/build_module_policy.py").read_bytes()
    # The SDK is an existing external build dependency, not a credential-bearing app build.
    sources["zygisk/BUILD-IDENTITY.json"] = json.dumps(manifest, indent=2, sort_keys=True).encode()
    sources.pop("zygisk/SOURCE-DISTRIBUTION.json", None)
    sources["zygisk/SOURCE-DISTRIBUTION.json"] = json.dumps({"files": {
        name: hashlib.sha256(data).hexdigest() for name, data in sources.items()}}, indent=2, sort_keys=True).encode()
    files["webroot/source.zip"] = zipped(sources)
    files["BUILD-IDENTITY.json"] = json.dumps(manifest, indent=2, sort_keys=True).encode()
    output = args.output or ROOT / f"dist-release/MapleSU-Zygisk-{version}-Ultra.zip"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(zipped(files))
    manifest["archive"] = {"file": output.name, "sha256": hashlib.sha256(output.read_bytes()).hexdigest()}
    output.with_suffix(".json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

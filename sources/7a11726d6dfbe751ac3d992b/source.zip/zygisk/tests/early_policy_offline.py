"""Run production early policy/script dispatch in an isolated Linux fixture."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
CASES = [("ready", 1, 0, 0, -1), ("policy-failed", 1, 17, 0, -1), ("blocked", 0, 17, 0, -1),
         ("blocked-script-failed", 0, 17, 7, -1), ("hide", 3, 0, 0, -1),
         ("lost-before-policy", 3, 0, 0, 1), ("lost-before-policy-exec", 3, 0, 0, 2),
         ("lost-before-scripts", 3, 0, 0, 3), ("lost-after-first-script", 3, 0, 0, 4)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--save", type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="maplesu-early-policy-") as temporary:
        out = Path(temporary)
        script = ("set -eu\ncc -std=gnu2x -D_GNU_SOURCE -DMAPLE_EARLY_OFFLINE "
                  "-UNDEBUG -Wall -Wextra -Werror -Wno-format-truncation "
                  "-fsanitize=address,undefined -fno-omit-frame-pointer "
                  "-I/source/zygisk/native /source/zygisk/tests/early_result_probe.c "
                  "-Wl,--wrap=fopen -Wl,--wrap=execv -o /output/probe\n")
        for name, mode, policy_exit, script_exit, allowed_reads in CASES:
            folder = out / name
            (folder / "module").mkdir(parents=True)
            for stage in ("post-fs-data", "post-mount", "service"):
                (folder / "module" / (stage + ".sh")).touch()
            (folder / "module/sepolicy.rule").write_text("fixture\n")
            (folder / "run.sh").write_text(
                f'printf "%s\\n" "$2" >> /output/{name}/scripts\nexit {script_exit}\n', newline="\n")
            (folder / "maplesu-policy").write_text(
                f'#!/bin/sh\nprintf "%s\\n" "$*" >> /output/{name}/policies\n'
                f'test "$2" = --require-boot-policy || exit 65\nexit {policy_exit}\n', newline="\n")
            expected = int(mode != 0 and script_exit == 0 and policy_exit == 0 and allowed_reads < 0)
            script += (f"chmod 700 /output/{name}/maplesu-policy\nset +e\n"
                       f"/output/probe /output/{name} {expected} {mode} {allowed_reads}\ncode=$?\nset -e\n"
                       f"printf '%s\\n' \"$code\" > /output/{name}/exit\n")
        result = subprocess.run([
            "docker", "run", "--rm", "--pull", "never", "--network", "none", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--mount", f"type=bind,source={ROOT},target=/source,readonly",
            "--mount", f"type=bind,source={out},target=/output",
            "ghcr.io/ylarod/ddk-min:android15-6.6-20260828", "sh", "-c", script,
        ], capture_output=True, text=True, timeout=60)
        checks = {}
        for name, mode, _, _, allowed_reads in CASES:
            folder = out / name
            policies = (folder / "policies").read_text().splitlines() if (folder / "policies").exists() else []
            stages = (folder / "scripts").read_text().splitlines() if (folder / "scripts").exists() else []
            checks[name] = {"exit": int((folder / "exit").read_text()) if (folder / "exit").exists() else -1,
                            "policyExecutions": len(policies), "policyCommands": policies, "scriptStages": stages,
                            "bootStampWritten": (folder / "early.boot").exists()}
            expected_stages = ["post-fs-data", "post-mount", "service"] if mode != 0 else []
            if allowed_reads >= 0:
                expected_stages = expected_stages[:max(0, allowed_reads - 3)]
            expected_policies = int(mode != 0 and (allowed_reads < 0 or allowed_reads >= 3))
            checks[name]["passed"] = (checks[name]["exit"] == 0 and len(policies) == expected_policies and
                                      stages == expected_stages and checks[name]["bootStampWritten"] == (mode != 0))
        record = {"deviceAccess": False, "productionBuild": False, "exitCode": result.returncode,
                  "checks": checks, "stdout": result.stdout, "stderr": result.stderr,
                  "sourceSha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                                   for p in (ROOT / "zygisk/native/early_modules.c",
                                             ROOT / "zygisk/tests/early_result_probe.c",
                                             ROOT / "zygisk/tests/early_policy_offline.py")}}
        if args.save:
            args.save.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(record, indent=2))
        assert result.returncode == 0 and all(row["passed"] for row in checks.values())


if __name__ == "__main__":
    main()

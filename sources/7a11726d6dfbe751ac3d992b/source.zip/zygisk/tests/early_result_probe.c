// SPDX-License-Identifier: AGPL-3.0-or-later
// Production dispatcher with a recorder policy and app-owned module fixture.
#include "../native/early_modules.c"

static char fixture[4096];
static int module_policy_mode = 1;
static int scans;
static int allowed_reads = -1, gate_reads;
bool maple_module_policy_allowed(void) {
    ++gate_reads;
    return module_policy_mode != 0 && (allowed_reads < 0 || gate_reads <= allowed_reads);
}
#ifdef MAPLE_EARLY_OFFLINE
int __real_execv(const char *, char *const[]);
int __wrap_execv(const char *path, char *const argv[]) {
    if (!strcmp(path, "/data/adb/maplesu/bin/busybox")) {
        char *args[] = {"/bin/sh", argv[2], argv[3], argv[4], argv[5], NULL};
        return __real_execv(args[0], args);
    }
    return __real_execv(path, argv);
}
#endif
FILE *__real_fopen(const char *, const char *);
FILE *__wrap_fopen(const char *path, const char *mode) {
    char target[4096];
    if (!strcmp(path, "/data/adb/maplesu_zygisk/early.boot")) {
        snprintf(target, sizeof(target), "%s/early.boot", fixture);
        path = target;
    }
    return __real_fopen(path, mode);
}
int maple_scan_modules(const char *root, const char *abi, struct maple_module **out, size_t *count) {
    (void)root; (void)abi;
    ++scans;
    *out = calloc(1, sizeof(**out));
    (*out)->name = strdup("policy_fixture");
    char path[4096]; snprintf(path, sizeof(path), "%s/module", fixture);
    (*out)->path = strdup(path);
    (*out)->dir_fd = open(path, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    (*out)->lib_fd = -1;
    *count = 1;
    return (*out)->dir_fd < 0;
}
void maple_free_modules(struct maple_module *modules, size_t count) {
    for (size_t i = 0; i < count; ++i) {
        close(modules[i].dir_fd); free(modules[i].name); free(modules[i].path);
    }
    free(modules);
}
int main(int argc, char **argv) {
    if (argc < 3 || argc > 5 || strlen(argv[1]) > 3800) return 64;
    if (argc >= 4) module_policy_mode = atoi(argv[3]);
    if (argc == 5) allowed_reads = atoi(argv[4]);
    strcpy(fixture, argv[1]);
    int pipefd[2];
    if (pipe2(pipefd, O_CLOEXEC) || dup2(pipefd[1], 198) < 0) return 1;
    close(pipefd[1]);
    char helper[4096]; snprintf(helper, sizeof(helper), "%s/run.sh", fixture);
    int code = maple_run_early_modules(helper);
    close(198);
    char ack = 0; ssize_t n = read(pipefd[0], &ack, 1); close(pipefd[0]);
    printf("EARLY_RESULT exit=%d ack=%c expected=%c scans=%d\n", code, ack, argv[2][0], scans);
    return n != 1 || ack != argv[2][0] || code != (argv[2][0] == '1' ? 0 : 1) ||
        scans != (module_policy_mode != 0);
}

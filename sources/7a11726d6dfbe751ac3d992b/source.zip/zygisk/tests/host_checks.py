"""Use the manager's actual archive inspector on the final host and official HMA."""
from pathlib import Path
import argparse
import json
import os
import subprocess
import tempfile
import zipfile
import hashlib

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--jdk", default=os.environ.get("JAVA_HOME"), required=not os.environ.get("JAVA_HOME"),
                        help="JDK home; default is JAVA_HOME")
    parser.add_argument("--gradle-cache", default=str(Path.home() / ".gradle/caches/modules-2/files-2.1"))
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--save", type=Path, required=True)
    args = parser.parse_args()
    cache = Path(args.gradle_cache)
    # Only the already-resolved archive parser dependencies, not unrelated user files.
    jars = []
    for library in ("org.apache.commons/commons-compress", "commons-io/commons-io", "commons-codec/commons-codec", "org.apache.commons/commons-lang3"):
        versions = sorted((path for path in (cache / library).iterdir() if path.is_dir()),
                          key=lambda path: tuple(int(part) for part in path.name.split('.')))
        version = versions[-1]
        jars.extend(version.rglob(library.split('/')[-1] + '-' + version.name + '.jar'))
    classpath = os.pathsep.join(str(path) for path in jars)
    assert jars, "Resolve manager Gradle dependencies first"
    host = args.package.resolve()
    identity = json.loads(host.with_suffix(".json").read_text(encoding="utf-8"))
    hma = ROOT / "evidence/ultra-zygisk-hma-20261104/HMA-OSS-ZYGISK-oss-173-release.zip"
    with tempfile.TemporaryDirectory(prefix="maplesu-zygisk-archive-") as temporary:
        compile_result = subprocess.run([str(Path(args.jdk) / ("bin/javac.exe" if os.name == "nt" else "bin/javac")), "-encoding", "UTF-8", "-cp", classpath, "-d", temporary,
                        str(ROOT / "manager/src/main/java/dev/maplesu/manager/ModuleArchiveInspector.java"),
                        str(ROOT / "manager/src/main/java/dev/maplesu/manager/MapleSuModuleMetadata.java"),
                        str(ROOT / "zygisk/tests/ArchiveProbe.java")], capture_output=True, text=True)
        if compile_result.returncode:
            raise RuntimeError(compile_result.stderr)
        result = subprocess.run([str(Path(args.jdk) / ("bin/java.exe" if os.name == "nt" else "bin/java")), "-cp", temporary + os.pathsep + classpath,
                                 "ArchiveProbe", str(host), str(hma), identity["version"]], check=True, capture_output=True, text=True)
    with zipfile.ZipFile(host) as archive:
        assert "webroot/index.html" in archive.namelist()
        assert "webroot/app.js" in archive.namelist()
        assert "webroot/style.css" in archive.namelist()
        assert "webroot/source.zip" in archive.namelist()
        assert not any(name.startswith("wwwroot/") for name in archive.namelist())
        assert "module.prop" not in archive.namelist()
        for path, record in identity["binaries"].items():
            data = archive.read(path)
            assert hashlib.sha256(data).hexdigest() == record["sha256"], path
            assert b"D:/Maple_Workflow" not in data and b"C:\\Users\\" not in data, path
        assert len(identity["binaries"]) == 9
    evidence = args.save
    evidence.parent.mkdir(parents=True, exist_ok=True)
    evidence.write_text(json.dumps({"passed": True, "result": result.stdout.strip(),
                                   "archiveSha256": hashlib.sha256(host.read_bytes()).hexdigest(),
                                   "verifiedBinaries": len(identity["binaries"])}, indent=2), encoding="utf-8")
    print(result.stdout.strip())


if __name__ == "__main__":
    main()

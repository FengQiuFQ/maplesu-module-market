"""Verify Zygisk's C ABI against the real shared boot-state reader."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
SOURCES = ["zygisk/native/module_policy_mode.h", "zygisk/native/module_policy_mode.cpp",
           "runtime/pro/policy/module_policy_config.h", "runtime/pro/policy/module_policy_config.cpp",
           "zygisk/tests/module_policy_mode_probe.cpp"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--save", type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="maplesu-module-policy-mode-") as temporary:
        out = Path(temporary)
        result = subprocess.run([
            "docker", "run", "--rm", "--pull", "never", "--network", "none", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--mount", f"type=bind,source={ROOT},target=/source,readonly",
            "--mount", f"type=bind,source={out},target=/output",
            "ghcr.io/ylarod/ddk-min:android15-6.6-20260828", "sh", "-c",
            "c++ -std=c++20 -D_GNU_SOURCE -UNDEBUG -Wall -Wextra -Werror -fno-rtti "
            "-fsanitize=address,undefined -fno-omit-frame-pointer -I/source/zygisk/native "
            "/source/zygisk/tests/module_policy_mode_probe.cpp /source/zygisk/native/module_policy_mode.cpp "
            "/source/runtime/pro/policy/module_policy_config.cpp -Wl,--wrap=open -Wl,--wrap=openat "
            "-Wl,--wrap=geteuid -o /output/probe && /output/probe",
        ], capture_output=True, text=True, timeout=60)
        record = {"deviceAccess": False, "productionBuild": False, "exitCode": result.returncode,
                  "sourceSha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in SOURCES},
                  "stdout": result.stdout, "stderr": result.stderr,
                  "passed": result.returncode == 0, "cases": result.stdout.count("PASS:")}
        if args.save:
            args.save.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(record, indent=2))
        assert record["passed"] and record["cases"] >= 45


if __name__ == "__main__":
    main()

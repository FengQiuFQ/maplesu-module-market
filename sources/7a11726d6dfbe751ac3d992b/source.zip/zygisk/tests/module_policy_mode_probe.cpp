// Production C ABI and shared Store, with only /data and boot-id I/O redirected.
#include "module_policy_mode.h"
#include "../../runtime/pro/policy/module_policy_config.h"
#include <cassert>
#include <cstdarg>
#include <cstdio>
#include <fcntl.h>
#include <string>
#include <sys/stat.h>
#include <unistd.h>

static unsigned writes;
static bool invalid_boot, non_root;
static constexpr const char *directory = "/output/data/adb/maplesu/module-policy";
extern "C" int __real_open(const char *, int, ...);
extern "C" int __real_openat(int, const char *, int, ...);
extern "C" uid_t __wrap_geteuid() { return non_root ? 10000 : 0; }
extern "C" int __wrap_open(const char *path, int flags, ...) {
    assert(!(flags & O_CREAT));
    writes += (flags & O_ACCMODE) != O_RDONLY;
    if (std::string(path) == "/data") path = "/output/data";
    if (invalid_boot && std::string(path) == "/proc/sys/kernel/random/boot_id") path = "/output/bad-boot";
    return __real_open(path, flags);
}
extern "C" int __wrap_openat(int parent, const char *name, int flags, ...) {
    assert(!(flags & O_CREAT));
    writes += (flags & O_ACCMODE) != O_RDONLY;
    return __real_openat(parent, name, flags);
}
static void put(const std::string &path, const std::string &value, mode_t mode = 0600) {
    int fd = __real_open(path.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, mode);
    assert(fd >= 0 && write(fd, value.data(), value.size()) == static_cast<ssize_t>(value.size()));
    assert(close(fd) == 0 && chmod(path.c_str(), mode) == 0);
}
static void check(const char *name, int expected) {
    int actual = maple_module_policy_allowed();
    printf("%s: %s allowed=%d expected=%d\n", actual == expected ? "PASS" : "FAIL", name, actual, expected);
    assert(actual == expected && writes == 0);
}
int main() {
    setbuf(stdout, nullptr);
    check("absent-data", 0);
    assert(access("/output/data", F_OK) != 0);
    for (const char *path : {"/output/data", "/output/data/adb", "/output/data/adb/maplesu", directory}) {
        assert(mkdir(path, 0700) == 0);
        check("missing-state-directory-never-loads-policy", 0);
    }
    const auto boot = maplesu::module_policy::current_boot_id();
    auto record = [&](int mode, int capabilities) {
        return "v1:" + std::to_string(mode) + ":" + std::to_string(capabilities) + ":" + boot + "\n";
    };
    std::string stale = record(1, 3);
    stale[7] = stale[7] == 'a' ? 'b' : 'a';
    struct Case { const char *name; std::string requested, effective; int expected; mode_t mode = 0600; };
    const Case cases[] = {
        {"absent-records", "", "", 0},
        {"requested-load-alone", "v1:1\n", "", 0},
        {"requested-block-alone", "v1:0\n", "", 0},
        {"requested-hide-alone", "v1:3\n", "", 0},
        {"block", "v1:3\n", record(0, 3), 0},
        {"visible-load", "v1:1\n", record(1, 1), 1},
        {"load-with-hide-capability-remains-load", "v1:1\n", record(1, 3), 1},
        {"requested-block-not-effective", "v1:0\n", record(1, 3), 1},
        {"requested-hide-not-effective", "v1:3\n", record(1, 3), 1},
        {"hide", "v1:3\n", record(3, 3), 1},
        {"requested-load-not-effective", "v1:1\n", record(3, 3), 1},
        {"requested-block-preserves-current-view", "v1:0\n", record(3, 3), 1},
        {"hidden-effective-alone", "", record(3, 3), 1},
        {"visible-effective-alone", "", record(1, 1), 1},
        {"stale-boot-never-loads-policy", "v1:3\n", stale, 0},
        {"hide-not-capable", "v1:3\n", record(3, 1), 0},
        {"invalid-capabilities", "v1:1\n", record(1, 0), 0},
        {"invalid-mode", "v1:1\n", record(2, 3), 0},
        {"malformed-state-never-loads-policy", "v1:2\n", record(3, 3), 0},
        {"short-record", "v1:1\n", "v1:1:3:boot\n", 0},
        {"extra-data", "v1:1\n", record(1, 3) + "x", 0},
        {"oversized", "v1:1\n", std::string(65, 'x'), 0},
        {"non-private-mode", "v1:1\n", record(1, 3), 0, 0644},
        {"writable-record", "v1:1\n", record(1, 3), 0, 0666}
    };
    std::string requested = std::string(directory) + "/requested", effective = std::string(directory) + "/effective";
    for (const auto &c : cases) {
        unlink(requested.c_str()); unlink(effective.c_str());
        if (!c.requested.empty()) put(requested, c.requested);
        if (!c.effective.empty()) put(effective, c.effective, c.mode);
        check(c.name, c.expected);
    }
    assert(unlink(requested.c_str()) == 0);
    const std::string attempt = std::string(directory) + "/attempt";
    for (const auto &value : {"v1:" + boot + "\n", "v1:" + stale.substr(7, 36) + "\n", std::string("bad\n")}) {
        unlink(effective.c_str());
        put(attempt, value);
        check("attempt-without-hidden-effective-never-loads-policy", 0);
        put(effective, record(3, 3));
        check("hidden-effective-precedes-attempt", 1);
    }
    assert(unlink(attempt.c_str()) == 0 && mkfifo(attempt.c_str(), 0600) == 0);
    assert(unlink(effective.c_str()) == 0);
    check("attempt-fifo-never-blocks-or-loads-policy", 0);
    assert(unlink(attempt.c_str()) == 0);
    const std::string fallback = std::string(directory) + "/fallback";
    put(requested, "v1:1\n");
    put(fallback, "v1:" + boot + "\n");
    check("hidden-failure-restores-host-without-effective-file", 1);
    put(effective, record(3, 3));
    check("hidden-fallback-wins-over-partial-publication", 1);
    put(requested, "v1:0\n");
    check("pending-block-does-not-undo-current-boot-fallback", 1);
    put(fallback, "v1:" + stale.substr(7, 36) + "\n");
    assert(unlink(effective.c_str()) == 0);
    check("previous-boot-fallback-never-reopens-policy", 0);
    assert(unlink(fallback.c_str()) == 0);
    put(effective, record(3, 3));
    assert(chmod(directory, 0777) == 0); check("writable-directory", 0);
    assert(chmod(directory, 0700) == 0); check("directory-restored", 1);
    put(requested, "v1:3\n");
    assert(unlink(effective.c_str()) == 0 && symlink("requested", effective.c_str()) == 0);
    check("symlink-record", 0);
    assert(unlink(effective.c_str()) == 0 && link(requested.c_str(), effective.c_str()) == 0);
    check("hardlink-record", 0);
    assert(unlink(effective.c_str()) == 0 && mkfifo(effective.c_str(), 0600) == 0);
    check("fifo-never-blocks", 0);
    assert(unlink(effective.c_str()) == 0);
    put(effective, record(3, 3));
    put("/output/bad-boot", "invalid\n");
    invalid_boot = true; check("invalid-current-boot", 0); invalid_boot = false;
    non_root = true; check("non-root", 0); non_root = false;
    check("root-restored", 1);
    assert(access((std::string(directory) + "/.lock").c_str(), F_OK) != 0);
    puts("PASS: read-only state never creates locks, requests or effective records");
}

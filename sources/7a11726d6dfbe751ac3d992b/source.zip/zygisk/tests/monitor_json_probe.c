// Exercise the actual monitor serializer without starting the monitor.
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#ifdef MAPLE_MONITOR_OFFLINE
#include <errno.h>
#include <limits.h>
#include <signal.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include "misc.h"
// Only metadata/JSON code is retained by --gc-sections; no Android logger or ptrace.
#define UTILS_H
#define LOGGING_H
#define WPTEVENT(x) ((x) >> 16)
#define LOGI(...) ((void)0)
#define LOGD(...) ((void)0)
#define LOGV(...) ((void)0)
#define LOGW(...) ((void)0)
#define LOGE(...) ((void)0)
#define PLOGE(...) ((void)0)
#define sigabbrev_np strsignal
int get_program(int, char *, size_t);
int fork_dont_care(void);
void parse_status(int, char *, size_t);
#endif
static const char *fixture;
static void remap(const char *path, char *out, size_t size) {
  const char *leaf = strrchr(path, '/');
  snprintf(out, size, "%s/%s%s", fixture, strstr(path, "/payload/") ? "payload/" : "", leaf ? leaf + 1 : path);
}
static FILE *fixture_fopen(const char *p, const char *mode) {
  char path[4096]; remap(p, path, sizeof(path)); return fopen(path, mode);
}
static int fixture_rename(const char *a, const char *b) {
  char from[4096], to[4096]; remap(a, from, sizeof(from)); remap(b, to, sizeof(to)); return rename(from, to);
}
static int fixture_unlink(const char *p) {
  char path[4096]; remap(p, path, sizeof(path)); return unlink(path);
}
#define fopen fixture_fopen
#define rename fixture_rename
#define unlink fixture_unlink
#define remove fixture_unlink
#include "monitor.c"
#undef fopen
#undef rename
#undef unlink
#undef remove
int main(int argc, char **argv) {
  if (argc != 3 && argc != 4) return 2;
  fixture = argv[1];
  status64.supported = true;
  status64.daemon_running = true;
  status64.zygote_injected = true;
  char *modules[] = {"hma_oss", "quotes\"\\\t\n"};
  environment_information64 = (struct environment_information){.root_impl = "MapleSU Ultra\"\\\n", .modules = modules, .modules_len = 2};
  if (strcmp(argv[2], "metadata") == 0) {
    int rounds = argc == 4 ? atoi(argv[3]) : 64;
    for (int round = 0; round < rounds; ++round) {
      if (!prepare_environment() || !update_status(NULL)) return 1;
    }
    return 0;
  }
  FILE *prop = fixture_fopen("/module.prop", "w");
  if (!prop) return 1;
  fputs("id=maplesu_zygisk\ndescription=fixture\n", prop);
  if (fclose(prop) != 0 || !prepare_environment()) return 1;
  if (!prepare_environment()) return 1;
  if (strcmp(argv[2], "message") == 0) return update_status("test message") ? 0 : 1;
  if (strcmp(argv[2], "long-error") == 0) {
    static char error[8192];
    memset(error, 'x', sizeof(error) - 1);
    status64.daemon_running = false;
    status64.daemon_error_info = error;
    status32.supported = true;
    status32.daemon_error_info = error;
  }
  if (strcmp(argv[2], "stopped") == 0) {
    tracing_state = STOPPED;
    monitor_stop_reason = "stopped\"\\\n";
    status64.daemon_running = false;
    status64.daemon_error_info = "error\"\\\n";
  }
  if (strcmp(argv[2], "dual") == 0) {
    status32.supported = true;
    status32.daemon_error_info = "32bit\"\\\n";
  }
  if (strcmp(argv[2], "long-status") == 0) {
    static char error[8192];
    memset(error, 'E', sizeof(error) - 1);
    status64.daemon_running = false;
    status64.daemon_error_info = error;
  }
  return update_status(NULL) ? 0 : 1;
}

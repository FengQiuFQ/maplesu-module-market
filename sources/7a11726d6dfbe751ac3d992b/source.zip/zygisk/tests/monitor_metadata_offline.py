"""Run the real monitor metadata producer under ASan/UBSan; never uses a device."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
FIXTURE = ROOT / "zygisk/tests/fixtures/plq110-5.1.2-overflow.module.prop"
# Extracted unchanged (LF/UTF-8) from zygisk-080333/modules.txt, 2026-11-09.
FIXTURE_SHA256 = "8b2561ba5ff276f1ae4ddda11c1487a97d4e8b3fec3629794815b4fe9761695f"
PREFIX = "[Monitor: ✅, ReZygisk 64-bit: ✅] ".encode()
BASE = b"MapleSU Ultra Zygisk host. Reboot after installation. Zygisk API 1\xe2\x80\x935; ARM64/ARM32."
LIMIT = 1024 * 1024


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prop", type=Path, default=FIXTURE)
    parser.add_argument("--monitor", type=Path, help="Old monitor.c for a deliberate red run")
    parser.add_argument("--overlay", type=Path, help="Already generated production overlay")
    parser.add_argument("--save", type=Path)
    args = parser.parse_args()
    live = args.prop.read_bytes()
    assert len(live) == 1167 and hashlib.sha256(live).hexdigest() == FIXTURE_SHA256
    assert live.count(b"[Monitor:") == 26
    header, old_description = live.split(b"description=", 1)
    assert old_description == PREFIX * 26 + BASE + b"\n"
    checks = []
    with tempfile.TemporaryDirectory(prefix="maplesu-monitor-metadata-") as temporary:
        out = Path(temporary)
        overlay = args.overlay
        if overlay is None:
            spec = importlib.util.spec_from_file_location("maple_overlay", ROOT / "zygisk/patch_upstream.py")
            port = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(port)
            port.OUTPUT = overlay = out / "upstream"
            port.main()
        # Copy the complete generated overlay: relative monitor includes stay real.
        shutil.copytree(overlay, out / "port")
        if args.monitor:
            (out / "port/loader/src/ptracer/monitor.c").write_bytes(args.monitor.read_bytes())
            (out / "port/loader/src/ptracer/monitor.h").write_bytes(
                (ROOT / "third_party/rezygisk/loader/src/ptracer/monitor.h").read_bytes())
        script = ["set -eu", "ulimit -c 0", "export ASAN_OPTIONS=detect_leaks=1:halt_on_error=1",
                  "export UBSAN_OPTIONS=halt_on_error=1",
                  "cc -std=gnu2x -D_GNU_SOURCE -DMAPLE_MONITOR_OFFLINE -DZKSU_VERSION='\"fixture\"' "
                  "-U_FORTIFY_SOURCE -D_FORTIFY_SOURCE=0 "
                  "-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -fno-pie -no-pie "
                  "-ffunction-sections -fdata-sections -Wl,--gc-sections "
                  "-I/output/port/loader/src/include -I/output/port/loader/src/ptracer "
                  "/source/zygisk/tests/monitor_json_probe.c -o /output/probe"]

        def case(name, content, expected, *, payload=None, rounds=64, reject=False, fresh=False, blocked=False):
            folder = out / name
            (folder / "payload").mkdir(parents=True)
            (folder / "payload/module.prop").write_bytes(payload if payload is not None else b"id=payload\ndescription=payload\n")
            if content is not None:
                (folder / "module.prop").write_bytes(content)
            if blocked:
                (folder / "module.prop.tmp").mkdir()
            (folder / "expected.prop").write_bytes(expected)
            invocation = f"/output/probe /output/{name} metadata {rounds}"
            if reject:
                script.append(f"if {invocation}; then exit 1; fi")
            elif fresh:
                script.append(f"for round in $(seq 1 64); do {invocation}; "
                              f"cmp /output/{name}/module.prop /output/{name}/expected.prop; done")
            else:
                script.append(invocation)
            script.extend([f"cmp /output/{name}/module.prop /output/{name}/expected.prop",
                           f"printf 'PASS {name}\\n'"])
            checks.append({"case": name, "rounds": 64 if fresh else rounds,
                           "expectedBytes": len(expected), "rejected": reject})

        case("plq110-1167-bytes", live, header + b"description=" + PREFIX + BASE + b"\n", rounds=1)
        before = b"# retained\nid=maplesu_zygisk\nextra.before=" + b"A" * 16384 + b"\ndescription="
        description = b"long description " + b"D" * 262144
        after = b"\nupdateJson=https://example.test/update.json\nextra.after=" + b"B" * 65536 + b"\n"
        case("long-description-and-fields", before + description + after, before + PREFIX + description + after)
        case("64-fresh-starts", live, header + b"description=" + PREFIX + BASE + b"\n", rounds=1, fresh=True)
        for name, source, expected in [
            ("empty", b"id=x\ndescription=\nextra=yes\n", b"id=x\ndescription=" + PREFIX + b"\nextra=yes\n"),
            ("missing", b"id=x\nextra=yes", b"id=x\nextra=yes\ndescription=" + PREFIX + b"\n"),
            ("no-final-newline", b"id=x\ndescription=original", b"id=x\ndescription=" + PREFIX + b"original"),
            ("crlf", b"id=x\r\ndescription=" + PREFIX * 3 + b"original\r\nextra=yes\r\n",
             b"id=x\r\ndescription=" + PREFIX + b"original\r\nextra=yes\r\n"),
            ("unclosed-prefix", b"id=x\ndescription=[Monitor: custom\nextra=yes\n",
             b"id=x\ndescription=" + PREFIX + b"[Monitor: custom\nextra=yes\n"),
            ("other-prefix", b"id=x\ndescription=[Other: retained] original\n",
             b"id=x\ndescription=" + PREFIX + b"[Other: retained] original\n"),
            ("old-conflict-label", "id=x\ndescription=[❌ Multiple Zygisks functioning] original\n".encode(),
             b"id=x\ndescription=" + PREFIX + b"original\n"),
        ]:
            case(name, source, expected)
        canonical = header + b"description=" + BASE + b"\n"
        case("payload-fallback", None, header + b"description=" + PREFIX + BASE + b"\n", payload=canonical)
        at_limit = b"id=x\ndescription=" + b"X" * (LIMIT - len(b"id=x\ndescription="))
        case("at-limit", at_limit, b"id=x\ndescription=" + PREFIX + at_limit[len(b"id=x\ndescription="):])
        case("over-limit", at_limit + b"X", at_limit + b"X", rounds=1, reject=True)
        nul = b"id=x\ndescription=bad\0metadata\n"
        case("embedded-nul", nul, nul, rounds=1, reject=True)
        case("publication-blocked", canonical, canonical, rounds=1, reject=True, blocked=True)
        # Keep existing JSON serializer coverage while exercising the bounded error label.
        for mode in ("dual", "stopped", "long-status"):
            folder = out / mode
            folder.mkdir()
            script.extend([f"/output/probe /output/{mode} {mode}", f"printf 'PASS {mode}\\n'"])
        (out / "run.sh").write_text("\n".join(script) + "\n", encoding="utf-8", newline="\n")
        result = subprocess.run([
            "docker", "run", "--rm", "--pull", "never", "--network", "none", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--mount", f"type=bind,source={ROOT},target=/source,readonly",
            "--mount", f"type=bind,source={out},target=/output",
            "ghcr.io/ylarod/ddk-min:android15-6.6-20260828", "sh", "/output/run.sh",
        ], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)
        for check in checks:
            check["passed"] = f"PASS {check['case']}\n" in result.stdout
        for mode in ("dual", "stopped", "long-status"):
            path = out / mode / "state.json"
            state = json.loads(path.read_text()) if path.exists() else None
            passed = state is not None and state["root"] == 'MapleSU Ultra"\\\n'
            if mode == "long-status" and passed:
                label = (out / mode / "module.prop").read_bytes()
                description = label.split(b"description=", 1)[1].rstrip(b"\n")
                passed = len(description) <= 265 and len(state["rezygiskd"]["64"]["reason"]) == 8191
            checks.append({"case": mode, "passed": passed})
        record = {"deviceAccess": False, "exitCode": result.returncode,
                  "passed": result.returncode == 0 and all(check["passed"] for check in checks),
                  "legacy": bool(args.monitor), "fixtureBytes": len(live),
                  "fixtureSha256": hashlib.sha256(live).hexdigest(),
                  "monitorSha256": hashlib.sha256((out / "port/loader/src/ptracer/monitor.c").read_bytes()).hexdigest(),
                  "checks": checks, "stdout": result.stdout, "stderr": result.stderr}
        if args.save:
            args.save.parent.mkdir(parents=True, exist_ok=True)
            args.save.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(record, ensure_ascii=False, indent=2))
        return 0 if record["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

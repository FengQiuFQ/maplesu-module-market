"""Replay production metadata/status code in shell-owned Android fixtures."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import secrets
import shlex
import subprocess


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--adb", required=True)
    parser.add_argument("--serial", required=True)
    parser.add_argument("--probe", type=Path, required=True)
    parser.add_argument("--legacy-probe", type=Path, required=True)
    parser.add_argument("--captured-prop", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    adb = [args.adb, "-s", args.serial]
    remote = "/data/local/tmp/maplesu-monitor-meta-" + secrets.token_hex(6)
    checks = []

    def run(command, expected=0):
        marker = "\nMONITOR_TEST_EXIT_" + secrets.token_hex(12) + "="
        framed = "( " + command + " ); result=$?; printf " + shlex.quote(marker + "%s\n") + ' "$result"'
        result = subprocess.run([*adb, "exec-out", framed], capture_output=True, timeout=25)
        output, separator, code = result.stdout.rpartition(marker.encode())
        assert result.returncode == 0 and separator and code.strip().isdigit(), "Missing device completion"
        status = int(code.strip())
        if expected is not None:
            assert status == expected, (command, status, result.stderr.decode(errors="replace"))
        return output, status

    def push(path, destination):
        subprocess.run([*adb, "push", str(path), destination], check=True, capture_output=True, timeout=25)

    def check(name, condition):
        checks.append({"name": name, "passed": bool(condition)})
        assert condition, name

    def fixture(content):
        args.output.mkdir(parents=True, exist_ok=True)
        path = args.output / "input.prop"
        path.write_bytes(content)
        run(f"rm -f {remote}/module.prop.tmp {remote}/state.json.tmp; mkdir -p {remote}/payload")
        push(path, remote + "/payload/module.prop")
        push(path, remote + "/module.prop")

    def probe(mode="metadata", binary="probe", expected=0):
        return run(f"{remote}/{binary} {remote} {mode}", expected)

    def read(name):
        return run(f"cat {remote}/{name}")[0]

    report = {"recordedAt": datetime.now(timezone.utc).isoformat(), "serial": args.serial,
              "rootUsed": False, "liveModulesChanged": False, "checks": checks}
    try:
        run(f"mkdir -m 700 {remote}")
        push(args.probe, remote + "/probe")
        push(args.legacy_probe, remote + "/legacy")
        run(f"chmod 700 {remote}/probe {remote}/legacy")
        captured = args.captured_prop.read_bytes()
        fixture(captured)
        output, code = probe(binary="legacy", expected=None)
        report["legacy"] = {"exit": code, "capturedBytes": len(captured),
                            "inputSha256": hashlib.sha256(captured).hexdigest()}
        check("legacy-captured-overflow-reproduced", code == 134)
        fixture(captured)
        probe()
        result = read("module.prop")
        check("captured-prefixes-recovered-64-rounds", result.count(b"[Monitor:") == 1)
        clean = b"id=maplesu_zygisk\nversion=5.1.2\ndescription=Original description\nupdateJson=fixture\n"
        fixture(clean)
        probe()
        check("immutable-payload-and-suffix-retained", read("payload/module.prop") == clean and
              read("module.prop").endswith(b"Original description\nupdateJson=fixture\n"))
        for name, content in (
            ("long-description", b"id=host\ndescription=" + b"x" * 131072 + b"\nafter=kept\n"),
            ("long-prefix", b"before=" + b"x" * 4096 + b"\ndescription=text\nafter=kept\n"),
            ("no-description", b"id=host\nname=kept"),
            ("empty", b""),
            ("no-final-newline", b"id=host\ndescription=text"),
        ):
            fixture(content)
            probe()
            actual = read("module.prop")
            marker = actual.index(b"[Monitor:")
            end = actual.index(b"] ", marker) + 2
            restored = actual[:marker] + actual[end:]
            expected = content if b"description=" in content else content + (b"\n" if content else b"") + b"description=\n"
            check(name, restored == expected and actual.count(b"[Monitor:") == 1)
        for mode in ("running", "stopped", "dual", "long-error", "message"):
            fixture(clean)
            probe(mode)
            if mode != "message":
                state = json.loads(read("state.json"))
                check("json-" + mode, state["root"] == 'MapleSU Ultra"\\\n' and
                      state["rezygiskd"]["64"]["modules"][1] == 'quotes"\\\t\n')
                if mode == "stopped":
                    check("stopped-state", state["monitor"]["state"] == "2")
            else:
                check("explicit-status-message", b"[test message] Original description" in read("module.prop"))
            run(f"test ! -e {remote}/module.prop.tmp && test ! -e {remote}/state.json.tmp")
        for name, bad in (("nul", b"description=bad\x00value"), ("oversize", b"x" * (1024 * 1024 + 1))):
            fixture(bad)
            probe(expected=1)
            check("reject-" + name + "-preserves-original", read("module.prop") == bad)
        fixture(clean)
        run(f"rm {remote}/payload/module.prop")
        probe(expected=1)
        check("missing-payload-preserves-original", read("module.prop") == clean)
        fixture(clean)
        run(f"ln -s /dev/full {remote}/module.prop.tmp")
        probe("message", expected=1)
        check("write-failure-preserves-original", read("module.prop") == clean)
        fixture(clean)
        run(f"mkdir {remote}/module.prop.tmp")
        probe("message", expected=1)
        check("open-failure-preserves-original", read("module.prop") == clean)
        run(f"rmdir {remote}/module.prop.tmp")
        fixture(clean)
        run(f"rm -f {remote}/state.json; mkdir {remote}/state.json")
        probe("running", expected=1)
        check("json-rename-failure-cleans-temporary", run(f"test ! -e {remote}/state.json.tmp")[1] == 0)
        report["passed"] = True
    finally:
        report.setdefault("passed", False)
        (args.output / "regression.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        # The random directory was created by this process and contains no live modules.
        run("rm -rf " + shlex.quote(remote))
    print(json.dumps({"passed": report["passed"], "checks": len(checks), "output": str(args.output)}))


if __name__ == "__main__":
    main()

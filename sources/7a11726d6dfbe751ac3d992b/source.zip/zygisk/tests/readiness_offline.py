"""Exercise production launch/readiness with explicit SDK/monitor/stage fixtures."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
IMAGE = "sha256:272ada1e61c525116032246df2a790d1ccec1804b7a9e0b09203c5e650dcb78e"
CASES = ["slow-success", "explicit-failure", "closed-without-result", "monitor-failure", "deadline-eintr"]
PROBE = r'''
#include "host_policy_fixture.hpp"
#include "host.cpp"
#include <sys/time.h>
extern "C" bool maple_module_policy_allowed() { return true; }
extern "C" void maple_startup_policy_init() { fixture::state->owner_pid = getpid(); }
extern "C" bool maple_startup_policy_snapshot(const char *) { return true; }
extern "C" bool maple_startup_policy_restored() { return false; }
extern "C" bool maple_startup_policy_needed() { return false; }
extern "C" void maple_startup_policy_finish(const char *, bool) {}
extern "C" maple_policy_receipt maple_startup_policy_withdraw(const char *, bool) {
    return {MAPLE_POLICY_DONE, 0};
}
extern "C" int __wrap_execl(const char *path, const char *arg0, ...) {
    va_list args; va_start(args, arg0);
    const char *command = va_arg(args, const char *);
    va_end(args);
    if (std::string(path).ends_with("/bin/maplesu-policy")) _exit(0);
    assert(command);
    if (!strcmp(command, "monitor")) {
        if (fixture::state->stage_code == 3) _exit(9);
        fixture::state->monitor_pid = getpid();
        (void)::write(199, "1", 1); close(199);
        for (;;) pause();
    }
    if (!strcmp(command, "stages")) {
        usleep(fixture::state->stage_delay_ms * 1000);
        fixture::state->stage_finished_ms = maple::millis();
        if (fixture::state->stage_code != 2)
            (void)::write(198, fixture::state->stage_code == 0 ? "1" : "0", 1);
        close(198);
        _exit(fixture::state->stage_code == 0 ? 0 : 9);
    }
    if (!strcmp(command, "ctl")) _exit(0);
    _exit(127);
}
static volatile sig_atomic_t interrupted;
static void alarm_tick(int) { ++interrupted; }
int main(int argc, char **argv) {
    assert(argc == 2);
    fixture::state = static_cast<fixture::State *>(mmap(nullptr, sizeof(fixture::State),
        PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0));
    assert(fixture::state != MAP_FAILED);
    auto &s = *fixture::state;
    s = {}; s.module_policy_mode = 1;
    std::string name(argv[1]);
    if (name == "deadline-eintr") {
        int descriptors[2]; assert(pipe(descriptors) == 0);
        struct sigaction action{}; action.sa_handler = alarm_tick;
        sigemptyset(&action.sa_mask); assert(sigaction(SIGALRM, &action, nullptr) == 0);
        itimerval timer{}; timer.it_value.tv_usec = timer.it_interval.tv_usec = 2000;
        assert(setitimer(ITIMER_REAL, &timer, nullptr) == 0);
        const auto start = maple::millis();
        const bool ready = await_ready(descriptors[0], 40);
        const auto elapsed = maple::millis() - start;
        timer = {}; assert(setitimer(ITIMER_REAL, &timer, nullptr) == 0);
        close(descriptors[0]); close(descriptors[1]);
        assert(!ready && interrupted > 1 && elapsed >= 35 && elapsed < 1000);
        printf("{\"case\":\"%s\",\"passed\":true,\"elapsedMs\":%lld,\"interruptions\":%d}\n",
            name.c_str(), elapsed, static_cast<int>(interrupted));
        return 0;
    }
    s.stage_delay_ms = name == "slow-success" ? 900 : 0;
    s.stage_code = name == "explicit-failure" ? 1 : name == "closed-without-result" ? 2 :
        name == "monitor-failure" ? 3 : 0;
    const auto start = maple::millis();
    const int code = launch("/fixture/host");
    const auto elapsed = maple::millis() - start;
    const bool finished = s.stage_finished_ms != 0;
    const bool failed_monitor = name == "monitor-failure";
    const auto until = maple::millis() + 4000;
    while (!failed_monitor && s.run_state == 0 && maple::millis() < until) usleep(10000);
    const bool host_alive = !failed_monitor && kill(s.owner_pid, 0) == 0 && kill(s.monitor_pid, 0) == 0;
    const bool passed = failed_monitor ? code != 0 :
        code == 0 && host_alive && s.run_state == (name == "slow-success" ? 1 : 2) &&
        (name != "slow-success" || (!finished && elapsed < 850));
    const int observed_state = s.run_state;
    if (s.owner_pid > 1) {
        kill(s.owner_pid, SIGTERM);
        int status = 0;
        if (!maple::wait_child(s.owner_pid, status, 3500)) maple::stop_child(s.owner_pid, status);
    }
    printf("{\"case\":\"%s\",\"passed\":%s,\"launchCode\":%d,\"elapsedMs\":%lld,"
        "\"stageFinishedAtReturn\":%s,\"observedState\":%d,\"residentHostAlive\":%s}\n",
        name.c_str(), passed ? "true" : "false", code, elapsed, finished ? "true" : "false",
        observed_state, host_alive ? "true" : "false");
    return passed ? 0 : 1;
}
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--save", type=Path)
    args = parser.parse_args()
    inputs = ["zygisk/native/host.cpp", "zygisk/native/process.hpp", "zygisk/tests/host_policy_fixture.hpp"]
    before = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in inputs}
    with tempfile.TemporaryDirectory(prefix="maplesu-zygisk-readiness-") as temp:
        out = Path(temp)
        for name in ("host.cpp", "process.hpp"):
            shutil.copyfile(ROOT / "zygisk/native" / name, out / name)
        fixture = (ROOT / inputs[-1]).read_text(encoding="utf-8").replace(
            "    int module_policy_mode;", "    int module_policy_mode;\n"
            "    int owner_pid, monitor_pid, stage_delay_ms, stage_code, run_state;\n"
            "    long long stage_finished_ms;")
        fixture = fixture.replace("throw fixture::BootstrapReached{};", "return 123;")
        fixture = fixture.replace(
            "    if (state == skroot_env::ModuleRunState::Abnormal)",
            "    fixture::state->run_state = static_cast<int>(state);\n"
            "    if (state == skroot_env::ModuleRunState::Abnormal)")
        (out / "host_policy_fixture.hpp").write_text(fixture, encoding="utf-8")
        for name in ("kernel_module_kit_umbrella.h", "bootstrap.h", "tracer_context.h", "webui.hpp",
                     "auth_snapshot.hpp", "startup_policy.h"):
            (out / name).write_text('#include "host_policy_fixture.hpp"\n', encoding="utf-8")
        (out / "module_policy_mode.h").write_text(
            '#pragma once\nextern "C" bool maple_module_policy_allowed();\n', encoding="utf-8")
        (out / "policy_notifications.hpp").write_text('#pragma once\nnamespace maple {\n'
            'inline bool restore_policy_notifications(bool *changed) { *changed=false; return true; }\n'
            'inline bool policy_notifications_consistent(bool *p=nullptr) '
            '{ if(p) *p=false; return true; }\n}\n', encoding="utf-8")
        (out / "sys").mkdir()
        (out / "sys/system_properties.h").write_text('#pragma once\n#define PROP_VALUE_MAX 92\n'
            'inline int __system_property_get(const char *, char *out) { out[0]=0; return 0; }\n', encoding="utf-8")
        (out / "probe.cpp").write_text(PROBE, encoding="utf-8")
        script = ('set -eu\nmkdir -p /data/adb/maplesu_zygisk /fixture/host/bin\n'
            'c++ -std=c++20 -D_GNU_SOURCE -UNDEBUG -Wall -Wextra -Werror '
            '-Wno-unused-function -Wno-attributes -Wno-volatile '
            '-I/output /output/probe.cpp -Wl,--wrap=execl -o /output/probe\n' +
            ''.join(f'/output/probe {case}\n' for case in CASES))
        run = subprocess.run(["docker", "run", "--rm", "--pull", "never", "--network", "none",
            "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--mount",
            f"type=bind,source={ROOT},target=/source,readonly", "--mount",
            f"type=bind,source={out},target=/output", IMAGE, "sh", "-c", script],
            capture_output=True, text=True, timeout=60)
    checks = [json.loads(line) for line in run.stdout.splitlines() if line.startswith("{")]
    record = {"sourceSha256": before, "sourceInputsStable": before == {
        name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in inputs},
        "actualHostCallsite": True, "deviceAccess": False,
        "simulatedBoundaries": ["SDK", "policy", "monitor", "stages"],
        "exitCode": run.returncode, "checks": checks, "stderr": run.stderr}
    record["passed"] = run.returncode == 0 and len(checks) == len(CASES) and all(x["passed"] for x in checks)
    if args.save:
        args.save.parent.mkdir(parents=True, exist_ok=True)
        args.save.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record, indent=2))
    assert record["passed"] and record["sourceInputsStable"]


if __name__ == "__main__":
    main()

"""Rebuild the embedded corresponding source, with only the documented external SDK."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--save", type=Path, required=True)
    args = parser.parse_args()
    artifact = args.package.name
    original = args.package.read_bytes()
    with zipfile.ZipFile(io.BytesIO(original)) as package:
        source = package.read("webroot/source.zip")
    build_root = (ROOT / "zygisk/build").resolve()
    with tempfile.TemporaryDirectory(prefix="source-rebuild-", dir=build_root) as temporary:
        target = Path(temporary).resolve()
        assert target.parent == build_root
        with zipfile.ZipFile(io.BytesIO(source)) as archive:
            for name in archive.namelist():
                assert (target / name).resolve().is_relative_to(target), name
            archive.extractall(target)
        # No credentials, app build, signing material or device state are copied.
        for folder in ("include", "lib/arm64-v8a"):
            shutil.copytree(ROOT / "runtime/upstream-pro" / folder,
                            target / "runtime/upstream-pro" / folder)
        shutil.copyfile(ROOT / "runtime/upstream-pro/SDK-RELEASE.json",
                        target / "runtime/upstream-pro/SDK-RELEASE.json")
        result = subprocess.run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
                                 str(target / "zygisk/build.ps1"), "-Python", sys.executable],
                                capture_output=True, text=True)
        (ROOT / "zygisk/build/source-rebuild.log").write_text(result.stdout + result.stderr, encoding="utf-8")
        if result.returncode:
            raise RuntimeError("Corresponding source rebuild failed; see zygisk/build/source-rebuild.log")
        rebuilt = (target / "dist-release" / artifact).read_bytes()
        with zipfile.ZipFile(io.BytesIO(original)) as before, zipfile.ZipFile(io.BytesIO(rebuilt)) as after:
            differing = [name for name in before.namelist() if before.read(name) != after.read(name)]
            if differing:
                args.save.with_name("source-rebuilt-host.so").write_bytes(after.read("libmodule_maplesu_zygisk.so"))
                args.save.with_name("source-rebuilt-identity.json").write_bytes(after.read("BUILD-IDENTITY.json"))
        evidence = {"passed": original == rebuilt, "differingEntries": differing,
                    "archiveSha256": hashlib.sha256(original).hexdigest(),
                    "rebuiltSha256": hashlib.sha256(rebuilt).hexdigest(),
                    "externalDependency": "existing Ultra SDK headers and ARM64 static library only"}
        output = args.save
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(evidence, indent=2), encoding="utf-8")
        assert original == rebuilt, evidence
        print("CORRESPONDING_SOURCE_REBUILD_OK BYTE_IDENTICAL_ARCHIVE")


if __name__ == "__main__":
    main()

#!/system/bin/sh
# MapleSU module stage script launcher.
#
# Executed as: <runner> <directory> <stage> [early-deadline-ms] [common-script-name]
# The runner then execs `<module-dir>/<stage>.sh` the way the pinned KSU userspace
# does, instead of sourcing it:
#
#   module.rs:343-344   Command::new(BUSYBOX_PATH).arg("sh").arg(<script path>)
#   module.rs:340       current_dir = script.parent()
#   module.rs:344       envs = get_common_script_envs(module_id)
#
# Why this file exists rather than `sh <script>` directly: it reproduces the exact
# upstream script contract that module installers depend on -
#
#   * `$0` is the script's own absolute path, so `MODDIR=${0%/*}` resolves to the
#     module directory. Sourcing the script instead (the previous behaviour) made
#     `$0` the runner, which silently broke every module that derives MODDIR that way.
#   * cwd is the module directory.
#   * PATH is the caller's PATH with the MapleSU tool directory appended, matching
#     `format!("{}:{}", env_var("PATH"), BINARY_DIR)` - appended, not prepended.
#
# Lifecycle scripts receive the same KSU compatibility environment as installers.
set -u

module_dir="${1:-}"
stage="${2:-}"
if [ -z "$module_dir" ] || [ -z "$stage" ]; then
  printf 'maplesu-module-runner: usage: run.sh <module-dir> <stage>\n' >&2
  exit 64
fi

common_script="${4:-}"
case "$common_script" in */*|.|..) exit 64 ;; esac
script="$module_dir/${common_script:-$stage.sh}"
if [ ! -f "$script" ] && [ "$stage" != uninstall ]; then
  printf 'maplesu-module-runner: no %s.sh in %s\n' "$stage" "$module_dir" >&2
  exit 66
fi

# MapleSU tool directory, appended so a module cannot shadow platform tools.
MAPLESU_BIN=${MAPLESU_BIN:-/data/adb/maplesu/bin}
export PATH="${PATH:-/system/bin:/system/xbin}:$MAPLESU_BIN"
# Existing installations may reach a hook before the upgraded APK republishes its
# tools. Bootstrap only the missing helper, including in the early host path.
if [ ! -x "$MAPLESU_BIN/ui_print" ] && [ -x "$MAPLESU_BIN/busybox" ]; then
  ui_print_tmp=$("$MAPLESU_BIN/busybox" mktemp "$MAPLESU_BIN/.ui_print.XXXXXX") || exit 73
  cat > "$ui_print_tmp" <<'MAPLESU_UI_PRINT'
#!/system/bin/sh
printf '%s\n' "$*"
MAPLESU_UI_PRINT
  chmod 0755 "$ui_print_tmp" && mv -f "$ui_print_tmp" "$MAPLESU_BIN/ui_print" || exit 73
fi
if [ "$stage" = metamount ]; then
  export MODULE_DIR=/data/adb/modules
  # Metamodule mounts must be visible from init and newly started applications.
  if [ "$(readlink /proc/self/ns/mnt)" != "$(readlink /proc/1/ns/mnt)" ]; then
    exec "$MAPLESU_BIN/busybox" nsenter -t 1 -m -- /system/bin/sh "$0" "$@"
  fi
fi

# KSU exports this for every script it runs (module.rs:63-88); BusyBox ash reads it
# to run in standalone mode instead of expecting an applet-symlink layout.
export ASH_STANDALONE=1

# Compatibility variables select the module contract implemented by this backend.
export MAPLESU=true
export MAPLESU_BACKEND=module_v1
export KSU=true KSU_VER=MapleSU KSU_VER_CODE=12000 KSU_KERNEL_VER_CODE=12000 KSU_UAPI_VER=1
export MAPLESU_STAGE="$stage"
export BOOTMODE=true
# Module id is derivable from the path exactly like KSU does it, and is only
# exported when it is a plain single path segment.
module_id="${module_dir##*/}"
case "$module_id" in
  ''|*/*|.|..) ;;
  *) export MAPLESU_MODULE="$module_id" KSU_MODULE="$module_id" ;;
esac
if [ -n "$common_script" ]; then
  # KSU common scripts share the shell environment, but belong to no module.
  unset MAPLESU_MODULE KSU_MODULE
fi

# Platform facts, read rather than assumed.
export API="$(/system/bin/getprop ro.build.version.sdk 2>/dev/null)"
export ARCH=arm64
export IS64BIT=true

cd "$module_dir" || exit 70

# Match KSU switch_cgroups: a module daemon must outlive its launching app.
for group in /acct /dev/cg2_bpf /sys/fs/cgroup; do
  if [ -f "$group/cgroup.procs" ]; then
    { printf '%s' "$$" >> "$group/cgroup.procs"; } 2>/dev/null || :
  fi
done
if [ "$(/system/bin/getprop ro.config.per_app_memcg 2>/dev/null)" != false ] &&
    [ -f /dev/memcg/apps/cgroup.procs ]; then
  { printf '%s' "$$" >> /dev/memcg/apps/cgroup.procs; } 2>/dev/null || :
fi

# Only the early boot stages wait, sharing KSU's absolute 35 second deadline.
# Their timeout stops waiting, never the script. Late stages acknowledge launch
# after setsid, close their stdio, and run independently of the Root IPC owner.
run_boot_script() {
  [ -x "$MAPLESU_BIN/busybox" ] || return 69
  wait_ms=0
  case "$stage" in
    post-fs-data|post-mount)
      now_ms=$("$MAPLESU_BIN/busybox" awk '{printf "%.0f", $1 * 1000}' /proc/uptime)
      deadline_ms=${1:-$((now_ms + 35000))}
      case "$deadline_ms" in ''|*[!0-9]*) return 64 ;; esac
      wait_ms=$((deadline_ms - now_ms))
      [ "$wait_ms" -gt 0 ] || wait_ms=0
      ;;
  esac
  start_detached() {
    "$MAPLESU_BIN/busybox" setsid "$MAPLESU_BIN/busybox" sh -c '
      exec 3>&1 1>/dev/null 2>&1
      printf "MAPLESU_BOOT_READY\n" >&3 || exit 74
      wait_ms=$1; shift
      if [ "$wait_ms" = 0 ]; then exec "$0" sh "$@" 3>&-; fi
      "$0" sh "$@" 3>&-
      code=$?
      # A deadline may already have closed the reader. The script has finished;
      # a broken result pipe must not affect it or any daemon it started.
      printf "MAPLESU_BOOT_EXIT:%s\n" "$code" >&3 2>/dev/null || :
    ' "$MAPLESU_BIN/busybox" "$wait_ms" "$script" </dev/null 2>/dev/null &
  }
  if [ "$wait_ms" = 0 ]; then
    result=$(start_detached | "$MAPLESU_BIN/busybox" head -n 1)
    reader_code=$?
  else
    wait_seconds=$(printf '%d.%03d' "$((wait_ms / 1000))" "$((wait_ms % 1000))")
    # ash reports a normally timed-out reader as "Terminated"; keep that internal.
    result=$(start_detached | "$MAPLESU_BIN/busybox" timeout "$wait_seconds" "$MAPLESU_BIN/busybox" cat) 2>/dev/null
    reader_code=$?
  fi
  case "$result" in
    "$(printf 'MAPLESU_BOOT_READY\nMAPLESU_BOOT_EXIT:')"*)
      code=${result##*MAPLESU_BOOT_EXIT:}
      case "$code" in ''|*[!0-9]*) return 70 ;; esac
      return "$code"
      ;;
    MAPLESU_BOOT_READY)
      # NoWait, or Until with a script still running at the shared deadline.
      if [ "$wait_ms" = 0 ] || [ "$reader_code" = 143 ] || [ "$reader_code" = 124 ]; then
        printf 'MAPLESU_SCRIPT_STARTED\n'
        return 0
      fi
      ;;
  esac
  printf 'maplesu-module-runner: background launch was not acknowledged\n' >&2
  return 70
}

# exec, not source: the script keeps its own $0, its own `set -e`, its own traps and
# its own exit status, all of which sourcing would have taken over.
# Standalone BusyBox supplies the module shell/applications used by KSU, including
# unshare --propagation (Android toybox unshare does not implement that option).
run_script() {
  # Match the module shell contract, not the SDK owner's private umask.
  case "$stage" in
    post-fs-data|post-mount|service|boot-completed|metamount|uninstall) umask 000 ;;
    *) umask 022 ;;
  esac
  # The early dispatcher opts in only the compatible LSPosed revision/boot.
  if [ "$module_id" = zygisk_lsposed ] && { [ "$stage" = service ] || [ "$stage" = post-fs-data ]; }; then
    state=/data/adb/maplesu_zygisk/shared-context
    context_boot=; context_device=; context_inode=; context_library=
    if [ -r "$state" ]; then read -r context_boot context_device context_inode context_library < "$state" || :; fi
    if [ -n "$context_library" ] && [ "$context_boot" = "$(cat /proc/sys/kernel/random/boot_id)" ] &&
        [ "$context_device $context_inode" = "$(stat -Lc '%d %i' "$module_dir")" ] && [ -r "$context_library" ]; then
      export MAPLESU_LSP_PRELOAD="${LD_PRELOAD:-}"
      export LD_PRELOAD="$context_library${LD_PRELOAD:+:$LD_PRELOAD}"
    fi
  fi
  if [ "$stage" = uninstall ]; then
    meta=/data/adb/metamodule
    is_meta=$(sed -n 's/^metamodule=//p' "$module_dir/module.prop" | tail -n1 | tr -d '[:space:]' | tr '[:upper:]' '[:lower:]')
    case "$is_meta" in
      1|true) ;;
      *)
        if [ -f "$meta/metauninstall.sh" ] && [ ! -e "$meta/disable" ]; then
          (
            export MODULE_ID="$module_id"
            KSU_MODULE=$(sed -n 's/^id=//p' "$meta/module.prop" | tail -n1 | tr -d '[:space:]')
            export KSU_MODULE
            cd "$meta" || exit 70
            if [ -x "$MAPLESU_BIN/busybox" ]; then
              exec "$MAPLESU_BIN/busybox" sh "$meta/metauninstall.sh"
            fi
            exec /system/bin/sh "$meta/metauninstall.sh"
          ) || return $?
        fi
        ;;
    esac
    [ -f "$script" ] || return 0
  fi
  case "$stage" in
    post-fs-data|post-mount|service|boot-completed) run_boot_script "${early_deadline:-}"; return $? ;;
  esac
  if [ -x "$MAPLESU_BIN/busybox" ]; then
    exec "$MAPLESU_BIN/busybox" sh "$script"
  fi
  exec /system/bin/sh "$script"
}

early_deadline=${3:-}

# The Ultra host dispatches Zygisk framework daemons before Zygote starts. Share
# the boot receipt with the later Manager stages so scripts run once per revision.
# A previous boot's host marker never changes the Normal backend's behavior.
case "$stage" in
  post-fs-data|post-mount|service|boot-completed)
    boot="$(cat /proc/sys/kernel/random/boot_id)"
    early="$(cat /data/adb/maplesu_zygisk/early.boot 2>/dev/null)"
    if [ -d "$module_dir/zygisk" ] && [ "$early" = "$boot" ] && [ -x "$MAPLESU_BIN/busybox" ]; then
      receipts="/data/adb/maplesu/module-boot/$(stat -Lc '%d-%i' "$module_dir")"
      mkdir -p "$receipts" || exit 73
      (
        "$MAPLESU_BIN/busybox" flock -n 9 || {
          # Another owner is still handling this exact revision/stage. Preserve
          # its in-progress state; no completed receipt has been observed.
          printf 'MAPLESU_SCRIPT_STARTED\n'
          exit 0
        }
        saved_boot=; saved_code=; saved_state=
        if [ -f "$receipts/$stage" ]; then read -r saved_boot saved_code saved_state < "$receipts/$stage" || :; fi
        if [ "$saved_boot" = "$boot" ] && [ -n "$saved_code" ]; then
          if [ "$saved_state" = started ]; then printf 'MAPLESU_SCRIPT_STARTED\n'; fi
          exit "$saved_code"
        fi
        # Keep the lock in the wrapper only. Native background daemons inherit
        # neither this FD nor the host's readiness pipe.
        output=$( (run_script) 9>&- )
        code=$?
        [ -z "$output" ] || printf '%s\n' "$output"
        saved_state=ok
        if [ "$output" = MAPLESU_SCRIPT_STARTED ]; then saved_state=started; fi
        printf '%s %s %s\n' "$boot" "$code" "$saved_state" > "$receipts/$stage.tmp"
        mv -f "$receipts/$stage.tmp" "$receipts/$stage"
        exit "$code"
      ) 9> "$receipts/$stage.lock"
      exit $?
    fi ;;
esac
run_script

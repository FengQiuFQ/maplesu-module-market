// Shared by the policy loader and early module dispatcher; only data labels.
#pragma once
#include <stdio.h>
#include <string.h>
#ifndef MAPLE_SHARED_CONTEXT_STATE
#define MAPLE_SHARED_CONTEXT_STATE "/data/adb/maplesu_zygisk/shared-context"
#endif
// 1: redundant LSPosed shared-file rule, 0: unrelated, -1: unknown contract.
static inline int maple_shared_file_rule(const char *line) {
    char text[4096], normalized[4096] = {0};
    if (strlen(line) >= sizeof(text)) return -1;
    strcpy(text, line);
    char *comment = strchr(text, '#');
    if (comment) *comment = 0;
    char *save = NULL;
    size_t used = 0;
    int relevant = 0;
    for (char *word = strtok_r(text, " \t\r\n{}:;", &save); word;
         word = strtok_r(NULL, " \t\r\n{}:;", &save)) {
        relevant |= strcmp(word, "lsposed_file") == 0;
        used += snprintf(normalized + used, sizeof(normalized) - used, "%s%s", used ? " " : "", word);
    }
    if (!relevant) return 0;
    const char *known[] = {"type lsposed_file file_type", "typeattribute lsposed_file mlstrustedobject",
        "allow domain lsposed_file dir *", "allow domain lsposed_file file *"};
    for (size_t i = 0; i < sizeof(known)/sizeof(*known); ++i)
        if (!strcmp(normalized, known[i])) return 1;
    return -1;
}

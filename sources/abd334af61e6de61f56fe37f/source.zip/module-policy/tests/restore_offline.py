"""Exercise real policy restore in an offline container without touching SELinux."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--save", type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="maplesu-policy-restore-") as temporary:
        commands = [
            "mkdir /output/build; cd /output/build; "
            "cc -D_GNU_SOURCE -DHAVE_REALLOCARRAY -Wno-unused-result -I/source/.research/maplesu-policy-selinux/libsepol/include "
            "-I/source/.research/maplesu-policy-selinux/libsepol/src "
            "-c /source/.research/maplesu-policy-selinux/libsepol/src/*.c && ar rcs libsepol.a *.o",
            "c++ -std=c++17 -D_GNU_SOURCE -UNDEBUG -Wall -Wextra -Werror "
            "-Wno-calloc-transposed-args -Wno-unused-function "
            "-fsanitize=address,undefined -fno-omit-frame-pointer "
            "-I/source/module-policy/derived -I/source/module-policy/src "
            "-I/source/.research/maplesu-policy-selinux/libsepol/include "
            "/source/module-policy/tests/restore_tests.cpp /source/module-policy/derived/sepolicy.cpp "
            "/output/build/libsepol.a -Wl,--wrap=open -Wl,--wrap=write -Wl,--wrap=close -o /output/probe",
            "c++ -std=c++17 -D_GNU_SOURCE -UNDEBUG -Wall -Wextra -Werror "
            "-Wno-calloc-transposed-args -Wno-unused-function "
            "-I/source/module-policy/derived -I/source/module-policy/src "
            "-I/source/.research/maplesu-policy-selinux/libsepol/include "
            "/source/module-policy/tests/policy_tests.cpp /source/module-policy/derived/sepolicy.cpp "
            "/output/build/libsepol.a -o /output/policy-tests",
            "/output/probe /source/evidence/zygisk-startup-window-20261106/product-v5-policy/actual-policy.bin /output/fixture",
            "mkdir /output/original-tests && /output/policy-tests "
            "/source/evidence/zygisk-startup-window-20261106/product-v5-policy/actual-policy.bin /output/original-tests",
        ]
        result = subprocess.run([
            "docker", "run", "--rm", "--pull", "never", "--network", "none", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--mount", f"type=bind,source={ROOT},target=/source,readonly",
            "--mount", f"type=bind,source={temporary},target=/output",
            "ghcr.io/ylarod/ddk-min:android15-6.6-20260828", "sh", "-c", " && ".join(commands),
        ], capture_output=True, text=True, timeout=180)
        receipt = {"deviceAccess": False, "exitCode": result.returncode,
                   "sanitizers": {"restore": ["ASan", "UBSan"], "originalSuite": []},
                   "sourceSha256": hashlib.sha256((ROOT / "module-policy/src/main.cpp").read_bytes()).hexdigest(),
                   "stdout": result.stdout, "stderr": result.stderr}
        if args.save:
            args.save.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(receipt, indent=2))
        assert result.returncode == 0


if __name__ == "__main__":
    main()

// Real parser/serializer/transaction tests; selinuxfs writes target fixture files only.
#define main policy_cli_main
#include "../src/main.cpp"
#undef main
#include <cassert>
#include <cstdarg>

static std::string fixture_root;
static int load_fd = -1, loads;
static bool fail_load, changed_readback;
extern "C" int __real_open(const char *, int, ...);
extern "C" ssize_t __real_write(int, const void *, size_t);
extern "C" int __real_close(int);
extern "C" int __wrap_close(int fd) {
    if (fd == load_fd) load_fd = -1;
    return __real_close(fd);
}
extern "C" int __wrap_open(const char *name, int flags, ...) {
    mode_t mode = 0;
    if (flags & O_CREAT) {
        va_list args; va_start(args, flags); mode = va_arg(args, int); va_end(args);
    }
    std::string path(name);
    if (path == LIVE) path = fixture_root + "/live";
    else if (path == LOAD) path = fixture_root + "/load";
    else if (path == ENFORCE) path = fixture_root + "/enforce";
    else if (path == "/data/adb/maplesu-policy.lock") path = fixture_root + "/lock";
    int fd = __real_open(path.c_str(), flags, mode);
    if (!strcmp(name, LOAD)) load_fd = fd;
    return fd;
}
extern "C" ssize_t __wrap_write(int fd, const void *data, size_t size) {
    if (fd != load_fd) return __real_write(fd, data, size);
    ++loads;
    if (fail_load) { errno = EIO; return -1; }
    auto bytes = std::vector<char>(static_cast<const char *>(data), static_cast<const char *>(data) + size);
    if (changed_readback) {
        auto policy = decode(bytes);
        apply_rule(*policy, {"fixture", "allow system_server system_server process execmem", 1});
        bytes = encode(*policy);
    }
    int live = __real_open((fixture_root + "/live").c_str(), O_WRONLY | O_TRUNC | O_CLOEXEC);
    assert(live >= 0 && __real_write(live, bytes.data(), bytes.size()) == static_cast<ssize_t>(bytes.size()));
    close(live);
    return __real_write(fd, data, size);
}
static int command(std::initializer_list<const char *> args) {
    std::vector<char *> argv;
    for (const char *arg : args) argv.push_back(const_cast<char *>(arg));
    return policy_cli_main(argv.size(), argv.data());
}
int main(int argc, char **argv) {
    setbuf(stdout, nullptr);
    assert(argc == 3);
    fixture_root = argv[2];
    assert(mkdir(fixture_root.c_str(), 0700) == 0);
    auto bytes = read_file(argv[1]);
    auto baseline = decode(bytes);
    apply_rule(*baseline, {"fixture", "deny system_server system_server process execmem", 1});
    auto clean = encode(*baseline);
    std::string backup = fixture_root + "/backup";
    save(backup, clean);
    apply_rule(*baseline, {"fixture", "allow system_server system_server process execmem", 1});
    apply_rule(*baseline, {"fixture", "permissive system_server", 2});
    auto modified = encode(*baseline);
    save(fixture_root + "/live", modified);
    save(fixture_root + "/enforce", {'1', '\n'});
    save(fixture_root + "/load", {});
    int result = command({"maplesu-policy", "restore", "--policy", backup.c_str()});
    auto restored_bytes = read_file(fixture_root + "/live");
    auto restored = decode(restored_bytes), expected = decode(clean);
    if (result != 0 || loads != 1 || !policy_equivalent(*expected, *restored)) {
        puts("FAIL: full restore did not load and verify the saved pre-host policy");
        return 1;
    }
    puts("PASS: restore removes real fixture changes and verifies the complete policy image");
    assert(command({"maplesu-policy", "restore"}) != 0 && loads == 1);
    assert(command({"maplesu-policy", "restore", "--policy", backup.c_str(), "--rules", backup.c_str()}) != 0 && loads == 1);
    puts("PASS: restore rejects a missing backup and extra rule mutation");
    save(backup, {'b', 'a', 'd'});
    assert(command({"maplesu-policy", "restore", "--policy", backup.c_str()}) != 0 && loads == 1);
    save(backup, clean);
    assert(command({"maplesu-policy", "restore", "--policy", "/missing-backup"}) != 0 && loads == 1);
    assert(command({"maplesu-policy", "restore", "--policy", backup.c_str(), "--output", backup.c_str()}) != 0 && loads == 1);
    puts("PASS: invalid or missing backup never reaches the load node");
    {
        Fd held(open("/data/adb/maplesu-policy.lock", O_RDWR | O_CLOEXEC));
        assert(held.value >= 0 && flock(held.value, LOCK_EX | LOCK_NB) == 0);
        assert(command({"maplesu-policy", "restore", "--policy", backup.c_str()}) == 75 && loads == 1);
    }
    puts("PASS: an overlapping policy transaction returns busy without a write");
    fail_load = true;
    assert(command({"maplesu-policy", "restore", "--policy", backup.c_str()}) != 0 && loads == 2);
    fail_load = false;
    changed_readback = true;
    assert(command({"maplesu-policy", "restore", "--policy", backup.c_str()}) == 3 && loads == 3);
    puts("PASS: write failure and mismatched readback never report successful restore");
    assert(read_file(fixture_root + "/enforce")[0] == '1');
    puts("PASS: enforcing state stays unchanged");
}

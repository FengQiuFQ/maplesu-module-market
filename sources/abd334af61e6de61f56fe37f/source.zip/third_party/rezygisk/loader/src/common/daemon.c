#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include <linux/un.h>
#include <sys/socket.h>
#include <errno.h>
#include <poll.h>
#include <stdint.h>
#include <time.h>
#ifndef MAPLE_SERVER_PREPARE_TIMEOUT_MS
#define MAPLE_SERVER_PREPARE_TIMEOUT_MS 6000
#endif

#include "logging.h"
#include "misc.h"
#include "socket_utils.h"

#include "daemon.h"

#define SOCKET_FILE_NAME LP_SELECT("cp32", "cp64") ".sock"

static int rezygiskd_connect(uint8_t retry) {
  struct sockaddr_un addr = {
    .sun_family = AF_UNIX,
    .sun_path = { 0 }
  };
  /*
    INFO: Application must assume that sun_path can hold _POSIX_PATH_MAX characters.

    Sources:
     - https://pubs.opengroup.org/onlinepubs/009696699/basedefs/sys/un.h.html
  */
  strcpy(addr.sun_path, "/data/misc/maplesu_zygisk/" SOCKET_FILE_NAME);

  retry++;
  while (--retry) {
    int fd = socket(PF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (fd == -1) {
      PLOGE("socket");

      return -1;
    }

    int ret = connect(fd, (struct sockaddr *)&addr, sizeof(addr));
    if (ret == -1) {
      PLOGE("connect (retry: %d)", retry);

      close(fd);

      if (retry == 1) return -1;

      sleep(1);

      /* INFO: Try again with a new socket; fd is closed here. */
      continue;
    }

    return fd;
  }

  return -1;
}

/* TODO: We should unify all of those */
#define safe_write(fn, name, ret_type)             \
  if (fn == -1) {                                  \
    LOGE("Failed to write " name " to ReZygiskd"); \
                                                   \
    close(fd);                                     \
                                                   \
    ret_type;                                      \
  }

#define safe_read(fn, name, ret_type)               \
  if (fn == -1) {                                   \
    LOGE("Failed to read " name " from ReZygiskd"); \
                                                    \
    close(fd);                                      \
                                                    \
    ret_type;                                       \
  }

bool rezygiskd_prepare_system_server(void) {
  // Generic read/write helpers retry EAGAIN indefinitely. This pre-fork RPC
  // needs one total deadline, including signals and a saturated listen queue.
  int fd = socket(PF_UNIX, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
  if (fd < 0) return false;
  struct timespec now;
  clock_gettime(CLOCK_MONOTONIC, &now);
  int64_t deadline = now.tv_sec * 1000LL + now.tv_nsec / 1000000 + MAPLE_SERVER_PREPARE_TIMEOUT_MS;
  struct sockaddr_un addr = {
    .sun_family = AF_UNIX,
    .sun_path = "/data/misc/maplesu_zygisk/" SOCKET_FILE_NAME
  };
  if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) { close(fd); return false; }
  bool sent = false, ok = false;
  uint8_t action = (uint8_t)PrepareSystemServer, ready = 0;
  for (;;) {
    clock_gettime(CLOCK_MONOTONIC, &now);
    int64_t remaining = deadline - (now.tv_sec * 1000LL + now.tv_nsec / 1000000);
    if (remaining <= 0) break;
    struct pollfd event = { .fd = fd, .events = sent ? POLLIN : POLLOUT };
    int result = poll(&event, 1, (int)remaining);
    if (result < 0 && errno == EINTR) continue;
    if (result <= 0) break;
    ssize_t size = sent ? recv(fd, &ready, 1, 0) : send(fd, &action, 1, MSG_NOSIGNAL);
    if (size == 1) {
      if (sent) { ok = ready == 1; break; }
      sent = true;
    } else if (size >= 0 || (errno != EAGAIN && errno != EINTR)) break;
  }
  close(fd);
  return ok;
}

bool rezygiskd_zygote_injected() {
  int fd = rezygiskd_connect(5);
  if (fd == -1) return false;

  safe_write(write_uint8_t(fd, (uint8_t)ZygoteInjected), "ZygoteInjected action", return false);

  close(fd);

  return true;
}

uint32_t rezygiskd_get_process_flags(uid_t uid, const char *const process) {
  int fd = rezygiskd_connect(1);
  if (fd == -1) return 0;

  safe_write(write_uint8_t(fd, (uint8_t)GetProcessFlags), "GetProcessFlags action", return 0);
  safe_write(write_uint32_t(fd, (uint32_t)uid), "uid", return 0);
  safe_write(write_string(fd, process), "process name", return 0);

  uint32_t res = 0;
  safe_read(read_uint32_t(fd, &res), "process flags", return 0);

  close(fd);

  return res;
}

void rezygiskd_get_info(struct rezygisk_info *info) {
  int fd = rezygiskd_connect(1);
  if (fd == -1) {
    info->running = false;

    return;
  }

  info->running = true;

  safe_write(write_uint8_t(fd, (uint8_t)GetInfo), "GetInfo action", return);

  uint32_t flags = 0;
  safe_read(read_uint32_t(fd, &flags), "info flags", return);

  if (flags & (1 << 26)) info->root_impl = ROOT_IMPL_MAPLESU;
  else if (flags & (1 << 28)) info->root_impl = ROOT_IMPL_APATCH;
  else if (flags & (1 << 29)) info->root_impl = ROOT_IMPL_KERNELSU;
  else if (flags & (1 << 30)) info->root_impl = ROOT_IMPL_MAGISK;
  else info->root_impl = ROOT_IMPL_NONE;

  safe_read(read_uint32_t(fd, (uint32_t *)&info->pid), "pid", return);

  safe_read(read_size_t(fd, &info->modules.modules_count), "modules count", return);
  if (info->modules.modules_count == 0) {
    info->modules.modules = NULL;

    close(fd);

    return;
  }

  info->modules.modules = (char **)malloc(sizeof(char *) * info->modules.modules_count);
  if (!info->modules.modules) {
    PLOGE("allocating modules name memory");

    info->modules.modules_count = 0;

    close(fd);

    return;
  }

  for (size_t i = 0; i < info->modules.modules_count; i++) {
    char *module_name = read_string(fd);
    if (module_name == NULL) {
      PLOGE("reading module name");

      goto info_cleanup;
    }

    char module_path[PATH_MAX];
    snprintf(module_path, sizeof(module_path), "/data/adb/modules/%s/module.prop", module_name);

    free(module_name);

    FILE *module_prop = fopen(module_path, "r");
    if (!module_prop) {
      PLOGE("failed to open module prop file %s", module_path);

      goto info_cleanup;
    }

    info->modules.modules[i] = NULL;

    char line[1024];
    while (fgets(line, sizeof(line), module_prop) != NULL) {
      if (strncmp(line, "name=", strlen("name=")) != 0) continue;

      size_t name_len = strlen(line + strlen("name="));
      if (name_len == 0 || line[name_len + strlen("name=") - 1] != '\n') {
        LOGE("Invalid module name in %s", module_path);

        fclose(module_prop);

        goto info_cleanup;
      }

      info->modules.modules[i] = strndup(line + strlen("name="), name_len - 1);
      if (info->modules.modules[i] == NULL) {
        PLOGE("allocate memory for module name from %s", module_path);

        fclose(module_prop);

        goto info_cleanup;
      }

      break;
    }

    if (info->modules.modules[i] == NULL) {
      PLOGE("failed to read module name from %s", module_path);

      fclose(module_prop);

      goto info_cleanup;
    }

    fclose(module_prop);

    continue;

    info_cleanup:
      info->modules.modules_count = i;
      free_rezygisk_info(info);

      break;
  }

  close(fd);
}

void free_rezygisk_info(struct rezygisk_info *info) {
  for (size_t i = 0; i < info->modules.modules_count; i++) {
    free(info->modules.modules[i]);
  }

  free(info->modules.modules);
  info->modules.modules = NULL;
  info->modules.modules_count = 0;
}

bool rezygiskd_read_modules(struct zygisk_modules *modules) {
  int fd = rezygiskd_connect(1);
  if (fd == -1) return false;

  safe_write(write_uint8_t(fd, (uint8_t)ReadModules), "ReadModules action", return false);

  size_t len = 0;
  safe_read(read_size_t(fd, &len), "modules count", return false);

  modules->modules = malloc(len * sizeof(char *));
  if (!modules->modules) {
    PLOGE("allocating modules name memory");

    close(fd);

    return false;
  }
  modules->modules_count = len;

  for (size_t i = 0; i < len; i++) {
    char *lib_path = read_string(fd);
    if (!lib_path) {
      PLOGE("reading module lib_path");

      modules->modules_count = i;
      free_modules(modules);

      close(fd);

      return false;
    }

    modules->modules[i] = lib_path;
  }

  close(fd);

  return true;
}

void free_modules(struct zygisk_modules *modules) {
  for (size_t i = 0; i < modules->modules_count; i++) {
    free(modules->modules[i]);
  }

  free(modules->modules);
  modules->modules = NULL;
  modules->modules_count = 0;
}

int rezygiskd_connect_companion(size_t index) {
  int fd = rezygiskd_connect(1);
  if (fd == -1) return -1;

  safe_write(write_uint8_t(fd, (uint8_t)RequestCompanionSocket), "RequestCompanionSocket action", return -1);
  safe_write(write_size_t(fd, index), "companion index", return -1);

  uint8_t res = 0;
  safe_read(read_uint8_t(fd, &res), "companion socket result", return -1);

  if (res == 1) return fd;
  else {
    close(fd);

    return -1;
  }
}

int rezygiskd_get_module_dir(size_t index) {
  int fd = rezygiskd_connect(1);
  if (fd == -1) return -1;

  safe_write(write_uint8_t(fd, (uint8_t)GetModuleDir), "GetModuleDir action", return -1);
  safe_write(write_size_t(fd, index), "module index", return -1);

  int dirfd = read_fd(fd);

  close(fd);

  return dirfd;
}

void rezygiskd_zygote_restart() {
  int fd = rezygiskd_connect(1);
  if (fd == -1) return;

  safe_write(write_uint8_t(fd, (uint8_t)ZygoteRestart), "ZygoteRestart action", return);

  close(fd);
}

bool rezygiskd_update_mns(enum mount_namespace_state nms_state, char *buf, size_t buf_size) {
  int fd = rezygiskd_connect(1);
  if (fd == -1) return false;

  safe_write(write_uint8_t(fd, (uint8_t)UpdateMountNamespace), "UpdateMountNamespace action", return false);
  safe_write(write_uint32_t(fd, (uint32_t)getpid()), "pid", return false);
  safe_write(write_uint8_t(fd, (uint8_t)nms_state), "mount namespace state", return false);

  uint32_t target_pid = 0;
  safe_read(read_uint32_t(fd, &target_pid), "target pid", return false);

  uint32_t target_fd = 0;
  safe_read(read_uint32_t(fd, &target_fd), "target fd", return false);

  if (target_fd == 0) {
    LOGE("Failed to get target fd");

    close(fd);

    return false;
  }

  snprintf(buf, buf_size, "/proc/%u/fd/%u", target_pid, target_fd);

  close(fd);

  return true;
}

bool rezygiskd_remove_module(size_t index) {
  int fd = rezygiskd_connect(1);
  if (fd == -1) return false;

  safe_write(write_uint8_t(fd, (uint8_t)RemoveModule), "RemoveModule action", return false);
  safe_write(write_size_t(fd, index), "module index", return false);

  uint8_t res = 0;
  safe_read(read_uint8_t(fd, &res), "remove module result", return false);

  close(fd);

  return res == 1;
}

#undef safe_read
#undef safe_write

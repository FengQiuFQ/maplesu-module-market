#!/usr/bin/env python3
"""Build the standalone policy tool from pinned, separately retained sources."""
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "module-policy"
DEPENDENCY = ROOT / ".research/maplesu-policy-selinux"
COMMIT = "be1b39a657fee7faacfae548b75cb53302043a01"


def run(args):
    subprocess.run([str(x) for x in args], check=True, cwd=ROOT)


def derive():
    original = PROJECT / "upstream/magisk"
    derived = PROJECT / "derived"
    derived.mkdir(exist_ok=True)
    manifest = json.loads((PROJECT / "upstream/sources.json").read_text(encoding="utf-8"))
    for name, expected in manifest["sha256"].items():
        if hashlib.sha256((PROJECT / "upstream" / name).read_bytes()).hexdigest() != expected:
            raise SystemExit("Upstream source or license checksum mismatch: " + name)
    header = (original / "policy.hpp").read_text(encoding="utf-8")
    header = header.replace("#include <rust/cxx.h>", '#include "base.hpp"')
    header = header.replace("using Str = rust::Str;", "using Str = std::string_view;")
    header = header.replace("struct Xperm;", "struct Xperm { uint16_t low, high; bool reset; };")
    header = header.replace("class sepol_impl {", "class sepol_impl {\npublic:")
    source = (original / "sepolicy.cpp").read_text(encoding="utf-8")
    source = source.replace('#include "include/sepolicy.hpp"', '#include "policy.hpp"')
    source = source.replace("rust::Str", "Str")
    source = source.replace("for (int i = 0; i < db->p_roles.nprim; ++i)", "for (uint32_t i = 0; i < db->p_roles.nprim; ++i)")
    source = source[:source.index("void SePolicy::strip_dontaudit()")]
    source += "sepol_impl::~sepol_impl() { policydb_destroy(db); free(db); }\n"
    # Reject an existing symbol of the wrong flavor instead of reporting success.
    source = source.replace('LOGW("Type %.*s already exists\\n", (int) type_name.size(), type_name.data());\n        return true;', 'if (type->flavor != flavor) {\n            LOGW("existing symbol %.*s has a different flavor\\n", (int) type_name.size(), type_name.data());\n            return false;\n        }\n        return true;')
    # Upstream internally warns then returns void for unsupported xperms.
    source = source.replace('    add_xperm_rule(src, tgt, cls, p, effect);', '    if (db->policyvers < POLICYDB_VERSION_XPERMS_IOCTL) {\n        LOGW("policy version does not support xperms\\n");\n        return false;\n    }\n    add_xperm_rule(src, tgt, cls, p, effect);')
    patches = []
    for name, text in (("policy.hpp", header), ("sepolicy.cpp", source)):
        destination = derived / name
        if not destination.exists() or destination.read_text(encoding="utf-8") != text:
            destination.write_text(text, encoding="utf-8", newline="\n")
        before = (original / name).read_text(encoding="utf-8")
        patches.extend(difflib.unified_diff(before.splitlines(True), text.splitlines(True), fromfile="upstream/" + name, tofile="derived/" + name))
    (PROJECT / "upstream/magisk-adapter.patch").write_text("".join(patches), encoding="utf-8", newline="\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ndk", default=os.environ.get("ANDROID_NDK_HOME", "D:/Maple_Env/Android/Sdk/ndk/26.1.10909125"))
    parser.add_argument("--cmake", default="D:/Maple_Env/Android/Sdk/cmake/3.22.1/bin/cmake.exe")
    parser.add_argument("--abi", default="arm64-v8a", choices=["arm64-v8a", "x86_64"])
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    git = shutil.which("git") or "C:/Program Files/Git/cmd/git.exe"
    if not DEPENDENCY.exists():
        run([git, "clone", "--no-checkout", "https://github.com/topjohnwu/selinux.git", DEPENDENCY])
        run([git, "-C", DEPENDENCY, "checkout", "--detach", COMMIT])
    actual = subprocess.check_output([git, "-C", str(DEPENDENCY), "rev-parse", "HEAD"], text=True).strip()
    if actual != COMMIT:
        raise SystemExit("SELinux source is not the pinned commit")
    dirty = subprocess.check_output([git, "-C", str(DEPENDENCY), "status", "--porcelain"], text=True).strip()
    if dirty:
        raise SystemExit("Pinned SELinux source has local modifications")
    derive()
    if args.prepare_only:
        return
    build = PROJECT / "build" / args.abi
    cmake = Path(args.cmake)
    run([cmake, "-S", PROJECT, "-B", build, "-G", "Ninja", f"-DCMAKE_MAKE_PROGRAM={cmake.parent / 'ninja.exe'}", f"-DCMAKE_TOOLCHAIN_FILE={Path(args.ndk) / 'build/cmake/android.toolchain.cmake'}", f"-DANDROID_ABI={args.abi}", "-DANDROID_PLATFORM=android-26", "-DANDROID_STL=c++_static", "-DCMAKE_BUILD_TYPE=Release"])
    run([cmake, "--build", build, "--parallel", "4"])
    binary = build / "maplesu-policy"
    tests = build / "maplesu-policy-tests"
    manifest = {"abi": args.abi, "selinux_commit": COMMIT, "magisk_commit": "e8a58776f1d7bdf852072ad0baa6eceb9a1e4aac", "binary": str(binary), "sha256": hashlib.sha256(binary.read_bytes()).hexdigest(), "bytes": binary.stat().st_size, "tests_binary": str(tests), "tests_sha256": hashlib.sha256(tests.read_bytes()).hexdigest()}
    (build / "build.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest))


if __name__ == "__main__":
    main()

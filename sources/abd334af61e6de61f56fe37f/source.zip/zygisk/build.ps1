param(
    [string]$SdkDirectory = 'D:/Maple_Env/Android/Sdk',
    [string]$Python = 'C:/Python314/python.exe',
    [ValidateSet('Debug','Release','RelWithDebInfo')][string]$Configuration = 'Release'
)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$cmake = "$SdkDirectory/cmake/3.22.1/bin/cmake.exe"
$ndk = "$SdkDirectory/ndk/26.1.10909125"
$ninja = "$SdkDirectory/cmake/3.22.1/bin/ninja.exe"
if (-not (Test-Path -LiteralPath "$PSScriptRoot/SOURCE-DISTRIBUTION.json")) {
    & $Python "$root/tools/build_module_policy.py" --prepare-only
    if ($LASTEXITCODE -ne 0) { throw 'Pinned policy dependency preparation failed' }
}
& $Python "$PSScriptRoot/patch_upstream.py"
if ($LASTEXITCODE -ne 0) { throw 'Pinned upstream preparation failed' }
foreach ($abi in @('arm64-v8a','armeabi-v7a')) {
    $build = "$PSScriptRoot/build/$abi"
    & $cmake -S $PSScriptRoot -B $build -G Ninja "-DCMAKE_MAKE_PROGRAM=$ninja" `
        "-DCMAKE_TOOLCHAIN_FILE=$ndk/build/cmake/android.toolchain.cmake" `
        "-DANDROID_ABI=$abi" -DANDROID_PLATFORM=android-29 -DANDROID_STL=c++_static "-DCMAKE_BUILD_TYPE=$Configuration"
    if ($LASTEXITCODE -ne 0) { throw "Configure failed: $abi" }
    & $cmake --build $build -j 6
    if ($LASTEXITCODE -ne 0) { throw "Build failed: $abi" }
}
& $Python "$PSScriptRoot/package.py" --ndk $ndk
if ($LASTEXITCODE -ne 0) { throw 'Package verification failed' }

// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <dirent.h>
#include <fstream>
#include <set>
#include <string>
#include <sys/stat.h>
#include <vector>

namespace maple {
// The SDK's SuAllowList stores one trimmed package name per line. The owner
// already has Root: reading that file must not fork and acquire Root again.
inline bool read_authorized_uids(const std::string &allowlist, const std::string &users,
                                 std::set<uid_t> &uids) {
    uids.clear();
    std::ifstream file(allowlist);
    if (!file) return false;
    std::vector<std::string> packages;
    std::string package;
    while (std::getline(file, package)) {
        auto first = package.find_first_not_of(" \t\r\n\f\v");
        if (first != std::string::npos)
            packages.push_back(package.substr(first, package.find_last_not_of(" \t\r\n\f\v") - first + 1));
    }
    if (file.bad()) return false;
    DIR *directory = opendir(users.c_str());
    if (!directory) return false;
    while (dirent *user = readdir(directory)) {
        if (user->d_name[0] < '0' || user->d_name[0] > '9') continue;
        for (const auto &pkg : packages) {
            struct stat st{};
            std::string path = users + "/" + user->d_name + "/" + pkg;
            if (stat(path.c_str(), &st) == 0 && st.st_uid >= 10000) uids.insert(st.st_uid);
        }
    }
    closedir(directory);
    return true;
}
}

// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <stdio.h>
#include <string.h>
#include <unistd.h>

// The SDK callback runs below the already-forked Zygote bootstrap. Follow only
// our own ancestry: a late manager/dev-run invocation must not seize live ART.
static int maple_bootstrap_process(int init_pid) {
    int pid = getpid();
    while (pid > 1) {
        char path[64], record[4096];
        snprintf(path, sizeof(path), "/proc/%d/stat", pid);
        FILE *file = fopen(path, "r");
        if (!file) return 0;
        char *line = fgets(record, sizeof(record), file);
        fclose(file);
        char *end = line ? strrchr(record, ')') : NULL;
        int parent;
        if (!end || sscanf(end + 1, " %*c %d", &parent) != 1 || parent <= 0 || parent == pid) return 0;
        if (parent != init_pid) { pid = parent; continue; }
        snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);
        file = fopen(path, "r");
        if (!file) return 0;
        size_t size = fread(record, 1, sizeof(record) - 1, file);
        fclose(file);
        record[size] = 0;
        if (strcmp(record, "/system/bin/app_process64") != 0) return 0;
        for (size_t i = strlen(record) + 1; i < size; i += strlen(record + i) + 1)
            if (strcmp(record + i, "--zygote") == 0) return pid;
        return 0;
    }
    return 0;
}

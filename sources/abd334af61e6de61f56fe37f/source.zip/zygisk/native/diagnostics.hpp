// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include "module_scope.h"
#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <sstream>
#include <string>
#include <strings.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/system_properties.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>

namespace maple::diagnostics {
inline std::string quote(const std::string &value) {
    std::string out = "\"";
    for (size_t i = 0; i < value.size(); ++i) {
        unsigned char c = value[i];
        if (c == '"' || c == '\\') { out += '\\'; out += c; }
        else if (c < 0x20) {
            constexpr char hex[] = "0123456789abcdef";
            out += "\\u00"; out += hex[c >> 4]; out += hex[c & 15];
        } else if (c < 0x80) out += c;
        else {
            size_t n = c >= 0xc2 && c <= 0xdf ? 2 : c >= 0xe0 && c <= 0xef ? 3 : c >= 0xf0 && c <= 0xf4 ? 4 : 0;
            bool valid = n && i + n <= value.size();
            for (size_t j = 1; valid && j < n; ++j) valid = (static_cast<unsigned char>(value[i + j]) & 0xc0) == 0x80;
            if (valid && n >= 3) {
                unsigned char next = value[i + 1];
                valid = !(c == 0xe0 && next < 0xa0) && !(c == 0xed && next >= 0xa0) &&
                    !(c == 0xf0 && next < 0x90) && !(c == 0xf4 && next >= 0x90);
            }
            if (valid) { out.append(value, i, n); i += n - 1; }
            else out += "\\ufffd";
        }
    }
    return out + '"';
}

inline bool alnum(unsigned char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');
}
inline std::string redact(std::string value, const std::string &host, const std::string &revisions) {
    for (const auto &root : {host, revisions}) {
        if (root.empty()) continue;
        size_t at = 0;
        while ((at = value.find(root, at)) != std::string::npos) {
            value.replace(at, root.size(), root == host ? "<host>" : "<revisions>");
            at += root == host ? 6 : 11;
        }
    }
    std::string out;
    for (size_t i = 0; i < value.size();) {
        if (value.compare(i, 7, "http://") == 0 || value.compare(i, 8, "https://") == 0) {
            size_t end = value.find_first_of(" \t\r\n\"'<>\\", i);
            i = end == std::string::npos ? value.size() : end;
            out += "<url>"; continue;
        }
        if (value.compare(i, 6, "/data/") == 0) {
            size_t end = i + 6;
            while (end < value.size() && alnum(value[end])) ++end;
            if ((end - i == 22 || end - i == 23) &&
                (end == value.size() || !alnum(value[end]))) {
                out += "/data/<private>"; i = end; continue;
            }
        }
        size_t token_end = i + 1;
        if (alnum(value[i])) {
            while (token_end < value.size() && alnum(value[token_end])) ++token_end;
            if (token_end - i == 48) { out += "<private-key>"; i = token_end; continue; }
        }
        bool secret = false;
        if (i == 0 || !alnum(value[i - 1])) {
            for (const char *name : {"root_key", "rootkey", "pairing_key", "token", "password", "authorization"}) {
                size_t n = strlen(name), at = i + n;
                if (at > value.size() || strncasecmp(value.c_str() + i, name, n)) continue;
                while (at < value.size() && (value[at] == '"' || value[at] == '\'' || value[at] == ' ' || value[at] == '\t')) ++at;
                if (at == value.size() || (value[at] != ':' && value[at] != '=')) continue;
                ++at;
                while (at < value.size() && (value[at] == '"' || value[at] == '\'' || value[at] == ' ' || value[at] == '\t')) ++at;
                if (value.compare(at, 7, "Bearer ") == 0) at += 7;
                size_t end = value.find_first_of(" \t\r\n\"',}\\", at);
                out.append(value, i, at - i); out += "<redacted>";
                i = end == std::string::npos ? value.size() : end;
                secret = true; break;
            }
        }
        if (!secret) { out.append(value, i, token_end - i); i = token_end; }
    }
    return out;
}

struct Sample {
    std::string content, error;
    bool truncated = false;
    int64_t size = 0;
};

class Collector {
    using Clock = std::chrono::steady_clock;
    std::string host, runtime, modules, revisions, system;
    Clock::time_point started = Clock::now(), deadline = started + std::chrono::seconds(4);
    size_t remaining = 2 * 1024 * 1024;
    bool expired() const { return Clock::now() >= deadline; }
    std::string path(const char *p) const { return system + p; }
    std::string text(const std::string &s) const { return quote(redact(s, host, revisions)); }
    std::string result(const Sample &s) const {
        std::string content = s.content;
        if (s.truncated && !content.empty() && content.back() != '\n') {
            size_t end = content.find_last_of('\n');
            content.resize(end == std::string::npos ? 0 : end + 1);
        }
        return "{\"content\":" + text(content) + ",\"error\":" + (s.error.empty() ? "null" : text(s.error)) +
            ",\"truncated\":" + (s.truncated ? "true" : "false") + ",\"size\":" + std::to_string(s.size) + "}";
    }
    Sample read(const std::string &name, size_t limit = 16384, bool head_tail = false) {
        Sample s;
        if (expired() || !remaining) { s.error = "collection_budget_exhausted"; return s; }
        int fd = open(name.c_str(), O_RDONLY | O_CLOEXEC | O_NONBLOCK | O_NOFOLLOW);
        if (fd < 0) { s.error = strerror(errno); return s; }
        struct stat st{};
        if (fstat(fd, &st) || !S_ISREG(st.st_mode)) {
            s.error = "not_readable_regular_file"; close(fd); return s;
        }
        s.size = st.st_size;
        limit = std::min(limit, remaining);
        size_t head = head_tail && s.size > static_cast<int64_t>(limit) ? std::min<size_t>(32768, limit / 4) : limit;
        auto take = [&](size_t count) {
            char buffer[4096];
            while (count && !expired()) {
                ssize_t n = ::read(fd, buffer, std::min(count, sizeof(buffer)));
                if (n < 0 && errno == EINTR) continue;
                if (n < 0) s.error = strerror(errno);
                if (n <= 0) break;
                s.content.append(buffer, n); count -= n;
            }
            if (count && expired()) s.error = "collection_deadline";
        };
        take(head);
        if (head < limit) {
            s.truncated = true;
            // Drop split lines so a truncated credential never escapes redaction.
            auto newline = s.content.find_last_of('\n');
            s.content.resize(newline == std::string::npos ? 0 : newline + 1);
            std::string first = std::move(s.content);
            s.content.clear();
            if (lseek(fd, s.size - (limit - head), SEEK_SET) < 0) s.error = strerror(errno);
            else take(limit - head);
            newline = s.content.find('\n');
            s.content.erase(0, newline == std::string::npos ? s.content.size() : newline + 1);
            s.content = first + "\n[... omitted middle ...]\n" + s.content;
        } else {
            char extra;
            s.truncated = ::read(fd, &extra, 1) > 0;
        }
        close(fd);
        remaining -= std::min(remaining, s.content.size());
        return s;
    }
    std::string info(const std::string &name) {
        struct stat st{};
        if (stat(name.c_str(), &st)) return "{\"error\":" + text(strerror(errno)) + "}";
        return "{\"size\":" + std::to_string(st.st_size) + ",\"mode\":" +
            std::to_string(st.st_mode & 07777) + ",\"modifiedEpoch\":" + std::to_string(st.st_mtime) + "}";
    }
    std::string fields(const std::string &base, std::initializer_list<const char *> names) {
        std::string out = "{";
        for (const char *name : names) {
            if (out.size() > 1) out += ',';
            out += quote(name) + ':' + result(read(base + '/' + name));
        }
        return out + '}';
    }
    static uint64_t little(const std::string &s, size_t at, size_t n = 4) {
        uint64_t value = 0;
        for (size_t i = 0; i < n; ++i) value |= uint64_t(static_cast<unsigned char>(s[at + i])) << (8 * i);
        return value;
    }
    std::string startup_policy() {
        auto a = read(runtime + "/startup-policy", 120), b = read(runtime + "/startup-policy", 120);
        if (!a.error.empty() || a.content.size() != 120 || a.truncated)
            return "{\"error\":" + text(a.error.empty() ? "unsupported_startup_record" : a.error) + "}";
        return "{\"stable\":" + std::string(a.content == b.content ? "true" : "false") +
            ",\"boot\":" + text(a.content.substr(0, strnlen(a.content.data(), 40))) +
            ",\"original\":" + std::to_string(static_cast<int32_t>(little(a.content, 40))) + ",\"closed\":" + std::to_string(little(a.content, 44)) +
            ",\"retained\":" + std::to_string(little(a.content, 48)) +
            ",\"startedUptimeMs\":" + std::to_string(little(a.content, 56, 8)) +
            ",\"readySinceUptimeMs\":" + std::to_string(little(a.content, 64, 8)) + "}";
    }
    std::string selinux() {
        auto before = read(path("/sys/fs/selinux/status"), 20);
        auto status = [&](const Sample &s) {
            if (!s.error.empty() || s.content.size() != 20) return "{\"error\":" + text(s.error.empty() ? "invalid_status" : s.error) + "}";
            return "{\"version\":" + std::to_string(little(s.content, 0)) + ",\"sequence\":" + std::to_string(little(s.content, 4)) +
                ",\"enforcing\":" + std::to_string(little(s.content, 8)) + ",\"policyload\":" + std::to_string(little(s.content, 12)) +
                ",\"denyUnknown\":" + std::to_string(little(s.content, 16)) + "}";
        };
        unsigned cls = 0, bit = 0, allowed = 0, decided = 0, auditallow = 0, auditdeny = 0, seqno = 0, flags = 0;
        std::istringstream(read(path("/sys/fs/selinux/class/process/index"), 32).content) >> cls;
        std::istringstream(read(path("/sys/fs/selinux/class/process/perms/execmem"), 32).content) >> bit;
        Sample access;
        if (!cls || !bit || bit > 32) access.error = "process_class_or_execmem_unreadable";
        else {
            int fd = open(path("/sys/fs/selinux/access").c_str(), O_RDWR | O_CLOEXEC | O_NONBLOCK);
            if (fd < 0) access.error = strerror(errno);
            else {
                // selinuxfs access is a permission query, never a policy reload.
                std::string query = "u:r:system_server:s0 u:r:system_server:s0 " + std::to_string(cls);
                char buffer[256];
                if (::write(fd, query.data(), query.size()) != static_cast<ssize_t>(query.size())) access.error = strerror(errno);
                else {
                    ssize_t n = ::read(fd, buffer, sizeof(buffer));
                    if (n < 0) access.error = strerror(errno);
                    else access.content.assign(buffer, n);
                }
                close(fd);
            }
        }
        bool queried = access.error.empty() && sscanf(access.content.c_str(), "%x %x %x %x %u %x",
            &allowed, &decided, &auditallow, &auditdeny, &seqno, &flags) == 6;
        if (!queried && access.error.empty()) access.error = "invalid_access_response";
        auto after = read(path("/sys/fs/selinux/status"), 20);
        bool stable = before.error.empty() && after.error.empty() && before.content.size() == 20 &&
            before.content == after.content && !(little(before.content, 4) & 1);
        std::string query = "{\"sample\":" + result(access) + ",\"seqno\":" + (queried ? std::to_string(seqno) : "null") +
            ",\"systemServerExecmem\":" + (!queried ? "null" : (allowed & (1u << (bit - 1))) ? "true" : "false") + "}";
        return "{\"statusBefore\":" + status(before) + ",\"access\":" + query + ",\"statusAfter\":" + status(after) +
            ",\"stable\":" + (stable ? "true" : "false") + ",\"seqnoConsistent\":" +
            (!stable || !queried ? "null" : little(before.content, 12) == seqno ? "true" : "false") +
            ",\"enforce\":" + result(read(path("/sys/fs/selinux/enforce"), 32)) + "}";
    }
public:
    Collector(std::string directory, std::string state, std::string module_root,
              std::string revision_root, std::string system_root)
        : host(std::move(directory)), runtime(std::move(state)), modules(std::move(module_root)),
          revisions(std::move(revision_root)), system(std::move(system_root)) {}
    std::string collect();
private:
    std::string inventory() {
        DIR *root = opendir(modules.c_str());
        if (!root) return "{\"error\":" + text(strerror(errno)) + ",\"items\":[]}";
        std::string items;
        size_t count = 0;
        bool truncated = false;
        while (dirent *entry = readdir(root)) {
            std::string id = entry->d_name;
            if (id.empty() || id[0] == '.' || id == "maplesu_zygisk" ||
                id.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-") != std::string::npos) continue;
            if (++count > 128 || expired()) { truncated = true; break; }
            std::string directory = modules + '/' + id;
            char resolved[PATH_MAX];
            bool owned = realpath(directory.c_str(), resolved) && maple_ultra_module(resolved, modules.c_str(), revisions.c_str());
            if (!items.empty()) items += ',';
            items += "{\"id\":" + text(id) + ",\"ownedByUltra\":" + (owned ? "true" : "false");
            if (owned) {
                items += ",\"files\":" + fields(directory, {"module.prop", "sepolicy.rule"});
                items += ",\"flags\":{";
                for (const char *name : {"disable", "remove", "update"}) {
                    if (items.back() != '{') items += ',';
                    items += quote(name) + ':' + (access((directory + '/' + name).c_str(), F_OK) == 0 ? "true" : "false");
                }
                items += "},\"components\":{";
                for (const char *name : {"zygisk/arm64-v8a.so", "zygisk/armeabi-v7a.so", "post-fs-data.sh", "post-mount.sh", "service.sh", "boot-completed.sh"}) {
                    if (items.back() != '{') items += ',';
                    items += quote(name) + ':' + info(directory + '/' + name);
                }
                struct stat st{};
                if (stat(directory.c_str(), &st) == 0) {
                    std::string receipt = path("/data/adb/maplesu/module-boot/") + std::to_string(st.st_dev) + '-' + std::to_string(st.st_ino);
                    items += "},\"stageReceipts\":" + fields(receipt, {"post-fs-data", "post-mount", "service", "boot-completed"});
                } else items += '}';
            }
            items += '}';
        }
        closedir(root);
        return "{\"error\":null,\"truncated\":" + std::string(truncated ? "true" : "false") + ",\"items\":[" + items + "]}";
    }
    static std::string relevant(const std::string &content, bool traces = false) {
        std::istringstream stream(content);
        std::string line, out;
        unsigned context = 0;
        while (std::getline(stream, line)) {
            std::string lower = line;
            std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return c >= 'A' && c <= 'Z' ? c + ('a' - 'A') : c; });
            bool selected = context > 0;
            if (context) --context;
            for (const char *term : {"zygisk", "zygote", "lsposed", "lspd", "hma", "hide_my_applist", "maplesu", "selinux", "avc:", "panic", "oops", "call trace", "calltrace", "kernel bug", "pc :", "lr :", "fsc =", "exception"}) {
                if (lower.find(term) != std::string::npos) { selected = true; break; }
            }
            if (selected) out += line + '\n';
            if (traces && selected && (lower.find("panic") != std::string::npos || lower.find("oops") != std::string::npos ||
                lower.find("call trace") != std::string::npos || lower.find("cmdline:") != std::string::npos)) context = 80;
        }
        return out;
    }
    std::string processes() {
        DIR *root = opendir(path("/proc").c_str());
        if (!root) return "{\"error\":" + text(strerror(errno)) + ",\"items\":[]}";
        std::string items;
        size_t count = 0;
        bool truncated = false;
        while (dirent *entry = readdir(root)) {
            std::string pid = entry->d_name;
            if (pid.empty() || pid.find_first_not_of("0123456789") != std::string::npos) continue;
            if (expired() || !remaining) { truncated = true; break; }
            std::string directory = path("/proc/") + pid;
            auto comm = read(directory + "/comm", 80);
            bool selected = pid == std::to_string(getpid());
            for (const char *name : {"zygote", "system_server", "zygisk", "lspd", "lsposed", "hma"})
                if (comm.content.find(name) != std::string::npos) selected = true;
            if (!selected) continue;
            if (++count > 48) { truncated = true; break; }
            auto maps = read(directory + "/maps", 65536, true);
            maps.content = relevant(maps.content);
            if (!items.empty()) items += ',';
            items += "{\"pid\":" + text(pid) + ",\"name\":" + result(comm) + ",\"files\":" +
                fields(directory, {"status", "attr/current", "wchan"}) + ",\"relatedMaps\":" + result(maps) + "}";
        }
        closedir(root);
        return "{\"error\":null,\"truncated\":" + std::string(truncated ? "true" : "false") + ",\"items\":[" + items + "]}";
    }
    Sample command(std::vector<std::string> args) {
        Sample s;
        if (expired() || !remaining) { s.error = "collection_budget_exhausted"; return s; }
        if (access(args[0].c_str(), X_OK)) { s.error = strerror(errno); return s; }
        std::vector<char *> argv;
        for (auto &arg : args) argv.push_back(arg.data());
        argv.push_back(nullptr);
        int output[2];
        if (pipe2(output, O_CLOEXEC | O_NONBLOCK)) { s.error = strerror(errno); return s; }
        pid_t parent = getpid(), child = fork();
        if (child == 0) {
            if (prctl(PR_SET_PDEATHSIG, SIGKILL) || getppid() != parent) _exit(125);
            close(output[0]);
            fcntl(output[1], F_SETFL, 0);
            if (dup2(output[1], STDOUT_FILENO) < 0 || dup2(output[1], STDERR_FILENO) < 0) _exit(125);
            close(output[1]);
            execv(argv[0], argv.data());
            _exit(127);
        }
        close(output[1]);
        if (child < 0) { s.error = strerror(errno); close(output[0]); return s; }
        auto until = std::min(deadline, Clock::now() + std::chrono::milliseconds(700));
        size_t limit = std::min<size_t>(131072, remaining);
        bool eof = false;
        while (!eof && Clock::now() < until && s.content.size() < limit) {
            char buffer[4096];
            ssize_t n = ::read(output[0], buffer, std::min(sizeof(buffer), limit - s.content.size()));
            if (n > 0) s.content.append(buffer, n);
            else if (n == 0) eof = true;
            else if (errno != EAGAIN && errno != EINTR) { s.error = strerror(errno); break; }
            else { struct pollfd event{output[0], POLLIN, 0}; poll(&event, 1, 20); }
        }
        close(output[0]);
        s.truncated = !eof && s.content.size() == limit;
        int status = 0;
        pid_t reaped = waitpid(child, &status, WNOHANG);
        while (!reaped && Clock::now() < until && eof) {
            usleep(1000); reaped = waitpid(child, &status, WNOHANG);
        }
        if (reaped == 0) {
            kill(child, SIGKILL);
            while (waitpid(child, &status, 0) < 0 && errno == EINTR) {}
            s.error = s.content.size() == limit ? "output_limit" : "collector_timeout";
            s.truncated = true;
        } else if (reaped < 0) s.error = "collector_status_unavailable";
        else if (!WIFEXITED(status) || WEXITSTATUS(status)) s.error = "collector_exit_" + std::to_string(WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status));
        else if (s.truncated) s.error = "output_limit";
        s.size = s.content.size();
        remaining -= s.content.size();
        return s;
    }
};

inline std::string Collector::collect() {
    struct utsname kernel{};
    uname(&kernel);
    std::string properties = "{";
    // Explicit whitelist: no serial, account, pairing or authorization properties.
    for (const char *key : {"ro.product.manufacturer", "ro.product.model", "ro.product.device", "ro.build.version.release",
            "ro.build.version.sdk", "ro.build.version.security_patch", "ro.build.fingerprint", "ro.build.type",
            "ro.product.cpu.abilist", "ro.product.cpu.abilist64", "ro.product.cpu.abilist32", "ro.boot.bootreason", "sys.boot.reason", "sys.boot_completed"}) {
        char value[PROP_VALUE_MAX]{};
        __system_property_get(key, value);
        if (properties.size() > 1) properties += ',';
        properties += quote(key) + ':' + text(value);
    }
    std::string out = "{\"system\":{\"properties\":" + properties + "},\"kernel\":" + text(std::string(kernel.release) + ' ' + kernel.version) +
        ",\"machine\":" + text(kernel.machine) + ",\"pageSize\":" + std::to_string(sysconf(_SC_PAGESIZE)) +
        ",\"files\":" + fields(path("/proc"), {"uptime", "sys/kernel/random/boot_id", "self/status", "self/attr/current", "1/status"}) + "}";
    out += ",\"selinux\":" + selinux() + ",\"startupPolicy\":" + startup_policy();
    std::string files = "{\"runtime/host.log\":" + result(read(runtime + "/host.log", 524288, true));
    for (const char *name : {"state.json", "startup.state", "policy-action.state", "policy-baseline.boot", "policy-restored", "early.boot", "monitor.pid", "shared-context", "published.path"})
        files += ",\"runtime/" + std::string(name) + "\":" + result(read(runtime + '/' + name));
    files += ",\"host/BUILD-IDENTITY.json\":" + result(read(host + "/BUILD-IDENTITY.json", 32768));
    for (const char *name : {"payload/module.prop", "sepolicy.rule", "startup-policy.rule", "steady-policy.rule"})
        files += ",\"host/" + std::string(name) + "\":" + result(read(host + '/' + name));
    out += ",\"files\":" + files + "},\"hostComponents\":{";
    for (const char *name : {"bin/run-module.sh", "bin/zygisk-ptrace64", "bin/zygisk-ptrace32", "bin/zygiskd64", "bin/zygiskd32", "bin/maplesu-policy", "lib64/libzygisk.so", "lib/libzygisk.so", "lib64/liblsp-shared.so"}) {
        if (out.back() != '{') out += ',';
        out += quote(name) + ':' + info(host + '/' + name);
    }
    out += "},\"modules\":" + inventory() + ",\"processes\":" + processes();
    out += ",\"mountReceipts\":" + fields(path("/data/adb/maplesu/module-mounts"), {"boot", "ledger"});
    auto logcat = command({path("/system/bin/logcat"), "-b", "all", "-d", "-t", "600", "-v", "threadtime",
        "zygisk-core64:V", "zygisk-core32:V", "zygisk-ptrace64:V", "zygisk-ptrace32:V", "zygisk-injector64:V", "zygisk-injector32:V",
        "zygiskd64:V", "zygiskd32:V", "zygiskd-companion64:V", "zygiskd-companion32:V", "LSPosed:V", "LSPosed-Bridge:V", "lspd:V", "HMA:V", "MapleSU:V", "*:S"});
    auto dmesg = command({path("/system/bin/dmesg")});
    if (dmesg.error.empty()) dmesg.content = relevant(dmesg.content, true);
    auto crash = command({path("/system/bin/logcat"), "-b", "crash", "-d", "-t", "300", "-v", "threadtime"});
    crash.content = relevant(crash.content, true);
    out += ",\"logs\":{\"logcat\":" + result(logcat) + ",\"kernel\":" + result(dmesg) + ",\"crash\":" + result(crash) + ",\"pstore\":{";
    DIR *pstore = opendir(path("/sys/fs/pstore").c_str());
    if (!pstore) out += "\"error\":" + text(strerror(errno));
    else {
        unsigned count = 0;
        while (dirent *entry = readdir(pstore)) {
            std::string name = entry->d_name;
            if (!name.starts_with("console-ramoops") && !name.starts_with("dmesg-ramoops")) continue;
            if (++count > 4 || expired()) { if (out.back() != '{') out += ','; out += "\"truncated\":true"; break; }
            if (out.back() != '{') out += ',';
            out += text(name) + ':' + result(read(path("/sys/fs/pstore/") + name, 131072, true));
        }
        closedir(pstore);
    }
    return out + "}},\"collection\":{\"durationMs\":" + std::to_string(std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now() - started).count()) +
        ",\"deadlineReached\":" + (expired() ? "true" : "false") + ",\"byteBudgetRemaining\":" + std::to_string(remaining) +
        ",\"policyReloaded\":false,\"credentialsIncluded\":false}}";
}
}

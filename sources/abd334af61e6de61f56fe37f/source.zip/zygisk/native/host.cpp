// SPDX-License-Identifier: AGPL-3.0-or-later
#include "kernel_module_kit_umbrella.h"
#include "process.hpp"
#include "bootstrap.h"
#include "tracer_context.h"
#include "webui.hpp"
#include "auth_snapshot.hpp"
#include "startup_policy.h"
#include "policy_notifications.hpp"
#include <memory>
#include <chrono>
#include <sys/file.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/system_properties.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <unistd.h>
#include <algorithm>
#include <fstream>
#include <set>
#include <sstream>

namespace {
// Retain the actual static link input through stripping; package.py verifies it.
__attribute__((used, retain)) const char sdk_link_identity[] =
    "MAPLESU_SDK_ARCHIVE_SHA256=" MAPLE_SDK_ARCHIVE_SHA256;
constexpr const char *runtime = "/data/adb/maplesu_zygisk";
constexpr const char *published = "/data/adb/modules/maplesu_zygisk";
volatile sig_atomic_t stopping = 0;
void stop_signal(int) { stopping = 1; }

std::string read(const std::string &path) {
    std::ifstream file(path);
    return {std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>()};
}
bool write(const std::string &path, const std::string &value, mode_t mode = 0600) {
    std::string tmp = path + ".tmp." + std::to_string(getpid());
    int fd = open(tmp.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC | O_NOFOLLOW, mode);
    if (fd < 0) return false;
    bool ok = ::write(fd, value.data(), value.size()) == static_cast<ssize_t>(value.size());
    close(fd);
    if (ok) ok = rename(tmp.c_str(), path.c_str()) == 0;
    if (!ok) unlink(tmp.c_str());
    return ok;
}
bool exists(const std::string &path) { return access(path.c_str(), F_OK) == 0; }
bool disabled(const std::string &dir) {
    return exists(dir + "/data/disabled") || exists(dir + "/disable") || exists(dir + "/remove");
}

// The published identity is also the discovery protocol used by HMA's installer.
// Never replace another owner's directory. Uninstall only removes our exact link.
bool publish(const std::string &dir) {
    mkdir("/data/adb/modules", 0755);
    char current[4096];
    ssize_t n = readlink(published, current, sizeof(current) - 1);
    if (n >= 0) {
        current[n] = 0;
        if (dir == current) return write(std::string(runtime) + "/published.path", dir);
        // SDK upgrades may move resources. Only replace a link this host published.
        if (read(std::string(runtime) + "/published.path") != current) return false;
    } else {
        struct stat st{};
        if (lstat(published, &st) == 0 || errno != ENOENT) return false;
    }
    std::string temporary = std::string(published) + ".tmp." + std::to_string(getpid());
    unlink(temporary.c_str());
    if (symlink(dir.c_str(), temporary.c_str()) != 0) return false;
    if (rename(temporary.c_str(), published) != 0) { unlink(temporary.c_str()); return false; }
    return write(std::string(runtime) + "/published.path", dir);
}
void unpublish(const std::string &dir) {
    char current[4096];
    ssize_t n = readlink(published, current, sizeof(current) - 1);
    if (n >= 0) { current[n] = 0; if (dir == current) unlink(published); }
}

bool refresh_auth(const std::string &dir) {
    std::set<uid_t> uids;
    if (!maple::read_authorized_uids(dir + "/../../su_allowlist.txt", "/data/user_de", uids)) {
        // Do not retain grants after an allowlist read error.
        write(std::string(runtime) + "/auth.uids", "");
        return false;
    }
    std::string text;
    for (uid_t uid : uids) text += std::to_string(uid) + "\n";
    return write(std::string(runtime) + "/auth.uids", text);
}

int control(const std::string &dir, const char *action) {
    pid_t parent = getpid();
    pid_t pid = fork();
    if (pid < 0) return -1;
    if (pid == 0) {
        maple::follow_parent(parent);
        std::string binary = dir + "/bin/zygisk-ptrace64";
        execl(binary.c_str(), binary.c_str(), "ctl", action, nullptr);
        _exit(127);
    }
    int status = 0;
    if (!maple::wait_child(pid, status, 500)) { maple::stop_child(pid, status); return -1; }
    return WIFEXITED(status) ? WEXITSTATUS(status) : -1;
}

enum class PolicyLoad { Reload, Base, Startup };
bool apply_policy(const std::string &dir, PolicyLoad mode) {
    auto until = std::chrono::steady_clock::now() + std::chrono::milliseconds(2500);
    for (int attempt = 0; attempt < 3; ++attempt) {
        int remaining = static_cast<int>(std::chrono::duration_cast<std::chrono::milliseconds>(
            until - std::chrono::steady_clock::now()).count());
        if (remaining <= 0) return false;
        pid_t parent = getpid(), child = fork();
        if (child == 0) {
            maple::follow_parent(parent);
            if (mode == PolicyLoad::Startup)
                execl((dir + "/bin/maplesu-policy").c_str(), "maplesu-policy", "apply", "--rules",
                    (dir + "/sepolicy.rule").c_str(), "--rules", (dir + "/startup-policy.rule").c_str(), nullptr);
            else if (mode == PolicyLoad::Base)
                execl((dir + "/bin/maplesu-policy").c_str(), "maplesu-policy", "apply", "--rules",
                    (dir + "/sepolicy.rule").c_str(), nullptr);
            else
                execl((dir + "/bin/maplesu-policy").c_str(), "maplesu-policy", "apply", nullptr);
            _exit(127);
        }
        if (child < 0) return false;
        int status = 0;
        bool exited = maple::wait_child(child, status, remaining);
        if (!exited) maple::stop_child(child, status);
        if (!exited || !WIFEXITED(status)) return false;
        int code = WEXITSTATUS(status);
        if (code != 75) return code == 0;
        if (attempt != 2) usleep(100000);
    }
    return false;
}

// Keep a successful switch write pending until a real load has notified userspace.
// An unknown SDK wrapper is not fatal if the native status/access contract works.
bool sync_policy_notifications(const std::string &dir, bool &pending) {
    bool changed = false;
    maple::restore_policy_notifications(&changed);
    pending |= changed;
    bool coherent = maple::policy_notifications_consistent();
    if (pending || !coherent) {
        if (!apply_policy(dir, PolicyLoad::Reload)) return false;
        pending = false;
        coherent = maple::policy_notifications_consistent();
    }
    return coherent;
}

int launch(const std::string &dir) {
    if (disabled(dir)) return 0;
    int bootstrap = maple_bootstrap_process(1);
    int lock = open((std::string(runtime) + "/owner.lock").c_str(), O_RDWR | O_CREAT | O_CLOEXEC, 0600);
    if (lock < 0) return 1;
    if (flock(lock, LOCK_EX | LOCK_NB) != 0) { close(lock); return 0; }
    int ready[2];
    if (pipe2(ready, O_CLOEXEC) != 0) { close(lock); return 1; }
    pid_t owner = fork();
    if (owner < 0) { close(lock); close(ready[0]); close(ready[1]); return 1; }
    if (owner > 0) {
        close(lock); close(ready[1]);
        struct pollfd pfd{ready[0], POLLIN, 0};
        char result = 0;
        int polled;
        do { polled = poll(&pfd, 1, 5000); } while (polled < 0 && errno == EINTR);
        bool ok = polled > 0 && ::read(ready[0], &result, 1) == 1 && result == '1';
        close(ready[0]);
        if (!ok) {
            kill(owner, SIGKILL);
            int status = 0;
            maple::wait_child(owner, status, 300);
        }
        return ok ? 0 : 1;
    }
    close(ready[0]);
    setsid();
    umask(0077);
    prctl(PR_SET_NAME, "maplesu-zygisk", 0, 0, 0);
    prctl(PR_SET_DUMPABLE, 0);
    signal(SIGTERM, stop_signal);
    signal(SIGINT, stop_signal);
    signal(SIGPIPE, SIG_IGN);
    chdir(dir.c_str());
    // Only this owner retains the runtime lock.
    int log = open((std::string(runtime) + "/host.log").c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
    if (log >= 0) { dup2(log, 1); dup2(log, 2); close(log); }
    refresh_auth(dir);
    // Keep real policy-load notifications working before the first transaction.
    // SDK96's default concealment switch otherwise leaves libselinux caches stale.
    bool notifications_reload_pending = false;
    if (!maple::restore_policy_notifications(&notifications_reload_pending))
        fprintf(stderr, "policy notifications: initial restoration incomplete\n");
    if (!maple_startup_policy_snapshot(dir.c_str()))
        fprintf(stderr, "policy baseline unavailable: full restoration requires a fresh boot\n");
    // Capture policy ownership before the host adds its startup grant.
    maple_startup_policy_init();
    bool policy_restored = maple_startup_policy_restored();
    // Policy is module-owned and loaded only for this explicitly installed host.
    // Ship the existing policy tool with the host, including its corresponding source.
    pid_t owner_pid = getpid();
    if (!policy_restored && !apply_policy(dir, maple_startup_policy_needed() ? PolicyLoad::Startup : PolicyLoad::Base)) {
        ::write(ready[1], "0", 1);
        kernel_module::set_current_module_run_state(skroot_env::ModuleRunState::Abnormal);
        _exit(1);
    }
    int monitor_ready[2];
    if (pipe2(monitor_ready, O_CLOEXEC) != 0) _exit(1);
    unlink((std::string(runtime) + "/init_monitor").c_str());
    unlink((std::string(runtime) + "/cp64.sock").c_str());
    unlink((std::string(runtime) + "/cp32.sock").c_str());
    unlink((std::string(runtime) + "/state.json").c_str());
    pid_t monitor = fork();
    if (monitor < 0) _exit(1);
    if (monitor == 0) {
        maple::follow_parent(owner_pid);
        if (!maple_tracer_context()) _exit(126);
        close(lock); close(ready[1]); close(monitor_ready[0]);
        if (dup2(monitor_ready[1], 199) < 0) _exit(126);
        if (fcntl(199, F_SETFD, 0) < 0) _exit(126);
        if (monitor_ready[1] != 199) close(monitor_ready[1]);
        std::string binary = dir + "/bin/zygisk-ptrace64";
        std::string bootstrap_pid = std::to_string(bootstrap);
        execl(binary.c_str(), binary.c_str(), "monitor", bootstrap_pid.c_str(), nullptr);
        _exit(127);
    }
    close(monitor_ready[1]);
    struct pollfd pfd{monitor_ready[0], POLLIN, 0};
    char result = 0;
    int polled = poll(&pfd, 1, 1500);
    bool running = polled > 0 && ::read(monitor_ready[0], &result, 1) == 1 && result == '1';
    close(monitor_ready[0]);
    if (running) {
        write(std::string(runtime) + "/monitor.pid", std::to_string(monitor));
        // The monitor acknowledgement does not prove module policy/script readiness.
        kernel_module::set_current_module_run_state(skroot_env::ModuleRunState::NotRunning);
        write(std::string(runtime) + "/startup.state", "boot=" + read("/proc/sys/kernel/random/boot_id") +
            "monitor=ready\nmodules=pending\n");
    }
    pid_t early = -1;
    int early_ready[2] = {-1, -1};
    bool scripts_ready = policy_restored;
    if (running && !policy_restored && pipe2(early_ready, O_CLOEXEC) == 0) {
        early = fork();
        if (early == 0) {
            maple::follow_parent(owner_pid);
            close(early_ready[0]);
            if (dup2(early_ready[1], 198) < 0 || fcntl(198, F_SETFD, 0) < 0) _exit(126);
            if (early_ready[1] != 198) close(early_ready[1]);
            std::string binary = dir + "/bin/zygisk-ptrace64";
            std::string helper = dir + "/bin/run-module.sh";
            execl(binary.c_str(), binary.c_str(), "stages", helper.c_str(), nullptr);
            _exit(127);
        }
        close(early_ready[1]);
        // Framework scripts normally just spawn a daemon and exit. Let them start
        // before releasing Zygote, but a slow third-party script never blocks init.
        if (early > 0) {
            struct pollfd event{early_ready[0], POLLIN, 0};
            poll(&event, 1, 500);
        }
        // Retain the event FD: policy completion follows actual script dispatch,
        // independently of the short SDK startup acknowledgement above.
    }
    if (running && !policy_restored && early <= 0)
        kernel_module::set_current_module_run_state(skroot_env::ModuleRunState::Abnormal);
    if (running && policy_restored) {
        kernel_module::set_current_module_run_state(skroot_env::ModuleRunState::Running);
        write(std::string(runtime) + "/startup.state", "boot=" + read("/proc/sys/kernel/random/boot_id") +
            "monitor=ready\nmodules=ready\npolicy=restored\n");
    }
    // This only acknowledges the resident monitor. Running is published after early's real result.
    ::write(ready[1], running ? "1" : "0", 1);
    close(ready[1]);
    bool previous_disabled = false;
    bool notifications_finished = false;
    bool notifications_boot_completed = false;
    int notification_attempts = 0;
    bool exited = false;
    int status = 0;
    while (running && !stopping && exists(dir)) {
        pid_t result = waitpid(monitor, &status, WNOHANG);
        if (result != 0) { exited = true; if (result < 0) status = -1; break; }
        if (early > 0) {
            int early_status;
            if (waitpid(early, &early_status, WNOHANG) == early) early = -1;
        }
        if (early_ready[0] >= 0) {
            struct pollfd event{early_ready[0], POLLIN, 0};
            if (poll(&event, 1, 0) > 0) {
                char dispatched = 0;
                scripts_ready = ::read(early_ready[0], &dispatched, 1) == 1 && dispatched == '1';
                kernel_module::set_current_module_run_state(scripts_ready ? skroot_env::ModuleRunState::Running :
                    skroot_env::ModuleRunState::Abnormal);
                write(std::string(runtime) + "/startup.state", "boot=" + read("/proc/sys/kernel/random/boot_id") +
                    "monitor=ready\nmodules=" + (scripts_ready ? "ready\n" : "failed\n"));
                if (!scripts_ready) fprintf(stderr, "early module preparation failed; inspect per-module codes\n");
                close(early_ready[0]);
                early_ready[0] = -1;
            }
        }
        bool now_disabled = disabled(dir);
        if (now_disabled != previous_disabled) control(dir, now_disabled ? "stop" : "start");
        previous_disabled = now_disabled;
        char completed[PROP_VALUE_MAX] = {};
        __system_property_get("sys.boot_completed", completed);
        if (!notifications_boot_completed && strcmp(completed, "1") == 0) {
            notifications_boot_completed = true;
            notifications_finished = false;
            notification_attempts = 0;
        }
        // Retry before boot completion too; app_zygote can already observe policy.
        // Recheck once SDK startup has finished, without unbounded kernel polling.
        if (!notifications_finished && notification_attempts < 3) {
            ++notification_attempts;
            notifications_finished = sync_policy_notifications(dir, notifications_reload_pending);
            if (!notifications_finished)
                fprintf(stderr, "policy notifications: synchronization failed attempt=%d boot_completed=%d\n",
                    notification_attempts, notifications_boot_completed);
        }
        if (!now_disabled) maple_startup_policy_finish(dir.c_str(), scripts_ready);
        refresh_auth(dir);
        sleep(2);
    }
    if (early_ready[0] >= 0) close(early_ready[0]);
    if (!exited) {
        control(dir, "exit");
        // The monitor owns its daemon children. Tracer exit detaches tracees.
        maple::stop_child(monitor, status);
    }
    if (early > 0) {
        int early_status;
        maple::stop_child(early, early_status);
    }
    unlink((std::string(runtime) + "/monitor.pid").c_str());
    unlink((std::string(runtime) + "/auth.uids").c_str());
    bool normal = running && (stopping || (status >= 0 && WIFEXITED(status) && WEXITSTATUS(status) == 0));
    kernel_module::set_current_module_run_state(normal ? skroot_env::ModuleRunState::NotRunning : skroot_env::ModuleRunState::Abnormal);
    _exit(normal ? 0 : 1);
}

class WebUI final : public kernel_module::WebUIHttpHandler {
    std::unique_ptr<maple::webui::Api> api;
    bool reply(mg_connection *conn, const std::string &method, const std::string &path) {
        if (!path.starts_with("/api/")) return false;
        auto result = api->dispatch(method, path);
        const kernel_module::webui::KvMap headers{{"Cache-Control", "no-store"}};
        kernel_module::webui::send_json(conn, result.status, result.body, &headers);
        return true;
    }
public:
    void onPrepareCreate(const char *, const char *path, uint32_t) override {
        api = std::make_unique<maple::webui::Api>(path, [directory = std::string(path)](bool full) {
            bool pending = false;
            maple::restore_policy_notifications(&pending);
            auto receipt = maple_startup_policy_withdraw(directory.c_str(), full);
            // A byte-for-byte policy restore alone does not repair a suppressed
            // notification or prove that libselinux caches received the reload.
            bool coherent = sync_policy_notifications(directory, pending);
            if (!coherent && receipt.result == MAPLE_POLICY_DONE) receipt.result = MAPLE_POLICY_FAILED;
            write(std::string(runtime) + "/policy-action.state", "boot=" + read("/proc/sys/kernel/random/boot_id") +
                "action=" + (full ? "restore\n" : "temporary\n") + "result=" + std::to_string(receipt.result) +
                "\nuptime_ms=" + std::to_string(maple::millis()) + "\nnotifications_coherent=" + (coherent ? "1\n" : "0\n"));
            return receipt;
        });
    }
    bool handleGet(CivetServer *, mg_connection *conn, const std::string &path, const std::string &) override {
        return reply(conn, "GET", path);
    }
    bool handlePost(CivetServer *, mg_connection *conn, const std::string &path, const std::string &) override {
        return reply(conn, "POST", path);
    }
    ServerExitAction onBeforeServerExit() override {
        return ServerExitAction::KeepRunning;
    }
};}

int skroot_module_main(const char *, const char *path) {
    std::string dir(path);
    mkdir(runtime, 0700);
    chmod(runtime, 0700);
    mkdir((dir + "/data").c_str(), 0700);
    if (!publish(dir)) return 1;
    return launch(dir);
}
std::string module_on_install(const char *, const char *path) {
    std::string dir(path);
    mkdir(runtime, 0700);
    chmod(runtime, 0700);
    mkdir((dir + "/data").c_str(), 0700);
    if (!write(dir + "/module.prop", read(dir + "/payload/module.prop"), 0644))
        return "MapleSU Zygisk metadata deployment failed.";
    chmod((dir + "/bin/zygisk-ptrace64").c_str(), 0700);
    chmod((dir + "/bin/zygiskd64").c_str(), 0700);
    chmod((dir + "/bin/zygisk-ptrace32").c_str(), 0700);
    chmod((dir + "/bin/zygiskd32").c_str(), 0700);
    chmod((dir + "/bin/maplesu-policy").c_str(), 0700);
    return publish(dir) ? "" : "MapleSU Zygisk standard path is already owned by another installation.";
}
void module_on_uninstall(const char *, const char *path) {
    if (read(std::string(runtime) + "/published.path") != path) return;
    control(path, "exit");
    unpublish(path);
}
SKROOT_MODULE_NAME("MapleSU Zygisk")
SKROOT_MODULE_VERSION("5.1.2")
SKROOT_MODULE_DESC("MapleSU Ultra Zygisk host · API 1–5 · ARM64/ARM32. Reboot after installation.")
SKROOT_MODULE_AUTHOR("MapleSU; ReZygisk contributors")
SKROOT_MODULE_ID32("c45e8a7390b24987a4b01d6e2c5f9143")
SKROOT_MODULE_WEB_UI(WebUI)
SKROOT_MODULE_ON_INSTALL(module_on_install)
SKROOT_MODULE_ON_UNINSTALL(module_on_uninstall)

// LSPosed daemon shared data only. No code is injected into application processes.
#include <dlfcn.h>
#include <dirent.h>
#include <ftw.h>
#include <stdio.h>
#include <sys/xattr.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

static int migrate_shared(const char *path, const struct stat *info, int kind, struct FTW *walk) {
    (void)info; (void)kind; (void)walk;
    char previous[1024], next[1024];
    const char prefix[] = "u:object_r:lsposed_file:";
    ssize_t size = lgetxattr(path, "security.selinux", previous, sizeof(previous) - 1);
    if (size <= 0) return 0;
    previous[size] = 0;
    if (strncmp(previous, prefix, sizeof(prefix) - 1)) return 0;
    int (*original)(const char *, const char *) = dlsym(RTLD_NEXT, "lsetfilecon");
    if (!original) return 0;
    snprintf(next, sizeof(next), "u:object_r:media_rw_data_file:%s", previous + sizeof(prefix) - 1);
    if (original(path, next)) fprintf(stderr, "shared-file migration failed: %s errno=%d\n", path, errno);
    return 0;
}
static void migrate_existing(void) {
    const char *roots[] = {"/data/misc", "/data/misc/apexdata"};
    for (size_t i = 0; i < sizeof(roots) / sizeof(*roots); ++i) {
        DIR *directory = opendir(roots[i]);
        if (!directory) continue;
        struct dirent *entry;
        while ((entry = readdir(directory))) {
            if (strlen(entry->d_name) != 36) continue;
            char path[4096], context[1024];
            snprintf(path, sizeof(path), "%s/%s", roots[i], entry->d_name);
            ssize_t size = lgetxattr(path, "security.selinux", context, sizeof(context) - 1);
            if (size <= 0) continue;
            context[size] = 0;
            // Only a directory already carrying LSPosed's own label is traversed.
            if (!strncmp(context, "u:object_r:lsposed_file:", sizeof("u:object_r:lsposed_file:") - 1)) nftw(path, migrate_shared, 16, FTW_PHYS);
        }
        closedir(directory);
    }
    nftw("/data/adb/lspd/modules", migrate_shared, 16, FTW_PHYS);
}

static const char *shared_context(const char *context) {
    return context && !strcmp(context, "u:object_r:lsposed_file:s0")
        ? "u:object_r:media_rw_data_file:s0" : context;
}

#define EXPORTED __attribute__((visibility("default")))
EXPORTED int setfilecon(const char *path, const char *context) {
    int (*original)(const char *, const char *) = dlsym(RTLD_NEXT, "setfilecon");
    if (!original) { errno = ENOSYS; return -1; }
    return original(path, shared_context(context));
}
EXPORTED int lsetfilecon(const char *path, const char *context) {
    int (*original)(const char *, const char *) = dlsym(RTLD_NEXT, "lsetfilecon");
    if (!original) { errno = ENOSYS; return -1; }
    return original(path, shared_context(context));
}
EXPORTED int fsetfilecon(int fd, const char *context) {
    int (*original)(int, const char *) = dlsym(RTLD_NEXT, "fsetfilecon");
    if (!original) { errno = ENOSYS; return -1; }
    return original(fd, shared_context(context));
}

// Keep the adapter in the daemon only; its later child processes use their
// original environment. The module's shell/native launcher must pass it on.
__attribute__((constructor)) static void daemon_environment(void) {
    char executable[4096];
    ssize_t size = readlink("/proc/self/exe", executable, sizeof(executable) - 1);
    if (size < 0) return;
    executable[size] = 0;
    if (!strstr(executable, "/app_process")) return;
    const char *previous = getenv("MAPLESU_LSP_PRELOAD");
    if (previous && *previous) setenv("LD_PRELOAD", previous, 1);
    else unsetenv("LD_PRELOAD");
    unsetenv("MAPLESU_LSP_PRELOAD");
    migrate_existing();
}

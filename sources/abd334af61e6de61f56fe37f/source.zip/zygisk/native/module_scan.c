#include "module_scan.h"
#include <dirent.h>
#include <fcntl.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static int valid_module(int fd, const char *name) {
    if (name[0] == '.' || strcmp(name, "maplesu_zygisk") == 0) return 0;
    for (const char *p = name; *p; ++p)
        if (!((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
              (*p >= '0' && *p <= '9') || *p == '.' || *p == '_' || *p == '-')) return 0;
    if (faccessat(fd, "disable", F_OK, 0) == 0 || faccessat(fd, "remove", F_OK, 0) == 0) return 0;
    int prop = openat(fd, "module.prop", O_RDONLY | O_CLOEXEC);
    if (prop < 0) return 0;
    FILE *file = fdopen(prop, "r");
    if (!file) { close(prop); return 0; }
    char line[1024];
    int matched = 0;
    while (fgets(line, sizeof(line), file)) {
        if (strncmp(line, "id=", 3) != 0) continue;
        line[strcspn(line, "\r\n")] = 0;
        matched = strcmp(line + 3, name) == 0;
        break;
    }
    fclose(file);
    return matched;
}

void maple_free_modules(struct maple_module *modules, size_t count) {
    for (size_t i = 0; i < count; ++i) {
        free(modules[i].name);
        free(modules[i].path);
        if (modules[i].dir_fd >= 0) close(modules[i].dir_fd);
        if (modules[i].lib_fd >= 0) close(modules[i].lib_fd);
        if (modules[i].companion >= 0) close(modules[i].companion);
    }
    free(modules);
}

static int compare_modules(const void *a, const void *b) {
    return strcmp(((const struct maple_module *)a)->name, ((const struct maple_module *)b)->name);
}

int maple_scan_modules(const char *root, const char *abi, struct maple_module **out, size_t *count) {
    return maple_scan_ultra_modules(root, abi, MAPLE_ZYGISK_REVISIONS, out, count);
}

int maple_scan_ultra_modules(const char *root, const char *abi, const char *revisions, struct maple_module **out, size_t *count) {
    *out = NULL;
    *count = 0;
    DIR *dir = opendir(root);
    if (!dir) return -1;
    char library[128];
    if (snprintf(library, sizeof(library), "zygisk/%s.so", abi ? abi : "arm64-v8a") >= (int)sizeof(library)) {
        closedir(dir); return -1;
    }
    struct dirent *entry;
    while ((entry = readdir(dir))) {
        // openat follows MapleSU's published directory links, also handling DT_UNKNOWN.
        int fd = openat(dirfd(dir), entry->d_name, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
        if (fd < 0) continue;
        if (!valid_module(fd, entry->d_name)) { close(fd); continue; }
        int lib = openat(fd, library, O_RDONLY | O_CLOEXEC);
        if (lib < 0 && !abi) lib = openat(fd, "zygisk/armeabi-v7a.so", O_RDONLY | O_CLOEXEC);
        if (lib < 0) { close(fd); continue; }
        char link[64], path[PATH_MAX];
        snprintf(link, sizeof(link), "/proc/self/fd/%d", fd);
        ssize_t n = readlink(link, path, sizeof(path) - 1);
        if (n < 0) { close(lib); close(fd); continue; }
        path[n] = 0;
        if (!maple_ultra_module(path, root, revisions)) { close(lib); close(fd); continue; }
        struct maple_module m = {
            .name = strdup(entry->d_name), .path = strdup(path),
            .dir_fd = fd, .lib_fd = lib, .companion = -1
        };
        struct maple_module *next = realloc(*out, (*count + 1) * sizeof(m));
        if (!m.name || !m.path || !next) {
            free(m.name); free(m.path); close(lib); close(fd);
            if (next) *out = next;
            maple_free_modules(*out, *count);
            *out = NULL; *count = 0; closedir(dir); return -1;
        }
        *out = next;
        (*out)[(*count)++] = m;
    }
    closedir(dir);
    if (*count > 1) qsort(*out, *count, sizeof(**out), compare_modules);
    return 0;
}

#pragma once
#include <stddef.h>
#include "module_scope.h"
#ifdef __cplusplus
extern "C" {
#endif
struct maple_module {
    char *name;
    char *path;
    int dir_fd;
    int lib_fd;
    int companion;
};
// A NULL ABI enumerates either ARM payload for shared early lifecycle scripts.
int maple_scan_modules(const char *root, const char *abi, struct maple_module **out, size_t *count);
int maple_scan_ultra_modules(const char *root, const char *abi, const char *revisions, struct maple_module **out, size_t *count);
void maple_free_modules(struct maple_module *modules, size_t count);
#ifdef __cplusplus
}
#endif

// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <inttypes.h>
#define MAPLE_ZYGISK_REVISIONS "/data/user_de/0/dev.maplesu.manager/files/module-zygisk/revisions"

// Retained for old Manager publications which pointed at a private revision.
static inline int maple_ultra_revision(const char *path, const char *revisions) {
    char root[PATH_MAX];
    if (!realpath(revisions, root)) return 0;
    size_t size = strlen(root);
    return strncmp(path, root, size) == 0 && path[size] == '/' && path[size + 1] &&
        !strchr(path + size + 1, '/');
}

// KSU modules stay in the shared root across a Normal/Ultra switch. Accept real
// installed directories as well as the Manager's old private revision links.
static inline int maple_ultra_module(const char *path, const char *modules, const char *revisions) {
    if (maple_ultra_revision(path, revisions)) return 1;
    char root[PATH_MAX], marker[PATH_MAX];
    if (!realpath(modules, root)) return 0;
    size_t size = strlen(root);
    if (strncmp(path, root, size) || path[size] != '/' || !path[size + 1] || strchr(path + size + 1, '/')) return 0;
    if (snprintf(marker, sizeof(marker), "%s/module.prop", path) >= (int)sizeof(marker)) return 0;
    struct stat st;
    if (lstat(marker, &st) || !S_ISREG(st.st_mode)) return 0;
    if (stat(path, &st) || !S_ISDIR(st.st_mode)) return 0;
    if (snprintf(marker, sizeof(marker), "%s/.maplesu-ultra/%ju-%ju", root,
            (uintmax_t)st.st_dev, (uintmax_t)st.st_ino) >= (int)sizeof(marker)) return 0;
    if (lstat(marker, &st) != 0) {
        if (snprintf(marker, sizeof(marker), "%s/.maplesu-ultra", path) >= (int)sizeof(marker)) return 0;
    }
    int fd = open(marker, O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) return 0;
    char value[66];
    ssize_t n = read(fd, value, sizeof(value));
    close(fd);
    if (n != 65 || value[64] != '\n') return 0;
    for (int i = 0; i < 64; ++i)
        if (!((value[i] >= '0' && value[i] <= '9') || (value[i] >= 'a' && value[i] <= 'f'))) return 0;
    return 1;
}

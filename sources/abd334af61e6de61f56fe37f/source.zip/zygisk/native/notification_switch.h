// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <stddef.h>
#include <stdint.h>

namespace maple {
// SDK96's notifier wrappers share one byte controlling whether the real kernel
// functions run. Decode its generated instructions rather than retaining an
// address across boots. An unfamiliar wrapper leaves the SDK state untouched.
template<class Read> uint64_t notification_switch(uint64_t address, Read read, const char** failure = nullptr) {
    if (failure) *failure = nullptr;
    auto fail = [failure](const char* reason) -> uint64_t {
        if (failure) *failure = reason;
        return 0;
    };
    uint32_t entry = 0;
    if (!read(address, &entry, sizeof(entry))) return fail("entry read failed");
    if (entry == 0xd503233f || entry == 0xd503245f) { // PACIASP / BTI c
        address += 4;
        if (!read(address, &entry, sizeof(entry))) return fail("entry read failed");
    }
    if ((entry & 0xfc000000) != 0x14000000) return fail("entry branch not recognized");
    int64_t offset = (int64_t(int32_t(entry << 6)) >> 6) * 4;
    uint64_t trampoline = address + offset;
    uint32_t wrapper[20] = {};
    if (!read(trampoline, wrapper, 8 * sizeof(uint32_t))) return fail("trampoline read failed");
    if (wrapper[0] != 0xd10143ff || wrapper[1] != 0xa9bf7bfd) return fail("trampoline not recognized");
    size_t i = 2, limit = 8, gate_branch = 0;
    if (wrapper[i] != 0xa9bf7ffc) {
        // New helper wrappers put a per-hook bypass gate before the callback.
        // It is not the SELinux notification switch: only decode past it.
        if ((wrapper[i] & 0xff80001f) != 0xd280001d) return fail("trampoline not recognized");
        if (!read(trampoline + 32, wrapper + 8, sizeof(wrapper) - 32)) return fail("gated trampoline read failed");
        limit = 20;
        uint64_t gate = uint64_t((wrapper[i] >> 5) & 0xffff) << (((wrapper[i] >> 21) & 3) * 16);
        for (++i; i < 6 && (wrapper[i] & 0xff80001f) == 0xf280001d; ++i) {
            unsigned shift = ((wrapper[i] >> 21) & 3) * 16;
            gate = (gate & ~(uint64_t(0xffff) << shift)) | (uint64_t((wrapper[i] >> 5) & 0xffff) << shift);
        }
        if (gate < 0xffff000000000000ULL || wrapper[i++] != 0x394003bd ||
            (wrapper[i] & 0xff00001f) != 0x3500001d) return fail("hook gate not recognized");
        gate_branch = i++;
        if (wrapper[i++] != 0xa8c17bfd || wrapper[i++] != 0xa9bf7bfd) return fail("hook gate frame not recognized");
    }
    if (wrapper[i++] != 0xa9bf7ffc || (wrapper[i] & 0xff80001f) != 0xd280001c)
        return fail("trampoline not recognized");
    uint64_t callback = uint64_t((wrapper[i] >> 5) & 0xffff) << (((wrapper[i] >> 21) & 3) * 16);
    ++i;
    // Zero halfwords are omitted by the SDK assembler after address relocation.
    for (; i < limit && (wrapper[i] & 0xff80001f) == 0xf280001c; ++i) {
        unsigned shift = ((wrapper[i] >> 21) & 3) * 16;
        callback = (callback & ~(uint64_t(0xffff) << shift)) | (uint64_t((wrapper[i] >> 5) & 0xffff) << shift);
    }
    if (i == limit || wrapper[i] != 0xd63f0380) return fail("callback branch not recognized");
    if (gate_branch) {
        int64_t target = int64_t(gate_branch) + (int64_t(int32_t(wrapper[gate_branch] << 8)) >> 13);
        if (target != int64_t(i + 1) || i + 2 >= limit || wrapper[i + 1] != 0xa8c17bfd || wrapper[i + 2] != 0x910143ff)
            return fail("hook gate target not recognized");
    }
    if (callback < 0xffff000000000000ULL) return fail("callback address rejected");
    uint32_t code[128] = {};
    if (!read(callback, code, sizeof(code))) return fail("callback read failed");
    uint64_t result = 0, candidate = 0;
    bool started = false;
    for (size_t i = 0; i + 1 < 128; ++i) {
        uint32_t word = code[i];
        if ((word & 0xff80001f) == 0xd280000a) {
            candidate = uint64_t((word >> 5) & 0xffff) << (((word >> 21) & 3) * 16);
            started = true;
        } else if (started && (word & 0xff80001f) == 0xf280000a) {
            unsigned shift = ((word >> 21) & 3) * 16;
            candidate = (candidate & ~(uint64_t(0xffff) << shift)) | (uint64_t((word >> 5) & 0xffff) << shift);
        } else if (started && word == 0x3940014a && (code[i + 1] & 0xff00001f) == 0x3400000a) {
            if (result) return fail("ambiguous switch");
            if (candidate < 0xffff000000000000ULL) return fail("switch address rejected");
            result = candidate;
            started = false;
        } else started = false;
    }
    return result ? result : fail("switch not recognized");
}
}

// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include "notification_switch.h"
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

namespace maple {
// Policy bytes do not contain the status-page notification state. Check the
// actual status/access contract separately after a restore or real reload.
inline bool policy_notifications_consistent() {
    auto status = [](uint32_t (&value)[5]) {
        int fd = open("/sys/fs/selinux/status", O_RDONLY | O_CLOEXEC | O_NONBLOCK);
        if (fd < 0) return false;
        bool ok = ::read(fd, value, sizeof(value)) == sizeof(value);
        close(fd);
        return ok;
    };
    char text[256] = {};
    int fd = open("/sys/fs/selinux/class/process/index", O_RDONLY | O_CLOEXEC | O_NONBLOCK);
    if (fd < 0) return false;
    ssize_t length = ::read(fd, text, sizeof(text) - 1);
    close(fd);
    unsigned cls = 0;
    if (length <= 0 || sscanf(text, "%u", &cls) != 1 || !cls) return false;
    char query[128];
    int size = snprintf(query, sizeof(query), "u:r:system_server:s0 u:r:system_server:s0 %u", cls);
    for (int attempt = 0; attempt < 3; ++attempt) {
        uint32_t before[5] = {}, after[5] = {};
        if (!status(before)) return false;
        fd = open("/sys/fs/selinux/access", O_RDWR | O_CLOEXEC | O_NONBLOCK);
        if (fd < 0) return false;
        bool written = ::write(fd, query, size) == size;
        length = written ? ::read(fd, text, sizeof(text) - 1) : -1;
        close(fd);
        if (length <= 0 || !status(after)) return false;
        text[length] = 0;
        unsigned allowed, decided, auditallow, auditdeny, seqno, flags;
        if (sscanf(text, "%x %x %x %x %u %x", &allowed, &decided, &auditallow, &auditdeny, &seqno, &flags) != 6)
            return false;
        if (memcmp(before, after, sizeof(before)) || (before[1] & 1)) continue;
        if (before[3] == seqno) return true;
        fprintf(stderr, "policy notifications: status.sequence=%u status.policyload=%u access.avd.seqno=%u\n",
            before[1], before[3], seqno);
        return false;
    }
    return false;
}
inline bool restore_policy_notifications(bool* changed = nullptr) {
    if (changed) *changed = false;
    uint64_t switches[2] = {};
    const char* names[] = {"selinux_status_update_policyload", "selinux_status_update_setenforce"};
    auto read = [](uint64_t address, void* data, uint32_t size) {
        return !is_failed(kernel_module::read_kernel_mem(address, data, size));
    };
    for (int i = 0; i < 2; ++i) {
        uint64_t address = 0;
        auto error = kernel_module::kallsyms_lookup_name(names[i], address);
        if (is_failed(error) || !address) {
            fprintf(stderr, "policy notifications: %s lookup failed error=%lld\n", names[i], static_cast<long long>(error));
            return false;
        }
        const char* failure = nullptr;
        switches[i] = notification_switch(address, read, &failure);
        if (!switches[i]) {
            fprintf(stderr, "policy notifications: %s: %s\n", names[i], failure);
            return false;
        }
    }
    if (switches[0] != switches[1]) {
        fprintf(stderr, "policy notifications: wrappers do not share a switch\n");
        return false;
    }
    uint8_t value = 255;
    if (!read(switches[0], &value, 1) || value > 1) {
        fprintf(stderr, "policy notifications: switch read failed or value rejected\n");
        return false;
    }
    if (value == 0) return true;
    uint8_t normal = 0;
    bool written = !is_failed(kernel_module::write_kernel_mem(switches[0], &normal, 1));
    // The caller owes a policy reload once a write succeeds, even if its
    // verification read fails and a later attempt finds the switch already zero.
    if (changed) *changed = written;
    if (!written) {
        fprintf(stderr, "policy notifications: switch write failed\n");
        return false;
    }
    bool verified = read(switches[0], &value, 1) && value == 0;
    if (!verified) fprintf(stderr, "policy notifications: switch verification failed\n");
    return verified;
}
}

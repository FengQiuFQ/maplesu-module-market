// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <cerrno>
#include <csignal>
#include <sys/prctl.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

namespace maple {
inline long long millis() {
    timespec now{};
    clock_gettime(CLOCK_MONOTONIC, &now);
    return now.tv_sec * 1000LL + now.tv_nsec / 1000000;
}
// Only a still-unreaped child may be signalled: never act on a saved, reused PID.
inline bool wait_child(pid_t child, int &status, int timeout_ms) {
    auto end = millis() + timeout_ms;
    do {
        errno = 0;
        pid_t result = waitpid(child, &status, WNOHANG);
        if (result == child) return true;
        if (result < 0 && errno != EINTR) return false;
        if (millis() >= end) return false;
        usleep(10000);
    } while (true);
}
inline void stop_child(pid_t child, int &status) {
    if (wait_child(child, status, 300) || errno == ECHILD) return;
    kill(child, SIGTERM);
    if (wait_child(child, status, 300) || errno == ECHILD) return;
    kill(child, SIGKILL);
    while (waitpid(child, &status, 0) < 0 && errno == EINTR) {}
}
inline void follow_parent(pid_t parent) {
    if (prctl(PR_SET_PDEATHSIG, SIGTERM) != 0 || getppid() != parent) _exit(125);
    // The owner handles TERM; executables and helpers use its default action.
    signal(SIGTERM, SIG_DFL);
}
}

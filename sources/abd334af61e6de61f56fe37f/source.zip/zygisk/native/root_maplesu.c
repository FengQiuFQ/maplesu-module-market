// MapleSU has its own root provider; do not pretend that a KSU kernel is installed.
#include "root_impl/common.h"
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>

void root_impls_setup(void) {}
void get_impl(struct root_impl *impl) { *impl = (struct root_impl){ .impl = MapleSU, .variant = 0 }; }
bool uid_granted_root(uid_t uid) {
    // Atomically replaced by the SDK owner. Read each query so revocation is observed.
    FILE *file = fopen("/data/adb/maplesu_zygisk/auth.uids", "r");
    if (!file) return false;
    unsigned int granted;
    bool found = false;
    while (fscanf(file, "%u", &granted) == 1) {
        if (granted == uid) { found = true; break; }
    }
    fclose(file);
    return found;
}
bool uid_should_umount(uid_t uid, const char *const process) {
    (void)uid; (void)process;
    // Ultra has no KSU/Magisk denylist. Explicit Zygisk unmount requests still work.
    return false;
}
uid_t uid_from_pkg(const char *restrict pkg) {
    char path[512];
    struct stat st;
    snprintf(path, sizeof(path), "/data/user_de/0/%s", pkg);
    return stat(path, &st) == 0 ? st.st_uid % 100000 : 0;
}
bool uid_is_manager(uid_t uid) {
    uid_t manager = uid_from_pkg("dev.maplesu.manager");
    return manager != 0 && uid % 100000 == manager;
}
void root_impl_cleanup(void) {}

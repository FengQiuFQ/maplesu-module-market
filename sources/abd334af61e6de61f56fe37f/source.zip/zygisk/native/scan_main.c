#include "module_scan.h"
#include <stdio.h>
int main(int argc, char **argv) {
    if (argc != 3 && argc != 4) return 2;
    struct maple_module *modules;
    size_t count;
    if (maple_scan_ultra_modules(argv[1], argv[2], argc == 4 ? argv[3] : MAPLE_ZYGISK_REVISIONS, &modules, &count) != 0) return 1;
    for (size_t i = 0; i < count; ++i) {
        printf("%s\t%s\n", modules[i].name, modules[i].path);
        // getModuleDir must refer to the same complete revision as the loaded library.
        if (modules[i].dir_fd < 0 || modules[i].lib_fd < 0) return 3;
    }
    maple_free_modules(modules, count);
    return 0;
}

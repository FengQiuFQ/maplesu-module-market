// SPDX-License-Identifier: AGPL-3.0-or-later
#include "startup_policy.h"
#include "module_scan.h"
#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#ifndef MAPLE_STARTUP_RUNTIME
#define MAPLE_STARTUP_RUNTIME "/data/adb/maplesu_zygisk"
#define MAPLE_STARTUP_MODULES "/data/adb/modules"
#define MAPLE_STARTUP_REVISIONS MAPLE_ZYGISK_REVISIONS
#define MAPLE_STARTUP_MISC "/data/misc"
#endif

#ifndef MAPLE_LSPOSED_CONFIG
#define MAPLE_LSPOSED_CONFIG "/data/adb/lspd/config/modules_config.db"
#endif

struct hma_file_stamp {
    uint64_t device, inode;
    int64_t modified_sec, modified_ns, changed_sec, changed_ns;
};
struct startup_window {
    char boot[40];
    int original, closed, retained;
    int64_t started, ready_since;
    struct hma_file_stamp hma_before;
};
_Static_assert(sizeof(struct startup_window) == 120, "ARM32 and ARM64 share one window record");
static bool hma_status(struct hma_file_stamp *stamp);

static int64_t window_millis(void) {
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    return now.tv_sec * 1000LL + now.tv_nsec / 1000000;
}

static int window_lock(bool wait) {
    int fd = open(MAPLE_STARTUP_RUNTIME "/startup-policy", O_RDWR | O_CREAT | O_CLOEXEC | O_NOFOLLOW, 0600);
    if (fd < 0) return -1;
    int64_t until = window_millis() + (wait ? 3000 : 0);
    do {
        if (flock(fd, LOCK_EX | LOCK_NB) == 0) return fd;
        if (errno != EWOULDBLOCK && errno != EINTR) break;
        if (window_millis() >= until) break;
        usleep(10000);
    } while (true);
    close(fd);
    return -1;
}

static bool window_read(int fd, struct startup_window *state) {
    char boot[40] = {0};
    FILE *file = fopen("/proc/sys/kernel/random/boot_id", "r");
    if (!file) return false;
    bool ok = fscanf(file, "%39s", boot) == 1;
    fclose(file);
    if (!ok) return false;
    return pread(fd, state, sizeof(*state), 0) == sizeof(*state) &&
        memcmp(state->boot, boot, sizeof(boot)) == 0;
}

static bool window_save(int fd, const struct startup_window *state) {
    return pwrite(fd, state, sizeof(*state), 0) == sizeof(*state) && ftruncate(fd, sizeof(*state)) == 0;
}

static int execmem_allowed(void) {
    unsigned cls = 0, bit = 0, allowed = 0;
    FILE *file = fopen("/sys/fs/selinux/class/process/index", "r");
    if (!file) return -1;
    bool ok = fscanf(file, "%u", &cls) == 1;
    fclose(file);
    file = fopen("/sys/fs/selinux/class/process/perms/execmem", "r");
    if (!file) return -1;
    ok = ok && fscanf(file, "%u", &bit) == 1 && bit > 0 && bit <= 32;
    fclose(file);
    if (!ok) return -1;
    int fd = open("/sys/fs/selinux/access", O_RDWR | O_CLOEXEC);
    if (fd < 0) return -1;
    char text[256];
    int n = snprintf(text, sizeof(text), "u:r:system_server:s0 u:r:system_server:s0 %u", cls);
    ok = write(fd, text, n) == n;
    ssize_t size = ok ? read(fd, text, sizeof(text) - 1) : -1;
    close(fd);
    if (size <= 0) return -1;
    text[size] = 0;
    if (sscanf(text, "%x", &allowed) != 1) return -1;
    return (allowed & (1u << (bit - 1))) != 0;
}

static bool window_execute(char *const args[], int timeout_ms) {
    pid_t parent = getpid(), child = fork();
    if (child == 0) {
        if (prctl(PR_SET_PDEATHSIG, SIGKILL) != 0 || getppid() != parent) _exit(125);
        execv(args[0], args);
        _exit(127);
    }
    if (child < 0) return false;
    int status = 0;
    int64_t until = window_millis() + timeout_ms;
    pid_t result;
    do {
        result = waitpid(child, &status, WNOHANG);
        if (result == child) return WIFEXITED(status) && WEXITSTATUS(status) == 0;
        if (result < 0 && errno != EINTR) return false;
        usleep(10000);
    } while (window_millis() < until);
    kill(child, SIGKILL);
    while (waitpid(child, &status, 0) < 0 && errno == EINTR) {}
    return false;
}

static bool window_apply(const char *host, bool grant, struct maple_module *modules, size_t count) {
    char tool[4096], rule[4096];
    snprintf(tool, sizeof(tool), "%s/bin/maplesu-policy", host);
    snprintf(rule, sizeof(rule), "%s/%s-policy.rule", host, grant ? "startup" : "steady");
    char **args = calloc(6 + count * 2, sizeof(*args));
    char **rules = calloc(count ? count : 1, sizeof(*rules));
    if (!args || !rules) { free(args); free(rules); return false; }
    size_t at = 0;
    args[at++] = tool; args[at++] = "apply"; args[at++] = "--rules"; args[at++] = rule;
    for (size_t i = 0; i < count; ++i) {
        if (faccessat(modules[i].dir_fd, "sepolicy.rule", F_OK, 0) != 0) continue;
        if (asprintf(&rules[i], "%s/sepolicy.rule", modules[i].path) < 0) {
            for (size_t j = 0; j < i; ++j) free(rules[j]);
            free(rules); free(args); return false;
        }
        args[at++] = "--rules"; args[at++] = rules[i];
    }
    bool ok = window_execute(args, 2000);
    for (size_t i = 0; i < count; ++i) free(rules[i]);
    free(rules); free(args);
    return ok;
}

static bool boot_marker(const char *path, const char *boot) {
    char value[40] = {0};
    FILE *file = fopen(path, "r");
    if (!file) return false;
    bool ok = fscanf(file, "%39s", value) == 1 && !strcmp(value, boot);
    fclose(file);
    return ok;
}

static bool write_boot_marker(const char *path, const char *boot) {
    char temporary[4096];
    snprintf(temporary, sizeof(temporary), "%s.tmp", path);
    int fd = open(temporary, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC | O_NOFOLLOW, 0600);
    if (fd < 0) return false;
    size_t size = strlen(boot);
    bool ok = write(fd, boot, size) == (ssize_t)size && fsync(fd) == 0;
    if (close(fd) != 0) ok = false;
    if (ok) ok = rename(temporary, path) == 0;
    if (!ok) unlink(temporary);
    return ok;
}

static bool baseline_tool(const char *host, bool restore) {
    char tool[4096];
    snprintf(tool, sizeof(tool), "%s/bin/maplesu-policy", host);
    char *args[] = {tool, restore ? "restore" : "save", restore ? "--policy" : "--output",
        MAPLE_STARTUP_RUNTIME "/policy-baseline", NULL};
    return window_execute(args, restore ? 5000 : 2000);
}

bool maple_startup_policy_snapshot(const char *host) {
    int fd = window_lock(true);
    if (fd < 0) return false;
    char boot[40] = {0};
    FILE *file = fopen("/proc/sys/kernel/random/boot_id", "r");
    bool ok = file && fscanf(file, "%39s", boot) == 1;
    if (file) fclose(file);
    if (ok && boot_marker(MAPLE_STARTUP_RUNTIME "/policy-baseline.boot", boot)) {
        close(fd);
        return access(MAPLE_STARTUP_RUNTIME "/policy-baseline", R_OK) == 0;
    }
    struct startup_window state;
    // A same-boot record proves that this host may already have changed policy.
    if (ok && !window_read(fd, &state)) {
        ok = baseline_tool(host, false) && write_boot_marker(MAPLE_STARTUP_RUNTIME "/policy-baseline.boot", boot);
    } else ok = false;
    close(fd);
    return ok;
}

bool maple_startup_policy_restored(void) {
    char boot[40] = {0};
    FILE *file = fopen("/proc/sys/kernel/random/boot_id", "r");
    if (!file) return false;
    bool ok = fscanf(file, "%39s", boot) == 1;
    fclose(file);
    // The marker is atomically renamed; reading it never fails just because a
    // policy transaction holds the window lock during a host restart.
    return ok && boot_marker(MAPLE_STARTUP_RUNTIME "/policy-restored", boot);
}

bool maple_startup_policy_needed(void) {
    struct maple_module *modules = NULL;
    size_t count = 0;
    bool needed = maple_scan_ultra_modules(MAPLE_STARTUP_MODULES, NULL, MAPLE_STARTUP_REVISIONS, &modules, &count) != 0 || count != 0;
    maple_free_modules(modules, count);
    return needed;
}

void maple_startup_policy_init(void) {
    int fd = window_lock(true);
    if (fd < 0) return;
    struct startup_window state = {0};
    if (!window_read(fd, &state)) {
        memset(&state, 0, sizeof(state));
        FILE *file = fopen("/proc/sys/kernel/random/boot_id", "r");
        if (!file) { close(fd); return; }
        bool ok = fscanf(file, "%39s", state.boot) == 1;
        fclose(file);
        if (!ok) { close(fd); return; }
        // Unknown is retained, never interpreted as a permission we own.
        state.original = execmem_allowed() != 0;
    }
    state.closed = boot_marker(MAPLE_STARTUP_RUNTIME "/policy-restored", state.boot);
    state.retained = 0;
    state.started = window_millis();
    state.ready_since = 0;
    hma_status(&state.hma_before);
    window_save(fd, &state);
    close(fd);
}

bool maple_startup_policy_prepare(const char *host) {
    int fd = window_lock(true);
    if (fd < 0) return false;
    struct startup_window state;
    if (!window_read(fd, &state)) { close(fd); return false; }
    if (boot_marker(MAPLE_STARTUP_RUNTIME "/policy-restored", state.boot)) { close(fd); return true; }
    bool ok = true;
    struct maple_module *modules = NULL;
    size_t count = 0;
    bool scanned = maple_scan_ultra_modules(MAPLE_STARTUP_MODULES, NULL, MAPLE_STARTUP_REVISIONS, &modules, &count) == 0;
    // No module will run system_server hooks: do not create a detectable grant
    // merely because a new server has requested its preparation window.
    bool needed = !scanned || count != 0;
    if (state.closed && needed) ok = scanned && window_apply(host, true, modules, count);
    if (!needed && !state.original && !state.closed)
        ok = window_apply(host, false, modules, count) && execmem_allowed() == 0;
    maple_free_modules(modules, count);
    if (ok) {
        state.closed = !needed;
        state.retained = 0;
        state.started = window_millis();
        state.ready_since = 0;
        hma_status(&state.hma_before);
        ok = window_save(fd, &state);
    }
    close(fd);
    return ok;
}

static bool hma_status(struct hma_file_stamp *stamp) {
    memset(stamp, 0, sizeof(*stamp));
    DIR *dir = opendir(MAPLE_STARTUP_MISC);
    if (!dir) return false;
    bool ready = false;
    size_t found = 0;
    struct dirent *entry;
    while ((entry = readdir(dir))) {
        if (strncmp(entry->d_name, "hide_my_applist_", 16) != 0) continue;
        char path[4096], text[512] = {0};
        snprintf(path, sizeof(path), MAPLE_STARTUP_MISC "/%s/status.json", entry->d_name);
        struct stat st;
        if (stat(path, &st) != 0) continue;
        if (++found > 1) { ready = false; break; }
        *stamp = (struct hma_file_stamp){st.st_dev, st.st_ino, st.st_mtim.tv_sec, st.st_mtim.tv_nsec,
            st.st_ctim.tv_sec, st.st_ctim.tv_nsec};
        FILE *file = fopen(path, "r");
        if (!file) continue;
        size_t size = fread(text, 1, sizeof(text) - 1, file);
        fclose(file);
        if (!size) continue;
        char *key = strstr(text, "\"workMode\"");
        char *value = key ? strchr(key + 10, ':') : NULL;
        int mode = 0;
        char end = 0;
        if (value && sscanf(value + 1, " %d %c", &mode, &end) == 2 && mode == 1 && (end == ',' || end == '}')) {
            ready = true;
        }
    }
    closedir(dir);
    return ready;
}

static int android_scope(void *found, int count, char **values, char **names) {
    (void)count; (void)values; (void)names;
    *(bool *)found = true;
    return 0;
}
static bool lsposed_dynamic_server_hooks(void) {
    // Framework-scoped modules may allocate new trampolines at any time. Only
    // an explicit empty enabled scope lets us release our initialization grant.
    void *library = dlopen("libsqlite.so", RTLD_NOW | RTLD_LOCAL);
    if (!library) return true;
    int (*open_db)(const char *, void **, int, const char *) = dlsym(library, "sqlite3_open_v2");
    int (*query)(void *, const char *, int (*)(void *, int, char **, char **), void *, char **) = dlsym(library, "sqlite3_exec");
    int (*close_db)(void *) = dlsym(library, "sqlite3_close");
    void *db = NULL;
    bool needed = true, found = false;
    if (open_db && query && close_db && open_db(MAPLE_LSPOSED_CONFIG, &db, 1, NULL) == 0) {
        const char *sql = "SELECT 1 FROM scope s JOIN modules_state m "
            "ON s.module_pkg_name=m.module_pkg_name AND s.user_id=m.user_id "
            "WHERE s.app_pkg_name='android' AND m.enabled=1 LIMIT 1";
        if (query(db, sql, android_scope, &found, NULL) == 0) needed = found;
    }
    if (db && close_db) close_db(db);
    dlclose(library);
    return needed;
}

void maple_startup_policy_finish(const char *host, bool scripts_ready) {
    int fd = window_lock(false);
    if (fd < 0) return;
    struct startup_window state;
    if (!window_read(fd, &state) || state.original || state.closed || state.retained ||
        boot_marker(MAPLE_STARTUP_RUNTIME "/policy-restored", state.boot)) { close(fd); return; }
    int64_t now = window_millis();
    if (now - state.started >= 180000) {
        state.retained = 1;
        fprintf(stderr, "startup policy retained: initialization deadline\n");
    } else if (scripts_ready) {
        struct maple_module *modules = NULL;
        size_t count = 0;
        bool scanned = maple_scan_ultra_modules(MAPLE_STARTUP_MODULES, NULL, MAPLE_STARTUP_REVISIONS, &modules, &count) == 0;
        bool hma = false, supported = scanned;
        for (size_t i = 0; i < count; ++i) {
            if (!strcmp(modules[i].name, "hma_oss_zygisk")) hma = true;
            else if (!strcmp(modules[i].name, "zygisk_lsposed")) supported &= !lsposed_dynamic_server_hooks();
            else supported = false;
        }
        if ((!hma && count != 0) || !supported) {
            state.retained = 1;
            fprintf(stderr, "startup policy retained: hma=%d supported_scope=%d modules=%zu scanned=%d\n",
                hma, supported, count, scanned);
        } else {
            struct hma_file_stamp current;
            // Compare this file generation, not wall-clock ordering: Android
            // can correct its clock between Zygote and framework startup.
            bool initialized = count == 0 ||
                (hma_status(&current) && memcmp(&current, &state.hma_before, sizeof(current)) != 0);
            if (!initialized) state.ready_since = 0;
            else {
                state.ready_since = now;
                bool applied = window_apply(host, false, modules, count);
                int allowed = execmem_allowed();
                if (applied && allowed == 0) {
                    state.closed = 1;
                    fprintf(stderr, "startup policy closed: %s\n", count ? "HMA initialized" : "no active Zygisk modules");
                } else {
                    // A declared module allow wins; an uncertain transaction
                    // restores startup permissions rather than breaking hooks.
                    if (!applied || allowed < 0) window_apply(host, true, modules, count);
                    state.retained = 1;
                    fprintf(stderr, "startup policy retained: module policy or transaction\n");
                }
            }
        }
        maple_free_modules(modules, count);
    }
    if (!window_save(fd, &state) && state.closed) window_apply(host, true, NULL, 0);
    close(fd);
}

struct maple_policy_receipt maple_startup_policy_withdraw(const char *host, bool full) {
    struct maple_policy_receipt receipt = {MAPLE_POLICY_BUSY, -1};
    int fd = window_lock(true);
    if (fd < 0) return receipt;
    struct startup_window state;
    if (!window_read(fd, &state)) { receipt.result = MAPLE_POLICY_NOT_READY; close(fd); return receipt; }
    char text[256] = {0}, expected[64];
    FILE *file = fopen(MAPLE_STARTUP_RUNTIME "/startup.state", "r");
    if (file) { fread(text, 1, sizeof(text) - 1, file); fclose(file); }
    snprintf(expected, sizeof(expected), "boot=%s\n", state.boot);
    // A still-running early policy script could reapply grants after restoration.
    bool scripts_done = !strncmp(text, expected, strlen(expected)) &&
        (strstr(text, "\nmodules=ready\n") || strstr(text, "\nmodules=failed\n"));
    if (!scripts_done) { receipt.result = MAPLE_POLICY_NOT_READY; close(fd); return receipt; }
    if (full) {
        if (!boot_marker(MAPLE_STARTUP_RUNTIME "/policy-baseline.boot", state.boot) ||
            access(MAPLE_STARTUP_RUNTIME "/policy-baseline", R_OK) != 0) {
            receipt.result = MAPLE_POLICY_NO_BACKUP;
        } else if (!write_boot_marker(MAPLE_STARTUP_RUNTIME "/policy-restored.next", state.boot)) {
            // Reserve marker storage before a real, irreversible policy load.
            receipt.result = MAPLE_POLICY_FAILED;
        } else if (!baseline_tool(host, true)) {
            unlink(MAPLE_STARTUP_RUNTIME "/policy-restored.next");
            receipt.result = MAPLE_POLICY_FAILED;
        } else {
            // PrepareSystemServer and later host starts must not silently undo
            // this explicit user action during the same boot.
            bool saved = rename(MAPLE_STARTUP_RUNTIME "/policy-restored.next", MAPLE_STARTUP_RUNTIME "/policy-restored") == 0;
            if (!saved) unlink(MAPLE_STARTUP_RUNTIME "/policy-restored.next");
            state.closed = 1;
            state.retained = 0;
            saved = window_save(fd, &state) && saved;
            receipt.result = saved ? MAPLE_POLICY_DONE : MAPLE_POLICY_FAILED;
            fprintf(stderr, "policy full restore: verified=1 state_saved=%d\n", saved);
        }
        receipt.execmem_allowed = execmem_allowed();
        close(fd);
        return receipt;
    }
    if (state.original) {
        receipt.result = MAPLE_POLICY_ORIGINAL;
        receipt.execmem_allowed = execmem_allowed();
        close(fd); return receipt;
    }
    state.retained = 0;
    state.started = window_millis();
    bool saved = window_save(fd, &state);
    close(fd);
    if (!saved) { receipt.result = MAPLE_POLICY_FAILED; return receipt; }
    // Reuse the automatic eligibility checks, including dynamic module rules.
    maple_startup_policy_finish(host, true);
    fd = window_lock(true);
    if (fd < 0) return receipt;
    receipt.execmem_allowed = execmem_allowed();
    if (!window_read(fd, &state) || receipt.execmem_allowed < 0 ||
        (state.closed && receipt.execmem_allowed != 0)) receipt.result = MAPLE_POLICY_FAILED;
    else if (state.closed && receipt.execmem_allowed == 0) receipt.result = MAPLE_POLICY_DONE;
    else if (state.retained) receipt.result = MAPLE_POLICY_REQUIRED;
    else receipt.result = MAPLE_POLICY_NOT_READY;
    close(fd);
    return receipt;
}

// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif
// Keep module initialization privileges separate from steady-state policy.
// All callers serialize through one root-private, per-boot state file.
void maple_startup_policy_init(void);
// Snapshot only before this boot's first host policy load. Never adopt a late
// modified policy as the original after an in-place module update.
bool maple_startup_policy_snapshot(const char *host);
bool maple_startup_policy_restored(void);
bool maple_startup_policy_needed(void);
bool maple_startup_policy_prepare(const char *host);
void maple_startup_policy_finish(const char *host, bool scripts_ready);
enum maple_policy_result {
    MAPLE_POLICY_DONE, MAPLE_POLICY_BUSY, MAPLE_POLICY_NOT_READY,
    MAPLE_POLICY_REQUIRED, MAPLE_POLICY_ORIGINAL, MAPLE_POLICY_NO_BACKUP,
    MAPLE_POLICY_FAILED
};
struct maple_policy_receipt { enum maple_policy_result result; int execmem_allowed; };
struct maple_policy_receipt maple_startup_policy_withdraw(const char *host, bool full);
#ifdef __cplusplus
}
#endif

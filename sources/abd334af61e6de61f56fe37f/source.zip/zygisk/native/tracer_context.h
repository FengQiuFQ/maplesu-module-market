// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <fcntl.h>
#include <unistd.h>

// init-child exec checks the tracer's SID. Reuse init's service domain.
static bool maple_tracer_context(void) {
    const char context[] = "u:r:init:s0";
    const char *paths[] = {"/proc/self/attr/current", "/proc/self/attr/exec"};
    for (unsigned i = 0; i < 2; ++i) {
        int fd = open(paths[i], O_WRONLY | O_CLOEXEC);
        if (fd < 0) return false;
        ssize_t n = write(fd, context, sizeof(context) - 1);
        close(fd);
        if (n != sizeof(context) - 1) return false;
    }
    return true;
}

"""Small, version-checked MapleSU port of the pinned upstream (no binary patching)."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[1]
UP = ROOT / "third_party/rezygisk"
COMMIT = "2c1d0df3b0d6e40d064927523c4dd1116cb8e832"
OUTPUT = ROOT / "zygisk/build/upstream"
sources = {}


def replace(path, before, after):
    text = sources[path]
    if before not in text:
        if after in text:
            return
        raise ValueError(f"Upstream context changed: {path}: {before[:70]}")
    sources[path] = text.replace(before, after)


def main():
    # Distributed corresponding sources are already ported and carry file hashes.
    # Git checkouts always derive the overlay from the pinned commit instead.
    if not (UP / ".git").exists():
        distribution = json.loads((ROOT / "zygisk/SOURCE-DISTRIBUTION.json").read_text(encoding="utf-8"))
        for path, expected in distribution["files"].items():
            file = (ROOT / path).resolve()
            if not file.is_relative_to(ROOT) or hashlib.sha256(file.read_bytes()).hexdigest() != expected:
                raise ValueError(f"Distributed source changed: {path}")
        manifest = json.loads((UP / "MAPLESU-PORT.json").read_text(encoding="utf-8"))
        for path, expected in manifest["files"].items():
            data = (UP / path).read_bytes()
            if hashlib.sha256(data).hexdigest() != expected:
                raise ValueError(f"Distributed source changed: {path}")
            if path.startswith(("loader/src/", "zygiskd/src/")) and "/external/" not in path:
                destination = OUTPUT / path
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
        print(f"Verified distributed MapleSU port of {COMMIT}")
        return
    actual = subprocess.check_output(["git", "-C", str(UP), "rev-parse", "HEAD"], text=True).strip()
    if actual != COMMIT:
        raise ValueError(f"Expected ReZygisk {COMMIT}, got {actual}")
    for folder, commit in {
        "csoloader": "0d29278cf60a3c38850dde3eaf07b0ffc3241f03",
        "plti": "ffbffaa9177bbb8ceede5bb120239a7ce0041c04",
    }.items():
        dependency = UP / "loader/src/external" / folder
        revision = subprocess.check_output(["git", "-C", str(dependency), "rev-parse", "HEAD"], text=True).strip()
        dirty = subprocess.check_output(["git", "-C", str(dependency), "diff", "HEAD", "--"], text=True)
        if revision != commit or dirty:
            raise ValueError(f"Pinned dependency changed: {folder}")
    for base in ("loader/src", "zygiskd/src"):
        for path in (UP / base).rglob("*"):
            if "external" in path.parts or path.suffix not in (".c", ".h"):
                continue
            relative = path.relative_to(UP).as_posix()
            text = subprocess.check_output(["git", "-C", str(UP), "show", f"{COMMIT}:{relative}"]).decode("utf-8")
            text = text.replace("/data/adb/modules/rezygisk", "/data/adb/modules/maplesu_zygisk")
            text = text.replace("/data/adb/rezygisk", "/data/adb/maplesu_zygisk")
            sources[relative] = text

    replace("zygiskd/src/root_impl/common.h", "  APatch,\n  Magisk\n", "  APatch,\n  Magisk,\n  MapleSU\n")
    replace("zygiskd/src/constants.h", "  PROCESS_GRANTED_ROOT =", "  PROCESS_ROOT_IS_MAPLESU = (1u << 26),\n  PROCESS_GRANTED_ROOT =")
    replace("loader/src/injector/module.h", "  PRIVATE_MASK = PROCESS_IS_FIRST_STARTED", "  PRIVATE_MASK = PROCESS_IS_FIRST_STARTED | (1u << 26)")
    replace("loader/src/include/daemon.h", "  ROOT_IMPL_MAGISK\n", "  ROOT_IMPL_MAGISK,\n  ROOT_IMPL_MAPLESU\n")
    replace("loader/src/common/daemon.c", "  if (flags & (1 << 28))", "  if (flags & (1 << 26)) info->root_impl = ROOT_IMPL_MAPLESU;\n  else if (flags & (1 << 28))")
    replace("loader/src/ptracer/main.c", '#include "monitor.h"', '#include "monitor.h"\nint maple_run_early_modules(const char *helper);')
    replace("loader/src/ptracer/main.c", '  if (argc >= 2 && strcmp(argv[1], "monitor")', '  if (argc == 3 && strcmp(argv[1], "stages") == 0) return maple_run_early_modules(argv[2]);\n\n  if (argc >= 2 && strcmp(argv[1], "monitor")')
    replace("loader/src/ptracer/main.c", "  } else if (argc >= 2 && strcmp(argv[1], \"ctl\")", "  } else if (argc >= 3 && strcmp(argv[1], \"ctl\")")
    replace("loader/src/ptracer/main.c", "    struct rezygisk_info info;", "    struct rezygisk_info info = {0};")
    replace("loader/src/ptracer/main.c", "      case ROOT_IMPL_NONE:", "      case ROOT_IMPL_MAPLESU: { printf(\"Root implementation: MapleSU Ultra\\n\"); break; }\n      case ROOT_IMPL_NONE:")
    replace("zygiskd/src/utils.c", "    case None: {", "    case MapleSU: { strcpy(output, \"MapleSU Ultra\"); break; }\n    case None: {")
    replace("zygiskd/src/utils.c", '"u:object_r:zygisk_file:s0"', '"u:object_r:system_data_file:s0"')
    # Keep Zygote's socket lookup outside the privileged module storage tree.
    replace("loader/src/common/daemon.c", 'strcpy(addr.sun_path, TMP_PATH "/" SOCKET_FILE_NAME);',
            'strcpy(addr.sun_path, "/data/misc/maplesu_zygisk/" SOCKET_FILE_NAME);')
    replace("zygiskd/src/zygiskd.c", '#define PATH_CP_NAME TMP_PATH "/" LP_SELECT("cp32.sock", "cp64.sock")',
            '#define PATH_CP_NAME "/data/misc/maplesu_zygisk/" LP_SELECT("cp32.sock", "cp64.sock")')
    replace("zygiskd/src/zygiskd.c", 'static int create_daemon_socket(void) {', '''static int create_daemon_socket(void) {
  mkdir("/data/misc/maplesu_zygisk", 0700);
  chmod("/data/misc/maplesu_zygisk", 0700);''')

    replace("zygiskd/src/utils.c", "bool umount_root(struct root_impl impl) {", '#include "mount_maplesu.inc"\n\nbool umount_root(struct root_impl impl) {')
    replace("zygiskd/src/utils.c", '  const char *source_name = "magisk";', '  if (impl.impl == MapleSU) {\n    bool ok = maple_unmount_root(&mounts);\n    free_mounts(&mounts);\n    return ok;\n  }\n\n  const char *source_name = "magisk";')
    replace("zygiskd/src/utils.c", "      unshare(CLONE_NEWNS);", '      if (unshare(CLONE_NEWNS) != 0 || mount(NULL, "/", NULL, MS_REC | MS_PRIVATE, NULL) != 0) {\n        write_uint8_t(socket_child, 0);\n        goto finalize_mns_fork;\n      }')

    text = sources["zygiskd/src/zygiskd.c"]
    if '#include "module_scan.h"' not in text:
        start = text.index("struct Module {")
        end = text.index("struct Context {", start)
        text = text[:start] + '#include "module_scan.h"\n#define Module maple_module\n\n' + text[end:]
        start = text.index("static void load_modules(")
        end = text.index("static int create_daemon_socket", start)
        text = text[:start] + '''static void load_modules(struct Context *restrict context) {
  if (maple_scan_modules(PATH_MODULES_DIR, ARCH_STR, &context->modules, &context->len) != 0)
    LOGE("Failed scanning MapleSU module tree");
}

static void free_modules(struct Context *restrict context) {
  maple_free_modules(context->modules, context->len);
  context->modules = NULL;
  context->len = 0;
}

''' + text[end:]
        sources["zygiskd/src/zygiskd.c"] = text
    replace("zygiskd/src/zygiskd.c", 'PATH_MODULES_DIR "/rezygisk/bin/', 'PATH_MODULES_DIR "/maplesu_zygisk/bin/')
    replace("zygiskd/src/zygiskd.c", "          case None: { break; }", "          case MapleSU: { flags |= PROCESS_ROOT_IS_MAPLESU; break; }\n          case None: { break; }")
    replace("zygiskd/src/zygiskd.c", '"/data/adb/modules/%s/zygisk/" ARCH_STR ".so", context.modules[i].name', '"%s/zygisk/" ARCH_STR ".so", context.modules[i].path')
    replace("zygiskd/src/zygiskd.c", "        int fd = open(module_dir, O_RDONLY);", '''        // Each request needs its own directory cursor; dup shares the daemon's
        // open file description and leaves later Zygotes at end-of-directory.
        int fd = openat(context.modules[index].dir_fd, ".", O_RDONLY | O_DIRECTORY | O_CLOEXEC);''')
    replace("zygiskd/src/zygiskd.c", "        free(module->name);", "        free(module->path);\n        close(module->dir_fd);\n        free(module->name);")
    # One stalled client must not block all app launches or kill the daemon.
    replace("zygiskd/src/zygiskd.c", "    uint8_t action8 = 0;", "    struct timeval timeout = { .tv_sec = 3 };\n    setsockopt(client_fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));\n    setsockopt(client_fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));\n    uint8_t action8 = 0;")
    replace("zygiskd/src/zygiskd.c", "      close(client_fd);\n\n      break;", "      close(client_fd);\n\n      continue;")

    # Restore the startup grant synchronously before system_server is forked.
    # Observing its PID later races the module's first ART allocations.
    replace("loader/src/include/daemon.h", "  RemoveModule\n", "  RemoveModule,\n  PrepareSystemServer\n")
    replace("zygiskd/src/constants.h", "  RemoveModule           = 8\n", "  RemoveModule           = 8,\n  PrepareSystemServer    = 9\n")
    replace("loader/src/include/daemon.h", "bool rezygiskd_zygote_injected();",
            "bool rezygiskd_zygote_injected();\nbool rezygiskd_prepare_system_server(void);")
    replace("loader/src/common/daemon.c", '#include <sys/socket.h>', '''#include <sys/socket.h>
#include <errno.h>
#include <poll.h>
#include <stdint.h>
#include <time.h>
#ifndef MAPLE_SERVER_PREPARE_TIMEOUT_MS
#define MAPLE_SERVER_PREPARE_TIMEOUT_MS 6000
#endif''')
    replace("loader/src/common/daemon.c", "bool rezygiskd_zygote_injected() {", '''bool rezygiskd_prepare_system_server(void) {
  // Generic read/write helpers retry EAGAIN indefinitely. This pre-fork RPC
  // needs one total deadline, including signals and a saturated listen queue.
  int fd = socket(PF_UNIX, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
  if (fd < 0) return false;
  struct timespec now;
  clock_gettime(CLOCK_MONOTONIC, &now);
  int64_t deadline = now.tv_sec * 1000LL + now.tv_nsec / 1000000 + MAPLE_SERVER_PREPARE_TIMEOUT_MS;
  struct sockaddr_un addr = {
    .sun_family = AF_UNIX,
    .sun_path = "/data/misc/maplesu_zygisk/" SOCKET_FILE_NAME
  };
  if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) { close(fd); return false; }
  bool sent = false, ok = false;
  uint8_t action = (uint8_t)PrepareSystemServer, ready = 0;
  for (;;) {
    clock_gettime(CLOCK_MONOTONIC, &now);
    int64_t remaining = deadline - (now.tv_sec * 1000LL + now.tv_nsec / 1000000);
    if (remaining <= 0) break;
    struct pollfd event = { .fd = fd, .events = sent ? POLLIN : POLLOUT };
    int result = poll(&event, 1, (int)remaining);
    if (result < 0 && errno == EINTR) continue;
    if (result <= 0) break;
    ssize_t size = sent ? recv(fd, &ready, 1, 0) : send(fd, &action, 1, MSG_NOSIGNAL);
    if (size == 1) {
      if (sent) { ok = ready == 1; break; }
      sent = true;
    } else if (size >= 0 || (errno != EAGAIN && errno != EINTR)) break;
  }
  close(fd);
  return ok;
}

bool rezygiskd_zygote_injected() {''')
    replace("zygiskd/src/zygiskd.c", '#include "constants.h"', '#include "constants.h"\n#include <sys/stat.h>\n#include "startup_policy.h"')
    replace("zygiskd/src/zygiskd.c", "      case ZygoteInjected: {", '''      case PrepareSystemServer: {
        uint8_t ready = maple_startup_policy_prepare(PATH_MODULES_DIR "/maplesu_zygisk");
        write_uint8_t(client_fd, ready);
        break;
      }
      case ZygoteInjected: {''')
    replace("loader/src/injector/hook.c", '''  FLAG_SET(ctx, SERVER_FORK_AND_SPECIALIZE);

  rz_fork_pre(ctx);''', '''  FLAG_SET(ctx, SERVER_FORK_AND_SPECIALIZE);
  if (!rezygiskd_prepare_system_server())
    LOGE("System server startup policy preparation failed");

  rz_fork_pre(ctx);''')

    # A fork stops init immediately after SEIZE. Block/listen for SIGCHLD before
    # claiming it; otherwise the first notification can be discarded and init
    # remains stopped while epoll waits forever.
    replace("loader/src/ptracer/monitor.c", "  if (!claim_init_tracer()) exit(1);\n\n", "")
    replace("loader/src/ptracer/monitor.c", "  monitor_events_loop();", "  if (!claim_init_tracer()) exit(1);\n\n  monitor_events_loop();")
    # Unlike post-fs-data, the SDK callback runs after init forked the primary
    # bootstrap. Watch its upcoming original app_process exec as well; no ART
    # restart, process scan, or late injection is involved.
    replace("loader/src/ptracer/monitor.h", "void init_monitor();", "void init_monitor(int bootstrap);")
    replace("loader/src/ptracer/main.c", "    init_monitor();", "    init_monitor(argc == 3 ? atoi(argv[2]) : 0);")
    replace("loader/src/ptracer/monitor.c", "void init_monitor() {", "void init_monitor(int bootstrap) {")
    replace("loader/src/ptracer/monitor.c", "  if (!claim_init_tracer()) exit(1);", '''  if (bootstrap > 1) {
    sigchld_process = malloc(sizeof(*sigchld_process));
    if (!sigchld_process) exit(1);
    sigchld_process[0] = bootstrap;
    sigchld_process_count = 1;
    if (ptrace(PTRACE_SEIZE, bootstrap, 0, PTRACE_O_TRACEEXEC) == -1) {
      PLOGE("seize SDK bootstrap");
      exit(1);
    }
  }
  if (!claim_init_tracer()) exit(1);''')
    # The SDK bootstrap waits for its module-loader child before exec. Forward
    # that child's SIGCHLD while retaining TRACEEXEC; ordinary delivery stops
    # must not detach the known bootstrap before the original app_process runs.
    replace("loader/src/ptracer/monitor.c", "void sigchld_listener_callback() {", "static pid_t sdk_bootstrap_pid;\nstatic char sdk_bootstrap_exe[PATH_MAX];\n\nvoid sigchld_listener_callback() {")
    replace("loader/src/ptracer/monitor.c", "void init_monitor(int bootstrap) {", "void init_monitor(int bootstrap) {\n  sdk_bootstrap_pid = bootstrap;\n  if (bootstrap > 1) get_program(bootstrap, sdk_bootstrap_exe, sizeof(sdk_bootstrap_exe));")
    # The SDK re-enters its bootstrap before execing the real Zygote on each
    # framework restart. Retain only this captured executable, not arbitrary init children.
    replace("loader/src/ptracer/monitor.c", '          LOGV("%d program %s", pid, program);', '''          LOGV("%d program %s", pid, program);
          if (sdk_bootstrap_exe[0] && strcmp(program, sdk_bootstrap_exe) == 0) {
            ptrace(PTRACE_CONT, pid, 0, 0);
            continue;
          }''')
    replace("loader/src/ptracer/monitor.c", '          LOGW("process %d received unknown sigchld_status %s", pid, status_str);', '''          if (pid == sdk_bootstrap_pid && WIFSTOPPED(sigchld_status) && WPTEVENT(sigchld_status) == 0) {
            ptrace(PTRACE_CONT, pid, 0, WSTOPSIG(sigchld_status));
            continue;
          }
          char program[PATH_MAX];
          if (WIFSTOPPED(sigchld_status) && WPTEVENT(sigchld_status) == 0 && sdk_bootstrap_exe[0] &&
              get_program(pid, program, sizeof(program)) == 0 && strcmp(program, sdk_bootstrap_exe) == 0) {
            ptrace(PTRACE_CONT, pid, 0, WSTOPSIG(sigchld_status));
            continue;
          }
          LOGW("process %d received unknown sigchld_status %s", pid, status_str);''')

    # An SDK launcher may ignore SIGCHLD/auto-reap children. The exec'd monitor
    # owns waitpid and signalfd and needs ordinary child notifications.
    replace("loader/src/ptracer/monitor.c", "  sigchld_process = NULL;\n\n  sigset_t mask;", '''  sigchld_process = NULL;

  struct sigaction action = { .sa_handler = SIG_DFL };
  sigemptyset(&action.sa_mask);
  if (sigaction(SIGCHLD, &action, NULL) == -1) return false;

  sigset_t mask;''')
    # Readiness is acknowledged only after init is traced and event listeners exist.
    replace("loader/src/ptracer/monitor.c", "  monitor_events_loop();", "  if (fcntl(199, F_GETFD) >= 0) { write(199, \"1\", 1); close(199); }\n  monitor_events_loop();")
    replace("loader/src/ptracer/monitor.c", '#include <errno.h>', '#include <errno.h>\n#include <fcntl.h>')
    # Daemons die with their monitor, including startup failure.
    replace("loader/src/ptracer/monitor.c", '#include <fcntl.h>', '#include <fcntl.h>\n#include <sys/prctl.h>')
    replace("loader/src/ptracer/monitor.c", "  pid_t pid = fork();", "  pid_t parent = getpid();\n  pid_t pid = fork();")
    replace("loader/src/ptracer/monitor.c", '    char daemon_name[PATH_MAX]', '    if (prctl(PR_SET_PDEATHSIG, SIGTERM) != 0 || getppid() != parent) _exit(1);\n    char daemon_name[PATH_MAX]')
    replace("loader/src/ptracer/monitor.c", "  if (status64.daemon_info)", "  if (status64.daemon_running) kill(status64.daemon_pid, SIGTERM);\n  if (status32.daemon_running) kill(status32.daemon_pid, SIGTERM);\n\n  if (status64.daemon_info)")
    replace("loader/src/ptracer/monitor.c", "        if (tracing_state == STOPPED && errno == ECHILD) break;\n        PLOGE(\"waitpid\");", '        if (errno != ECHILD) PLOGE("waitpid");\n        break;')
    replace("loader/src/ptracer/monitor.c", "  monitor_events_init();", "  if (!monitor_events_init()) exit(1);")
    replace("loader/src/ptracer/monitor.c", "  monitor_events_register_event(rezygiskd_listener_callback, monitor_sock_fd, EPOLLIN | EPOLLET);", "  if (!monitor_events_register_event(rezygiskd_listener_callback, monitor_sock_fd, EPOLLIN | EPOLLET)) exit(1);")
    replace("loader/src/ptracer/monitor.c", "  monitor_events_register_event(sigchld_listener_callback, sigchld_signal_fd, EPOLLIN | EPOLLET);", "  if (!monitor_events_register_event(sigchld_listener_callback, sigchld_signal_fd, EPOLLIN | EPOLLET)) exit(1);")
    # START must reflect the actual ptrace result rather than displaying success.
    replace("loader/src/ptracer/monitor.c", "          ptrace(PTRACE_SEIZE, 1, 0, PTRACE_O_TRACEFORK);", "          if (ptrace(PTRACE_SEIZE, 1, 0, PTRACE_O_TRACEFORK) == -1) break;")
    # Companions deliberately double-fork. The daemon control socket owns their
    # lifetime; binding PDEATHSIG to the short-lived launcher kills every companion.
    text = sources["zygiskd/src/utils.c"]
    start = text.index("int non_blocking_execv(")
    end = text.index("void stringify_root_impl_name", start)
    sources["zygiskd/src/utils.c"] = text[:start] + '''int non_blocking_execv(const char *restrict file, char *const argv[]) {
  pid_t pid = fork();
  if (pid == -1) return -1;
  if (pid == 0) {
    execv(file, argv);
    _exit(127);
  }
  return 0;
}

''' + text[end:]
    replace("zygiskd/src/zygiskd.c", "  int daemon_fd = sockets[0];", "  int daemon_fd = sockets[0];\n  struct timeval startup_timeout = { .tv_sec = 3 };\n  setsockopt(daemon_fd, SOL_SOCKET, SO_RCVTIMEO, &startup_timeout, sizeof(startup_timeout));")
    replace("zygiskd/src/zygiskd.c", "      case 1: { return daemon_fd; }", "      case 1: {\n        startup_timeout.tv_sec = 0;\n        setsockopt(daemon_fd, SOL_SOCKET, SO_RCVTIMEO, &startup_timeout, sizeof(startup_timeout));\n        return daemon_fd;\n      }")
    # Only errors/warnings go to logcat in Release; routine module identities stay private.
    replace("loader/src/include/logging.h", '#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)', '#ifndef NDEBUG\n#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)\n#else\n#define LOGI(...)\n#endif')
    replace("zygiskd/src/utils.h", "#define LOGI(...)", "#ifndef NDEBUG\n#define LOGI(...)")
    replace("zygiskd/src/utils.h", "#define LOGW(...)", "#else\n#define LOGI(...)\n#endif\n\n#define LOGW(...)")
    # Status is written into module.prop. Re-reading it on each boot accumulates
    # status prefixes until the original description buffer overflows.
    replace("loader/src/ptracer/monitor.c", 'fopen("/data/adb/modules/maplesu_zygisk/module.prop", "r")',
            'fopen("/data/adb/modules/maplesu_zygisk/payload/module.prop", "r")')
    # Malformed JSON after stop was an upstream status bug.
    replace("loader/src/ptracer/monitor.c", '\\"%s\\",\\n", monitor_stop_reason)', '\\"%s\\"\\n", monitor_stop_reason)')
    # WebUI readers must never observe a partial status document. Escape error
    # strings too: linker errors and module names may contain quotes/newlines.
    replace("loader/src/ptracer/monitor.c", 'static bool update_status(const char *message) {', r'''static void maple_json_string(FILE *out, const char *text) {
  fputc('"', out);
  for (const unsigned char *p = (const unsigned char *)text; *p; ++p) {
    if (*p == '"' || *p == '\\') { fputc('\\', out); fputc(*p, out); }
    else if (*p < 0x20) fprintf(out, "\\u%04x", *p);
    else fputc(*p, out);
  }
  fputc('"', out);
}

static bool update_status(const char *message) {''')
    replace("loader/src/ptracer/monitor.c", 'fopen("/data/adb/maplesu_zygisk/state.json", "w")', 'fopen("/data/adb/maplesu_zygisk/state.json.tmp", "w")')
    replace("loader/src/ptracer/monitor.c", '    fclose(json);', '''    bool state_ok = !ferror(json);
    if (fclose(json) != 0) state_ok = false;
    if (state_ok) state_ok = rename("/data/adb/maplesu_zygisk/state.json.tmp", "/data/adb/maplesu_zygisk/state.json") == 0;
    if (!state_ok) { unlink("/data/adb/maplesu_zygisk/state.json.tmp"); return false; }''')
    replace("loader/src/ptracer/monitor.c", '    fprintf(json, "  \\"root\\": \\"%s\\",\\n", environment_information64.root_impl ? environment_information64.root_impl : environment_information32.root_impl);',
        '    fprintf(json, "  \\"root\\": ");\n    maple_json_string(json, environment_information64.root_impl ? environment_information64.root_impl : environment_information32.root_impl);\n    fprintf(json, ",\\n");')
    # Use checked replacements for each runtime string emitted by the producer.
    for expression, prefix, suffix in (
        ("monitor_stop_reason", r',\n    "reason": ', r'\n'),
        ("status64.daemon_error_info", r'      "reason": ', r',\n'),
        ("status32.daemon_error_info", r'      "reason": ', r',\n'),
    ):
        escaped_prefix = prefix.replace('"', r'\"')
        old = f'if ({expression}) fprintf(json, "{escaped_prefix}\\\"%s\\\"{suffix}", {expression});'
        new = f'if ({expression}) {{ fprintf(json, "{escaped_prefix}"); maple_json_string(json, {expression}); fprintf(json, "{suffix}"); }}'
        replace("loader/src/ptracer/monitor.c", old, new)
    for abi in ("64", "32"):
        replace("loader/src/ptracer/monitor.c", f'fprintf(json, "\\\"%s\\\"", environment_information{abi}.modules[i]);', f'maple_json_string(json, environment_information{abi}.modules[i]);')
    replace("loader/src/injector/hook.c", "rezygiskd_remove_module(i);", "rezygiskd_remove_module(zygisk_module_length);")
    replace("loader/src/injector/hook.c", "malloc(ms.modules_count * sizeof(struct rezygisk_module))", "calloc(ms.modules_count ? ms.modules_count : 1, sizeof(struct rezygisk_module))")
    replace("loader/src/injector/hook.c", "target_module->api_version > REZYGISK_API_VERSION", "(target_module->api_version < 1 || target_module->api_version > REZYGISK_API_VERSION)")
    # Legacy regex hooks need the same ELF registration as the API 4 inode path.
    replace("loader/src/injector/hook.c",
        "if (!ignored && !plti_add_hook(&plti_ctx, map->path, reg->symbol, reg->callback, reg->backup)) {",
        "if (!ignored && (!plti_add_manual_lib(&plti_ctx, map->path, map->start) ||\n"
        "                       !plti_add_hook(&plti_ctx, map->path, reg->symbol, reg->callback, reg->backup))) {")
    replace("loader/src/injector/hook.c",
        "if (ign->symbol && strcmp(ign->symbol, reg->symbol) != 0) continue;",
        "if (ign->symbol && *ign->symbol && strcmp(ign->symbol, reg->symbol) != 0) continue;")
    # API 4/5 callers consume the bool result; preserve Magisk's no-op semantics
    # and reject fork variants that cannot pass an fd-ignore array to Android.
    replace("loader/src/injector/module.h", "void (*exempt_fd)(int);", "bool (*exempt_fd)(int);")
    replace("loader/src/injector/hook.c", '''static void api_exempt_fd(int fd) {
  if (!g_ctx) return;

  if (FLAG_GET(g_ctx, POST_SPECIALIZE) || FLAG_GET(g_ctx, SKIP_FD_SANITIZATION)) return;
  if (!FLAG_GET(g_ctx, APP_FORK_AND_SPECIALIZE)) return;
  if (g_ctx->exempted_fds_count >= MAX_EXEMPTED_FDS) return;

  g_ctx->exempted_fds[g_ctx->exempted_fds_count++] = fd;

  return;
}''', '''static bool api_exempt_fd(int fd) {
  if (!g_ctx) return false;

  if (FLAG_GET(g_ctx, POST_SPECIALIZE) || FLAG_GET(g_ctx, SKIP_FD_SANITIZATION)) return true;
  if (!FLAG_GET(g_ctx, APP_FORK_AND_SPECIALIZE) || !g_ctx->args.app->fds_to_ignore) return false;
  if (g_ctx->exempted_fds_count >= MAX_EXEMPTED_FDS) return false;

  g_ctx->exempted_fds[g_ctx->exempted_fds_count++] = fd;

  return true;
}''')
    for path, text in sources.items():
        destination = OUTPUT / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(text, encoding="utf-8", newline="\n")
    print(f"MapleSU build overlay generated from {COMMIT}")


if __name__ == "__main__":
    main()

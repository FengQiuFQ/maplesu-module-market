import dev.maplesu.manager.ModuleArchiveInspector;
import java.io.File;

/** Calls the production parser on final package bytes without Android or native loading. */
public final class ArchiveProbe {
    public static void main(String[] args) throws Exception {
        var host = ModuleArchiveInspector.inspect(new File(args[0]));
        if (host.type != ModuleArchiveInspector.ModuleType.MAPLESU
                || !host.id.equals("c45e8a7390b24987a4b01d6e2c5f9143")
                || !host.nativeEntry.equals("libmodule_maplesu_zygisk.so")
                || !host.properties.get("version").equals("5.1.0")
                || !host.features.contains(ModuleArchiveInspector.Feature.WEB_UI)) {
            throw new AssertionError("Host archive identity mismatch: " + host.properties);
        }
        var hma = ModuleArchiveInspector.inspect(new File(args[1]));
        if (hma.type != ModuleArchiveInspector.ModuleType.KERNEL_SU
                || !hma.id.equals("hma_oss_zygisk")
                || !hma.nativeAbis.containsKey("zygisk/arm64-v8a.so")) {
            throw new AssertionError("HMA archive identity mismatch: " + hma.properties);
        }
        System.out.println("ULTRA_NATIVE_ARCHIVE_OK HMA_SCRIPT_ARCHIVE_OK SDK_METADATA_OK WEBUI_OK");
    }
}

// Load the actual HMA release in this test process, without tracing Android services.
#include "module.h"
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static struct rezygisk_abi registered;
static int dlclose_requested;
static int module_fd = -1;
static int dir_requested;
static void option(void *impl, enum rezygisk_options value) {
    (void)impl;
    if (value == DLCLOSE_MODULE_LIBRARY) dlclose_requested = 1;
}
static int module_dir(void *impl) { (void)impl; dir_requested++; return dup(module_fd); }
static bool register_module(struct rezygisk_api *api, const struct rezygisk_abi *abi) {
    if (abi->api_version < 1 || abi->api_version > REZYGISK_API_VERSION) return false;
    registered = *abi;
    api->set_option = option;
    api->get_module_dir = module_dir;
    return true;
}

int main(int argc, char **argv) {
    if (argc != 3) return 2;
    struct csoloader lib = {0};
    if (!csoloader_load(&lib, argv[1])) return 3;
    void (*entry)(void *, void *) = csoloader_get_symbol(&lib, "zygisk_module_entry");
    if (!entry) return 4;
    struct rezygisk_api api = { .register_module = register_module };
    // onLoad only records the API/JNI pointers and requests dlclose in HMA/ZygoteLoader.
    entry(&api, NULL);
    if (registered.api_version != 4 || !dlclose_requested ||
        !registered.pre_server_specialize || !registered.post_server_specialize) return 5;
    module_fd = open(argv[2], O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (module_fd < 0) return 6;
    // An empty package tree exercises server callbacks/getModuleDir without Java VM.
    // Real HMA's packages/android + dex execution is reserved for Ultra boot acceptance.
    struct server_specialize_args_v1 args = {0};
    registered.pre_server_specialize(registered.impl, &args);
    registered.post_server_specialize(registered.impl, &args);
    if (dir_requested != 1) return 7;
    close(module_fd);
    printf("HMA_API4_REGISTERED DLCLOSE_REQUESTED SERVER_CALLBACKS_OK MODULE_DIR_FD_OK\n");
    return csoloader_unload(&lib) ? 0 : 8;
}

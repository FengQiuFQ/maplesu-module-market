// Exercise the production API table and callback adapters without tracing Android.
#include "hook.c"
#include <assert.h>

_Static_assert(_Generic(((struct rezygisk_api *)0)->exempt_fd,
                       bool (*)(int): 1, default: 0),
               "Zygisk API 4/5 exemptFd must return bool");

static int callbacks;
static long version;
static struct app_specialize_args_v5 expected;

static void check_app(void *impl, const void *opaque, bool post) {
  assert(impl == &callbacks);
  if (version <= 2) {
    const struct app_specialize_args_v1 *args = opaque;
    assert(args->uid == expected.uid && args->gid == expected.gid);
    assert(args->gids == expected.gids && args->runtime_flags == expected.runtime_flags);
    assert(args->mount_external == expected.mount_external && args->se_info == expected.se_info);
    assert(args->nice_name == expected.nice_name && args->instruction_set == expected.instruction_set);
    assert(args->app_data_dir == expected.app_data_dir && args->is_child_zygote == expected.is_child_zygote);
    assert(args->is_top_app == expected.is_top_app && args->pkg_data_info_list == expected.pkg_data_info_list);
    assert(args->whitelisted_data_info_list == expected.whitelisted_data_info_list);
    assert(args->mount_data_dirs == expected.mount_data_dirs && args->mount_storage_dirs == expected.mount_storage_dirs);
    if (!post) *args->uid = 12345;
  } else {
    const struct app_specialize_args_v4 *args = opaque;
    assert(memcmp(args, &expected, sizeof(*args)) == 0);
    if (version == 5)
      assert(((const struct app_specialize_args_v5 *)opaque)->mount_sysprop_overrides == expected.mount_sysprop_overrides);
    if (!post) *args->uid = 12345;
  }
  callbacks++;
}
static void pre_app(void *impl, void *args) { check_app(impl, args, false); }
static void post_app(void *impl, const void *args) { check_app(impl, args, true); }
static struct server_specialize_args_v1 *server_args;
static void pre_server(void *impl, void *args) {
  assert(impl == &callbacks && args == server_args);
  *server_args->uid = 1000;
  callbacks++;
}
static void post_server(void *impl, const void *args) {
  assert(impl == &callbacks && args == server_args && *server_args->uid == 1000);
  callbacks++;
}

// Only the JNI array operations used by the real FD sanitizer are replaced.
struct test_array { jsize size; jint values[256]; };
static struct test_array merged;
static jsize array_length(JNIEnv *env, jarray array) { return ((struct test_array *)array)->size; }
static jintArray new_array(JNIEnv *env, jsize size) {
  assert(size <= 256);
  merged = (struct test_array){.size = size};
  return (jintArray)&merged;
}
static jint *array_elements(JNIEnv *env, jintArray array, jboolean *copy) {
  return ((struct test_array *)array)->values;
}
static void array_region(JNIEnv *env, jintArray array, jsize start, jsize size, const jint *values) {
  assert(start >= 0 && size >= 0 && start + size <= ((struct test_array *)array)->size);
  memcpy(((struct test_array *)array)->values + start, values, size * sizeof(jint));
}
static void release_elements(JNIEnv *env, jintArray array, jint *values, jint mode) {}
static void delete_ref(JNIEnv *env, jobject object) {}
static const struct JNINativeInterface jni = {
  .GetArrayLength = array_length, .NewIntArray = new_array,
  .GetIntArrayElements = array_elements, .SetIntArrayRegion = array_region,
  .ReleaseIntArrayElements = release_elements, .DeleteLocalRef = delete_ref
};

static pid_t replacement_pid(void) { return 314159; }

static void check_plt(const char *path) {
  void *library = dlopen(path, RTLD_NOW | RTLD_LOCAL);
  assert(library);
  pid_t (*pid_call)(void) = dlsym(library, "fixture_pid");
  pid_t (*ppid_call)(void) = dlsym(library, "fixture_ppid");
  assert(pid_call && ppid_call);
  const pid_t pid = getpid(), ppid = getppid();
  struct stat st;
  assert(stat(path, &st) == 0);
  struct rezygisk_module module = {0};
  zygisk_modules = &module;
  zygisk_module_length = 1;
  for (long api_version = 1; api_version <= REZYGISK_API_VERSION; ++api_version) {
    struct zygisk_context context = {.hook_info_lock = PTHREAD_MUTEX_INITIALIZER};
    g_ctx = &context;
    struct rezygisk_api api = {.impl = ENCODE_ID(0)};
    struct rezygisk_abi abi = {.api_version = api_version};
    assert(rezygisk_module_register(&api, &abi));
    assert(plti_init(&plti_ctx));
    assert(pid_call() == pid && ppid_call() == ppid);
    void *original = NULL;
    const char *regex = ".*/libmaplesu-zygisk-plt-fixture\\.so$";
    if (api_version < 4) {
      // Excluding one symbol must leave other imports in the same ELF hookable.
      api.plt_hook_exclude(regex, "getpid");
      api.plt_hook_register(regex, "getpid", replacement_pid, NULL);
      api.plt_hook_register(regex, "getppid", replacement_pid, &original);
      assert(api.plt_hook_commit());
      assert(pid_call() == pid && ppid_call() == replacement_pid());
      assert(original && ((pid_t (*)(void))original)() == ppid);
      assert(plti_remove_hook(&plti_ctx, path, "getppid", &original));
      assert(ppid_call() == ppid);
      assert(context.register_info_count == 0 && context.ignore_info_count == 0);
      api.plt_hook_exclude(regex, NULL);
      api.plt_hook_register(regex, "getpid", replacement_pid, NULL);
      assert(api.plt_hook_commit() && pid_call() == pid);
      // The legacy implementation also treats an empty symbol as all symbols.
      api.plt_hook_exclude(regex, "");
      api.plt_hook_register(regex, "getpid", replacement_pid, NULL);
      assert(api.plt_hook_commit() && pid_call() == pid);
    }
    original = NULL;
    if (api_version < 4)
      api.plt_hook_register(regex, "getpid", replacement_pid, &original);
    else
      api.plt_hook_register_v4(st.st_dev, st.st_ino, "getpid", replacement_pid, &original);
    assert(api.plt_hook_commit());
    assert(pid_call() == replacement_pid() && getpid() == pid);
    assert(original && ((pid_t (*)(void))original)() == pid);
    assert(plti_remove_hook(&plti_ctx, path, "getpid", &original));
    assert(pid_call() == pid && ppid_call() == ppid);
    assert(plti_deinit(&plti_ctx));
    assert(pthread_mutex_destroy(&context.hook_info_lock) == 0);
    printf("API%ld PLT_REAL_IMPORT_BACKUP_EXCLUSION_RESTORE_OK\n", api_version);
  }
  g_ctx = NULL;
  assert(dlclose(library) == 0);
}

int main(int argc, char **argv) {
  setvbuf(stdout, NULL, _IONBF, 0);
  struct zygisk_context context = {0};
  struct rezygisk_module module = {0};
  g_ctx = &context;
  zygisk_modules = &module;
  zygisk_module_length = 1;
  for (version = 1; version <= REZYGISK_API_VERSION; ++version) {
    struct rezygisk_api api = {.impl = ENCODE_ID(0), .register_module = rezygisk_module_register};
    struct rezygisk_abi abi = {version, &callbacks, pre_app, post_app, pre_server, post_server};
    assert(api.register_module(&api, &abi));
    assert(api.hook_jni_native_methods && api.plt_hook_register && api.plt_hook_commit);
    assert(api.connect_companion && api.set_option);
    assert((api.get_module_dir != NULL) == (version >= 2));
    assert((api.get_flags != NULL) == (version >= 2));
    if (version >= 2) {
      context.info_flags = PROCESS_GRANTED_ROOT | PROCESS_ON_DENYLIST | PROCESS_IS_FIRST_STARTED | (1u << 26);
      assert(api.get_flags() == (PROCESS_GRANTED_ROOT | PROCESS_ON_DENYLIST));
    }
    module.unload = false;
    context.flags = 0;
    api.set_option(api.impl, DLCLOSE_MODULE_LIBRARY);
    assert(module.unload);
    api.set_option(api.impl, FORCE_DENYLIST_UNMOUNT);
    assert(FLAG_GET(&context, DO_REVERT_UNMOUNT));

    jint uid = 10001;
    // Distinct field addresses expose any shifted API-version layout.
    jint gid, runtime, mount;
    jintArray gids, fds;
    jstring seinfo, name, instruction, directory;
    jobjectArray rlimits, packages, whitelist;
    jboolean child, top, data, storage, sysprops;
    expected = (struct app_specialize_args_v5){
      &uid, &gid, &gids, &runtime, &rlimits, &mount, &seinfo, &name, &instruction, &directory,
      &fds, &child, &top, &packages, &whitelist, &data, &storage, &sysprops
    };
    struct app_specialize_args_v5 app = expected;
    callbacks = 0;
    rz_module_call_pre_app_specialize(&module, &app);
    assert(uid == 12345 && callbacks == 1);
    rz_module_call_post_app_specialize(&module, &app);
    assert(callbacks == 2);
    struct server_specialize_args_v1 server = {.uid = &uid};
    server_args = &server;
    rz_module_call_pre_server_specialize(&module, &server);
    rz_module_call_post_server_specialize(&module, &server);
    assert(uid == 1000 && callbacks == 4);

    if (version >= 4) {
      JNIEnv env = &jni;
      struct test_array original = {2, {3, 9}};
      fds = (jintArray)&original;
      context = (struct zygisk_context){.args.app = &app, .env = &env, .pid = 1};
      FLAG_SET(&context, APP_FORK_AND_SPECIALIZE);
      assert(api.exempt_fd(42));
      assert(context.exempted_fds_count == 1 && context.exempted_fds[0] == 42);
      assert(api.exempt_fd(43));
      rz_sanitize_fds(&context);
      const jint kept[] = {3, 9, 42, 43};
      assert(fds == (jintArray)&merged && merged.size == 4);
      assert(memcmp(merged.values, kept, sizeof(kept)) == 0);
      assert(context.allowed_fds[3] && context.allowed_fds[9] && context.allowed_fds[42] && context.allowed_fds[43]);
      assert(FLAG_GET(&context, SKIP_FD_SANITIZATION));
      context.flags = 0;
      FLAG_SET(&context, APP_FORK_AND_SPECIALIZE);
      context.exempted_fds_count = MAX_EXEMPTED_FDS;
      assert(!api.exempt_fd(43));
      assert(context.exempted_fds_count == MAX_EXEMPTED_FDS);
      context.exempted_fds_count = 0;
      app.fds_to_ignore = NULL;
      assert(!api.exempt_fd(42) && context.exempted_fds_count == 0);
      context.flags = 0;
      assert(!api.exempt_fd(42));
      FLAG_SET(&context, SKIP_FD_SANITIZATION);
      assert(api.exempt_fd(42) && context.exempted_fds_count == 0);
      context.flags = 0;
      FLAG_SET(&context, POST_SPECIALIZE);
      assert(api.exempt_fd(42) && context.exempted_fds_count == 0);
      g_ctx = NULL;
      assert(!api.exempt_fd(42));
      g_ctx = &context;
    }
    printf("API%ld TABLE_CALLBACK_LAYOUT_MUTATION_OPTIONS_FLAGS_OK\n", version);
  }
  struct rezygisk_api api = {.impl = ENCODE_ID(0)};
  struct rezygisk_abi abi = {.api_version = 0};
  assert(!rezygisk_module_register(&api, &abi));
  abi.api_version = REZYGISK_API_VERSION + 1;
  assert(!rezygisk_module_register(&api, &abi));
  puts("EXEMPT_FD_BOOL_SUCCESS_CAPACITY_OPTIONAL_ARGS_NOOP_CONTEXT_AND_SANITIZER_OK");
  if (argc == 2) check_plt(argv[1]);
  return 0;
}

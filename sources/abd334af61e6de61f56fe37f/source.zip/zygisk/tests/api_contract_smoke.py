"""Run the real API-table/callback/FD core in an unprivileged device process."""
import argparse
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import uuid


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--serial", required=True)
    parser.add_argument("--adb", default="D:/platform-tools/adb.exe")
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--fixture", type=Path)
    parser.add_argument("--save", type=Path, required=True)
    args = parser.parse_args()
    adb = [args.adb, "-s", args.serial]
    remote = "/data/local/tmp/maplesu-zygisk-api-" + uuid.uuid4().hex

    def shell(*command):
        result = subprocess.run([*adb, "shell", shlex.join(command)],
                                capture_output=True, text=True, timeout=25)
        if result.returncode:
            raise RuntimeError(result.stdout + result.stderr)
        return result.stdout

    try:
        shell("mkdir", remote)
        subprocess.run([*adb, "push", str(args.binary), remote + "/probe"], check=True,
                       capture_output=True, timeout=20)
        shell("chmod", "700", remote + "/probe")
        command = [remote + "/probe"]
        if args.fixture:
            fixture = remote + "/libmaplesu-zygisk-plt-fixture.so"
            subprocess.run([*adb, "push", str(args.fixture), fixture], check=True,
                           capture_output=True, timeout=20)
            command.append(fixture)
        output = shell(*command)
        for version in range(1, 6):
            assert f"API{version} TABLE_CALLBACK_LAYOUT_MUTATION_OPTIONS_FLAGS_OK" in output, output
        assert "EXEMPT_FD_BOOL_SUCCESS_CAPACITY_OPTIONAL_ARGS_NOOP_CONTEXT_AND_SANITIZER_OK" in output, output
        if args.fixture:
            for version in range(1, 6):
                assert f"API{version} PLT_REAL_IMPORT_BACKUP_EXCLUSION_RESTORE_OK" in output, output
        receipt = {"passed": True, "binarySha256": hashlib.sha256(args.binary.read_bytes()).hexdigest(),
                   "output": output, "scope": "Unprivileged isolated process; production API registration, callbacks, FD sanitizer and PLT hooks; JNI arrays are fixtures; no ART injection or reboot"}
        if args.fixture:
            receipt["fixtureSha256"] = hashlib.sha256(args.fixture.read_bytes()).hexdigest()
        args.save.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(receipt))
    finally:
        shell("rm", "-rf", remote)


if __name__ == "__main__":
    main()

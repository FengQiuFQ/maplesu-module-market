// SPDX-License-Identifier: AGPL-3.0-or-later
#include "auth_snapshot.hpp"
#include <cstdio>

int main(int argc, char **argv) {
    if (argc != 3) return 2;
    std::set<uid_t> uids;
    bool ok = maple::read_authorized_uids(argv[1], argv[2], uids);
    std::printf("%s", ok ? "OK" : "ERROR");
    for (uid_t uid : uids) std::printf(" %u", uid);
    std::puts("");
    return ok ? 0 : 1;
}

"""Exercise the production allowlist reader in a disposable Android fixture."""
import argparse
import json
from pathlib import Path
import shlex
import subprocess


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--serial", required=True)
    p.add_argument("--save", type=Path, required=True)
    args = p.parse_args()
    adb = ["D:/platform-tools/adb.exe", "-s", args.serial]
    binary = Path(__file__).resolve().parents[1] / "build/arm64-v8a/maplesu-zygisk-auth-probe"
    remote = "/data/local/tmp/maplesu-zygisk-auth-fixture"
    subprocess.run([*adb, "shell", "mkdir", "-p", remote], check=True, capture_output=True, timeout=10)
    subprocess.run([*adb, "push", str(binary), remote + "/probe"], check=True, capture_output=True, timeout=10)
    script = r'''
set -e
cd /data/local/tmp/maplesu-zygisk-auth-fixture
chmod 755 probe
mkdir -p users/0/dev.fixture.a users/1/dev.fixture.a users/0/dev.fixture.b users/other/dev.fixture.a
chown 12345:12345 users/0/dev.fixture.a
chown 112345:112345 users/1/dev.fixture.a
chown 15432:15432 users/0/dev.fixture.b
chown 22345:22345 users/other/dev.fixture.a
check() {
  expected="$1"
  shift
  actual=$(./probe "$@" || true)
  test "$actual" = "$expected" || { echo "FAIL: $actual"; exit 1; }
  echo "PASS: $actual"
}
printf ' \tdev.fixture.a\r\n\ndev.fixture.a\n' > allowlist
check 'OK 12345 112345' allowlist users
printf 'dev.fixture.b\n' > replacement
mv replacement allowlist
check 'OK 15432' allowlist users
: > allowlist
check 'OK' allowlist users
check 'ERROR' missing users
check 'ERROR' allowlist missing-users
printf 'dev.fixture.absent\ndev.fixture.a' > allowlist
check 'OK 12345 112345' allowlist users
rm allowlist
check 'ERROR' allowlist users
'''
    result = subprocess.run([*adb, "shell", shlex.join(["su", "-c", script])],
                            capture_output=True, text=True, timeout=20)
    report = {"passed": result.returncode == 0 and result.stdout.count("PASS:") == 7,
              "stdout": result.stdout, "stderr": result.stderr}
    args.save.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report))
    raise SystemExit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()

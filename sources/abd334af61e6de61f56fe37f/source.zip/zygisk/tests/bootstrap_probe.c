// SPDX-License-Identifier: AGPL-3.0-or-later
#define _GNU_SOURCE
#include "bootstrap.h"
#include <stdlib.h>
#include <sys/wait.h>

int main(int argc, char **argv) {
    if (argc == 4) {
        int init = atoi(argv[2]), expected = atoi(argv[3]);
        pid_t child = fork();
        if (child == 0) _exit(maple_bootstrap_process(init) == expected ? 0 : 1);
        int status;
        if (child < 0 || waitpid(child, &status, 0) != child) return 1;
        return WIFEXITED(status) ? WEXITSTATUS(status) : 1;
    }
    const char *names[] = {"/system/bin/app_process64", "dev.maplesu.manager", "/system/bin/app_process64"};
    for (int i = 0; i < 3; ++i) {
        pid_t child = fork();
        if (child == 0) {
            char init[16], expected[16];
            snprintf(init, sizeof(init), "%d", getppid());
            snprintf(expected, sizeof(expected), "%d", i == 0 ? getpid() : 0);
            execl("/proc/self/exe", names[i], i < 2 ? "--zygote" : "--application", init, expected, NULL);
            _exit(127);
        }
        int status;
        if (child < 0 || waitpid(child, &status, 0) != child || !WIFEXITED(status) || WEXITSTATUS(status)) return 1;
    }
    puts("PASS: SDK bootstrap ancestry; manager and non-zygote excluded");
    return 0;
}

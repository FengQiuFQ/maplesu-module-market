// Exercise the production companion launcher/protocol without any Android injection.
#include "zygiskd.c"
#include <assert.h>
#include <sys/prctl.h>
#include <time.h>

int main(int argc, char **argv) {
  if (argc != 2) return 2;
  setvbuf(stdout, NULL, _IONBF, 0);
  assert(prctl(PR_SET_CHILD_SUBREAPER, 1) == 0);
  int library = open(argv[1], O_RDONLY | O_CLOEXEC);
  assert(library >= 0);
  int companion = spawn_companion(argv, "lsposed-fixture", library);
  close(library);
  if (companion < 0) return 3;
  int client[2];
  assert(socketpair(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0, client) == 0);
  struct timeval timeout = {.tv_sec=8};
  setsockopt(client[0], SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
  assert(write_fd(companion, client[1]) >= 0);
  close(client[1]);
  uint8_t ready = 0;
  assert(read_uint8_t(client[0], &ready) == 1 && ready == 1);
  int cache_size = 0;
  assert(read(client[0], &cache_size, sizeof(cache_size)) == sizeof(cache_size));
  if (cache_size > 0) {
    int cache = read_fd(client[0]);
    assert(cache >= 0);
    close(cache);
  }
  close(client[0]);
  close(companion);
  for (int i = 0; i < 30; i++) {
    pid_t child = waitpid(-1, NULL, WNOHANG);
    if (child < 0 && errno == ECHILD) {
      printf("LSPOSED_REAL_COMPANION_OK CACHE_SIZE=%d SOCKET_CLOSE_CLEANUP_OK\n", cache_size);
      return 0;
    }
    struct timespec pause = {.tv_nsec=100000000};
    nanosleep(&pause, NULL);
  }
  return 4;
}

"""Isolated process/fixture tests; never installs a host, traces init or restarts Android."""
from pathlib import Path
import argparse
import hashlib
import json
import shlex
import subprocess
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / "evidence/maplesu-zygisk-20261104"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--serial", required=True)
    parser.add_argument("--adb", default="D:/platform-tools/adb.exe")
    args = parser.parse_args()
    adb = [args.adb, "-s", args.serial]
    remote = "/data/local/tmp/maplesu-zygisk-smoke-20261104"
    hma = ROOT / "evidence/ultra-zygisk-hma-20261104/hma-release/zygisk/arm64-v8a.so"
    rows = []

    def shell(command):
        result = subprocess.run([*adb, "shell", command], capture_output=True, text=True, timeout=45)
        rows.append({"command": command, "exitCode": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
        if result.returncode:
            raise RuntimeError(result.stdout + result.stderr)
        return result.stdout.strip()

    def push(source, target):
        subprocess.run([*adb, "push", str(source), target], capture_output=True, text=True, check=True, timeout=45)

    with tempfile.TemporaryDirectory(prefix="maplesu-zygisk-smoke-") as temporary:
        folder = Path(temporary)
        fixtures = folder / "fixtures"

        def module(name, prop=None, marker=None, abi="arm64-v8a"):
            directory = fixtures / "revisions" / name
            (directory / "zygisk").mkdir(parents=True)
            (directory / "module.prop").write_text(f"id={prop or name}\nname={name}\n")
            (directory / "zygisk" / f"{abi}.so").write_bytes(b"scanner-fixture")
            if marker:
                (directory / marker).touch()

        module("enabled")
        module("disabled", marker="disable")
        module("removed", marker="remove")
        module("foreign.maplesu-stale-123", prop="foreign")
        module("mismatch", prop="different")
        module("wrongabi", abi="x86")
        module("active_update", marker="update")
        module(".hidden", prop=".hidden")
        module("maplesu_zygisk")
        target = fixtures / "revisions/linked"
        (target / "zygisk").mkdir(parents=True)
        (target / "module.prop").write_text("id=linked\nname=Linked\n")
        (target / "zygisk/arm64-v8a.so").write_bytes(b"scanner-fixture")
        archive = folder / "fixtures.tar"
        with tarfile.open(archive, "w") as tar:
            tar.add(fixtures, arcname="fixtures")
        EVIDENCE.mkdir(parents=True, exist_ok=True)
        try:
            shell(f"mkdir -p {remote}")
            push(archive, remote + "/fixtures.tar")
            for binary in ("maplesu-zygisk-scan", "maplesu-zygisk-abi-probe", "maplesu-zygisk-process-probe", "maplesu-zygisk-mount-probe", "zygisk-ptrace", "zygiskd"):
                push(ROOT / "zygisk/build/arm64-v8a" / binary, remote + "/" + binary)
            push(ROOT / "zygisk/build/arm64-v8a/policy/maplesu-policy", remote + "/policy")
            push(ROOT / "zygisk/module/sepolicy.rule", remote + "/sepolicy.rule")
            push(hma, remote + "/hma.so")
            shell(f"cd {remote} && tar -xf fixtures.tar && chmod 700 maplesu-* zygisk* && "
                  "mkdir -p fixtures/modules && for d in fixtures/revisions/*; do ln -s ../revisions/$(basename \"$d\") fixtures/modules/$(basename \"$d\"); done && ln -s ../missing fixtures/modules/dangling && "
                  "mkdir -p empty/packages")
            output = shell(f"{remote}/maplesu-zygisk-scan {remote}/fixtures/modules arm64-v8a {remote}/fixtures/revisions")
            modules = [line.split("\t")[0] for line in output.splitlines()]
            assert modules == ["active_update", "enabled", "linked"], modules
            shell(f"{remote}/maplesu-zygisk-abi-probe {remote}/hma.so {remote}/empty")
            shell(f"{remote}/maplesu-zygisk-process-probe")
            shell(f"{remote}/maplesu-zygisk-mount-probe")
            shell(f"chmod 700 {remote}/policy")
            output = shell("su -c " + shlex.quote(f"{remote}/policy check --rules {remote}/sepolicy.rule"))
            checked = [json.loads(line) for line in output.splitlines() if line.startswith('{')][-1]
            assert checked["status"] == "checked" and checked["committed"] is False and checked["written_bytes"] == 0, checked

            # Execute HMA's unmodified detection logic with only the absolute fixture root
            # substituted. No installed module paths, properties or policies are changed.
            gate = (ROOT / "evidence/ultra-zygisk-hma-20261104/hma-release/customize.d/22-check-zygisk.sh").read_text(encoding="utf-8")
            gate = gate.replace("/data/adb/", remote + "/hma-gate/")
            prologue = "SYSTEM_LANG=en-US; ZYGISK_ENABLED=; ZYGISK_NAME=; " \
                "ui_print() { echo \"$*\"; }; abort() { echo \"$*\"; exit 1; }; magisk() { return 127; };\n"
            script = folder / "hma-gate.sh"
            script.write_text(prologue + gate, encoding="utf-8", newline="\n")
            push(script, remote + "/hma-gate.sh")
            shell(f"mkdir -p {remote}/hma-gate/modules/maplesu_zygisk/bin {remote}/hma-gate/modules_update && "
                  f"touch {remote}/hma-gate/modules/maplesu_zygisk/bin/zygiskd64")
            prop = folder / "host.prop"
            prop.write_bytes((ROOT / "zygisk/module/module.prop").read_bytes())
            push(prop, remote + "/hma-gate/modules/maplesu_zygisk/module.prop")

            def check_gate(name, expected):
                result = subprocess.run([*adb, "shell", f"sh {remote}/hma-gate.sh"], capture_output=True, text=True, timeout=10)
                assert (result.returncode == 0) == expected, (name, result.stdout, result.stderr)
                if expected:
                    assert "MapleSU Zygisk" in result.stdout, (name, result.stdout)
                rows.append({"case": "hma-gate-" + name, "passed": True, "output": result.stdout})

            check_gate("installed-host", True)
            shell(f"touch {remote}/hma-gate/modules/maplesu_zygisk/disable")
            check_gate("disabled-host", False)
            shell(f"rm {remote}/hma-gate/modules/maplesu_zygisk/disable && touch {remote}/hma-gate/modules/maplesu_zygisk/remove")
            check_gate("removed-host", False)
            shell(f"rm {remote}/hma-gate/modules/maplesu_zygisk/remove && "
                  f"ln -s ../modules/maplesu_zygisk {remote}/hma-gate/modules_update/maplesu_zygisk")
            check_gate("same-host-update", True)
            shell(f"mkdir -p {remote}/hma-gate/modules/other/bin && "
                  f"cp {remote}/hma-gate/modules/maplesu_zygisk/bin/zygiskd64 {remote}/hma-gate/modules/other/bin/zygiskd64 && "
                  f"echo name=OtherZygisk > {remote}/hma-gate/modules/other/module.prop")
            check_gate("conflicting-host", False)
            shell(f"touch {remote}/hma-gate/modules/other/disable && "
                  f"rm {remote}/hma-gate/modules/maplesu_zygisk/bin/zygiskd64")
            check_gate("missing-daemon", False)
            # Wrong argc must print usage without out-of-bounds reads.
            result = subprocess.run([*adb, "shell", f"{remote}/zygisk-ptrace ctl"], capture_output=True, text=True, timeout=10)
            assert result.returncode == 1 and "Available commands" in result.stdout
            rows.append({"case": "control-missing-argument", "passed": True})
            shell(f"{remote}/zygiskd version")
            manifest = {"passed": True, "scannerFixtures": 11, "hmaInstallerFixtures": 6, "loadedModules": modules,
                        "policy": checked,
                        "hmaSha256": hashlib.sha256(hma.read_bytes()).hexdigest(),
                        "scope": "isolated process only; no init tracing, host install, reboot or actual HMA service", "steps": rows}
            (EVIDENCE / "device-smoke.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
            print(json.dumps({"passed": True, "evidence": str(EVIDENCE / "device-smoke.json")}))
        finally:
            # Fixed task-owned directory only; no reads or changes to installed modules.
            shell(f"rm -rf {remote}")


if __name__ == "__main__":
    main()

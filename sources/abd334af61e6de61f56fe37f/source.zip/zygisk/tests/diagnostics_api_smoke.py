"""Offline regression for the production WebUI export handler; no ADB or SDK."""
import argparse
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--save", type=Path)
    args = parser.parse_args()
    checks = []
    with tempfile.TemporaryDirectory(prefix="maplesu-bugreport-") as temporary:
        folder = Path(temporary)
        include = folder / "include/sys"
        include.mkdir(parents=True)
        (include / "system_properties.h").write_text(
            '#pragma once\n#include <string.h>\n#define PROP_VALUE_MAX 92\n'
            'inline int __system_property_get(const char *key, char *out) {\n'
            'const char *v = !strcmp(key,"ro.product.model") ? "Fixture phone" : '
            '!strcmp(key,"ro.product.cpu.abilist64") ? "arm64-v8a" : "";\n'
            'strcpy(out,v); return strlen(v); }\n')
        probe = folder / "probe"
        subprocess.run([shutil.which("g++") or "c++", "-std=c++20", "-Wall", "-Wextra", "-Werror",
                        "-pthread", "-I" + str(include.parent), "-I" + str(ROOT / "zygisk/native"),
                        str(ROOT / "zygisk/tests/webui_probe.cpp"), "-o", str(probe)], check=True)
        fixture = folder / "fixture"
        for name in ("host/payload", "host/data", "host/webroot", "runtime", "modules", "exports",
                     "revisions/hma/zygisk", "system/proc/1", "system/proc/sys/kernel/random",
                     "system/sys/fs/selinux/class/process/perms", "system/system/bin"):
            (fixture / name).mkdir(parents=True)

        def write(name, content):
            path = fixture / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content if isinstance(content, bytes) else content.encode())

        write("host/payload/module.prop", "id=maplesu_zygisk\nversion=5.1.0\n")
        write("host/webroot/source.zip", b"PK-source-fixture")
        write("runtime/state.json", '{"monitor":{"state":"0"}}')
        write("runtime/startup.state", "monitor=ready\nmodules=failed\n")
        write("runtime/policy-action.state", "boot=fixture-boot\naction=restore\nresult=6\nnotifications_coherent=0\n")
        write("runtime/policy-baseline.boot", "fixture-boot")
        write("runtime/policy-restored", "fixture-boot")
        write("revisions/hma/module.prop", "id=hma\nname=HMA\nversion=1\n")
        write("revisions/hma/zygisk/arm64-v8a.so", b"\x7fELF\x02\x01" + bytes(58))
        os.symlink(fixture / "revisions/hma", fixture / "modules/hma")
        write("system/proc/sys/kernel/random/boot_id", "fixture-boot\n")
        write("system/proc/uptime", "20.00 1.00\n")
        write("system/sys/fs/selinux/status", struct.pack("<5I", 1, 4, 1, 3, 0))
        write("system/sys/fs/selinux/enforce", "1\n")
        write("system/sys/fs/selinux/class/process/index", "2\n")
        write("system/sys/fs/selinux/class/process/perms/execmem", "26\n")
        query = "u:r:system_server:s0 u:r:system_server:s0 2"
        write("system/sys/fs/selinux/access", "X" * len(query) + "257ffd ffffffff 0 ffffffff 4 0\n")
        write("runtime/startup-policy", struct.pack("<40siii4xqqQQqqqq", b"fixture-boot", 0, 1, 0,
                                                 10826, 17091, 0, 0, 0, 0, 0, 0))
        key = "SECRET" * 8
        private = "/data/AbCdEf0123456789/owner"
        write("runtime/host.log", "policy notifications: SDK wrapper not recognized\n" + key + "\n" +
              private + "\nhttps://example.test/secret?token=hidden\npassword=short-secret\n中文诊断\n")

        def api(method="POST", path="/api/export", expected=200):
            result = subprocess.run([str(probe), str(fixture), method, path, "tracing"],
                                    check=True, capture_output=True, text=True, timeout=8)
            receipt = json.loads(result.stdout)
            assert receipt["httpStatus"] == expected, receipt
            return receipt["body"]

        def report():
            receipt = api()
            assert receipt["ok"]
            raw = Path(receipt["path"]).read_text()
            return json.loads(raw), raw

        saved, raw = report()
        assert saved.get("schemaVersion") == 2, "Export still contains only status/catalog, without a Bugreport"
        assert saved["sections"]["selinux"]["statusBefore"]["policyload"] == 3
        assert saved["sections"]["selinux"]["access"]["seqno"] == 4
        assert saved["sections"]["selinux"]["seqnoConsistent"] is False
        assert saved["sections"]["selinux"]["access"]["systemServerExecmem"] is False
        checks.append("selinux-real-transaction-and-sequence-mismatch")
        assert saved["sections"]["startupPolicy"]["closed"] == 1
        assert saved["sections"]["startupPolicy"]["startedUptimeMs"] == 10826
        assert "modules=failed" in raw and "SDK wrapper not recognized" in raw
        assert saved["sections"]["system"]["properties"]["ro.product.model"] == "Fixture phone"
        checks.append("startup-failure-and-device-evidence-preserved")
        files = saved["sections"]["files"]
        assert "notifications_coherent=0" in files["runtime/policy-action.state"]["content"]
        assert files["runtime/policy-baseline.boot"]["content"] == "fixture-boot"
        assert files["runtime/policy-restored"]["content"] == "fixture-boot"
        checks.append("last-policy-action-and-same-boot-restore-receipts")
        assert all(secret not in raw for secret in (key, private, "example.test", "short-secret"))
        assert "中文诊断" in raw and saved["catalog"]["modules"][0]["id"] == "hma"
        checks.append("credentials-private-paths-and-links-redacted")

        # Module discovery failure must never suppress the rest of the report.
        (fixture / "modules").rename(fixture / "modules.saved")
        api("GET", "/api/modules", 500)
        saved, raw = report()
        assert saved["catalog"]["error"] == "modules_unreadable"
        assert saved["sections"]["modules"]["error"]
        assert "SDK wrapper not recognized" in raw
        checks.append("unreadable-module-directory-still-exports")
        (fixture / "modules.saved").rename(fixture / "modules")
        write("runtime/state.json", "{broken state\x00")
        saved, raw = report()
        assert "broken state" in raw
        checks.append("corrupt-runtime-json-remains-valid-bugreport")
        first = b"boot-first-line\n"
        split_key = ("PRIVATEFRAGMENT" + "X" * 10).encode() * 2
        write("runtime/host.log", first + b"X" * (32768 - 24 - len(first) - 1) + b"\n" +
              split_key + b"\n" + b"X" * (3 * 1024 * 1024) + b"\nlast-failure\xff\n")
        started = time.monotonic()
        saved, raw = report()
        log = saved["sections"]["files"]["runtime/host.log"]
        assert log["truncated"] and "boot-first-line" in log["content"] and "last-failure" in log["content"]
        assert "PRIVATEFRAGMENT" not in raw
        assert len(raw) < 3 * 1024 * 1024 and time.monotonic() - started < 6
        assert saved["sections"]["logs"]["logcat"]["error"]
        checks.append("bounded-head-tail-invalid-utf8-and-missing-collectors")
        write("system/system/bin/logcat", '#!/bin/sh\nprintf "zygiskd64: collector started\\n"\nexec /bin/sleep 10\n')
        write("system/system/bin/dmesg", '#!/bin/sh\nprintf "unrelated-message\\nKernel panic\\nx0=1234\\nframe-at-0x1234\\n"\n')
        for name in ("logcat", "dmesg"):
            (fixture / "system/system/bin" / name).chmod(0o700)
        started = time.monotonic()
        saved, raw = report()
        assert time.monotonic() - started < 4
        assert saved["sections"]["logs"]["logcat"]["error"] == "collector_timeout"
        assert "collector started" in raw and "x0=1234" in raw and "frame-at-0x1234" in raw
        assert "unrelated-message" not in raw
        checks.append("stalled-collectors-reaped-with-partial-logs-and-trace-context")
        # Current boot stage receipts distinguish an actual failure from discovery.
        module = fixture / "revisions/hma"
        stamp = module.stat()
        write(f"system/data/adb/maplesu/module-boot/{stamp.st_dev}-{stamp.st_ino}/service", "fixture-boot 1 failed\n")
        saved, raw = report()
        hma = next(item for item in saved["sections"]["modules"]["items"] if item["id"] == "hma")
        assert hma["ownedByUltra"] and hma["stageReceipts"]["service"]["content"] == "fixture-boot 1 failed\n"
        checks.append("per-module-ownership-and-real-stage-receipt")
        (fixture / "exports/MapleSU-Zygisk-diagnostic.json.tmp").mkdir()
        assert api(expected=500)["error"] == "export_failed"
        checks.append("write-failure-never-claims-exported")
        source = api(path="/api/export-source")
        assert Path(source["path"]).read_bytes() == b"PK-source-fixture"
        checks.append("source-export-unchanged")

    result = {"passed": True, "scope": "isolated Linux API fixture; no ADB, SDK, host startup or policy reload",
              "tests": checks}
    if args.save:
        args.save.write_text(json.dumps(result, indent=2) + "\n")
    print("BUGREPORT_API_OK", len(checks), "checks")


if __name__ == "__main__":
    main()

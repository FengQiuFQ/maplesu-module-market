// SPDX-License-Identifier: AGPL-3.0-or-later
// Production dispatcher with a recorder policy and app-owned module fixture.
#include "../native/early_modules.c"

static char fixture[4096];
FILE *__real_fopen(const char *, const char *);
FILE *__wrap_fopen(const char *path, const char *mode) {
    char target[4096];
    if (!strcmp(path, "/data/adb/maplesu_zygisk/early.boot")) {
        snprintf(target, sizeof(target), "%s/early.boot", fixture);
        path = target;
    }
    return __real_fopen(path, mode);
}
int maple_scan_modules(const char *root, const char *abi, struct maple_module **out, size_t *count) {
    (void)root; (void)abi;
    *out = calloc(1, sizeof(**out));
    (*out)->name = strdup("policy_fixture");
    char path[4096]; snprintf(path, sizeof(path), "%s/module", fixture);
    (*out)->path = strdup(path);
    (*out)->dir_fd = open(path, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    (*out)->lib_fd = -1;
    *count = 1;
    return (*out)->dir_fd < 0;
}
void maple_free_modules(struct maple_module *modules, size_t count) {
    for (size_t i = 0; i < count; ++i) {
        close(modules[i].dir_fd); free(modules[i].name); free(modules[i].path);
    }
    free(modules);
}
int main(int argc, char **argv) {
    if (argc != 3 || strlen(argv[1]) > 3800) return 64;
    strcpy(fixture, argv[1]);
    int pipefd[2];
    if (pipe2(pipefd, O_CLOEXEC) || dup2(pipefd[1], 198) < 0) return 1;
    close(pipefd[1]);
    char helper[4096]; snprintf(helper, sizeof(helper), "%s/run.sh", fixture);
    int code = maple_run_early_modules(helper);
    close(198);
    char ack = 0; ssize_t n = read(pipefd[0], &ack, 1); close(pipefd[0]);
    printf("EARLY_RESULT exit=%d ack=%c expected=%c\n", code, ack, argv[2][0]);
    return n != 1 || ack != argv[2][0];
}

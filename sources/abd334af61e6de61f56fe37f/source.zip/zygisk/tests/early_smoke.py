"""Exercise production early dispatch with private module and /data/local/tmp mounts."""
from pathlib import Path
import argparse
import hashlib
import json
import shlex
import subprocess
import tarfile
import tempfile
import time
import zipfile

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / "evidence/maplesu-zygisk-20261104"
FILES = "/data/user_de/0/dev.maplesu.manager/files"
REVISIONS = FILES + "/module-zygisk/revisions"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--serial", required=True)
    parser.add_argument("--adb", default="D:/platform-tools/adb.exe")
    parser.add_argument("--sdk-probe", action="store_true", help="Use the installed signed SDK test instrumentation")
    parser.add_argument("--build-dir", type=Path, default=ROOT / "zygisk/build/arm64-v8a")
    parser.add_argument("--launcher", type=Path, default=ROOT / "manager/src/main/assets/maplesu/modules/run.sh")
    parser.add_argument("--save", type=Path, default=EVIDENCE / "early-smoke.json")
    parser.add_argument("--keep-failure", action="store_true")
    args = parser.parse_args()
    adb = [args.adb, "-s", args.serial]
    remote = "/data/local/tmp/maplesu-zygisk-installer-early-20261104"

    def shell(command):
        if args.sdk_probe:
            script = "( " + command + " ); code=$?; printf '\\nMAPLE_TEST_EXIT=%s\\n' \"$code\""
            command_line = "am instrument -w -e action command -e script " + shlex.quote(script) + " dev.maplesu.zygisksprobe/.ProbeRunner"
        else:
            command_line = "su -c " + shlex.quote(command)
        result = subprocess.run([*adb, "shell", command_line],
                                capture_output=True, text=True, timeout=45)
        if args.sdk_probe:
            if result.returncode or "INSTRUMENTATION_RESULT: ok=true" not in result.stdout:
                raise RuntimeError(result.stdout + result.stderr)
            _, found, output = result.stdout.partition("INSTRUMENTATION_RESULT: output=")
            output, marker, receipt = output.partition("\nMAPLE_TEST_EXIT=")
            if not found or not marker:
                raise RuntimeError("SDK test command has no exit receipt: " + result.stdout)
            result = subprocess.CompletedProcess(result.args, int(receipt.splitlines()[0]), output, result.stderr)
        if result.returncode:
            raise RuntimeError(result.stdout + result.stderr)
        return result

    with tempfile.TemporaryDirectory(prefix="maplesu-early-") as temporary:
        folder = Path(temporary)
        fixture = folder / "adb"
        tools = fixture / "maplesu/bin"
        tools.mkdir(parents=True)
        (fixture / "maplesu_zygisk").mkdir()
        (fixture / "modules").mkdir()
        test = fixture / "test"
        (test / "tmp").mkdir(parents=True)
        for source, target in [(ROOT / "third_party/busybox/aarch64/busybox", tools / "busybox"),
                               (args.build_dir / "zygisk-ptrace", test / "ptrace"),
                               (args.build_dir / "maplesu-zygisk-installer-probe", folder / "namespace"),
                               (args.launcher, test / "run.sh")]:
            target.write_bytes(source.read_bytes())
        (test / "maplesu-policy").write_text("#!/system/bin/sh\nprintf 'policy %s\\n' \"$*\" >> /data/adb/test/events\n", newline="\n")

        def module(name, abi="arm64-v8a"):
            directory = fixture / "de-files/module-zygisk/revisions" / name
            (directory / "zygisk").mkdir(parents=True)
            (directory / "module.prop").write_text(f"id={name}\n")
            (directory / "zygisk" / (abi + ".so")).touch()
            return directory

        simple = module("a_simple")
        for stage in ("post-fs-data", "post-mount", "service"):
            (simple / (stage + ".sh")).write_text(
                f"#!/system/bin/sh\nprintf 'simple {stage} %s %s\\n' \"$0\" \"$PWD\" >> /data/adb/test/events\n" +
                ("exit 7\n" if stage == "post-fs-data" else ""), newline="\n")
        for name, marker in [("disabled", "disable"), ("removed", "remove")]:
            directory = module(name)
            (directory / marker).touch()
            (directory / "service.sh").write_text("echo INVALID_MODULE_RAN >> /data/adb/test/events\n", newline="\n")
        official = {}
        for name, filename, abi in [("lsposed", "LSPosed-v1.9.2-7024-zygisk-release.zip", "arm64-v8a"),
                                    ("vector", "Vector-v2.2-3080-Release.zip", "armeabi-v7a")]:
            directory = module(name, abi)
            package = EVIDENCE / filename
            with zipfile.ZipFile(package) as archive:
                for path in ("post-fs-data.sh", "service.sh", "sepolicy.rule"):
                    if path in archive.namelist():
                        (directory / path).write_bytes(archive.read(path))
                official[filename] = hashlib.sha256(package.read_bytes()).hexdigest()
            # Real official stage scripts, fake daemon: no ART injection or services.
            (directory / "daemon").write_text(
                f"#!/system/bin/sh\nprintf 'daemon {name} %s %s\\n' \"$PWD\" \"$*\" >> /data/adb/test/events\n"
                "echo $$ >> /data/adb/test/pids\nexec /system/bin/sleep 120\n", newline="\n")
        stalled = module("z_stalled")
        (stalled / "service.sh").write_text(
            "#!/system/bin/sh\necho $$ > /data/adb/test/stalled.pid\nsleep 120\n", newline="\n")
        normal = fixture / "modules/normal_only"
        (normal / "zygisk").mkdir(parents=True)
        (normal / "module.prop").write_text("id=normal_only\n")
        (normal / "zygisk/arm64-v8a.so").touch()
        (normal / "service.sh").write_text("echo INVALID_MODULE_RAN >> /data/adb/test/events\n", newline="\n")
        (test / "test.sh").write_text(r'''#!/system/bin/sh
exec > /data/adb/test/trace.log 2>&1
set -eu
bb=/data/adb/maplesu/bin/busybox
receipt() { printf '/data/adb/maplesu/module-boot/%s\n' "$(stat -Lc '%d-%i' "/data/adb/modules/$1")"; }
# Hide the real Manager files only inside this process's private namespace.
"$bb" mount --bind /data/adb/de-files /data/user_de/0/dev.maplesu.manager/files
revisions=/data/user_de/0/dev.maplesu.manager/files/module-zygisk/revisions
# Keep even the official LSPosed temp-file cleanup inside this namespace.
"$bb" mount --bind /data/adb/test/tmp /data/local/tmp
/data/adb/test/ptrace stages /data/adb/test/run.sh > /data/adb/test/early.log 2>&1 &
owner=$!
trap 'kill -TERM "$owner" 2>/dev/null || :; wait "$owner" 2>/dev/null || :' EXIT
for n in $(seq 1 200); do
  [ ! -f "$(receipt vector)/service" ] || break
  sleep 0.05
done
test -f "$(receipt vector)/service"
test -f "$(receipt a_simple)/post-mount"
test -z "$(find /data/adb/de-files/module-zygisk/revisions -name .maplesu-boot)"
for n in $(seq 1 200); do
  [ ! -f /data/adb/test/pids ] || [ "$(wc -l < /data/adb/test/pids)" -lt 3 ] || break
  sleep 0.05
done
test "$(wc -l < /data/adb/test/pids)" -eq 3
! grep -q INVALID_MODULE_RAN /data/adb/test/events
test "$(grep -c '^simple ' /data/adb/test/events)" -eq 3
test "$(grep -c '^policy ' /data/adb/test/events)" -eq 2
# policy and all post-fs stages precede the first service dispatch.
test "$(grep -n '^policy ' /data/adb/test/events | tail -1 | cut -d: -f1)" -lt "$(grep -n '^simple post-fs-data ' /data/adb/test/events | cut -d: -f1)"
grep -Fqx "daemon vector $revisions/vector --system-server-max-retry=3" /data/adb/test/events
"$bb" flock -n "$(receipt vector)/service.lock" true
# The later Manager uses the same launcher: no duplicate process or script.
/data/adb/maplesu/bin/busybox sh /data/adb/test/run.sh /data/adb/modules/vector service
code=0
/data/adb/maplesu/bin/busybox sh /data/adb/test/run.sh /data/adb/modules/a_simple post-fs-data || code=$?
test "$code" -eq 7
test "$(grep -c '^simple ' /data/adb/test/events)" -eq 3
test "$(wc -l < /data/adb/test/pids)" -eq 3
# A boot change invalidates a revision's cached stage outcome.
printf 'old-boot 0\n' > "$(receipt a_simple)/service"
/data/adb/maplesu/bin/busybox sh /data/adb/test/run.sh /data/adb/modules/a_simple service
test "$(grep -c '^simple service ' /data/adb/test/events)" -eq 2
# A stale Ultra marker does not deduplicate Normal lifecycle execution.
printf 'old-boot\n' > /data/adb/maplesu_zygisk/early.boot
/data/adb/maplesu/bin/busybox sh /data/adb/test/run.sh /data/adb/modules/a_simple service
test "$(grep -c '^simple service ' /data/adb/test/events)" -eq 3
# Late services acknowledge launch and remain owned by the supervisor.
for n in $(seq 1 100); do
  [ ! -f /data/adb/test/stalled.pid ] || break
  sleep 0.05
done
test -f /data/adb/test/stalled.pid
kill -0 "$(cat /data/adb/test/stalled.pid)"
test "$(awk '{print $3}' "$(receipt z_stalled)/service")" = started
grep -q 'stage=post-fs-data module=a_simple code=7' /data/adb/test/early.log
grep -q 'stage=service module=z_stalled code=0' /data/adb/test/early.log
grep -q 'prepared=0' /data/adb/test/early.log
kill -TERM "$owner"
owner_code=0
wait "$owner" || owner_code=$?
test "$owner_code" -eq 1
trap - EXIT
for pid in $(cat /data/adb/test/pids); do test ! -e "/proc/$pid"; done
test ! -e "/proc/$(cat /data/adb/test/stalled.pid)"
cat /data/adb/test/events
cat /data/adb/test/early.log
echo EARLY_DISPATCH_OK POLICY_ORDER_OK LSPOSED_VECTOR_SCRIPTS_OK DEDUP_OK BOOT_INVALIDATION_OK ASYNC_SERVICE_OK FAILURE_PROPAGATION_OK OWNED_CLEANUP_OK
''', newline="\n")
        archive = folder / "fixture.tar"
        with tarfile.open(archive, "w") as tar:
            tar.add(fixture, arcname="adb")
            tar.add(folder / "namespace", arcname="namespace")
            for directory in (fixture / "de-files/module-zygisk/revisions").iterdir():
                link = tarfile.TarInfo("adb/modules/" + directory.name)
                link.type = tarfile.SYMTYPE
                link.linkname = REVISIONS + "/" + directory.name
                tar.addfile(link)
        shell(f"rm -rf {remote} && mkdir -p {remote} && chown 2000:2000 {remote} && chmod 700 {remote}")
        subprocess.run([*adb, "push", str(archive), remote + "/fixture.tar"], check=True, capture_output=True)
        passed = False
        try:
            shell(f"cd {remote} && tar -xf fixture.tar && chmod 755 namespace adb/test/ptrace adb/test/maplesu-policy adb/maplesu/bin/busybox adb/de-files/module-zygisk/revisions/*/daemon")
            before = shell("readlink /proc/1/ns/mnt").stdout
            shell(f"chmod 755 {remote}; : > {remote}/result.log; chmod 644 {remote}/result.log; "
                  f"( {remote}/namespace {remote} /data/adb/maplesu/bin/busybox sh /data/adb/test/test.sh; "
                  f"code=$?; tail -n 45 {remote}/adb/test/trace.log; "
                  f"if [ $code -ne 0 ]; then cat {remote}/adb/test/events {remote}/adb/test/early.log; fi; "
                  f"printf '%s\\n' \"$code\" > {remote}/exit; chmod 644 {remote}/exit "
                  f") < /dev/null > {remote}/result.log 2>&1 &")
            until = time.monotonic() + 90
            while time.monotonic() < until:
                receipt = subprocess.run([*adb, "shell", f"cat {remote}/exit"],
                                         capture_output=True, text=True, timeout=10)
                if receipt.returncode == 0:
                    result = subprocess.run([*adb, "shell", f"cat {remote}/result.log"],
                                            capture_output=True, text=True, timeout=10)
                    assert receipt.stdout.strip() == "0", result.stdout + result.stderr
                    break
                time.sleep(0.2)
            else:
                raise TimeoutError("Early fixture did not finish")
            assert "EARLY_DISPATCH_OK" in result.stdout
            assert shell("readlink /proc/1/ns/mnt").stdout == before
            output = args.save
            output.write_text(json.dumps({"passed": True, "officialPackages": official,
                "stdout": result.stdout, "stderr": result.stderr,
                "scope": "production stages entrypoint and shared Manager launcher; private /data/adb and /data/local/tmp; unmodified official LSPosed/Vector lifecycle scripts; policies and daemons are recorders; no actual policy load, ART, init tracing or reboot"}, indent=2), encoding="utf-8")
            print(json.dumps({"passed": True, "evidence": str(output)}))
            passed = True
        finally:
            if passed or not args.keep_failure:
                shell(f"rm -rf {remote}")


if __name__ == "__main__":
    main()

"""Official LSPosed/Vector ELF registration and isolated installer/service fixtures."""
from pathlib import Path
import argparse
import hashlib
import json
import shlex
import subprocess
import tarfile
import tempfile
import uuid
import zipfile

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / "evidence/maplesu-zygisk-20261104"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--serial", required=True)
    parser.add_argument("--adb", default="D:/platform-tools/adb.exe")
    parser.add_argument("--sdk-probe", action="store_true")
    parser.add_argument("--build-dir", type=Path, default=ROOT / "zygisk/build/arm64-v8a")
    parser.add_argument("--save", type=Path, default=EVIDENCE / "framework-smoke.json")
    args = parser.parse_args()
    adb = [args.adb, "-s", args.serial]
    remote = "/data/local/tmp/maplesu-zygisk-installer-framework-" + uuid.uuid4().hex
    rows = []

    def shell(command, check=True):
        if args.sdk_probe:
            script = "( " + command + " ); code=$?; printf '\\nMAPLE_TEST_EXIT=%s\\n' \"$code\""
            command_line = "am instrument -w -e action command -e script " + shlex.quote(script) + " dev.maplesu.zygisksprobe/.ProbeRunner"
        else:
            command_line = "su -c " + shlex.quote(command)
        result = subprocess.run([*adb, "shell", command_line],
                                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=40)
        if args.sdk_probe:
            if result.returncode or "INSTRUMENTATION_RESULT: ok=true" not in result.stdout:
                raise RuntimeError(result.stdout + result.stderr)
            _, found, output = result.stdout.partition("INSTRUMENTATION_RESULT: output=")
            output, marker, receipt = output.partition("\nMAPLE_TEST_EXIT=")
            if not found or not marker:
                raise RuntimeError("SDK test command has no exit receipt: " + result.stdout)
            result = subprocess.CompletedProcess(result.args, int(receipt.splitlines()[0]), output, result.stderr)
        if check and result.returncode:
            raise RuntimeError(result.stdout + result.stderr)
        return result

    vector = EVIDENCE / "Vector-v2.2-3080-Release.zip"
    lsposed = EVIDENCE / "LSPosed-v1.9.2-7024-zygisk-release.zip"
    with tempfile.TemporaryDirectory(prefix="maplesu-framework-") as temporary:
        folder = Path(temporary)
        for source, target in [(args.build_dir / "maplesu-zygisk-installer-probe", "namespace"),
                               (args.build_dir / "maplesu-zygisk-module-probe", "probe"),
                               (args.build_dir / "maplesu-zygisk-companion-probe", "companion-probe"),
                               (ROOT / "manager/src/main/assets/maplesu/modules/runner.sh", "runner.sh"),
                               (ROOT / "manager/src/main/assets/maplesu/modules/run.sh", "run.sh"),
                               (lsposed, "lsposed.zip"),
                               (vector, "input.zip")]:
            (folder / target).write_bytes(source.read_bytes())
        (folder / "adb/maplesu/bin").mkdir(parents=True)
        (folder / "adb/maplesu/bin/busybox").write_bytes((ROOT / "third_party/busybox/aarch64/busybox").read_bytes())
        (folder / "adb/modules/maplesu_zygisk/bin").mkdir(parents=True)
        (folder / "adb/modules/maplesu_zygisk/bin/zygiskd64").write_bytes((args.build_dir / "zygiskd").read_bytes())
        (folder / "bin").mkdir()
        (folder / "bin/chcon").write_text('#!/system/bin/sh\nprintf "%s\\n" "$*" >> "$TEST_CHCON_LOG"\n', newline="\n")
        with zipfile.ZipFile(vector) as archive:
            (folder / "vector.so").write_bytes(archive.read("lib/arm64-v8a/libzygisk.so"))
            service = archive.read("service.sh")
        with zipfile.ZipFile(lsposed) as archive:
            (folder / "lsposed.so").write_bytes(archive.read("lib/arm64-v8a/liblspd.so"))
        archive = folder / "fixture.tar"
        with tarfile.open(archive, "w") as tar:
            for path in folder.iterdir():
                if path != archive:
                    tar.add(path, arcname=path.name)
        shell(f"mkdir -p {remote} && chown 2000:2000 {remote} && chmod 700 {remote}")
        subprocess.run([*adb, "push", str(archive), remote + "/fixture.tar"], check=True, capture_output=True)
        try:
            shell(f"cd {remote} && tar -xf fixture.tar && chmod 755 namespace probe companion-probe bin/chcon adb/maplesu/bin/busybox adb/modules/maplesu_zygisk/bin/zygiskd64")
            # Use the real published compatibility entry in the private fixture.
            shell(f"mkdir -p {remote}/adb/maplesu/bin/compat && "
                  f"cp /data/adb/maplesu/bin/compat/magisk {remote}/adb/maplesu/bin/compat/magisk")
            for name in ("lsposed", "vector"):
                result = shell(f"{remote}/probe {remote}/{name}.so")
                expected_api = 2 if name == "lsposed" else 4
                assert f"REGISTERED_API{expected_api} APP_AND_SERVER_CALLBACKS_PRESENT" in result.stdout, result.stdout
                rows.append({"case": name + "-elf-registration", "output": result.stdout,
                             "librarySha256": hashlib.sha256((folder / (name + ".so")).read_bytes()).hexdigest(),
                             "boundary": "onLoad only; companion connection is stubbed as unavailable; no JNI specialization or ART hooks"})
            result = shell(f"{remote}/namespace {remote} {remote}/companion-probe {remote}/lsposed.so")
            assert "LSPOSED_REAL_COMPANION_OK" in result.stdout and "SOCKET_CLOSE_CLEANUP_OK" in result.stdout
            rows.append({"case": "lsposed-real-companion", "output": result.stdout,
                         "boundary": "production spawn/exec/FD protocol and official companion; symbol cache may be unavailable without ART"})
            shell(f"mkdir {remote}/module && cd {remote}/module && unzip -oq {remote}/input.zip")
            result = shell(f"TEST_CHCON_LOG={remote}/chcon.log {remote}/namespace {remote}")
            assert "Welcome to Vector!" in result.stdout, result
            shell(f"cmp {remote}/vector.so {remote}/module/zygisk/arm64-v8a.so && "
                  f"test -f {remote}/module/zygisk/armeabi-v7a.so && test ! -e {remote}/module/.maplesu-tmp")
            modes = shell(f"stat -c '%a' {remote}/module/cli {remote}/module/daemon "
                          f"{remote}/module/bin/dex2oat64").stdout.splitlines()
            assert modes == ["744", "744", "755"], modes
            rows.append({"case": "vector-full-installer", "output": result.stdout,
                         "verifiedResources": result.stdout.count("- Verified "),
                         "executableModes": modes,
                         "boundary": "unmodified official installer; chcon recorded by a fixture command; no policy apply"})
            # Keep the official service.sh. Only replace its daemon with a recorder,
            # so its namespace command, working directory and arguments execute for real.
            daemon = folder / "daemon"
            daemon.write_text('''#!/system/bin/sh
printf '%s\\n' "$PWD" "$*" "$(readlink /proc/self/ns/mnt)" > "$TEST_DAEMON_LOG"
''', newline="\n")
            subprocess.run([*adb, "push", str(daemon), remote + "/daemon.fixture"], check=True, capture_output=True)
            shell(f"cp {remote}/daemon.fixture {remote}/module/daemon && chmod 755 {remote}/module/daemon")
            before = shell("readlink /proc/1/ns/mnt").stdout.strip()
            result = shell(f"TEST_DAEMON_LOG={remote}/daemon.log MAPLESU_BIN=/data/adb/maplesu/bin "
                           f"{remote}/namespace {remote} /system/bin/sh {remote}/run.sh {remote}/module service")
            output = shell(f"for n in 1 2 3 4 5 6 7 8 9 10; do test ! -f {remote}/daemon.log || break; sleep 0.1; done; "
                           f"cat {remote}/daemon.log").stdout.splitlines()
            assert output[:2] == [remote + "/module", "--system-server-max-retry=3"], output
            assert output[2] != before and shell("readlink /proc/1/ns/mnt").stdout.strip() == before
            rows.append({"case": "vector-official-service-launch", "workingDirectory": output[0],
                         "daemonArguments": output[1], "privateNamespace": True,
                         "serviceSha256": hashlib.sha256(service).hexdigest(),
                         "boundary": "real BusyBox/unshare and official service.sh; daemon is a recorder"})
            shell(f"rm -rf {remote}/module && mkdir {remote}/module && "
                  f"cp {remote}/lsposed.zip {remote}/input.zip && "
                  f"cd {remote}/module && unzip -oq {remote}/input.zip")
            result = shell(f"TEST_CHCON_LOG={remote}/chcon.log {remote}/namespace {remote}")
            assert "Welcome to LSPosed!" in result.stdout, result.stdout + result.stderr
            assert "not found" not in result.stderr and "integer expression" not in result.stderr, result.stderr
            shell(f"cmp {remote}/lsposed.so {remote}/module/zygisk/arm64-v8a.so && "
                  f"test -f {remote}/module/zygisk/armeabi-v7a.so && test ! -e {remote}/module/.maplesu-tmp")
            modes = shell(f"stat -c '%a' {remote}/module/daemon {remote}/module/bin/dex2oat64").stdout.splitlines()
            assert modes == ["744", "755"], modes
            rows.append({"case": "lsposed-full-installer", "output": result.stdout,
                         "executableModes": modes,
                         "boundary": "unmodified official installer and checksums; chcon is a recorder; no policy apply or ART hooks"})
            with zipfile.ZipFile(lsposed) as package:
                service = package.read("service.sh")
            shell(f"cp {remote}/daemon.fixture {remote}/module/daemon && chmod 755 {remote}/module/daemon && "
                  f"rm -f {remote}/daemon.log")
            shell(f"TEST_DAEMON_LOG={remote}/daemon.log MAPLESU_BIN=/data/adb/maplesu/bin "
                  f"{remote}/namespace {remote} /system/bin/sh {remote}/run.sh {remote}/module service")
            output = shell(f"for n in 1 2 3 4 5 6 7 8 9 10; do test ! -f {remote}/daemon.log || break; sleep 0.1; done; "
                           f"cat {remote}/daemon.log").stdout.splitlines()
            assert output[:2] == [remote + "/module", "--from-service"], output
            assert output[2] != before and shell("readlink /proc/1/ns/mnt").stdout.strip() == before
            rows.append({"case": "lsposed-official-service-launch", "workingDirectory": output[0],
                         "daemonArguments": output[1], "privateNamespace": True,
                         "serviceSha256": hashlib.sha256(service).hexdigest(),
                         "boundary": "real BusyBox/unshare and official service.sh; daemon is a recorder"})
            evidence = {"passed": True, "scope": "isolated processes and private mount namespace; no framework installation, policy apply, actual framework daemon, init tracing or reboot",
                        "officialPackages": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (lsposed, vector)},
                        "sources": {"LSPosed-v1.9.2": "f8927757e8704d96611e1f3d75f702e3f0ce061f", "Vector-v2.2": "88f8e1faa8b4e7ce20aefabe9c295cd746ea038e"},
                        "launchers": {name: hashlib.sha256((folder / name).read_bytes()).hexdigest()
                                      for name in ("runner.sh", "run.sh")},
                        "cases": rows}
            path = args.save
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(evidence, indent=2), encoding="utf-8")
            print(json.dumps({"passed": True, "evidence": str(path)}))
        finally:
            shell(f"rm -rf {remote}")


if __name__ == "__main__":
    main()

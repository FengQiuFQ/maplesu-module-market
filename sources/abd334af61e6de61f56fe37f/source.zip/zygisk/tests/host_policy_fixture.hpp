// Isolated host-callsite fixture. SDK memory and policy-load events are simulated;
// host.cpp, its notifier decoder and its action callback execute unchanged.
#pragma once
#include <cassert>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <functional>
#include <map>
#include <set>
#include <string>
#include <sys/mman.h>
#include <unistd.h>
#include "/source/zygisk/native/startup_policy.h"

namespace fixture {
struct State {
    uint8_t suppressed;
    bool fail_write, fail_verification, fail_status, malformed_access, racing_status, no_wrapper, fail_load;
    bool odd_status, resuppress;
    unsigned status_reads;
    unsigned control_reads, notifier_writes, loads, withdrawals;
    unsigned policyload, access_seqno, sequence;
    maple_policy_result outcome;
};
inline State *state;
inline std::function<maple_policy_receipt(bool)> action;
inline constexpr uint64_t function = 0xffff000000001000ULL;
inline constexpr uint64_t callback = 0xffffd193991a0000ULL;
inline constexpr uint64_t control = 0xffffd193991a6000ULL;
inline void constant(uint32_t *out, uint64_t address, unsigned reg) {
    for (unsigned i = 0; i < 4; ++i)
        out[i] = (i ? 0xf2800000 : 0xd2800000) | (i << 21) |
            (((address >> (16 * i)) & 0xffff) << 5) | reg;
}
inline void load() {
    ++state->loads;
    ++state->access_seqno;
    if (!state->suppressed) {
        state->sequence += 2;
        state->policyload = state->access_seqno;
    }
}
}
inline bool is_failed(int error) { return error != 0; }
struct CivetServer {};
struct mg_connection {};
namespace skroot_env { enum class ModuleRunState { NotRunning, Running, Abnormal }; }
namespace kernel_module {
inline int kallsyms_lookup_name(const char *name, uint64_t &address) {
    if (fixture::state->no_wrapper) return -1;
    address = fixture::function + (strcmp(name, "selinux_status_update_setenforce") == 0 ? 0x1000 : 0);
    return 0;
}
inline int read_kernel_mem(uint64_t address, void *output, uint32_t size) {
    if (address == fixture::control && size == 1) {
        if (++fixture::state->control_reads == 2 && fixture::state->fail_verification) return -1;
        memcpy(output, &fixture::state->suppressed, 1);
        return 0;
    }
    for (unsigned i = 0; i < 2; ++i) {
        uint32_t entry = 0x14000040;
        if (address == fixture::function + i * 0x1000 && size == sizeof(entry)) {
            memcpy(output, &entry, size); return 0;
        }
        uint32_t wrapper[8] = {0xd10143ff, 0xa9bf7bfd, 0xa9bf7ffc};
        fixture::constant(wrapper + 3, fixture::callback + i * 0x1000, 28);
        wrapper[7] = 0xd63f0380;
        if (address == fixture::function + i * 0x1000 + 0x100 && size == sizeof(wrapper)) {
            memcpy(output, wrapper, size); return 0;
        }
        uint32_t callback[128] = {};
        fixture::constant(callback + 12, fixture::control, 10);
        callback[16] = 0x3940014a; callback[17] = 0x3400010a;
        if (address == fixture::callback + i * 0x1000 && size == sizeof(callback)) {
            memcpy(output, callback, size); return 0;
        }
    }
    return -1;
}
inline int write_kernel_mem(uint64_t address, const void *data, uint32_t size) {
    assert(address == fixture::control && size == 1);
    ++fixture::state->notifier_writes;
    if (fixture::state->fail_write) return -1;
    memcpy(&fixture::state->suppressed, data, 1);
    return 0;
}
inline void set_current_module_run_state(skroot_env::ModuleRunState) {}
class WebUIHttpHandler {
public:
    enum class ServerExitAction { KeepRunning };
    virtual void onPrepareCreate(const char *, const char *, uint32_t) {}
    virtual bool handleGet(CivetServer *, mg_connection *, const std::string &, const std::string &) { return false; }
    virtual bool handlePost(CivetServer *, mg_connection *, const std::string &, const std::string &) { return false; }
    virtual ServerExitAction onBeforeServerExit() { return ServerExitAction::KeepRunning; }
};
namespace webui {
using KvMap = std::map<std::string, std::string>;
inline void send_json(mg_connection *, int, const std::string &, const KvMap *) {}
}
}
namespace maple {
inline bool read_authorized_uids(const std::string &, const char *, std::set<uid_t> &) { return true; }
namespace webui {
struct Reply { int status; std::string body; };
class Api {
public:
    Api(const char *, std::function<maple_policy_receipt(bool)> action) { fixture::action = std::move(action); }
    Reply dispatch(const std::string &, const std::string &) { return {200, "{}"}; }
};
}
}
inline int maple_bootstrap_process(int) { return 1; }
inline bool maple_tracer_context() { return true; }
#define MAPLE_SDK_ARCHIVE_SHA256 "offline-fixture"
#define SKROOT_MODULE_NAME(...)
#define SKROOT_MODULE_VERSION(...)
#define SKROOT_MODULE_DESC(...)
#define SKROOT_MODULE_AUTHOR(...)
#define SKROOT_MODULE_ID32(...)
#define SKROOT_MODULE_WEB_UI(...)
#define SKROOT_MODULE_ON_INSTALL(...)
#define SKROOT_MODULE_ON_UNINSTALL(...)

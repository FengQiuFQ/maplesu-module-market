"""Execute unmodified production host call sites with offline SDK/kernel I/O."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
CASES = ["full-restore", "temporary", "already-normal", "readback-failed", "write-failed", "missing-backup",
         "status-unreadable", "malformed-access", "status-odd", "racing-status", "no-wrapper", "reload-failed", "resuppressed"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--save", type=Path)
    parser.add_argument("--baseline", type=Path)
    parser.add_argument("--case", choices=CASES)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="maplesu-host-policy-") as temporary:
        out = Path(temporary)
        sources = ["zygisk/native/host.cpp", "zygisk/native/process.hpp", "zygisk/native/policy_notifications.hpp",
                   "zygisk/native/notification_switch.h", "zygisk/native/startup_policy.h",
                   "zygisk/tests/host_policy_fixture.hpp", "zygisk/tests/host_policy_probe.cpp"]
        inputs = {name: ROOT / name for name in sources}
        if args.baseline:
            for name in ("zygisk/native/host.cpp", "zygisk/native/policy_notifications.hpp"):
                inputs[name] = args.baseline / ("before-" + Path(name).name)
        for name, source in inputs.items():
            if name != "zygisk/native/startup_policy.h":
                shutil.copyfile(source, out / Path(name).name)
        for name in ("kernel_module_kit_umbrella.h", "bootstrap.h", "tracer_context.h", "webui.hpp",
                     "auth_snapshot.hpp", "startup_policy.h"):
            (out / name).write_text('#include "host_policy_fixture.hpp"\n', encoding="utf-8")
        (out / "sys").mkdir()
        (out / "sys/system_properties.h").write_text(
            '#pragma once\n#define PROP_VALUE_MAX 92\n'
            'inline int __system_property_get(const char *, char *value) { value[0]=0; return 0; }\n')
        cases = [args.case] if args.case else CASES
        script = ('set -eu\nc++ -std=c++20 -D_GNU_SOURCE -UNDEBUG -Wall -Wextra -Werror '
                  '-Wno-unused-function -Wno-attributes -fsanitize=address,undefined -fno-omit-frame-pointer '
                  '-I/output /output/host_policy_probe.cpp -Wl,--wrap=execl -Wl,--wrap=open -Wl,--wrap=read -Wl,--wrap=write -Wl,--wrap=close -o /output/probe\n')
        for case in cases:
            script += f'set +e\n/output/probe {case}\ncode=$?\nset -e\nprintf "%s\\n" "$code" > /output/{case}.exit\n'
        run = subprocess.run([
            "docker", "run", "--rm", "--pull", "never", "--network", "none", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--mount", f"type=bind,source={ROOT},target=/source,readonly",
            "--mount", f"type=bind,source={out},target=/output",
            "ghcr.io/ylarod/ddk-min:android15-6.6-20260828", "sh", "-c", script,
        ], capture_output=True, text=True, timeout=60)
        results = {case: int((out / f"{case}.exit").read_text()) for case in cases if (out / f"{case}.exit").exists()}
        record = {"deviceAccess": False, "productionBuild": False, "kernelIoSimulated": True,
                  "sourceSha256": {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in inputs.items()},
                  "containerExitCode": run.returncode, "checks": results, "stdout": run.stdout, "stderr": run.stderr}
        if args.save:
            args.save.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(record, indent=2))
        assert run.returncode == 0 and len(results) == len(cases) and all(code == 0 for code in results.values())


if __name__ == "__main__":
    main()

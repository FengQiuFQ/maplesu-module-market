// Runs the production host WebUI callback with simulated kernel I/O only.
#include "host_policy_fixture.hpp"
#include "host.cpp"

extern "C" void maple_startup_policy_init() {}
extern "C" bool maple_startup_policy_snapshot(const char *) { return true; }
extern "C" bool maple_startup_policy_restored() { return true; }
extern "C" bool maple_startup_policy_needed() { return false; }
extern "C" void maple_startup_policy_finish(const char *, bool) {}
extern "C" maple_policy_receipt maple_startup_policy_withdraw(const char *, bool) {
    ++fixture::state->withdrawals;
    if (fixture::state->outcome == MAPLE_POLICY_DONE) fixture::load();
    if (fixture::state->resuppress) fixture::state->suppressed = 1;
    return {fixture::state->outcome, 0};
}
extern "C" int __wrap_execl(const char *path, const char *arg0, ...) {
    assert(std::string(path).ends_with("/bin/maplesu-policy"));
    va_list args; va_start(args, arg0);
    const char *command = va_arg(args, const char *);
    assert(command && strcmp(command, "apply") == 0 && va_arg(args, const char *) == nullptr);
    va_end(args);
    if (fixture::state->fail_load) _exit(17);
    fixture::load();
    _exit(0);
}


// Only SELinuxfs descriptors are simulated. Forks, waits and host policy
// subprocess argv still use the real production path in the Linux fixture.
extern "C" int __real_open(const char *, int, ...);
extern "C" ssize_t __real_read(int, void *, size_t);
extern "C" ssize_t __real_write(int, const void *, size_t);
extern "C" int __real_close(int);
static constexpr int status_fd = 900000, access_fd = 900001, class_fd = 900002;
extern "C" int __wrap_open(const char *path, int flags, ...) {
    if (!strcmp(path, "/sys/fs/selinux/status")) {
        if (fixture::state->fail_status) { errno = EACCES; return -1; }
        return status_fd;
    }
    if (!strcmp(path, "/sys/fs/selinux/access")) return access_fd;
    if (!strcmp(path, "/sys/fs/selinux/class/process/index")) return class_fd;
    mode_t mode = 0;
    if (flags & O_CREAT) {
        va_list args; va_start(args, flags); mode = va_arg(args, int); va_end(args);
    }
    return __real_open(path, flags, mode);
}
extern "C" ssize_t __wrap_read(int fd, void *out, size_t size) {
    auto &s = *fixture::state;
    if (fd == status_fd) {
        assert(size == 20);
        uint32_t status[] = {1, s.sequence | (s.odd_status ? 1u : 0u), 1, s.policyload, 0};
        memcpy(out, status, sizeof(status));
        ++s.status_reads;
        return sizeof(status);
    }
    if (fd == access_fd || fd == class_fd) {
        char response[256];
        if (fd == class_fd) strcpy(response, "2\n");
        else if (s.malformed_access) strcpy(response, "invalid\n");
        else {
            if (s.racing_status && s.status_reads == 1) fixture::load();
            snprintf(response, sizeof(response), "0 ffffffff 0 ffffffff %u 0\n", s.access_seqno);
        }
        assert(strlen(response) < size);
        memcpy(out, response, strlen(response));
        return strlen(response);
    }
    return __real_read(fd, out, size);
}
extern "C" ssize_t __wrap_write(int fd, const void *data, size_t size) {
    if (fd == access_fd) {
        assert(std::string(static_cast<const char *>(data), size) == "u:r:system_server:s0 u:r:system_server:s0 2");
        return size;
    }
    return __real_write(fd, data, size);
}
extern "C" int __wrap_close(int fd) {
    return fd >= status_fd && fd <= class_fd ? 0 : __real_close(fd);
}

int main(int argc, char **argv) {
    assert(argc == 2);
    fixture::state = static_cast<fixture::State *>(mmap(nullptr, sizeof(fixture::State),
        PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0));
    assert(fixture::state != MAP_FAILED);
    auto &s = *fixture::state;
    s = {}; s.suppressed = 1; s.policyload = 3; s.access_seqno = 4; s.sequence = 4;
    s.outcome = MAPLE_POLICY_DONE;
    std::string test(argv[1]);
    bool full = test != "temporary";
    if (test == "already-normal") { s.suppressed = 0; s.policyload = s.access_seqno; }
    if (test == "readback-failed") s.fail_verification = true;
    if (test == "write-failed") s.fail_write = true;
    if (test == "missing-backup") s.outcome = MAPLE_POLICY_NO_BACKUP;
    if (test == "status-unreadable") s.fail_status = true;
    if (test == "malformed-access") s.malformed_access = true;
    if (test == "status-odd") s.odd_status = true;
    if (test == "racing-status") s.racing_status = true;
    if (test == "no-wrapper") { s.no_wrapper = true; s.suppressed = 0; s.policyload = s.access_seqno; }
    if (test == "reload-failed") { s.fail_load = true; s.outcome = MAPLE_POLICY_REQUIRED; }
    if (test == "resuppressed") s.resuppress = true;
    WebUI webui;
    webui.onPrepareCreate(nullptr, "/fixture/host", 0);
    auto result = fixture::action(full);
    bool expected_failure = test == "write-failed" || test == "missing-backup" || test == "status-unreadable" ||
        test == "malformed-access" || test == "status-odd" || test == "reload-failed";
    bool coherent = s.policyload == s.access_seqno;
    bool passed = s.withdrawals == 1 && (expected_failure ? result.result != MAPLE_POLICY_DONE :
        result.result == MAPLE_POLICY_DONE && coherent && s.suppressed == 0);
    if (test == "missing-backup") passed &= result.result == MAPLE_POLICY_NO_BACKUP && coherent;
    if (test == "reload-failed") passed &= result.result == MAPLE_POLICY_REQUIRED && s.policyload != s.access_seqno;
    printf("%s: %s result=%d status.sequence=%u status.policyload=%u access.avd.seqno=%u loads=%u notifier_writes=%u\n",
        passed ? "PASS" : "FAIL", test.c_str(), result.result, s.sequence, s.policyload, s.access_seqno,
        s.loads, s.notifier_writes);
    munmap(fixture::state, sizeof(fixture::State));
    return passed ? 0 : 1;
}

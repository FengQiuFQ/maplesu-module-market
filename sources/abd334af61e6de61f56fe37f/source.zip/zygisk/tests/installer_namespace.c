// Run installers with a process-private fixture mounted at /data/adb.
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mount.h>
#include <unistd.h>
#include <limits.h>

int main(int argc, char **argv) {
    const char *prefix = "/data/local/tmp/maplesu-zygisk-installer-";
    if (argc < 2 || strncmp(argv[1], prefix, strlen(prefix)) != 0) return 2;
    char base[PATH_MAX];
    if (!realpath(argv[1], base) || strcmp(base, argv[1]) != 0) return 2;
    if (unshare(CLONE_NEWNS) != 0 || mount(NULL, "/", NULL, MS_REC | MS_PRIVATE, NULL) != 0) {
        perror("isolate namespace");
        return 3;
    }
    char adb[PATH_MAX], runner[PATH_MAX], module[PATH_MAX], zip[PATH_MAX], path[PATH_MAX];
    snprintf(adb, sizeof(adb), "%s/adb", base);
    if (mount(adb, "/data/adb", NULL, MS_BIND, NULL) != 0) {
        perror("bind fixture");
        return 4;
    }
    snprintf(runner, sizeof(runner), "%s/runner.sh", base);
    snprintf(module, sizeof(module), "%s/module", base);
    snprintf(zip, sizeof(zip), "%s/input.zip", base);
    snprintf(path, sizeof(path), "%s/bin:/system/bin:/system/xbin", base);
    setenv("PATH", path, 1);
    if (argc > 2) execv(argv[2], &argv[2]);
    else execl("/system/bin/sh", "sh", runner, module, "customize.sh", zip, NULL);
    perror("exec installer");
    return 5;
}

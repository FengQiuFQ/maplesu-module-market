#!/bin/sh
# Run as Root in an isolated Linux environment; no device installation.
set -eu
runner="$1"
fixture="$(mktemp -d /tmp/maplesu-installer-permissions.XXXXXX)"
trap 'rm -rf -- "$fixture"' EXIT
mkdir "$fixture/bin"
printf '#!/bin/sh\necho 36\n' > "$fixture/bin/getprop"
chmod 755 "$fixture/bin/getprop"
export PATH="$fixture/bin:$PATH"

for mode in customize skip-unzip defaults callback; do
    module="$fixture/$mode"
    mkdir -p "$module/system/bin"
    printf fixture > "$module/module.prop"
    printf fixture > "$module/ordinary"
    printf fixture > "$module/system/bin/tool"
    chmod 777 "$module/ordinary" "$module/system/bin/tool"
    case "$mode" in
        customize)
            printf 'set_perm "$MODPATH/ordinary" 0 0 0744\n' > "$module/customize.sh" ;;
        skip-unzip)
            printf 'SKIPUNZIP=1\nset_perm "$MODPATH/ordinary" 0 0 0744\n' > "$module/customize.sh" ;;
        defaults)
            printf 'true\n' > "$module/customize.sh" ;;
        callback)
            printf 'set_permissions() { set_perm "$MODPATH/ordinary" 0 0 0744; }\n' > "$module/customize.sh" ;;
    esac
    sh "$runner" "$module" customize.sh "$fixture/input.zip"
    expected=744
    [ "$mode" != defaults ] || expected=644
    actual="$(stat -c '%a' "$module/ordinary")"
    if [ "$actual" != "$expected" ]; then
        printf 'FAIL case=%s expected=%s actual=%s\n' "$mode" "$expected" "$actual"
        exit 1
    fi
    if [ "$mode" != skip-unzip ]; then
        [ "$(stat -c '%a' "$module/system/bin/tool")" = 755 ]
    fi
    [ ! -e "$module/.maplesu-tmp" ]
    printf 'PASS case=%s mode=%s\n' "$mode" "$actual"
done

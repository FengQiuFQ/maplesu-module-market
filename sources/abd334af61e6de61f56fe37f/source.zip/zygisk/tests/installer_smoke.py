"""Run the unmodified HMA installer in a process-private /data/adb fixture."""
from pathlib import Path
import argparse
import hashlib
import json
import shlex
import subprocess
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / "evidence/maplesu-zygisk-20261104"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--serial", required=True)
    parser.add_argument("--adb", default="D:/platform-tools/adb.exe")
    parser.add_argument("--baseline", action="store_true")
    args = parser.parse_args()
    adb = [args.adb, "-s", args.serial]
    remote = "/data/local/tmp/maplesu-zygisk-installer-20261104"
    package = ROOT / "evidence/ultra-zygisk-hma-20261104/HMA-OSS-ZYGISK-oss-173-release.zip"
    rows = []

    def shell(command, check=True):
        result = subprocess.run([*adb, "shell", "su -c " + shlex.quote(command)],
                                capture_output=True, text=True, timeout=50)
        if check and result.returncode:
            raise RuntimeError(result.stdout + result.stderr)
        return result

    with tempfile.TemporaryDirectory(prefix="maplesu-installer-") as temporary:
        folder = Path(temporary)
        (folder / "runner.sh").write_bytes((ROOT / "manager/src/main/assets/maplesu/modules/runner.sh").read_bytes())
        (folder / "namespace").write_bytes((ROOT / "zygisk/build/arm64-v8a/maplesu-zygisk-installer-probe").read_bytes())
        (folder / "bin").mkdir()
        (folder / "bin/pm").write_text('''#!/system/bin/sh
case "$1 $2" in
  'list packages') [ "$HMA_PM_CASE" != update ] || echo package:org.frknkrc44.hma_oss ;;
  'list users') printf 'Users:\\n\\tUserInfo{0:Owner:13} running\\n\\tUserInfo{10:Work:30} running\\n\\tUserInfo{999:Dual:30} running\\n' ;;
  'path --user') echo package:/fixture/manager.apk ;;
  'install --user') printf '%s\\n' "$*" >> "$HMA_PM_LOG"; echo Success ;;
  *) exit 97 ;;
esac
exit 0
''', encoding="utf-8", newline="\n")
        host = folder / "adb/modules/maplesu_zygisk"
        (host / "bin").mkdir(parents=True)
        (folder / "adb/modules_update").mkdir()
        (host / "bin/zygiskd64").touch()
        (host / "module.prop").write_bytes((ROOT / "zygisk/module/module.prop").read_bytes())
        (folder / "input.zip").write_bytes(package.read_bytes())
        archive = folder / "fixture.tar"
        with tarfile.open(archive, "w") as tar:
            for name in ("runner.sh", "namespace", "bin", "adb", "input.zip"):
                tar.add(folder / name, arcname=name)
        shell(f"mkdir -p {remote} && chown 2000:2000 {remote} && chmod 700 {remote}")
        subprocess.run([*adb, "push", str(archive), remote + "/fixture.tar"],
                       capture_output=True, check=True, timeout=45)
        try:
            shell(f"cd {remote} && tar -xf fixture.tar && chmod 755 bin/pm namespace")
            before = shell("readlink /proc/1/ns/mnt; awk '$5 == \"/data/adb\" {print}' /proc/1/mountinfo").stdout
            cases = [("fresh", True)] if args.baseline else [("fresh", True), ("update", True),
                                                             ("corrupt-resource", False), ("missing-host", False)]
            for case, expected in cases:
                # Every run starts from official bytes, including all resource hashes.
                shell(f"rm -rf {remote}/module && mkdir {remote}/module && "
                      f"cd {remote}/module && unzip -oq {remote}/input.zip && rm -f {remote}/pm.log")
                if case == "corrupt-resource":
                    shell(f"echo corrupt >> {remote}/module/classes.dex")
                if case == "missing-host":
                    shell(f"touch {remote}/adb/modules/maplesu_zygisk/disable")
                result = shell(f"SYSTEM_LANG=en-US HMA_PM_CASE={case} HMA_PM_LOG={remote}/pm.log "
                               f"{remote}/namespace {remote}", check=False)
                row = {"case": case, "exitCode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
                if args.baseline:
                    assert result.returncode != 0 and "Installing manager app" in result.stdout, row
                    row["reproduced"] = "runner errexit aborts after successful pm install"
                else:
                    assert (result.returncode == 0) == expected, row
                    if expected:
                        count = result.stdout.count("' verified")
                        assert count == 23, count
                        assert "MapleSU Zygisk" in result.stdout and "Restore module permissions" in result.stdout
                        checks = shell(f"test -f {remote}/module/zygisk/arm64-v8a.so && "
                                       f"test -f {remote}/module/zygisk/armeabi-v7a.so && "
                                       f"test ! -e {remote}/module/zygisk/x86.so && "
                                       f"test ! -e {remote}/module/zygisk/x86_64.so && "
                                       f"cmp {remote}/module/hmaoss.sh {remote}/adb/boot-completed.d/hmaoss.sh && "
                                       f"cmp {remote}/module/module.prop {remote}/module/module.prop.bak && "
                                       f"test ! -e {remote}/module/.maplesu-tmp && cat {remote}/pm.log")
                        users = [line.split()[2] for line in checks.stdout.splitlines() if line.startswith("install --user ")]
                        assert users == (["0", "10"] if case == "update" else ["0"]), users
                        row.update(resourceHashesVerified=count, managerUsers=users,
                                   armLibrariesPresent=True, foreignAbisRemoved=True,
                                   bootHookPublished=True, propBackup=True, temporaryFilesRemoved=True)
                    elif case == "corrupt-resource":
                        assert "classes.dex' verify failed" in result.stderr
                    else:
                        assert "No known Zygisk frameworks" in result.stderr
                rows.append(row)
            after = shell("readlink /proc/1/ns/mnt; awk '$5 == \"/data/adb\" {print}' /proc/1/mountinfo").stdout
            assert before == after, (before, after)
            output = EVIDENCE / ("installer-baseline.json" if args.baseline else "installer-smoke.json")
            output.write_text(json.dumps({"passed": True, "packageSha256": hashlib.sha256(package.read_bytes()).hexdigest(),
                                          "runnerSha256": hashlib.sha256((folder / "runner.sh").read_bytes()).hexdigest(),
                                          "scope": "private mount namespace, unmodified HMA scripts and resources; pm is stubbed; no app install, real module install, policy apply, init tracing or reboot",
                                          "initMountNamespaceUnchanged": True, "cases": rows}, indent=2), encoding="utf-8")
            print(json.dumps({"passed": True, "evidence": str(output)}))
        finally:
            shell(f"rm -rf {remote}")


if __name__ == "__main__":
    main()

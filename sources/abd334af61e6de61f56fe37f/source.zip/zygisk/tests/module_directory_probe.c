// Exercise repeated getModuleDir RPCs against the running production daemon.
#include "daemon.h"
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char **argv) {
  if (argc != 3) return 2;
  setbuf(stdout, NULL);
  size_t index = strtoul(argv[1], NULL, 10);
  ino_t inode = 0;
  unsigned previous = 0;
  int failed = 0;
  for (int round = 0; round < 3; ++round) {
    int fd = rezygiskd_get_module_dir(index);
    struct stat st;
    if (fd < 0 || fstat(fd, &st) != 0 || !S_ISDIR(st.st_mode)) return 3;
    off_t start = lseek(fd, 0, SEEK_CUR);
    int resource = openat(fd, argv[2], O_RDONLY | O_CLOEXEC);
    if (resource < 0) return 4;
    close(resource);
    DIR *dir = fdopendir(fd);
    if (!dir) return 5;
    unsigned count = 0, found = 0;
    struct dirent *entry;
    while ((entry = readdir(dir))) {
      if (entry->d_name[0] == '.') continue;
      ++count;
      found += strcmp(entry->d_name, argv[2]) == 0;
    }
    printf("ROUND=%d START=%lld ENTRIES=%u RESOURCE_LISTED=%u RESOURCE_OPEN=1\n",
           round + 1, (long long)start, count, found);
    if (!found || !count || start != 0 || (round && (count != previous || st.st_ino != inode))) failed = 1;
    previous = count;
    inode = st.st_ino;
    closedir(dir);
  }
  if (failed) return 10;
  puts("MODULE_DIRECTORY_REPEATED_ENUMERATION_OK");
  return 0;
}

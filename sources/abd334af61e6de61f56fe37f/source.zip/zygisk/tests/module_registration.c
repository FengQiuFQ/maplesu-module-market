// Registration-only test of official framework ELFs in an isolated process.
#include "module.h"
#include <stdio.h>
#include <unistd.h>

static struct rezygisk_abi registered;
static int companion_requested;
static int companion(void *impl) { (void)impl; companion_requested++; return -1; }
static void option(void *impl, enum rezygisk_options value) { (void)impl; (void)value; }
static bool register_module(struct rezygisk_api *api, const struct rezygisk_abi *abi) {
    if (abi->api_version < 1 || abi->api_version > REZYGISK_API_VERSION) return false;
    registered = *abi;
    api->connect_companion = companion;
    api->set_option = option;
    return true;
}
int main(int argc, char **argv) {
    if (argc != 2) return 2;
    setvbuf(stdout, NULL, _IONBF, 0);
    struct csoloader lib = {0};
    if (!csoloader_load(&lib, argv[1])) return 3;
    void (*entry)(void *, void *) = csoloader_get_symbol(&lib, "zygisk_module_entry");
    if (!entry) return 4;
    struct rezygisk_api api = { .register_module = register_module };
    entry(&api, NULL);
    if (!registered.api_version || !registered.pre_app_specialize || !registered.post_app_specialize ||
        !registered.pre_server_specialize || !registered.post_server_specialize) return 5;
    printf("REGISTERED_API%ld APP_AND_SERVER_CALLBACKS_PRESENT COMPANION_REQUESTS=%d COMPANION_ENTRY=%d\n",
           registered.api_version, companion_requested,
           csoloader_get_symbol(&lib, "zygisk_companion_entry") != NULL);
    // Neither module requested dlclose during onLoad. Preserve its library lifetime.
    _exit(0);
}

"""Exercise Ultra-only loading of published links and owned real directories."""
from pathlib import Path
import argparse, json, shlex, subprocess, tarfile, tempfile
ROOT = Path(__file__).resolve().parents[2]

def main():
 p=argparse.ArgumentParser();p.add_argument('--serial',required=True);p.add_argument('--adb',default='D:/platform-tools/adb.exe');a=p.parse_args()
 adb=[a.adb,'-s',a.serial];remote='/data/local/tmp/maplesu-zygisk-scope-20261105'
 def shell(cmd):
  return subprocess.check_output([*adb,'shell',cmd],text=True,encoding='utf-8',timeout=20)
 def push(src,name):
  subprocess.run([*adb,'push',str(src),remote+'/'+name],check=True,capture_output=True,timeout=20)
 with tempfile.TemporaryDirectory(prefix='maplesu-scope-') as tmp:
  base=Path(tmp);fixture=base/'fixture'
  for path,id,disabled in [('modules/normal_active','normal_active',False),('modules/normal_disabled','normal_disabled',True),('foreign','foreign',False),('revisions/active','ultra_active',False),('revisions/disabled','ultra_disabled',True),('revisions/retired','ultra_retired',False),('modules/real_active','real_active',False),('modules/real_disabled','real_disabled',True),('modules/real_removed','real_removed',False),('modules/bad_receipt','bad_receipt',False),('modules/sidecar_active','sidecar_active',False),('modules/sidecar_disabled','sidecar_disabled',True),('modules/stale_receipt','stale_receipt',False)]:
   d=fixture/path;(d/'zygisk').mkdir(parents=True);(d/'module.prop').write_text(f'id={id}\nname={id}\nversion=1\n',encoding='utf-8');(d/'zygisk/arm64-v8a.so').write_bytes(b'fixture')
   if disabled:(d/'disable').touch()
   if id.startswith('real_'):(d/'.maplesu-ultra').write_text('a'*64+'\n',encoding='utf-8',newline='\n')
   if id=='real_removed':(d/'remove').touch()
   if id=='bad_receipt':(d/'.maplesu-ultra').write_text('invalid\n',encoding='utf-8')
  with tarfile.open(base/'fixture.tar','w') as tar:tar.add(fixture,arcname='fixture')
  try:
   shell('mkdir -p '+remote);push(base/'fixture.tar','fixture.tar')
   push(ROOT/'zygisk/build/arm64-v8a/maplesu-zygisk-webui-probe','api');push(ROOT/'zygisk/build/arm64-v8a/maplesu-zygisk-scan','scan')
   shell(f'cd {remote} && tar -xf fixture.tar && chmod 700 api scan && ln -s ../revisions/active fixture/modules/ultra_active && ln -s ../revisions/disabled fixture/modules/ultra_disabled && ln -s ../foreign fixture/modules/foreign && ln -s ../missing fixture/modules/dangling')
   shell(f"cd {remote}/fixture && mkdir -p modules/.maplesu-ultra && for id in sidecar_active sidecar_disabled stale_receipt; do printf '%s\\n' {'a'*64} > modules/.maplesu-ultra/$(stat -c '%d-%i' modules/$id); done && mv modules/stale_receipt retired && cp -a retired modules/stale_receipt")
   listed=json.loads(shell(f'{remote}/api {remote}/fixture GET /api/modules'))['body']['modules']
   assert [m['id'] for m in listed]==['real_active','real_disabled','real_removed','sidecar_active','sidecar_disabled','ultra_active','ultra_disabled'],listed
   assert {m['id']:m['enabled'] for m in listed}=={'real_active':True,'real_disabled':False,'real_removed':False,'sidecar_active':True,'sidecar_disabled':False,'ultra_active':True,'ultra_disabled':False},listed
   loaded=shell(f'{remote}/scan {remote}/fixture/modules arm64-v8a {remote}/fixture/revisions')
   assert [line.split('\t')[0] for line in loaded.splitlines()]==['real_active','sidecar_active','ultra_active'],loaded
   result={'passed':True,'listed':[m['id'] for m in listed],'loaded':['real_active','sidecar_active','ultra_active'],'excluded':['normal_active','normal_disabled','foreign','dangling','ultra_retired','bad_receipt','stale_receipt']}
   target=ROOT/'evidence/ksu-root-layout-20261105';target.mkdir(parents=True,exist_ok=True);(target/'module-scope.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
  finally:shell('rm -rf '+shlex.quote(remote))
if __name__=='__main__':main()

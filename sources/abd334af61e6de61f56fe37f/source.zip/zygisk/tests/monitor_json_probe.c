// Exercise the actual monitor serializer without starting the monitor.
#include <stdio.h>
#include <string.h>
#include <unistd.h>
static const char *fixture;
static void remap(const char *path, char *out, size_t size) {
  const char *leaf = strrchr(path, '/');
  snprintf(out, size, "%s/%s%s", fixture, strstr(path, "/payload/") ? "payload/" : "", leaf ? leaf + 1 : path);
}
static FILE *fixture_fopen(const char *p, const char *mode) {
  char path[4096]; remap(p, path, sizeof(path)); return fopen(path, mode);
}
static int fixture_rename(const char *a, const char *b) {
  char from[4096], to[4096]; remap(a, from, sizeof(from)); remap(b, to, sizeof(to)); return rename(from, to);
}
static int fixture_unlink(const char *p) {
  char path[4096]; remap(p, path, sizeof(path)); return unlink(path);
}
#define fopen fixture_fopen
#define rename fixture_rename
#define unlink fixture_unlink
#define remove fixture_unlink
#include "monitor.c"
#undef fopen
#undef rename
#undef unlink
#undef remove
int main(int argc, char **argv) {
  if (argc != 3) return 2;
  fixture = argv[1];
  status64.supported = true;
  status64.daemon_running = true;
  status64.zygote_injected = true;
  char *modules[] = {"hma_oss", "quotes\"\\\t\n"};
  environment_information64 = (struct environment_information){.root_impl = "MapleSU Ultra\"\\\n", .modules = modules, .modules_len = 2};
  if (strcmp(argv[2], "metadata") == 0) {
    for (int round = 0; round < 64; ++round) {
      memset(pre_section, 0, sizeof(pre_section));
      memset(post_section, 0, sizeof(post_section));
      if (!prepare_environment() || !update_status(NULL)) return 1;
    }
    return 0;
  }
  if (strcmp(argv[2], "stopped") == 0) {
    tracing_state = STOPPED;
    monitor_stop_reason = "stopped\"\\\n";
    status64.daemon_running = false;
    status64.daemon_error_info = "error\"\\\n";
  }
  if (strcmp(argv[2], "dual") == 0) {
    status32.supported = true;
    status32.daemon_error_info = "32bit\"\\\n";
  }
  return update_status(NULL) ? 0 : 1;
}

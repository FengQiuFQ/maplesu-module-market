// Run the real init monitor against an owned process, never the system init.
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/epoll.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include "misc.h"
#define UTILS_H
#define LOGGING_H
#define WPTEVENT(x) ((x) >> 16)
#define LOGI(...) ((void)0)
#define LOGD(...) ((void)0)
#define LOGV(...) ((void)0)
#define LOGW(...) ((void)0)
#define LOGE(...) ((void)0)
#define PLOGE(...) ((void)0)
static pid_t target, bootstrap;
static int trigger_fd, finished_fd;
static int bootstrap_trigger;
static bool completed, bootstrap_exec_seen, watch_bootstrap;
static long long deadline;
extern bool monitor_events_running;
static long long millis(void) {
  struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
  return t.tv_sec * 1000LL + t.tv_nsec / 1000000;
}
static const char *signal_name(int sig) { return strsignal(sig); }
#define sigabbrev_np signal_name
static void parse_status(int s, char *out, size_t n) { snprintf(out, n, "%x", s); }
static int get_program(int pid, char *out, size_t n) {
  if (pid == bootstrap) bootstrap_exec_seen = true;
  char path[80]; snprintf(path, sizeof(path), "/proc/%d/exe", pid);
  ssize_t k = readlink(path, out, n - 1);
  if (k < 0) return -1;
  out[k] = 0; return 0;
}
static int fork_dont_care(void) { abort(); }
static long fixture_ptrace(enum __ptrace_request request, pid_t pid, void *addr, long data) {
  long result = ptrace(request, pid == 1 ? target : pid, addr, (void *)data);
  if (request == PTRACE_SEIZE && pid == 1 && result == 0) {
    // Force a real fork event into the interval between SEIZE and signalfd setup.
    if (write(trigger_fd, "1", 1) != 1) abort();
    if (watch_bootstrap && write(bootstrap_trigger, "1", 1) != 1) abort();
    long long until = millis() + 500;
    while (millis() < until) {
      char path[80], line[256]; snprintf(path, sizeof(path), "/proc/%d/status", target);
      FILE *f = fopen(path, "r"); bool stopped = false;
      if (f) { while (fgets(line, sizeof(line), f)) if (strncmp(line, "State:\t", 7) == 0 && line[7] == 't') stopped = true; fclose(f); }
      if (stopped) { usleep(20000); break; }
      usleep(1000);
    }
  }
  return result;
}
static pid_t fixture_waitpid(pid_t pid, int *status, int flags) {
  pid_t result = waitpid(pid == 1 ? target : pid, status, flags);
  return result == target ? 1 : result;
}
static int fixture_epoll_wait(int fd, struct epoll_event *events, int count, int timeout) {
  char c;
  if (read(finished_fd, &c, 1) == 1) completed = true;
  if ((completed && (!watch_bootstrap || bootstrap_exec_seen)) || millis() > deadline) { monitor_events_running = false; return 0; }
  return epoll_wait(fd, events, count, 10);
}
#define ptrace fixture_ptrace
#define waitpid fixture_waitpid
#define epoll_wait fixture_epoll_wait
#include "monitor.c"
#undef ptrace
#undef waitpid
#undef epoll_wait
int main(int argc, char **argv) {
  sigset_t empty; sigemptyset(&empty); sigprocmask(SIG_SETMASK, &empty, NULL);
  signal(SIGCHLD, SIG_DFL);
  watch_bootstrap = argc > 1 && strncmp(argv[1], "bootstrap", 9) == 0;
  int boot[2];
  if (pipe(boot)) return 2;
  if (watch_bootstrap) {
    bootstrap = fork();
    if (bootstrap < 0) return 2;
    if (bootstrap == 0) {
      close(boot[1]);
      if (strcmp(argv[1], "bootstrap-child") == 0) {
        pid_t loader = fork();
        if (loader < 0) _exit(2);
        if (loader == 0) {
          char c; if (read(boot[0], &c, 1) != 1) _exit(2);
          _exit(0);
        }
        int status; while (waitpid(loader, &status, 0) < 0 && errno == EINTR) {}
      } else {
        char c; if (read(boot[0], &c, 1) != 1) _exit(2);
      }
      execl("/bin/true", "true", NULL);
      _exit(127);
    }
  }
  close(boot[0]); bootstrap_trigger = boot[1];
  int start[2], done[2]; if (pipe(start) || pipe(done)) return 2;
  target = fork();
  if (target < 0) return 2;
  if (target == 0) {
    setsid(); close(start[1]); close(done[0]);
    char c; if (read(start[0], &c, 1) != 1) _exit(2);
    pid_t child = fork(); if (child < 0) _exit(2);
    if (child == 0) _exit(0);
    int s; while (waitpid(child, &s, 0) < 0 && errno == EINTR) {}
    write(done[1], "1", 1); _exit(0);
  }
  close(start[0]); close(done[1]); trigger_fd = start[1]; finished_fd = done[0];
  fcntl(finished_fd, F_SETFL, O_NONBLOCK);
  if (argc > 1 && strcmp(argv[1], "ignored") == 0) signal(SIGCHLD, SIG_IGN);
  unlink("/data/adb/maplesu_zygisk/init_monitor");
  deadline = millis() + 1000;
#ifdef MAPLE_MONITOR_BOOTSTRAP
  init_monitor(bootstrap);
#else
  init_monitor();
#endif
  kill(-target, SIGKILL); kill(target, SIGKILL);
  if (bootstrap > 0) kill(bootstrap, SIGKILL);
  while (waitpid(-1, NULL, __WALL) > 0 || errno == EINTR) {}
  printf("%s: traced init fixture %s after startup fork\n", completed ? "PASS" : "FAIL", completed ? "resumed" : "stalled");
  if (watch_bootstrap) printf("%s: pre-existing bootstrap exec %s\n", bootstrap_exec_seen ? "PASS" : "FAIL", bootstrap_exec_seen ? "captured" : "missed");
  return completed && (!watch_bootstrap || bootstrap_exec_seen) ? 0 : 1;
}

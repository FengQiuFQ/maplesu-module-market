"""Real ptrace startup regression, in an isolated Linux container only."""
from pathlib import Path
import argparse
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--container", default="maplesu-zygisk-bootdiag-20261104")
    parser.add_argument("--rounds", type=int, default=5)
    parser.add_argument("--before", type=Path, help="Original generated monitor.c, to verify regression sensitivity")
    parser.add_argument("--save", type=Path)
    args = parser.parse_args()
    rows = []

    def run(command, expected=0):
        result = subprocess.run(["docker", "exec", args.container, "bash", "-c", command],
                                capture_output=True, text=True, timeout=30)
        rows.append({"command": command, "exitCode": result.returncode,
                     "stdout": result.stdout, "stderr": result.stderr})
        print(result.stdout.strip() or result.stderr.strip())
        assert result.returncode == expected, rows[-1]

    run("mkdir -p /data/adb/modules/maplesu_zygisk /data/adb/maplesu_zygisk; "
        "printf 'id=maplesu_zygisk\\nname=fixture\\ndescription=fixture\\n' > /data/adb/modules/maplesu_zygisk/module.prop")
    upstream = "/workspace/zygisk/build/upstream/loader/src"
    options = (f"gcc -std=gnu2x -w -ffunction-sections -fdata-sections -Wl,--gc-sections "
               f"-DZKSU_VERSION='\"fixture\"' -I{upstream}/include ")
    if args.before:
        before = args.before.resolve().relative_to(ROOT).as_posix()
        run(f"mkdir -p /tmp/maple-monitor-before; cp /workspace/{before} /tmp/maple-monitor-before/monitor.c; "
            "cp /workspace/third_party/rezygisk/loader/src/ptracer/monitor.h /tmp/maple-monitor-before/monitor.h; "
            f"{options} -I/tmp/maple-monitor-before -I{upstream}/ptracer "
            "/workspace/zygisk/tests/monitor_startup_probe.c -o /tmp/maple-monitor-before/probe")
        for mode in ("", "ignored", "bootstrap", "bootstrap-child"):
            run(f"timeout 5 /tmp/maple-monitor-before/probe {mode}", expected=1)
    run(f"{options} -DMAPLE_MONITOR_BOOTSTRAP -I{upstream}/ptracer "
        "/workspace/zygisk/tests/monitor_startup_probe.c -o /tmp/maple-monitor-startup")
    for _ in range(args.rounds):
        for mode in ("", "ignored", "bootstrap", "bootstrap-child"):
            run(f"timeout 5 /tmp/maple-monitor-startup {mode}")
    run("gcc -std=gnu2x -Wall -Wextra -Werror -I/workspace/zygisk/native "
        "/workspace/zygisk/tests/bootstrap_probe.c -o /tmp/maple-bootstrap-probe; /tmp/maple-bootstrap-probe")
    if args.save:
        args.save.write_text(json.dumps({"passed": True, "rounds": args.rounds, "rows": rows}, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()

// Pure receipt/namespace identity tests; performs no mounts or unmounts.
#include "utils.c"
#include <assert.h>

int main(void) {
  struct mountinfo origin_mount = {.id=100, .device=12, .root="/", .target="/system/etc",
    .type="overlay", .source="overlay", .fs_option="ro,lowerdir=/data/user_de/0/dev.maplesu.manager/files/module-revisions/test:/system/etc"};
  struct mountinfo clone = origin_mount;
  clone.id = 200;
  struct mountinfo foreign = clone;
  foreign.fs_option = "ro,lowerdir=/unrelated:/system/etc";
  struct mountinfo children[3] = {clone, foreign, clone};
  children[2].target = "/system/etc/foreign-child";
  struct mountinfos origin = {.mounts=&origin_mount, .length=1};
  struct mountinfos current = {.mounts=children, .length=3};
  bool selected[3] = {0}, detached[3] = {0};
  FILE *ledger = tmpfile();
  assert(ledger);
  fputs("100 /system/etc\n", ledger);
  rewind(ledger);
  assert(maple_select_mounts(&origin, &current, ledger, selected));
  assert(selected[0] && !selected[1] && !selected[2]);
  assert(maple_mount_covered(&current, detached, 0));
  detached[1] = true;
  assert(maple_mount_covered(&current, detached, 0));
  detached[2] = true;
  assert(!maple_mount_covered(&current, detached, 0));
  children[2].target = "/system/etc-lookalike";
  detached[2] = false;
  assert(!maple_mount_covered(&current, detached, 0));
  fclose(ledger);
  ledger = tmpfile();
  assert(ledger);
  fputs("999 /system/etc\n100 /system/other\n", ledger);
  rewind(ledger);
  memset(selected, 0, sizeof(selected));
  assert(maple_select_mounts(&origin, &current, ledger, selected));
  assert(!selected[0] && !selected[1] && !selected[2]);
  fclose(ledger);
  puts("MAPLESU_MOUNT_RECEIPTS_OK CLONED_IDS_OK FOREIGN_LAYERS_PRESERVED NO_MOUNT_SYSCALLS");
  return 0;
}

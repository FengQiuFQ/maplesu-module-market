// Offline instruction fixtures: never read or write live kernel memory.
#include "../native/notification_switch.h"
#include <assert.h>
#include <initializer_list>
#include <stdio.h>
#include <string.h>

static constexpr uint64_t function = 0xffff000000001000ULL;
static constexpr uint64_t wrapper_address = function + 0x100;
static constexpr uint64_t callback = 0xffffd193991a0000ULL;
static constexpr uint64_t control = 0xffffd193991a6000ULL;
static uint32_t entry[2], wrapper[20], code[128];
static unsigned reads;
static bool fail_read;
static bool read(uint64_t address, void* output, size_t size) {
    ++reads;
    if (fail_read) return false;
    const void* input = nullptr;
    if (address >= function && address + size <= function + sizeof(entry)) input = (char*)entry + (address - function);
    if (address >= wrapper_address && address + size <= wrapper_address + sizeof(wrapper))
        input = (char*)wrapper + (address - wrapper_address);
    if ((address == callback || address == 0xffffffd28fde7000ULL) && size == sizeof(code)) input = code;
    if (!input) return false;
    memcpy(output, input, size);
    return true;
}
static void constant(uint32_t* output, uint64_t value, unsigned reg) {
    for (unsigned i = 0; i < 4; ++i)
        output[i] = (i ? 0xf2800000 : 0xd2800000) | (i << 21) | (((value >> (16 * i)) & 0xffff) << 5) | reg;
}
static void fixture(uint32_t prefix) {
    memset(entry, 0, sizeof(entry)); memset(wrapper, 0, sizeof(wrapper)); memset(code, 0, sizeof(code));
    entry[0] = prefix;
    size_t at = prefix ? 1 : 0;
    entry[at] = 0x14000000 | ((wrapper_address - (function + at * 4)) / 4);
    wrapper[0] = 0xd10143ff; wrapper[1] = 0xa9bf7bfd; wrapper[2] = 0xa9bf7ffc;
    constant(wrapper + 3, callback, 28); wrapper[7] = 0xd63f0380;
    constant(code + 12, control, 10); code[16] = 0x3940014a; code[17] = 0x3400010a;
    reads = 0; fail_read = false;
}
static void gated_fixture(uint64_t gate) {
    fixture(0xd503233f);
    size_t at = 2;
    auto emit = [&](uint64_t address, unsigned reg) {
        bool first = true;
        for (unsigned shift = 0; shift < 4; ++shift) {
            uint32_t halfword = (address >> (shift * 16)) & 0xffff;
            if (!halfword) continue;
            wrapper[at++] = (first ? 0xd2800000 : 0xf2800000) | (shift << 21) | (halfword << 5) | reg;
            first = false;
        }
    };
    emit(gate, 29);
    wrapper[at++] = 0x394003bd;
    size_t branch = at++;
    wrapper[at++] = 0xa8c17bfd;
    wrapper[at++] = 0xa9bf7bfd;
    wrapper[at++] = 0xa9bf7ffc;
    emit(callback, 28);
    wrapper[at++] = 0xd63f0380;
    wrapper[branch] = 0x3500001d | ((at - branch) << 5);
    wrapper[at++] = 0xa8c17bfd;
    wrapper[at] = 0x910143ff;
}
int main() {
    for (uint32_t prefix : {uint32_t{0}, uint32_t{0xd503233f}, uint32_t{0xd503245f}}) {
        fixture(prefix); assert(maple::notification_switch(function, read) == control); assert(reads <= 4);
    }
    // The real next-boot setenforce wrapper omits its zero low halfword.
    fixture(0);
    wrapper[3] = 0xd2a0001c | (((callback >> 16) & 0xffff) << 5);
    wrapper[4] = 0xf2c0001c | (((callback >> 32) & 0xffff) << 5);
    wrapper[5] = 0xf2e0001c | (((callback >> 48) & 0xffff) << 5);
    wrapper[6] = 0xd63f0380; wrapper[7] = 0xa8c17bfd;
    if (maple::notification_switch(function, read) != control) {
        puts("FAIL: aligned SDK callback uses three constant instructions");
        return 1;
    }
    fixture(0); entry[0] = 0x17ffffc0; assert(maple::notification_switch(function, read) == 0);
    fixture(0); fail_read = true; assert(maple::notification_switch(function, read) == 0);
    fixture(0); wrapper[7] = 0xd63f0360; assert(maple::notification_switch(function, read) == 0);
    fixture(0); code[16] = 0x3940054a; assert(maple::notification_switch(function, read) == 0);
    fixture(0); code[13] = 0xd503201f; assert(maple::notification_switch(function, read) == 0);
    fixture(0); constant(code + 50, control, 10); code[54] = code[16]; code[55] = code[17];
    assert(maple::notification_switch(function, read) == 0);
    fixture(0); constant(code + 12, 0x1000, 10); assert(maple::notification_switch(function, read) == 0);
    const char* failure = "previous attempt";
    fixture(0); assert(maple::notification_switch(function, read, &failure) == control && !failure);
    fixture(0); fail_read = true;
    assert(maple::notification_switch(function, read, &failure) == 0 && strcmp(failure, "entry read failed") == 0);
    fixture(0); wrapper[0] = 0;
    assert(maple::notification_switch(function, read, &failure) == 0 && strcmp(failure, "trampoline not recognized") == 0);
    fixture(0); memset(code, 0, sizeof(code));
    assert(maple::notification_switch(function, read, &failure) == 0 && strcmp(failure, "switch not recognized") == 0);
    // Captured on Ace 6, boot 595526c0, SDK r10, 2026-11-07 06:04 UTC.
    const uint32_t guarded_wrapper[] = {
        0xd10143ff, 0xa9bf7bfd, 0xd290013d, 0xf2b19f1d,
        0xf2dffa5d, 0xf2fffffd, 0x394003bd, 0x3500013d,
        0xa8c17bfd, 0xa9bf7bfd, 0xa9bf7ffc, 0xd28e001c,
        0xf2b1fbdc, 0xf2dffa5c, 0xf2fffffc, 0xd63f0380,
        0xa8c17bfd, 0x910143ff, 0xa9be7bfd, 0x17a5a60f
    };
    fixture(0xd503233f); memcpy(wrapper, guarded_wrapper, sizeof(wrapper));
    if (maple::notification_switch(function, read) != control) {
        puts("FAIL: live SDK guarded wrapper does not reach the shared notification switch");
        return 1;
    }
    wrapper[7] ^= 0x20;
    assert(maple::notification_switch(function, read) == 0);
    fixture(0xd503233f); memcpy(wrapper, guarded_wrapper, sizeof(wrapper)); wrapper[8] = 0;
    assert(maple::notification_switch(function, read) == 0);
    fixture(0xd503233f); memcpy(wrapper, guarded_wrapper, sizeof(wrapper)); wrapper[15] = 0xd63f0360;
    assert(maple::notification_switch(function, read) == 0);
    for (uint64_t gate : {uint64_t{0xffffffd28cf88009ULL}, uint64_t{0xffffffd28cf80000ULL}, uint64_t{0xffffd19300000000ULL}}) {
        gated_fixture(gate);
        assert(maple::notification_switch(function, read) == control);
    }
    puts("PASS: notifier wrapper, PAC/BTI, read failures, unfamiliar encodings and ambiguous pointers");
}

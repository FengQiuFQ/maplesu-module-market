// Replay sanitized kernel reads offline; no SDK or live kernel access.
#include "../native/notification_switch.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <string.h>
#include <vector>

struct Segment {
    uint64_t address;
    std::vector<unsigned char> data;
};
int main() {
    uint64_t functions[2], expected;
    unsigned count;
    assert(scanf("%" SCNx64 " %" SCNx64 " %" SCNx64 " %u", &functions[0], &functions[1], &expected, &count) == 4);
    std::vector<Segment> segments;
    for (unsigned i = 0; i < count; ++i) {
        uint64_t address;
        char text[1025];
        assert(scanf("%" SCNx64 " %1024s", &address, text) == 2);
        size_t length = strlen(text);
        assert(length % 2 == 0);
        Segment segment{address, {}};
        for (size_t at = 0; at < length; at += 2) {
            unsigned byte;
            assert(sscanf(text + at, "%2x", &byte) == 1);
            segment.data.push_back(static_cast<unsigned char>(byte));
        }
        segments.push_back(segment);
    }
    auto read = [&](uint64_t address, void* data, size_t size) {
        for (const auto& segment : segments) {
            if (address < segment.address) continue;
            uint64_t offset = address - segment.address;
            if (offset > segment.data.size() || size > segment.data.size() - offset) continue;
            memcpy(data, segment.data.data() + offset, size);
            return true;
        }
        return false;
    };
    for (uint64_t function : functions) {
        if (maple::notification_switch(function, read) != expected) {
            puts("FAIL: live notifier replay did not resolve the shared notification switch");
            return 1;
        }
    }
    puts("PASS: both live guarded wrappers resolve the shared notification switch, not either per-hook gate");
}

// A normal dlopen library whose imported calls can be observed independently.
#include <unistd.h>

__attribute__((visibility("default"))) pid_t fixture_pid(void) { return getpid(); }
__attribute__((visibility("default"))) pid_t fixture_ppid(void) { return getppid(); }

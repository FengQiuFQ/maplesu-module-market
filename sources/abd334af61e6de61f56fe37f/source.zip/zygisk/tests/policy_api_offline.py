"""Exercise actual policy API routing/receipts without a device or SDK."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--save", type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="maplesu-policy-api-") as temporary:
        output = Path(temporary)
        (output / "sys").mkdir()
        (output / "sys/system_properties.h").write_text(
            '#pragma once\n#define PROP_VALUE_MAX 92\n'
            'static inline int __system_property_get(const char *key, char *value) {'
            '(void)key; value[0]=0; return 0;}\n')
        result = subprocess.run([
            "docker", "run", "--rm", "--pull", "never", "--network", "none", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--mount", f"type=bind,source={ROOT},target=/source,readonly",
            "--mount", f"type=bind,source={output},target=/output",
            "ghcr.io/ylarod/ddk-min:android15-6.6-20260828", "sh", "-c",
            "c++ -std=c++20 -D_GNU_SOURCE -UNDEBUG -Wall -Wextra -Werror -pthread "
            "-fsanitize=address,undefined -fno-omit-frame-pointer -I/output -I/source/zygisk/native "
            "/source/zygisk/tests/policy_api_probe.cpp -o /output/probe && /output/probe",
        ], capture_output=True, text=True, timeout=60)
        rows = [json.loads(line) for line in result.stdout.splitlines()] if result.returncode == 0 else []
        if rows:
            assert rows[0]["verified"] is True and rows[0]["action"] == "temporary" and rows[0]["systemServerExecmem"] is False
            assert rows[1]["verified"] is True and rows[1]["action"] == "restore" and rows[1]["systemServerExecmem"] is True
            assert all(row["ok"] is False and row["verified"] is False for row in rows[2:-1])
        sources = ["zygisk/native/webui.hpp", "zygisk/native/startup_policy.h", "zygisk/tests/policy_api_probe.cpp"]
        receipt = {"deviceAccess": False, "exitCode": result.returncode, "receipts": rows,
                   "sourceSha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sources},
                   "stdout": result.stdout, "stderr": result.stderr}
        if args.save:
            args.save.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(receipt, indent=2))
        assert result.returncode == 0 and rows[-1]["passed"]


if __name__ == "__main__":
    main()

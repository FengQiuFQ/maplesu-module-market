// Production WebUI policy routes with typed local callbacks; no SDK or policy I/O.
#include "webui.hpp"
#include <cassert>
#include <future>
#include <iostream>
#include <thread>

int main() {
    using maple::webui::Api;
    Api unavailable("/not-used");
    assert(unavailable.dispatch("POST", "/api/policy/temporary").status == 503);
    assert(unavailable.dispatch("GET", "/api/policy/restore").status == 404);
    assert(unavailable.dispatch("POST", "/api/policy/anything").status == 404);
    int calls = 0;
    Api success("/not-used", [&](bool full) {
        ++calls;
        return maple_policy_receipt{MAPLE_POLICY_DONE, full ? 1 : 0};
    });
    for (const char *action : {"temporary", "restore"}) {
        auto reply = success.dispatch("POST", std::string("/api/policy/") + action);
        assert(reply.status == 200);
        std::cout << reply.body << '\n';
    }
    assert(calls == 2);
    const maple_policy_result failures[] = {MAPLE_POLICY_BUSY, MAPLE_POLICY_NOT_READY,
        MAPLE_POLICY_REQUIRED, MAPLE_POLICY_ORIGINAL, MAPLE_POLICY_NO_BACKUP, MAPLE_POLICY_FAILED};
    for (auto result : failures) {
        Api failure("/not-used", [=](bool) { return maple_policy_receipt{result, -1}; });
        auto reply = failure.dispatch("POST", "/api/policy/restore");
        assert(reply.status == (result == MAPLE_POLICY_FAILED ? 500 : 409));
        std::cout << reply.body << '\n';
    }
    std::promise<void> entered, release;
    auto released = release.get_future().share();
    Api serialized("/not-used", [&](bool) {
        entered.set_value(); released.wait();
        return maple_policy_receipt{MAPLE_POLICY_DONE, 0};
    });
    std::thread first([&] { assert(serialized.dispatch("POST", "/api/policy/temporary").status == 200); });
    entered.get_future().wait();
    assert(serialized.dispatch("POST", "/api/policy/restore").status == 409);
    release.set_value(); first.join();
    std::cout << "{\"passed\":true,\"cases\":11,\"concurrentAction\":\"busy\"}\n";
}

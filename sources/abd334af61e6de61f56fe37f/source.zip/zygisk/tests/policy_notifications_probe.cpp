// Offline SDK fixture: never read or write live kernel memory.
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

namespace kernel_module {
int kallsyms_lookup_name(const char*, uint64_t&);
int read_kernel_mem(uint64_t, void*, uint32_t);
int write_kernel_mem(uint64_t, const void*, uint32_t);
}
static bool is_failed(int error) { return error != 0; }
#include "../native/policy_notifications.hpp"

static constexpr uint64_t function = 0xffff000000001000ULL;
static constexpr uint64_t callback = 0xffffd193991a0000ULL;
static constexpr uint64_t control = 0xffffd193991a6000ULL;
static uint32_t entries[2], wrappers[2][8], callbacks[2][128];
static uint8_t value;
static unsigned control_reads, fail_control_read, writes;
static int fail_lookup;
static bool fail_write;

static void constant(uint32_t* output, uint64_t address, unsigned reg) {
    for (unsigned i = 0; i < 4; ++i)
        output[i] = (i ? 0xf2800000 : 0xd2800000) | (i << 21) |
            (((address >> (16 * i)) & 0xffff) << 5) | reg;
}
static void fixture(bool shared = true) {
    memset(callbacks, 0, sizeof(callbacks));
    for (unsigned i = 0; i < 2; ++i) {
        entries[i] = 0x14000040;
        wrappers[i][0] = 0xd10143ff;
        wrappers[i][1] = 0xa9bf7bfd;
        wrappers[i][2] = 0xa9bf7ffc;
        constant(wrappers[i] + 3, callback + i * 0x1000, 28);
        wrappers[i][7] = 0xd63f0380;
        constant(callbacks[i] + 12, control + (shared ? 0 : i), 10);
        callbacks[i][16] = 0x3940014a;
        callbacks[i][17] = 0x3400010a;
    }
    value = 1;
    control_reads = fail_control_read = writes = 0;
    fail_lookup = -1;
    fail_write = false;
}
int kernel_module::kallsyms_lookup_name(const char* name, uint64_t& address) {
    unsigned i = strcmp(name, "selinux_status_update_setenforce") == 0;
    if (static_cast<int>(i) == fail_lookup) return -1;
    address = function + i * 0x1000;
    return 0;
}
int kernel_module::read_kernel_mem(uint64_t address, void* output, uint32_t size) {
    if (address == control && size == 1) {
        if (++control_reads == fail_control_read) return -1;
        memcpy(output, &value, 1);
        return 0;
    }
    for (unsigned i = 0; i < 2; ++i) {
        const void* input = nullptr;
        if (address == function + i * 0x1000 && size == sizeof(entries[i])) input = &entries[i];
        if (address == function + i * 0x1000 + 0x100 && size == sizeof(wrappers[i])) input = wrappers[i];
        if (address == callback + i * 0x1000 && size == sizeof(callbacks[i])) input = callbacks[i];
        if (input) { memcpy(output, input, size); return 0; }
    }
    return -1;
}
int kernel_module::write_kernel_mem(uint64_t address, const void* input, uint32_t size) {
    assert(address == control && size == 1);
    ++writes;
    if (fail_write) return -1;
    memcpy(&value, input, 1);
    return 0;
}

int main() {
    bool changed = false;
    fixture();
    assert(maple::restore_policy_notifications(&changed) && changed && writes == 1 && value == 0);
    assert(maple::restore_policy_notifications(&changed) && !changed && writes == 1);
    for (int symbol = 0; symbol < 2; ++symbol) {
        fixture(); fail_lookup = symbol;
        assert(!maple::restore_policy_notifications(&changed) && !changed && writes == 0);
    }
    fixture(false);
    assert(!maple::restore_policy_notifications(&changed) && !changed && writes == 0);
    fixture(); callbacks[1][16] = 0;
    assert(!maple::restore_policy_notifications(&changed) && !changed && writes == 0);
    fixture(); value = 2;
    assert(!maple::restore_policy_notifications(&changed) && !changed && writes == 0);
    fixture(); fail_control_read = 1;
    assert(!maple::restore_policy_notifications(&changed) && !changed && writes == 0);
    fixture(); fail_write = true;
    assert(!maple::restore_policy_notifications(&changed) && !changed && writes == 1 && value == 1);

    // The host retains a reload obligation even if verification needs a retry.
    fixture(); fail_control_read = 2;
    bool pending_reload = false;
    assert(!maple::restore_policy_notifications(&changed) && value == 0 && writes == 1);
    pending_reload |= changed;
    assert(maple::restore_policy_notifications(&changed) && !changed && writes == 1);
    pending_reload |= changed;
    if (!pending_reload) {
        puts("FAIL: successful notification restore lost its required policy reload after a readback failure");
        return 1;
    }
    puts("PASS: notifier restore, idempotence, lookup/read/write failures, shared control and durable reload obligation");
}

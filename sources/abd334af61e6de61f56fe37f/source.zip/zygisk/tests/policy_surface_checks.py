"""Check the shipped SELinux ABI and actual transport/tracer regression receipts."""
import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
evidence = root / "evidence/maplesu-zygisk-surface-20261105"
archive = root / "dist-release/MapleSU-Zygisk-5.1.0-Ultra.zip"
with zipfile.ZipFile(archive) as package:
    rules = package.read("sepolicy.rule")
    assert rules == (root / "zygisk/module/sepolicy.rule").read_bytes()
    declarations = [line for line in rules.decode().splitlines()
                    if line.split() and line.split()[0] in ("type", "attribute", "typeattribute")]
    assert not declarations, declarations
    for name in ("libmodule_maplesu_zygisk.so", "bin/zygiskd64", "bin/zygiskd32"):
        data = package.read(name)
        assert b"u:r:maplesu_zygisk:s0" not in data, name
        assert b"u:object_r:zygisk_file:s0" not in data, name
red = (evidence / "transport-red.txt").read_text()
green = (evidence / "transport-green.txt").read_text()
tracer = (evidence / "policy-tracer-green.txt").read_text()
hashes = (evidence / "installed-hashes.txt").read_text()
assert "SOCKET_LABEL=u:object_r:zygisk_file:s0" in red and "TEST_EXIT=134" in red
assert "SOCKET_LABEL=u:object_r:system_data_file:s0" in green
assert "PASS: init sender -> zygote UID1000" in green and "TEST_EXIT=0" in green
assert "TRACER_CONTEXT=u:r:init:s0" in tracer
assert "PASS: kernel exec transition reached" in tracer
assert hashes.count("HASH_OK:") == 8 and "HASH_MISMATCH:" not in hashes
result = {"passed": True, "archiveSha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
          "newPolicySymbols": declarations, "tracerHalTransitionPassed": True,
          "productionSocketAndFdTransportPassed": True, "installedBinariesVerified": 8,
          "scope": "Artifact and isolated enforcing-device tests; cold-boot removal checked separately"}
(evidence / "regression.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))

// Production socket/SCM_RIGHTS helpers, with a private init -> zygote client.
#include <stdbool.h>
#include "tracer_context.h"
#include "utils.h"
#include <assert.h>
#include <errno.h>
#include <grp.h>
#include <signal.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <sys/xattr.h>

static pid_t child;
static void timeout_handler(int sig) {
  if (child > 0) kill(child, SIGKILL);
  _exit(124);
}

static void set_context(const char *value) {
  int fd = open("/proc/self/attr/current", O_WRONLY | O_CLOEXEC);
  assert(fd >= 0);
  assert(write(fd, value, strlen(value)) == (ssize_t)strlen(value));
  close(fd);
}

static int access_allowed(const char *source, const char *target, const char *clazz, const char *permission) {
  char path[256], request[512], response[256] = {0};
  unsigned class_index, permission_index, allowed;
  snprintf(path, sizeof(path), "/sys/fs/selinux/class/%s/index", clazz);
  FILE *file = fopen(path, "r");
  assert(file && fscanf(file, "%u", &class_index) == 1);
  fclose(file);
  snprintf(path, sizeof(path), "/sys/fs/selinux/class/%s/perms/%s", clazz, permission);
  file = fopen(path, "r");
  assert(file && fscanf(file, "%u", &permission_index) == 1);
  fclose(file);
  assert(permission_index > 0 && permission_index <= 32);
  int fd = open("/sys/fs/selinux/access", O_RDWR | O_CLOEXEC);
  assert(fd >= 0);
  int size = snprintf(request, sizeof(request), "%s %s %u", source, target, class_index);
  assert(write(fd, request, size) == size);
  assert(read(fd, response, sizeof(response) - 1) > 0);
  close(fd);
  assert(sscanf(response, "%x", &allowed) == 1);
  return (allowed & (1u << (permission_index - 1))) != 0;
}

int main(int argc, char **argv) {
  if (argc != 2 || strcmp(argv[1], "/data/misc/maplesu-zygisk-transport-20261105")) return 2;
  setbuf(stdout, NULL);
  signal(SIGALRM, timeout_handler);
  alarm(12);
  assert(maple_tracer_context());
  if (access_allowed("u:r:zygote:s0", "u:object_r:adb_data_file:s0", "dir", "search")) {
    puts("FAIL: host broadened Zygote module-storage access");
    return 3;
  }
  char path[108], library[256];
  snprintf(path, sizeof(path), "%s/control", argv[1]);
  snprintf(library, sizeof(library), "%s/module.so", argv[1]);
  assert(chcon(argv[1], "u:object_r:system_data_file:s0") == 0);
  assert(chcon(library, "u:object_r:app_data_file:s0") == 0);
  set_socket_create_context("u:r:zygote:s0");
  int listener = unix_listener_from_path(path);
  assert(listener >= 0);
  char label[128] = {0};
  assert(lgetxattr(path, "security.selinux", label, sizeof(label) - 1) > 0);
  printf("SOCKET_LABEL=%s\n", label);
  assert(strcmp(label, "u:object_r:system_data_file:s0") == 0);
  assert(chmod(path, 0666) == 0);
  int directory = open(argv[1], O_RDONLY | O_DIRECTORY | O_CLOEXEC);
  int module = open(library, O_RDONLY | O_CLOEXEC);
  assert(directory >= 0 && module >= 0);
  pid_t parent = getpid();
  child = fork();
  assert(child >= 0);
  if (!child) {
    assert(prctl(PR_SET_PDEATHSIG, SIGKILL) == 0 && getppid() == parent);
    alarm(10);
    close(listener); close(directory); close(module);
    set_context("u:r:zygote:s0");
    assert(setgroups(0, NULL) == 0);
    assert(setresgid(1000, 1000, 1000) == 0);
    assert(setresuid(1000, 1000, 1000) == 0);
    assert(getuid() == 1000 && geteuid() == 1000);
    int socket_fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    assert(socket_fd >= 0);
    struct sockaddr_un address = {.sun_family = AF_UNIX};
    strcpy(address.sun_path, path);
    assert(connect(socket_fd, (struct sockaddr *)&address, sizeof(address)) == 0);
    int dir_fd = read_fd(socket_fd), lib_fd = read_fd(socket_fd);
    assert(dir_fd >= 0 && lib_fd >= 0);
    struct stat info;
    assert(fstat(dir_fd, &info) == 0 && S_ISDIR(info.st_mode));
    int resource = openat(dir_fd, "module.so", O_RDONLY | O_CLOEXEC);
    assert(resource >= 0);
    close(resource);
    const char *image = mmap(NULL, 4096, PROT_READ | PROT_EXEC, MAP_PRIVATE, lib_fd, 0);
    assert(image != MAP_FAILED && memcmp(image, "\x7f" "ELF", 4) == 0);
    munmap((void *)image, 4096);
    close(dir_fd); close(lib_fd);
    assert(write(socket_fd, "1", 1) == 1);
    close(socket_fd);
    _exit(0);
  }
  int client = accept4(listener, NULL, NULL, SOCK_CLOEXEC);
  assert(client >= 0);
  assert(write_fd(client, directory) == 1);
  assert(write_fd(client, module) == 1);
  char ready = 0;
  assert(read(client, &ready, 1) == 1 && ready == '1');
  int status;
  assert(waitpid(child, &status, 0) == child && WIFEXITED(status) && WEXITSTATUS(status) == 0);
  child = 0;
  close(client); close(listener); close(directory); close(module);
  unlink(path);
  puts("PASS: stock adb boundary; init sender -> zygote UID1000; socket, directory FD, module FD and executable mmap");
  return 0;
}

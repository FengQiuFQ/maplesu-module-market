// SPDX-License-Identifier: AGPL-3.0-or-later
// Private child processes only: no Android services or installed host are touched.
#include "process.hpp"
#include <cstdio>

int main() {
    int status = 0;
    pid_t child = fork();
    if (child < 0) return 1;
    if (child == 0) _exit(42);
    if (!maple::wait_child(child, status, 500) || !WIFEXITED(status) || WEXITSTATUS(status) != 42) return 2;

    int ready[2];
    if (pipe(ready)) return 3;
    child = fork();
    if (child < 0) return 4;
    if (child == 0) {
        close(ready[0]);
        signal(SIGTERM, SIG_IGN);
        write(ready[1], "1", 1);
        while (true) pause();
    }
    close(ready[1]);
    char byte;
    if (read(ready[0], &byte, 1) != 1) return 5;
    close(ready[0]);
    if (maple::wait_child(child, status, 30)) return 6;
    maple::stop_child(child, status);
    if (!WIFSIGNALED(status) || WTERMSIG(status) != SIGKILL) return 7;

    if (prctl(PR_SET_CHILD_SUBREAPER, 1)) return 8;
    if (pipe(ready)) return 9;
    child = fork();
    if (child < 0) return 10;
    if (child == 0) {
        close(ready[0]);
        int linked[2];
        if (pipe(linked)) _exit(11);
        pid_t parent = getpid();
        pid_t helper = fork();
        if (helper < 0) _exit(12);
        if (helper == 0) {
            close(linked[0]);
            maple::follow_parent(parent);
            write(linked[1], "1", 1);
            while (true) pause();
        }
        close(linked[1]);
        if (read(linked[0], &byte, 1) != 1) _exit(13);
        write(ready[1], &helper, sizeof(helper));
        _exit(0);
    }
    close(ready[1]);
    pid_t helper = 0;
    if (read(ready[0], &helper, sizeof(helper)) != sizeof(helper)) return 14;
    close(ready[0]);
    if (!maple::wait_child(child, status, 500) || !WIFEXITED(status) || WEXITSTATUS(status)) return 15;
    if (!maple::wait_child(helper, status, 1000) || !WIFSIGNALED(status) || WTERMSIG(status) != SIGTERM) return 16;
    puts("CHILD_REAP_OK TIMEOUT_CLEANUP_OK PARENT_DEATH_CLEANUP_OK");
    return 0;
}

"""Rebuild the embedded corresponding source, with only the documented external SDK."""
from pathlib import Path
import hashlib
import io
import json
import shutil
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]


def main():
    artifact = "MapleSU-Zygisk-5.1.0-Ultra.zip"
    original = (ROOT / "dist-release" / artifact).read_bytes()
    with zipfile.ZipFile(io.BytesIO(original)) as package:
        source = package.read("webroot/source.zip")
    build_root = (ROOT / "zygisk/build").resolve()
    with tempfile.TemporaryDirectory(prefix="source-rebuild-", dir=build_root) as temporary:
        target = Path(temporary).resolve()
        assert target.parent == build_root
        with zipfile.ZipFile(io.BytesIO(source)) as archive:
            for name in archive.namelist():
                assert (target / name).resolve().is_relative_to(target), name
            archive.extractall(target)
        # No credentials, app build, signing material or device state are copied.
        for folder in ("include", "lib/arm64-v8a"):
            shutil.copytree(ROOT / "runtime/upstream-pro" / folder,
                            target / "runtime/upstream-pro" / folder)
        result = subprocess.run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
                                 str(target / "zygisk/build.ps1")], capture_output=True, text=True)
        (ROOT / "zygisk/build/source-rebuild.log").write_text(result.stdout + result.stderr, encoding="utf-8")
        if result.returncode:
            raise RuntimeError("Corresponding source rebuild failed; see zygisk/build/source-rebuild.log")
        rebuilt = (target / "dist-release" / artifact).read_bytes()
        with zipfile.ZipFile(io.BytesIO(original)) as before, zipfile.ZipFile(io.BytesIO(rebuilt)) as after:
            differing = [name for name in before.namelist() if before.read(name) != after.read(name)]
        evidence = {"passed": original == rebuilt, "differingEntries": differing,
                    "archiveSha256": hashlib.sha256(original).hexdigest(),
                    "rebuiltSha256": hashlib.sha256(rebuilt).hexdigest(),
                    "externalDependency": "existing Ultra SDK headers and ARM64 static library only"}
        output = ROOT / "evidence/zygisk-5.1.0-finalize-20261106/source-rebuild.json"
        output.write_text(json.dumps(evidence, indent=2), encoding="utf-8")
        assert original == rebuilt, evidence
        print("CORRESPONDING_SOURCE_REBUILD_OK BYTE_IDENTICAL_ARCHIVE")


if __name__ == "__main__":
    main()

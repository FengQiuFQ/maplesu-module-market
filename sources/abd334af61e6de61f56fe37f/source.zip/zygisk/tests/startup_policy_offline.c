// Production startup-policy lifecycle with only SELinux I/O redirected to fixtures.
// Runs in an isolated Linux container; no SDK, device or real policy writes.
#define MAPLE_OFFLINE_ROOT "/tmp/maplesu-startup-offline"
#define MAPLE_STARTUP_RUNTIME MAPLE_OFFLINE_ROOT "/runtime"
#define MAPLE_STARTUP_MODULES MAPLE_OFFLINE_ROOT "/modules"
#define MAPLE_STARTUP_REVISIONS MAPLE_OFFLINE_ROOT "/revisions"
#define MAPLE_STARTUP_MISC MAPLE_OFFLINE_ROOT "/misc"
#define MAPLE_LSPOSED_CONFIG MAPLE_OFFLINE_ROOT "/missing-scope.db"
#include "../native/startup_policy.c"
#include <assert.h>
#include <stdarg.h>

static const char *host = MAPLE_OFFLINE_ROOT "/host";
static const char *query = "u:r:system_server:s0 u:r:system_server:s0 2";
FILE *__real_fopen(const char *, const char *);
int __real_open(const char *, int, ...);

static void put(const char *path, const char *value, mode_t mode) {
    int fd = __real_open(path, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, mode);
    assert(fd >= 0 && write(fd, value, strlen(value)) == (ssize_t)strlen(value));
    assert(close(fd) == 0);
}
FILE *__wrap_fopen(const char *path, const char *mode) {
    if (!strcmp(path, "/proc/sys/kernel/random/boot_id")) path = MAPLE_OFFLINE_ROOT "/boot";
    if (!strcmp(path, "/sys/fs/selinux/class/process/index")) path = MAPLE_OFFLINE_ROOT "/class";
    if (!strcmp(path, "/sys/fs/selinux/class/process/perms/execmem")) path = MAPLE_OFFLINE_ROOT "/bit";
    return __real_fopen(path, mode);
}
int __wrap_open(const char *path, int flags, ...) {
    mode_t mode = 0;
    if (flags & O_CREAT) {
        va_list args; va_start(args, flags); mode = va_arg(args, int); va_end(args);
    }
    if (!strcmp(path, "/sys/fs/selinux/access")) {
        FILE *file = __real_fopen(MAPLE_OFFLINE_ROOT "/permission", "r");
        assert(file);
        int value = fgetc(file); fclose(file);
        if (value == '?') { errno = EACCES; return -1; }
        char response[256];
        snprintf(response, sizeof(response), "%s%s ffffffff 0 ffffffff 1 0\n", query, value == '1' ? "2000000" : "0");
        put(MAPLE_OFFLINE_ROOT "/access", response, 0600);
        path = MAPLE_OFFLINE_ROOT "/access";
    }
    return __real_open(path, flags, mode);
}
static struct startup_window load(void) {
    struct startup_window state;
    int fd = window_lock(true);
    assert(fd >= 0 && window_read(fd, &state));
    close(fd); return state;
}
static void save(struct startup_window state) {
    int fd = window_lock(true);
    assert(fd >= 0 && window_save(fd, &state));
    close(fd);
}
static void finish_ready(void) {
    maple_startup_policy_finish(host, true);

}
static void fresh(int baseline) {
    put(MAPLE_OFFLINE_ROOT "/permission", baseline == 0 ? "0" : baseline == 1 ? "1" : "?", 0600);
    unlink(MAPLE_STARTUP_RUNTIME "/startup-policy");
    maple_startup_policy_init();
    assert(load().original == (baseline != 0));
    put(MAPLE_OFFLINE_ROOT "/permission", "1", 0600);
}
static void module(const char *id) {
    char path[4096], link[4096], prop[128];
    snprintf(path, sizeof(path), MAPLE_STARTUP_REVISIONS "/%s", id); assert(mkdir(path, 0700) == 0);
    snprintf(link, sizeof(link), MAPLE_STARTUP_MODULES "/%s", id); assert(symlink(path, link) == 0);
    snprintf(path, sizeof(path), "%s/zygisk", link); assert(mkdir(path, 0700) == 0);
    snprintf(path, sizeof(path), "%s/zygisk/arm64-v8a.so", link); put(path, "fixture", 0600);
    snprintf(path, sizeof(path), "%s/module.prop", link);
    snprintf(prop, sizeof(prop), "id=%s\n", id); put(path, prop, 0600);
}
int main(int argc, char **argv) {
    setbuf(stdout, NULL);
    const char *dirs[] = {MAPLE_OFFLINE_ROOT, MAPLE_STARTUP_RUNTIME, MAPLE_STARTUP_MODULES,
        MAPLE_STARTUP_REVISIONS, MAPLE_STARTUP_MISC, MAPLE_OFFLINE_ROOT "/host", MAPLE_OFFLINE_ROOT "/host/bin"};
    for (size_t i = 0; i < sizeof(dirs) / sizeof(*dirs); ++i) assert(mkdir(dirs[i], 0700) == 0);
    put(MAPLE_OFFLINE_ROOT "/boot", "fixture-boot\n", 0600);
    put(MAPLE_OFFLINE_ROOT "/class", "2\n", 0600);
    put(MAPLE_OFFLINE_ROOT "/bit", "26\n", 0600);
    put(MAPLE_OFFLINE_ROOT "/host/bin/maplesu-policy",
        "#!/bin/sh\n"
        "test ! -e " MAPLE_OFFLINE_ROOT "/fail || exit 17\n"
        "printf '%s\\n' \"$1\" >> " MAPLE_OFFLINE_ROOT "/transactions\n"
        "case \"$1\" in\n"
        "save) cp " MAPLE_OFFLINE_ROOT "/permission \"$3\"; exit $?;;\n"
        "restore) cp \"$3\" " MAPLE_OFFLINE_ROOT "/permission; exit $?;;\n"
        "esac\n"
        "value=$(cat " MAPLE_OFFLINE_ROOT "/permission)\n"
        "for rule in \"$@\"; do\n"
        "case \"$rule\" in\n"
        "*/startup-policy.rule) value=1;;\n"
        "*/steady-policy.rule) value=0;;\n"
        "*/sepolicy.rule) if grep -q execmem \"$rule\"; then value=1; fi;;\n"
        "esac\ndone\n"
        "printf '%s' \"$value\" > " MAPLE_OFFLINE_ROOT "/permission\n", 0700);

    if (argc > 1 && !strcmp(argv[1], "empty-prepare")) {
        fresh(0);
        struct startup_window state = load(); state.closed = 1; save(state);
        put(MAPLE_OFFLINE_ROOT "/permission", "0", 0600);
        assert(maple_startup_policy_prepare(host));
        if (execmem_allowed() != 0) {
            puts("FAIL: PrepareSystemServer granted execmem with no active Zygisk modules");
            return 1;
        }
        puts("PASS: PrepareSystemServer with no modules never adds the startup grant");
        return 0;
    }
    if (argc > 1 && !strcmp(argv[1], "hma-ready")) {
        module("hma_oss_zygisk"); fresh(0);
        assert(mkdir(MAPLE_STARTUP_MISC "/hide_my_applist_fixture", 0700) == 0);
        put(MAPLE_STARTUP_MISC "/hide_my_applist_fixture/status.json", "{\"workMode\":1}", 0600);
        maple_startup_policy_finish(host, true);
        if (execmem_allowed() != 0 || !load().closed) {
            puts("FAIL: HMA reported ready but execmem remains visible during an added startup delay");
            return 1;
        }
        puts("PASS: verified HMA readiness withdraws execmem without an extra boot or time gate");
        return 0;
    }

    if (argc > 1 && !strcmp(argv[1], "actions")) {
        put(MAPLE_OFFLINE_ROOT "/permission", "0", 0600);
        assert(maple_startup_policy_snapshot(host));
        assert(access(MAPLE_STARTUP_RUNTIME "/policy-baseline", R_OK) == 0);
        maple_startup_policy_init();
        module("dynamic_module");
        put(MAPLE_OFFLINE_ROOT "/permission", "1", 0600);
        put(MAPLE_STARTUP_RUNTIME "/startup.state", "boot=fixture-boot\nmodules=pending\n", 0600);
        assert(maple_startup_policy_withdraw(host, true).result == MAPLE_POLICY_NOT_READY);
        assert(execmem_allowed() == 1);
        put(MAPLE_STARTUP_RUNTIME "/startup.state", "boot=fixture-boot\nmodules=ready\n", 0600);
        struct maple_policy_receipt receipt = maple_startup_policy_withdraw(host, false);
        assert(receipt.result == MAPLE_POLICY_REQUIRED && receipt.execmem_allowed == 1);
        puts("PASS: temporary collection preserves unknown modules and waits for real script completion");
        assert(mkdir(MAPLE_STARTUP_RUNTIME "/policy-restored.next.tmp", 0700) == 0);
        assert(maple_startup_policy_withdraw(host, true).result == MAPLE_POLICY_FAILED);
        assert(execmem_allowed() == 1 && !maple_startup_policy_restored());
        assert(rmdir(MAPLE_STARTUP_RUNTIME "/policy-restored.next.tmp") == 0);
        puts("PASS: marker storage failure is rejected before committing a restoration");
        receipt = maple_startup_policy_withdraw(host, true);
        assert(receipt.result == MAPLE_POLICY_DONE && receipt.execmem_allowed == 0);
        assert(maple_startup_policy_restored() && maple_startup_policy_prepare(host));
        assert(execmem_allowed() == 0);
        puts("PASS: full restore uses the pre-host snapshot and server preparation never regrants it");
        int held = window_lock(true); assert(held >= 0);
        assert(maple_startup_policy_restored()); close(held);
        maple_startup_policy_init();
        assert(maple_startup_policy_restored() && maple_startup_policy_snapshot(host));
        assert(maple_startup_policy_prepare(host) && execmem_allowed() == 0);
        puts("PASS: same-boot host restart preserves full restoration and its original backup");
        put(MAPLE_OFFLINE_ROOT "/boot", "next-boot\n", 0600);
        assert(!maple_startup_policy_restored());
        maple_startup_policy_init();
        put(MAPLE_STARTUP_RUNTIME "/startup.state", "boot=next-boot\nmodules=ready\n", 0600);
        assert(maple_startup_policy_withdraw(host, true).result == MAPLE_POLICY_NO_BACKUP);
        assert(!maple_startup_policy_snapshot(host));
        puts("PASS: a cross-boot backup and a late already-modified policy are never adopted");
        unlink(MAPLE_STARTUP_RUNTIME "/startup-policy");
        put(MAPLE_OFFLINE_ROOT "/fail", "1", 0600);
        assert(!maple_startup_policy_snapshot(host));
        unlink(MAPLE_OFFLINE_ROOT "/fail");
        assert(maple_startup_policy_snapshot(host));
        maple_startup_policy_init();
        put(MAPLE_OFFLINE_ROOT "/permission", "1", 0600);
        put(MAPLE_OFFLINE_ROOT "/fail", "1", 0600);
        assert(maple_startup_policy_withdraw(host, true).result == MAPLE_POLICY_FAILED);
        assert(!maple_startup_policy_restored() && execmem_allowed() == 1);
        unlink(MAPLE_OFFLINE_ROOT "/fail");
        puts("PASS: snapshot and restore tool failures never report a verified restoration");
        put(MAPLE_STARTUP_MODULES "/dynamic_module/remove", "", 0600);
        receipt = maple_startup_policy_withdraw(host, false);
        assert(receipt.result == MAPLE_POLICY_DONE && receipt.execmem_allowed == 0);
        put(MAPLE_OFFLINE_ROOT "/permission", "1", 0600);
        receipt = maple_startup_policy_withdraw(host, false);
        assert(receipt.result == MAPLE_POLICY_FAILED);
        puts("PASS: temporary collection verifies live access instead of trusting a closed marker");
        return 0;
    }

    fresh(0);
    maple_startup_policy_finish(host, false);
    assert(execmem_allowed() == 1 && !load().closed);
    finish_ready();
    if (!load().closed || execmem_allowed() != 0) {
        puts("FAIL: no Ultra modules were installed, but the host retained system_server execmem");
        return 1;
    }
    puts("PASS: empty Ultra module set releases its startup grant as soon as scripts finish");
    maple_startup_policy_init();
    assert(load().original == 0);
    assert(window_apply(host, true, NULL, 0));
    finish_ready();
    assert(load().closed && execmem_allowed() == 0);
    puts("PASS: same-boot host restart preserves ownership and releases the reopened grant");
    fresh(1); maple_startup_policy_finish(host, true);
    assert(execmem_allowed() == 1 && !load().closed);
    fresh(-1); maple_startup_policy_finish(host, true);
    assert(execmem_allowed() == 1 && !load().closed);
    puts("PASS: preexisting and unknown baseline permissions are preserved");

    fresh(0);
    assert(rename(MAPLE_STARTUP_MODULES, MAPLE_OFFLINE_ROOT "/modules-held") == 0);
    maple_startup_policy_finish(host, true);
    assert(execmem_allowed() == 1 && !load().closed);
    assert(rename(MAPLE_OFFLINE_ROOT "/modules-held", MAPLE_STARTUP_MODULES) == 0);
    puts("PASS: failed module discovery is not interpreted as an empty installation");
    fresh(0); put(MAPLE_OFFLINE_ROOT "/fail", "1", 0600);
    finish_ready();
    assert(execmem_allowed() == 1 && !load().closed);
    unlink(MAPLE_OFFLINE_ROOT "/fail");
    puts("PASS: failed policy transaction does not report a release");

    module("dynamic_module"); fresh(0); maple_startup_policy_finish(host, true);
    assert(load().retained && execmem_allowed() == 1);
    put(MAPLE_STARTUP_MODULES "/dynamic_module/remove", "", 0600);
    fresh(0); finish_ready();
    assert(load().closed && execmem_allowed() == 0);
    puts("PASS: unknown active modules retain permissions; pending removal stays untouched");

    module("hma_oss_zygisk"); fresh(0); maple_startup_policy_finish(host, true);
    assert(!load().closed && execmem_allowed() == 1);
    assert(mkdir(MAPLE_STARTUP_MISC "/hide_my_applist_fixture", 0700) == 0);
    put(MAPLE_STARTUP_MISC "/hide_my_applist_fixture/status.json", "{\"workMode\":1}", 0600);
    maple_startup_policy_finish(host, true);
    struct startup_window state = load(); assert(state.ready_since > 0);
    assert(load().closed && execmem_allowed() == 0);
    assert(maple_startup_policy_prepare(host));
    assert(!load().closed && execmem_allowed() == 1);
    puts("PASS: HMA initialization closes its owned window and a new system_server reopens it");
    module("zygisk_lsposed"); fresh(0); maple_startup_policy_finish(host, true);
    assert(load().retained && execmem_allowed() == 1);
    puts("PASS: LSPosed with unknown framework scope retains its dynamic-hook permissions");
    return 0;
}

"""Compile/run the production policy lifecycle in an isolated Linux fixture."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--save", type=Path)
    parser.add_argument("--case", choices=["empty-prepare", "hma-ready", "actions"])
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="maplesu-startup-test-") as temporary:
        out = Path(temporary)
        commands = [
            "cc -std=gnu2x -D_GNU_SOURCE -Wall -Wextra -Werror -Wno-format-truncation -UNDEBUG "
            "-fsanitize=address,undefined -fno-omit-frame-pointer -I/output "
            "/source/zygisk/tests/startup_policy_offline.c /source/zygisk/native/module_scan.c "
            "-Wl,--wrap=fopen -Wl,--wrap=open -ldl -o /output/probe",
            "/output/probe" + (" " + args.case if args.case else ""),
        ]
        result = subprocess.run([
            "docker", "run", "--rm", "--pull", "never", "--network", "none",
            "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
            "--mount", f"type=bind,source={ROOT},target=/source,readonly",
            "--mount", f"type=bind,source={out},target=/output",
            "ghcr.io/ylarod/ddk-min:android15-6.6-20260828", "sh", "-c", " && ".join(commands),
        ], capture_output=True, text=True, timeout=60)
        sources = ["zygisk/native/startup_policy.c", "zygisk/native/module_scan.c",
                   "zygisk/native/module_scope.h", "zygisk/tests/startup_policy_offline.c"]
        receipt = {"deviceAccess": False, "exitCode": result.returncode,
                   "sourceSha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                                    for name in sources},
                   "stdout": result.stdout, "stderr": result.stderr}
        if args.save:
            args.save.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(receipt, indent=2))
        assert result.returncode == 0


if __name__ == "__main__":
    main()

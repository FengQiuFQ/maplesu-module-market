// Exercise the real state file, locks, module scan and enforcing policy tool.
// Only the policy bit already covered by the HMA experiment is changed; restored on exit.
#define MAPLE_LSPOSED_CONFIG "/data/local/tmp/maplesu-startup-policy-fixture/lsp-scope.db"
#define MAPLE_STARTUP_RUNTIME "/data/local/tmp/maplesu-startup-policy-fixture/runtime"
#define MAPLE_STARTUP_MODULES "/data/local/tmp/maplesu-startup-policy-fixture/modules"
#define MAPLE_STARTUP_REVISIONS "/data/local/tmp/maplesu-startup-policy-fixture/revisions"
#define MAPLE_STARTUP_MISC "/data/local/tmp/maplesu-startup-policy-fixture/misc"
#include "../native/startup_policy.c"
#include <assert.h>

static const char *host;
static int initial;
static const char *status_file = MAPLE_STARTUP_MISC "/hide_my_applist_fixture/status.json";

static void put(const char *path, const char *text, mode_t mode) {
    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, mode);
    assert(fd >= 0 && write(fd, text, strlen(text)) == (ssize_t)strlen(text));
    close(fd);
}
static struct startup_window load(void) {
    int fd = window_lock(true);
    struct startup_window state;
    assert(fd >= 0 && window_read(fd, &state));
    close(fd);
    return state;
}
static void save(struct startup_window state) {
    int fd = window_lock(true);
    assert(fd >= 0 && window_save(fd, &state));
    close(fd);
}
static void restore(void) {
    assert(window_apply(host, initial, NULL, 0));
}
static void fresh(int baseline) {
    assert(window_apply(host, baseline, NULL, 0));
    unlink(MAPLE_STARTUP_RUNTIME "/startup-policy");
    maple_startup_policy_init();
    assert(load().original == baseline);
    assert(window_apply(host, true, NULL, 0));
    assert(maple_startup_policy_prepare(host));
}
static void ready(void) {
    usleep(10000);
    put(status_file, "{\"workMode\":1,\"managerUid\":10476}", 0600);
    maple_startup_policy_finish(host, true);
    struct startup_window state = load();
    assert(state.ready_since > 0);
    state.ready_since -= 10001;
    save(state);
}
static void module(const char *name) {
    char path[4096], text[1024];
    snprintf(path, sizeof(path), MAPLE_STARTUP_REVISIONS "/%s", name); assert(mkdir(path, 0700) == 0);
    snprintf(text, sizeof(text), MAPLE_STARTUP_MODULES "/%s", name); assert(symlink(path, text) == 0);
    snprintf(path, sizeof(path), MAPLE_STARTUP_MODULES "/%s/zygisk", name); assert(mkdir(path, 0700) == 0);
    snprintf(path, sizeof(path), MAPLE_STARTUP_MODULES "/%s/zygisk/arm64-v8a.so", name); put(path, "fixture", 0600);
    snprintf(path, sizeof(path), MAPLE_STARTUP_MODULES "/%s/module.prop", name);
    snprintf(text, sizeof(text), "id=%s\n", name); put(path, text, 0600);
    snprintf(path, sizeof(path), MAPLE_STARTUP_MODULES "/%s/.maplesu-ultra", name);
    put(path, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n", 0600);
}

int main(int argc, char **argv) {
    assert(argc == 2);
    host = argv[1];
    setbuf(stdout, NULL);
    initial = execmem_allowed();
    assert(initial >= 0);
    printf("INITIAL_EXECMEM=%d\n", initial);
    assert(atexit(restore) == 0);
    assert(mkdir(MAPLE_STARTUP_RUNTIME, 0700) == 0);
    assert(mkdir(MAPLE_STARTUP_MODULES, 0700) == 0);
    assert(mkdir(MAPLE_STARTUP_REVISIONS, 0700) == 0);
    assert(mkdir(MAPLE_STARTUP_MISC, 0700) == 0);
    assert(mkdir(MAPLE_STARTUP_MISC "/hide_my_applist_fixture", 0700) == 0);
    module("hma_oss_zygisk");

    fresh(0);
    maple_startup_policy_init(); // Same-boot host restart must retain ownership.
    assert(load().original == 0);
    put(status_file, "{\"workMode\":1}", 0600);
    maple_startup_policy_finish(host, false);
    assert(!load().ready_since && execmem_allowed() == 1);
    puts("PASS: early scripts remain asynchronous; same-boot ownership preserved");

    put(status_file, "{\"workMode\":4}", 0600);
    maple_startup_policy_finish(host, true);
    assert(!load().ready_since && execmem_allowed() == 1);
    ready();
    maple_startup_policy_finish(host, true);
    assert(load().closed && execmem_allowed() == 0);
    puts("PASS: HMA failure retains permission; initialized HMA closes the window");

    usleep(10000);
    assert(maple_startup_policy_prepare(host));
    assert(!load().closed && execmem_allowed() == 1);
    maple_startup_policy_finish(host, true);
    assert(!load().ready_since); // Previous server's OK file is stale.
    ready();
    maple_startup_policy_finish(host, true);
    assert(load().closed && execmem_allowed() == 0);
    puts("PASS: prepare restores permission synchronously; stale server status rejected");

    fresh(0);
    struct timespec future[2] = {{2000000000, 0}, {2000000000, 0}};
    assert(utimensat(AT_FDCWD, status_file, future, 0) == 0);
    assert(maple_startup_policy_prepare(host));
    maple_startup_policy_finish(host, true);
    assert(!load().ready_since && execmem_allowed() == 1);
    ready(); // Its new mtime is earlier than the old file's future timestamp.
    maple_startup_policy_finish(host, true);
    assert(load().closed && execmem_allowed() == 0);
    puts("PASS: boot clock correction cannot make an old status look newly initialized");

    fresh(1);
    put(status_file, "{\"workMode\":1}", 0600);
    maple_startup_policy_finish(host, true);
    assert(!load().closed && execmem_allowed() == 1);
    puts("PASS: preexisting policy grant preserved");

    fresh(0);
    module("other_module");
    maple_startup_policy_finish(host, true);
    assert(load().retained && execmem_allowed() == 1);
    put(MAPLE_STARTUP_MODULES "/other_module/remove", "", 0600);
    puts("PASS: unknown module retains its normal dynamic-hook contract");

    void *sqlite = dlopen("libsqlite.so", RTLD_NOW | RTLD_LOCAL);
    assert(sqlite);
    int (*open_scope)(const char *, void **, int, const char *) = dlsym(sqlite, "sqlite3_open_v2");
    int (*scope_sql)(void *, const char *, void *, void *, void *) = dlsym(sqlite, "sqlite3_exec");
    int (*close_scope)(void *) = dlsym(sqlite, "sqlite3_close");
    assert(open_scope && scope_sql && close_scope);
    void *scope_db = NULL;
    assert(lsposed_dynamic_server_hooks()); // Missing/unknown config retains the grant.
    assert(open_scope(MAPLE_LSPOSED_CONFIG, &scope_db, 6, NULL) == 0);
    assert(scope_sql(scope_db, "CREATE TABLE scope(module_pkg_name,app_pkg_name,user_id);"
        "CREATE TABLE modules_state(module_pkg_name,user_id,enabled);", NULL, NULL, NULL) == 0);
    assert(!lsposed_dynamic_server_hooks());
    module("zygisk_lsposed");
    fresh(0); ready(); maple_startup_policy_finish(host, true);
    assert(load().closed && execmem_allowed() == 0);
    puts("PASS: initialized HMA plus LSPosed with no Android-scoped module releases only the startup grant");
    assert(scope_sql(scope_db, "INSERT INTO scope VALUES('fixture','android',0);"
        "INSERT INTO modules_state VALUES('fixture',0,1);", NULL, NULL, NULL) == 0);
    assert(lsposed_dynamic_server_hooks());
    fresh(0); maple_startup_policy_finish(host, true);
    assert(load().retained && execmem_allowed() == 1);
    assert(scope_sql(scope_db, "UPDATE modules_state SET enabled=0;", NULL, NULL, NULL) == 0);
    assert(!lsposed_dynamic_server_hooks());
    assert(scope_sql(scope_db, "UPDATE modules_state SET enabled=1;"
        "UPDATE scope SET app_pkg_name='com.android.providers.media.module';", NULL, NULL, NULL) == 0);
    assert(!lsposed_dynamic_server_hooks());
    assert(close_scope(scope_db) == 0);
    unlink(MAPLE_LSPOSED_CONFIG); dlclose(sqlite);
    put(MAPLE_STARTUP_MODULES "/zygisk_lsposed/remove", "", 0600);
    puts("PASS: enabled Android scope retains dynamic hooks; disabled and application scopes do not reserve server permissions");

    fresh(0);
    put(MAPLE_STARTUP_MODULES "/hma_oss_zygisk/sepolicy.rule",
        "allow { system_server } { system_server } : process { execmem }\n", 0600);
    ready();
    maple_startup_policy_finish(host, true);
    assert(load().retained && !load().closed && execmem_allowed() == 1);
    unlink(MAPLE_STARTUP_MODULES "/hma_oss_zygisk/sepolicy.rule");
    puts("PASS: declared module policy overrides host withdrawal, including grouped syntax");

    fresh(0);
    struct startup_window state = load();
    state.started -= 180001; save(state);
    maple_startup_policy_finish(host, false);
    assert(load().retained && execmem_allowed() == 1);
    puts("PASS: initialization deadline keeps the compatible grant");

    char tool[4096], actual[4096], wrapper[8192];
    snprintf(tool, sizeof(tool), "%s/bin/maplesu-policy", host);
    snprintf(actual, sizeof(actual), "%s/bin/actual-policy", host);
    fresh(0);
    ready();
    assert(rename(tool, actual) == 0);
    put(tool, "#!/system/bin/sh\nexit 17\n", 0700);
    maple_startup_policy_finish(host, true);
    assert(load().retained && execmem_allowed() == 1);
    assert(unlink(tool) == 0 && rename(actual, tool) == 0);
    puts("PASS: transaction failure retains working permissions");

    fresh(0);
    ready();
    assert(rename(tool, actual) == 0);
    snprintf(wrapper, sizeof(wrapper), "#!/system/bin/sh\ntouch " MAPLE_STARTUP_RUNTIME "/inflight\nsleep 0.2\nexec '%s' \"$@\"\n", actual);
    put(tool, wrapper, 0700);
    pid_t child = fork();
    assert(child >= 0);
    if (!child) { maple_startup_policy_finish(host, true); _exit(0); }
    int64_t until = window_millis() + 2000;
    while (access(MAPLE_STARTUP_RUNTIME "/inflight", F_OK) != 0 && window_millis() < until) usleep(10000);
    assert(access(MAPLE_STARTUP_RUNTIME "/inflight", F_OK) == 0);
    assert(maple_startup_policy_prepare(host));
    int status;
    assert(waitpid(child, &status, 0) == child && WIFEXITED(status) && WEXITSTATUS(status) == 0);
    assert(!load().closed && execmem_allowed() == 1);
    assert(unlink(tool) == 0 && rename(actual, tool) == 0);
    puts("PASS: concurrent close/prepare serializes; new server always gets the startup grant");
    puts("PASS: startup policy lifecycle complete; initial permission restored on exit");
    return 0;
}

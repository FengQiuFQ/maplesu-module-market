// Exercise the production preparation RPC against real Unix socket peers.
#include <assert.h>
#include <errno.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include "daemon.h"

static struct sockaddr_un address;
static void interrupt_poll(int signal_number) { (void)signal_number; }
int __real_connect(int, const struct sockaddr *, socklen_t);
int __real_setsockopt(int, int, int, const void *, socklen_t);
int __wrap_connect(int fd, const struct sockaddr *ignored, socklen_t size) {
    return __real_connect(fd, (const struct sockaddr *)&address, sizeof(address));
}
int __wrap_setsockopt(int fd, int level, int option, const void *value, socklen_t size) {
    // Shorten the previous implementation's socket timeout, preserving its retry loop.
    struct timeval timeout = {.tv_usec = 100000};
    if (level == SOL_SOCKET && (option == SO_RCVTIMEO || option == SO_SNDTIMEO)) {
        value = &timeout; size = sizeof(timeout);
    }
    return __real_setsockopt(fd, level, option, value, size);
}
static int64_t millis(void) {
    struct timespec now;
    assert(clock_gettime(CLOCK_MONOTONIC, &now) == 0);
    return now.tv_sec * 1000LL + now.tv_nsec / 1000000;
}
static int listener(void) {
    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    assert(fd >= 0);
    memset(&address, 0, sizeof(address));
    address.sun_family = AF_UNIX;
    snprintf(address.sun_path + 1, sizeof(address.sun_path) - 1, "maplesu-startup-rpc-%d", getpid());
    assert(bind(fd, (const struct sockaddr *)&address, sizeof(address)) == 0);
    assert(listen(fd, 1) == 0);
    return fd;
}
static void reply_case(uint8_t reply, unsigned delay, bool expected) {
    int server = listener();
    pid_t child = fork();
    assert(child >= 0);
    if (!child) {
        signal(SIGPIPE, SIG_IGN);
        int client = accept(server, NULL, NULL);
        uint8_t action = 0;
        assert(client >= 0 && read(client, &action, 1) == 1 && action == 9);
        usleep(delay * 1000);
        write(client, &reply, 1);
        close(client); close(server); _exit(0);
    }
    int64_t started = millis();
    bool result = rezygiskd_prepare_system_server();
    int64_t elapsed = millis() - started;
    kill(child, SIGTERM);
    int status;
    assert(waitpid(child, &status, 0) == child);
    close(server);
    printf("reply=%u delay=%u elapsed=%lld result=%d\n", reply, delay, (long long)elapsed, result);
    if (result != expected || elapsed >= 400) {
        fprintf(stderr, "FAIL: preparation exceeded its deadline or accepted a late acknowledgement\n");
        exit(1);
    }
}
int main(void) {
    setbuf(stdout, NULL);
    reply_case(1, 0, true);
    reply_case(0, 0, false);
    struct sigaction action = {.sa_handler = interrupt_poll};
    sigemptyset(&action.sa_mask);
    assert(sigaction(SIGALRM, &action, NULL) == 0);
    struct itimerval timer = {.it_interval = {.tv_usec = 5000}, .it_value = {.tv_usec = 5000}};
    assert(setitimer(ITIMER_REAL, &timer, NULL) == 0);
    reply_case(1, 50, true);
    reply_case(1, 700, false);
    timer = (struct itimerval){0};
    assert(setitimer(ITIMER_REAL, &timer, NULL) == 0);
    puts("PASS: silent daemon respects the preparation deadline");
    int server = listener();
    int pending[2];
    for (int i = 0; i < 2; ++i) {
        pending[i] = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
        assert(pending[i] >= 0 && __real_connect(pending[i], (const struct sockaddr *)&address, sizeof(address)) == 0);
    }
    pid_t child = fork();
    assert(child >= 0);
    if (!child) _exit(rezygiskd_prepare_system_server() ? 1 : 0);
    int status = 0;
    int64_t until = millis() + 400;
    pid_t result;
    do { result = waitpid(child, &status, WNOHANG); if (result) break; usleep(1000); } while (millis() < until);
    if (!result) { kill(child, SIGKILL); assert(waitpid(child, &status, 0) == child); }
    for (int i = 0; i < 2; ++i) close(pending[i]);
    close(server);
    if (result != child || !WIFEXITED(status) || WEXITSTATUS(status) != 0) {
        fprintf(stderr, "FAIL: preparation blocked on the daemon backlog\n");
        return 1;
    }
    puts("PASS: saturated daemon backlog never blocks system_server fork");
    assert(!rezygiskd_prepare_system_server());
    puts("PASS: missing daemon returns promptly");
    return 0;
}

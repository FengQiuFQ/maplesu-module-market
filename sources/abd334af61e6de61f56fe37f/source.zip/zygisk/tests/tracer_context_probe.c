// SPDX-License-Identifier: AGPL-3.0-or-later
// Own child only. Stop at kernel exec event and kill BEFORE HAL/linker code runs.
#define _GNU_SOURCE
#include <stdbool.h>
#include "tracer_context.h"
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <unistd.h>
static pid_t child;
static void timeout_handler(int sig) {
    if (child > 0) kill(child, SIGKILL);
    _exit(124);
}
static int context(const char *attr, const char *value) {
    char path[96];
    snprintf(path, sizeof(path), "/proc/self/attr/%s", attr);
    int fd = open(path, O_WRONLY | O_CLOEXEC);
    if (fd < 0) return -1;
    int result = write(fd, value, strlen(value));
    int saved = errno;
    close(fd);
    errno = saved;
    return result >= 0 ? 0 : -1;
}
int main(int argc, char **argv) {
    if (argc != 2) return 2;
    setbuf(stdout, NULL);
    if (strcmp(argv[1], "fixed") == 0) {
        if (!maple_tracer_context()) return 2;
        execl(argv[0], argv[0], "u:r:init:s0", NULL);
        return 2;
    }
    signal(SIGCHLD, SIG_DFL);
    signal(SIGALRM, timeout_handler);
    alarm(5);
    volatile int *result = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    int gate[2];
    if (result == MAP_FAILED || pipe(gate)) return 2;
    child = fork();
    if (child < 0) return 2;
    if (!child) {
        prctl(PR_SET_PDEATHSIG, SIGKILL);
        close(gate[1]);
        char c;
        if (read(gate[0], &c, 1) != 1) _exit(2);
        close(gate[0]);
        result[0] = 1;
        if (context("current", "u:r:init:s0")) {result[1] = errno; _exit(2);}
        if (context("exec", "u:r:hal_ir_default:s0")) {result[1] = errno; _exit(2);}
        result[0] = 2;
        if (setresgid(1000, 1000, 1000) || setresuid(1000, 1000, 1000)) {result[1] = errno; _exit(2);}
        result[0] = 3;
        execl("/odm/bin/hw/android.hardware.ir-service", "android.hardware.ir-service", NULL);
        result[1] = errno;
        result[0] = 4;
        _exit(127);
    }
    close(gate[0]);
    if (context("current", argv[1]) || ptrace(PTRACE_SEIZE, child, 0, PTRACE_O_TRACEEXEC)) {
        printf("SETUP_FAILED errno=%d\n", errno);
        kill(child, SIGKILL); waitpid(child, NULL, 0);
        return 2;
    }
    printf("TRACER_CONTEXT=%s NoNewPrivs=%d\n", argv[1], prctl(PR_GET_NO_NEW_PRIVS, 0, 0, 0, 0));
    write(gate[1], "1", 1); close(gate[1]);
    int status;
    while (waitpid(child, &status, __WALL) == child) {
        if (!WIFSTOPPED(status)) {
            printf("EXEC_FAILED status=%#x stage=%d errno=%d (%s)\n", status, result[0], result[1], strerror(result[1]));
            child = 0; return 1;
        }
        if ((unsigned)status >> 16 == PTRACE_EVENT_EXEC) {
            kill(child, SIGKILL);
            while (waitpid(child, &status, __WALL) == child && WIFSTOPPED(status)) ptrace(PTRACE_CONT, child, 0, SIGKILL);
            child = 0;
            puts("PASS: kernel exec transition reached; child killed before userspace HAL code");
            return 0;
        }
        ptrace(PTRACE_CONT, child, 0, 0);
    }
    return 2;
}

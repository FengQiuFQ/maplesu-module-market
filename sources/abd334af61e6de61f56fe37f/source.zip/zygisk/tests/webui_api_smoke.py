"""Run production API/monitor serializers against shell-owned device fixtures only."""
from pathlib import Path
import argparse
import json
import shlex
import shutil
import subprocess
import tarfile
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / "evidence/zygisk-5.1.0-finalize-20261106"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--serial", required=True)
    parser.add_argument("--adb", default=shutil.which("adb") or "adb")
    args = parser.parse_args()
    adb = [args.adb, "-s", args.serial]
    remote = "/data/local/tmp/maplesu-zygisk-webui-20261104"
    results, snapshots = [], {}

    def shell(command, ok=True):
        r = subprocess.run([*adb, "shell", command], capture_output=True, text=True, encoding="utf-8", timeout=20)
        if ok and r.returncode:
            raise RuntimeError(r.stdout + r.stderr)
        return r

    def push(source, target):
        subprocess.run([*adb, "push", str(source), target], check=True, capture_output=True, timeout=30)

    def api(method, path, live=None, expected=200):
        cmd = f"{remote}/api {remote}/fixture {method} {path}" + (" " + live if live else "")
        result = json.loads(shell(cmd).stdout)
        assert result["httpStatus"] == expected, result
        return result["body"]

    def record(name, value=True):
        assert value, name
        results.append({"case": name, "passed": True})

    with tempfile.TemporaryDirectory(prefix="maplesu-webui-api-") as temp:
        folder = Path(temp)
        fixture = folder / "fixture"
        for path in ("host/data", "host/payload", "host/webroot", "runtime", "modules", "revisions", "json"):
            (fixture / path).mkdir(parents=True)
        (fixture / "host/payload/module.prop").write_bytes((ROOT / "zygisk/module/module.prop").read_bytes())
        (fixture / "host/webroot/source.zip").write_bytes(b"PK-source-copy-fixture")
        state = {"root": "MapleSU Ultra", "monitor": {"state": "0"}, "rezygiskd": {"64": {"state": 1, "modules": ["hma_oss", "disabled", "linked"]}}, "zygote": {"64": 1}}
        (fixture / "runtime/state.json").write_text(json.dumps(state), encoding="utf-8")

        def module(id, marker=None, abis=("arm64-v8a",), actual=None):
            d = fixture / "revisions" / id
            (d / "zygisk").mkdir(parents=True)
            (d / "module.prop").write_text(f'id={actual or id}\r\nname=Name <img src=x onerror=alert(1)> "{id}"\r\nversion=1.2\r\nauthor=Maple & Team\r\n', encoding="utf-8", newline="\n")
            for abi in abis:
                (d / "zygisk" / (abi + ".so")).write_bytes(b"fixture-not-ELF")
            if marker:
                (d / marker).touch()
        module("hma_oss")
        module("disabled", "disable")
        module("removed", "remove")
        module("update", "update", ("arm64-v8a", "armeabi-v7a"))
        module("only32", abis=("armeabi-v7a",))
        module(".hidden")
        module("maplesu_zygisk")
        module("wrong", actual="mismatch")
        module("stale.maplesu-123", actual="stale")
        module("bad!id")
        module("x86", abis=("x86",))
        # The real scanner must follow the published revision link, but not dead links.
        revision = fixture / "revisions/linked"
        (revision / "zygisk").mkdir(parents=True)
        (revision / "module.prop").write_text("id=linked\nname=Linked module\nversion=2\nauthor=MapleSU\n")
        (revision / "zygisk/arm64-v8a.so").touch()
        archive = folder / "fixture.tar"
        with tarfile.open(archive, "w") as tar:
            tar.add(fixture, arcname="fixture")
        EVIDENCE.mkdir(parents=True, exist_ok=True)
        try:
            shell(f"mkdir -p {remote}")
            push(archive, remote + "/fixture.tar")
            push(ROOT / "zygisk/build/arm64-v8a/maplesu-zygisk-webui-probe", remote + "/api")
            push(ROOT / "zygisk/build/arm64-v8a/maplesu-zygisk-json-probe", remote + "/json-probe")
            shell(f"cd {remote} && tar -xf fixture.tar && chmod 700 api json-probe && for d in fixture/revisions/*; do ln -s ../revisions/$(basename \"$d\") fixture/modules/$(basename \"$d\"); done && ln -s ../missing fixture/modules/dangling")
            listing = api("GET", "/api/modules")
            snapshots["modules"] = listing
            mods = {m["id"]: m for m in listing["modules"]}
            assert list(mods) == ["disabled", "hma_oss", "linked", "only32", "removed", "update"], listing
            record("metadata-valid-ids-abi-and-revision-symlinks", list(mods) == ["disabled", "hma_oss", "linked", "only32", "removed", "update"])
            record("disabled-and-pending-removal-visible", not mods["disabled"]["enabled"] and mods["removed"]["removed"])
            record("dual-abi-update-and-escaped-metadata", mods["update"]["abis"] == ["64", "32"] and mods["update"]["update"] and '<img' in mods["hma_oss"]["name"])
            running = api("GET", "/api/status", "tracing")
            snapshots["running"] = running
            record("live-monitor-tracer-and-version", running["running"] and running["monitorAlive"] and running["version"] == "5.1.0" and running["api"] == 5)
            record("actual-system-abis", running["supportedAbis"] == [abi for abi, prop in (("64", "ro.product.cpu.abilist64"), ("32", "ro.product.cpu.abilist32")) if shell("getprop " + prop).stdout.strip()])
            paused = api("GET", "/api/status", "paused")
            record("monitor-without-tracer-not-running", not paused["running"] and paused["monitorAlive"])
            shell(f"echo 2147483647 > {remote}/fixture/runtime/monitor.pid")
            stale = api("GET", "/api/status")
            snapshots["waiting"] = stale
            record("stale-runtime-not-reported", not stale["running"] and not stale["monitorAlive"] and stale["state"] is None)
            exported = api("POST", "/api/export")
            saved = json.loads(shell(f"cat {remote}/fixture/exports/MapleSU-Zygisk-diagnostic.json").stdout)
            record("diagnostic-export-actually-written", exported["ok"] and saved["product"] == "MapleSU Zygisk" and len(saved["catalog"]["modules"]) == 6)
            source = api("POST", "/api/export-source")
            record("source-export-byte-copy", source["ok"] and shell(f"cat {remote}/fixture/exports/MapleSU-Zygisk-source.zip").stdout == "PK-source-copy-fixture")
            shell(f"mkdir {remote}/fixture/exports/MapleSU-Zygisk-diagnostic.json.tmp")
            record("export-write-error-no-success-receipt", api("POST", "/api/export", expected=500)["error"] == "export_failed")
            shell(f"rmdir {remote}/fixture/exports/MapleSU-Zygisk-diagnostic.json.tmp")
            for enable in (False, False, True, True):
                reply = api("POST", "/api/enable" if enable else "/api/disable")
                status = api("GET", "/api/status")
                record("toggle-idempotent-" + str(enable), reply["ok"] and reply["enabled"] is enable and reply["rebootRequired"] and status["enabled"] is enable)
                present = shell(f"test -e {remote}/fixture/host/disable && test -e {remote}/fixture/host/data/disabled", ok=False).returncode == 0
                assert present is not enable
                if not enable:
                    snapshots["disabled"] = status
            shell(f"mkdir {remote}/fixture/host/disable")
            failed = api("POST", "/api/disable", expected=500)
            record("partial-write-rollback", not failed["ok"] and shell(f"test ! -e {remote}/fixture/host/data/disabled").returncode == 0)
            shell(f"rmdir {remote}/fixture/host/disable && touch {remote}/fixture/host/remove")
            removed = api("POST", "/api/enable", expected=409)
            record("pending-removal-not-falsely-enabled", removed["error"] == "pending_removal" and not api("GET", "/api/status")["enabled"])
            shell(f"mv {remote}/fixture/modules {remote}/fixture/modules.saved")
            record("module-read-error-is-explicit", api("GET", "/api/modules", expected=500)["error"] == "modules_unreadable")
            shell(f"mv {remote}/fixture/modules.saved {remote}/fixture/modules")
            record("unknown-api-and-wrong-method", api("GET", "/api/disable", expected=404)["error"] == "not_found")
            for mode in ("running", "stopped", "dual"):
                shell(f"{remote}/json-probe {remote}/fixture/json {mode}")
                serialized = json.loads(shell(f"cat {remote}/fixture/json/state.json").stdout)
                record("monitor-json-escaping-" + mode, serialized["root"] == 'MapleSU Ultra"\\\n' and serialized["rezygiskd"]["64"]["modules"][1] == 'quotes"\\\t\n')
                if mode == "stopped":
                    assert serialized["monitor"]["state"] == "2" and serialized["monitor"]["reason"] == 'stopped"\\\n'
                if mode == "dual":
                    assert serialized["rezygiskd"]["32"]["reason"] == '32bit"\\\n'
                record("atomic-state-no-temporary-" + mode, shell(f"test ! -e {remote}/fixture/json/state.json.tmp").returncode == 0)
            shell(f"rm {remote}/fixture/json/state.json && mkdir {remote}/fixture/json/state.json")
            failed = shell(f"{remote}/json-probe {remote}/fixture/json running", ok=False)
            record("atomic-publish-failure-cleans-temporary", failed.returncode != 0 and shell(f"test ! -e {remote}/fixture/json/state.json.tmp").returncode == 0)
        finally:
            # Exact task-owned path only. No host install, policy change, injection or reboot.
            shell(f"rm -rf {shlex.quote(remote)}")
    with zipfile.ZipFile(ROOT / "dist-release/MapleSU-Zygisk-5.1.0-Ultra.zip") as package:
        (EVIDENCE / "source-download.zip").write_bytes(package.read("webroot/source.zip"))
    (EVIDENCE / "api-fixtures.json").write_text(json.dumps(snapshots, ensure_ascii=False, indent=2), encoding="utf-8")
    (EVIDENCE / "api-tests.json").write_text(json.dumps({"passed": True, "device": args.serial, "scope": "isolated shell-owned API and serializer processes; no SDK host started", "tests": results}, indent=2), encoding="utf-8")
    print(f"WEBUI_NATIVE_API_OK {len(results)} checks")


if __name__ == "__main__":
    main()

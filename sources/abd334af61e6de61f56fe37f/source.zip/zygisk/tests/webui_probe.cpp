// Isolated API fixture, never starts the SDK host or traces another process.
#include "webui.hpp"
#include <iostream>
int main(int argc, char **argv) {
    if (argc < 4) return 2;
    std::string root(argv[1]);
    if (argc > 4) {
        std::ofstream(root + "/runtime/monitor.pid") << getpid();
        std::ofstream(root + "/init.status") << "Name:\tfixture\nTracerPid:\t" << (std::string(argv[4]) == "tracing" ? getpid() : 0) << '\n';
    }
    maple::webui::Api api(root + "/host", {}, root + "/runtime", root + "/modules", root + "/init.status", root + "/exports", root + "/revisions", root + "/system");
    auto reply = api.dispatch(argv[2], argv[3]);
    std::cout << "{\"httpStatus\":" << reply.status << ",\"body\":" << reply.body << "}\n";
}

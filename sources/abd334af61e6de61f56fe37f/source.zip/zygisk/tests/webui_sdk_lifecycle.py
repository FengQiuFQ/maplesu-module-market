"""Verify one real SDK server survives its signed creator finishing.

Input is the saved `run_probe.py webui_soak` instrumentation receipt. This check
does not open another server, invoke Root, enable a module, or reboot the device.
"""
import argparse
import json
from pathlib import Path
import subprocess
import time
import urllib.request


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--serial", required=True)
    parser.add_argument("--adb", default="D:/platform-tools/adb.exe")
    parser.add_argument("--receipt", required=True, type=Path)
    parser.add_argument("--save", required=True, type=Path)
    args = parser.parse_args()
    fields = {}
    for line in args.receipt.read_text(encoding="utf-8").splitlines():
        if line.startswith("INSTRUMENTATION_RESULT: "):
            key, value = line.split(": ", 1)[1].split("=", 1)
            fields[key] = value
    samples = json.loads(fields["samples"])
    port = json.loads(fields["data"])["port"]
    creator = samples[0]["callerPid"]
    adb = [args.adb, "-s", args.serial]

    def shell(command):
        return subprocess.run([*adb, "shell", command], check=True,
                              capture_output=True, text=True, timeout=10).stdout.strip()

    alive = shell(f"if [ -d /proc/{creator} ]; then echo alive; else echo exited; fi")
    result = {"creatorPid": creator, "creatorState": alive,
              "bootId": shell("cat /proc/sys/kernel/random/boot_id"),
              "duringCreatorPassed": fields.get("soakPassed") == "true" and len(samples) == 16,
              "duringCreatorSamples": samples, "afterCreator": []}
    forwarded = subprocess.run([*adb, "forward", "tcp:0", f"tcp:{port}"],
                               check=True, capture_output=True, text=True, timeout=10).stdout.strip()
    try:
        for _ in range(3):
            row = {}
            for endpoint in ("status", "modules"):
                start = time.monotonic()
                try:
                    with urllib.request.urlopen(f"http://127.0.0.1:{forwarded}/api/{endpoint}", timeout=2) as response:
                        body = json.load(response)
                        assert response.status == 200
                        assert isinstance(body, dict)
                        assert (isinstance(body.get("enabled"), bool) if endpoint == "status"
                                else isinstance(body.get("modules"), list))
                        row[endpoint] = {"ok": True, "http": response.status}
                except Exception as error:
                    row[endpoint] = {"ok": False, "error": type(error).__name__}
                row[endpoint]["durationMs"] = round((time.monotonic() - start) * 1000)
            result["afterCreator"].append(row)
            time.sleep(1)
    finally:
        subprocess.run([*adb, "forward", "--remove", f"tcp:{forwarded}"],
                       capture_output=True, timeout=10)
    result["bootIdAfter"] = shell("cat /proc/sys/kernel/random/boot_id")
    result["passed"] = (result["duringCreatorPassed"] and alive == "exited" and
                        result["bootId"] == result["bootIdAfter"] and
                        all(r[e]["ok"] for r in result["afterCreator"] for e in ("status", "modules")))
    args.save.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("passed", "creatorState", "duringCreatorPassed", "afterCreator")}))
    raise SystemExit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()

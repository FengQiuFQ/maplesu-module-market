LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := module_protect_device

LOCAL_SRC_FILES := \
	../module_protect_device.cpp \
	../block_device_manager.cpp \
	../block_device_policy.cpp \
	../block_device_scanner.cpp \
	../patch_base.cpp \
	../patch_blkdev_open.cpp

KERNEL_MODULE_KIT := $(LOCAL_PATH)/../../kernel_module_kit
LOCAL_C_INCLUDES  += $(KERNEL_MODULE_KIT)/include
LOCAL_LDFLAGS  += $(KERNEL_MODULE_KIT)/lib/libkernel_module_kit_static.a

include $(LOCAL_PATH)/build_macros.mk

include $(BUILD_SHARED_LIBRARY)


